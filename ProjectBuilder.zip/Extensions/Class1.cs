﻿namespace Extensions
{
    public class Class1
    {

    }
}
