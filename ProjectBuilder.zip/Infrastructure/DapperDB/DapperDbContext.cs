﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace DapperDB
{
    public class DapperDbContext
    {
        public class DbContext(IConfiguration configuration)
        {
            private readonly IConfiguration _configuration = configuration;
            private string? _connection = configuration.GetConnectionString("DefaultConnection");

            public void UpdateConnectionString(string newConnectionString)
            {
                _connection = newConnectionString;

                // Dynamically update the configuration to store the new connection string
                // Update in-memory configuration (not the actual file, but available during runtime)
                _configuration["ConnectionStrings:NewConnectionString"] = newConnectionString;
            }

            public void SetConnection(string connectionString)
            {
                _connection = connectionString;
            }

            public IDbConnection CreateConnection() => new SqlConnection(_connection);

        }
    }
}
