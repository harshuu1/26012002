﻿using DapperDB;
using Entities.Models.AppUser;
using Interfaces;
using Interfaces.ClientBuilderInterfaces;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Repositories;
using Repositories.ClientBuilderRepositories;

namespace InfrastructureDI
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {                   
            //Dapper
            services.AddScoped<DapperDbContext.DbContext>(sp =>
            {
                return new DapperDbContext.DbContext(configuration);
            });

            services.AddScoped<IAppUser, AppUserRepository>();
            services.AddScoped<IClient, ClientRepository>();
            services.AddScoped<IProject, ProjectRepository>();
            services.AddScoped<ITokenRepository, TokenRepository>();
            services.AddScoped<IPasswordHasher<AppUserModel>, PasswordHasher<AppUserModel>>();           
            services.AddScoped<IUserInfo, UserInfo>();
            services.AddScoped<UserInfo>();
            // ClientBuilder
            services.AddScoped<IFields, FieldsRepository>();
            services.AddScoped<ITable, TableRepository>();

            return services;
        }
    }
}
