﻿using Application.Modules.Project.Queries;
using Dapper;
using Entities.Enums;
using Entities.Models.AppUser;
using Entities.Models.ClientBuilderModels.ClientModels;
using Entities.Models.Menu;
using Entities.Models.Project;
using Entities.Models.Request;
using Entities.Models.Response;
using Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.Transactions;
using static DapperDB.DapperDbContext;

namespace Repositories
{
    public class ProjectRepository(DbContext context, IConfiguration configuration,IUserInfo userInfo ) : IProject
    {
        private readonly DbContext _context = context;
        private readonly IConfiguration _configuration = configuration;
        private readonly IUserInfo _userInfo = userInfo; 
       
        public object Project => throw new NotImplementedException();

        public async Task<ProjectModel?> GetProjectById(int id)
        {
            using var connection = _context.CreateConnection();
            var project = await connection.QuerySingleOrDefaultAsync<ProjectModel>(ProjectSQLQuery.GetProjectById, new { Id = id });

            if (project != null)
            {
                var serverIpAddress = _configuration.GetValue<string>("ServerIpAddress");
                project.ClientApiLink = !string.IsNullOrWhiteSpace(project.ClientApiLink) ? $"{serverIpAddress}{project.ClientApiLink}/swagger" : project.ClientApiLink;

                project.ClientUiLink = !string.IsNullOrWhiteSpace(project.ClientUiLink)? $"{serverIpAddress}{project.ClientUiLink}": project.ClientUiLink;

                project.ConfigurationApiLink = !string.IsNullOrWhiteSpace(project.ConfigurationApiLink)
                    ? $"{serverIpAddress}{project.ConfigurationApiLink}/swagger": project.ConfigurationApiLink;

                project.ConfigurationUiLink =!string.IsNullOrWhiteSpace(project.ConfigurationUiLink) ? $"{serverIpAddress}{project.ConfigurationUiLink}" : project.ConfigurationUiLink;

                project.ClientAdminApiLink = !string.IsNullOrWhiteSpace(project.ClientAdminApiLink) ? $"{serverIpAddress}{project.ClientAdminApiLink}/swagger": project.ClientAdminApiLink;

                project.ClientAdminUiLink = !string.IsNullOrWhiteSpace(project.ClientAdminUiLink) ? $"{serverIpAddress}{project.ClientAdminUiLink}" : project.ClientAdminUiLink;

                //project.ClientApiLink = serverIpAddress + project.ClientApiLink + "swagger";
                //project.ClientUiLink = serverIpAddress + project.ClientUiLink;
                //project.ConfigurationApiLink = serverIpAddress + project.ConfigurationApiLink + "swagger";
                //project.ConfigurationUiLink = serverIpAddress + project.ConfigurationUiLink;
                //project.ClientAdminApiLink = serverIpAddress + project.ClientAdminApiLink + "swagger";
                //project.ClientAdminUiLink = serverIpAddress + project.ClientAdminUiLink;
            }

            return project;
        }

        public async Task<int?> GetAlignmentTypeById(int id)
        {
            using var connection = _context.CreateConnection();
            var alignmentType = await connection.QuerySingleOrDefaultAsync<int?>(
                "SELECT AlignmentType FROM ProjectManagement WHERE ID = @Id",
                new { Id = id });

            return alignmentType;
        }

        public async Task<Response> GetAllProject(Request request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request), "Request cannot be null.");
            }

            var whereClause = "";
            if (request.Filter != null)
            {
                whereClause = new Filter().BuildWhereClause(request.Filter);
                if (!string.IsNullOrEmpty(whereClause))
                {
                    whereClause = "WHERE " + whereClause;
                }
            }

            var totalCountQuery = $"SELECT COUNT(*) FROM ProjectManagement {whereClause}";

            var baseQuery = $@"
                SELECT ProjectManagement.ID, ProjectManagement.Name, ProjectManagement.Description, 
                       ProjectManagement.ClientId, ProjectManagement.IsActive, ClientManagement.CompanyName,ProjectManagement.ProjectLogo,ProjectManagement.AlignmentType 
                FROM ProjectManagement
                INNER JOIN ClientManagement ON ProjectManagement.ClientId = ClientManagement.ID
                {whereClause} 
                ORDER BY {(request.Sort != null && request.Sort.Count != 0 ?
                                    string.Join(',', request.Sort.Select(s => $"{s.Field} {s.Dir}")) : "ProjectManagement.ID")} 
              
                ";

            using var connection = _context.CreateConnection();
            var parameters = new
            {
                skip = request.Skip > 0 ? request.Skip : 0,
                take = request.Take > 0 ? request.Take : 10
            };

            var total = await connection.ExecuteScalarAsync<int>(totalCountQuery);
            var result = await connection.QueryAsync<ProjectModel>(
                baseQuery,
                parameters
            );

            var aggregates = new Dictionary<string, Dictionary<string, string>>();
            bool isGrouped = false;

            //var FileName = result.ToList().Where(x => x.projectLogo != null).Select(x => x.projectLogo).FirstOrDefault();

            //var FilePath = Path.GetFullPath(FileName);

            return new Response(result.ToList(), aggregates, total, isGrouped);
        }

        //private async Task ValidateProjectPortsAsync(ProjectModel project, IDbConnection connection, IDbTransaction? transaction = null)
        //{
        //    bool IsPublishEnabled = _configuration.GetValue<bool>("IsPublishClientUsingScript");
        //    //if (!IsPublishEnabled)
        //    //    return;

        //    static int? ExtractPort(string? url)
        //    {
        //        if (string.IsNullOrWhiteSpace(url)) return null;

        //        if (int.TryParse(url, out int port)) return port;

        //        try
        //        {
        //            if (!url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) && !url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        //            {
        //                url = "http://" + url.Trim('/');
        //            }
        //            var uri = new Uri(url);
        //            return uri.Port;
        //        }
        //        catch
        //        {
        //            return null; 
        //        }
        //    }
        //    try
        //    {
        //        object parameters;
        //        if (project.TabType?.Equals("configuration", StringComparison.OrdinalIgnoreCase) == true)
        //        {
        //            parameters = new
        //            {
        //                project.ProjectId,
        //                ConfigurationApiLink = ExtractPort(project.ConfigurationApiLink),
        //                ConfigurationUiLink = ExtractPort(project.ConfigurationUiLink)
        //            };
        //        }
        //        else if (project.TabType?.Equals("clientadmin", StringComparison.OrdinalIgnoreCase) == true)
        //        {
        //            parameters = new
        //            {
        //                project.ProjectId,
        //                ClientApiLink = ExtractPort(project.ClientApiLink),
        //                ClientUiLink = ExtractPort(project.ClientUiLink),
        //                ClientAdminApiLink = ExtractPort(project.ClientAdminApiLink),
        //                ClientAdminUiLink = ExtractPort(project.ClientAdminUiLink)
        //            };
        //        }
        //        else
        //        {
        //            return;
        //        }
        //        await connection.ExecuteAsync("ValidateProjectPorts",parameters, commandType: CommandType.StoredProcedure, transaction: transaction);
        //    }
        //    catch (SqlException ex)
        //    {
        //        // Forward SQL THROW message (for duplicate port etc.)
        //        throw new Exception(ex.Message);
        //    }
        //}
        private async Task ValidateProjectPortsAsync(ProjectModel project, IDbConnection connection, IDbTransaction? transaction = null)
        {           
            var parameters = new
            {
                project.ProjectId,
                project.ClientApiLink,
                project.ClientUiLink,
                project.ClientAdminApiLink,
                project.ClientAdminUiLink,
                project.ConfigurationApiLink,
                project.ConfigurationUiLink
            };
            try
            {
                await connection.ExecuteAsync("ValidateProjectPorts",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );
            }
            catch (SqlException ex)
            {
                // Catch custom THROW messages from SQL (50001–50010)
                throw new Exception(ex.Message);
            }
        }
        public async Task<string> CreateProject(ProjectModel project, IDbConnection connection, IDbTransaction transaction, string webRootPath)
        {
            try
            {
                // 1) Check for duplicate project name
                var existingCount = await connection.ExecuteScalarAsync<int>(
                    "SELECT COUNT(*) FROM ProjectManagement WHERE Name = @Name AND ClientId = @ClientId",
                    new { project.Name, project.ClientId }, transaction);

                if (existingCount > 0)
                    return "A Application with the same name already exists.";

                //await ValidateProjectPortsAsync(project, connection, transaction);

                // 2) Handle image upload (if any)
                string fileName = "";
                if (project.ProjectLogoFile != null && project.ProjectLogoFile.Length > 0)
                {
                    //string fileExtension = Path.GetExtension(project.ProjectLogoFile.FileName)
                    //                         .ToLowerInvariant();
                    string fileExtension = Path.GetExtension(project.ProjectLogoFile.FileName)
                          .ToLowerInvariant()
                          .Trim();
                    var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp" };
                    if (!allowedExtensions.Contains(fileExtension))
                        return "";

                    // Create and assign file name
                    if (string.IsNullOrWhiteSpace(project.Name))
                    {
                        return "project name is required.";
                    }
                    // Build the target file name
                    fileName = $"{project.Name.Replace(" ", "")}{fileExtension}";

                    // Resolve your wwwroot/Image folder
                    //var dirPath = Path.GetFullPath("ProjectBuilder\\DemoWeb");
                    //var mainDirPath = dirPath.Split("ProjectBuilder")[0];
                    //var relativePath = @"ProjectBuilder\WebApi\wwwroot\ProjectLogo\";
                    //var uploadsFolder = Path.GetFullPath(Path.Combine(mainDirPath, relativePath));

                    var uploadsFolder1 = Path.Combine(webRootPath, "ProjectLogo");

                    if (!Directory.Exists(uploadsFolder1))
                        Directory.CreateDirectory(uploadsFolder1);

                    // Save the file
                    var filePath = Path.Combine(uploadsFolder1, fileName);
                    using var fileStream = new FileStream(filePath, FileMode.Create);
                    await project.ProjectLogoFile.CopyToAsync(fileStream);
                }

                
                // insert current userid

                project.CreatedBy = _userInfo.UserId;
                project.CreatedDate = DateTime.UtcNow;

                // 3) Insert into DB
                var rowsAffected = await connection.ExecuteScalarAsync<int>(
                    ProjectSQLQuery.CreateProject, // Assuming this is a query to insert a project and return the ID
                    new
                    {
                        project.ClientId,
                        project.Name,
                        project.Description,
                        projectLogo = fileName,
                        project.CreatedBy,
                        project.CreatedDate,
                        project.AlignmentType,
                        project.ClientApiLink,
                        project.ClientUiLink,
                        project.ConfigurationApiLink,
                        project.ConfigurationUiLink,
                        project.ClientAdminApiLink,
                        project.ClientAdminUiLink,
                        project.IsActive,
                    }, transaction);

                // 4) Return final status
                if (rowsAffected > 0)
                {
                    project.ID = rowsAffected;
                    return $"Application created successfully. Project ID: {rowsAffected}";
                }
                else
                {
                    return "Failed to create project.";
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to create Project. " + ex.Message);
            }
        }
        public async Task<string> UpdateProject(ProjectModel project, string webRootPath)
        {
            var checkQuery = "SELECT COUNT(1) FROM ProjectManagement WHERE ID = @Id";

            using var connection = _context.CreateConnection();
            var projectExists = await connection.ExecuteScalarAsync<int>(checkQuery, new { project.ID });

            if (projectExists == 0)
            {
                return "No Project found with the specified Id.";
            }

            //Check if the project name already exists for the same client, but under a different ID
            var nameExistsQuery = @"
            SELECT COUNT(*) 
            FROM ProjectManagement 
            WHERE Name = @Name AND ClientId = @ClientId AND ID != @ID";

            var nameExists = await connection.ExecuteScalarAsync<int>(nameExistsQuery, new
            {
                project.Name,
                project.ClientId,
                project.ID
            });

            if (nameExists > 0)
            {
                return "A Application with the same name already exists under this client.";
            }
            if (!string.IsNullOrEmpty(project.TabType))
            {
                if (project.TabType.Equals("configuration", StringComparison.OrdinalIgnoreCase) || project.TabType.Equals("clientadmin", StringComparison.OrdinalIgnoreCase))
                {
                    await ValidateProjectPortsAsync(project, connection);
                }
            }

            // 🔁 1. Load existing logo from DB
            var existingLogoQuery = "SELECT ProjectLogo FROM ProjectManagement WHERE ID = @ID";
            var existingLogo = await connection.ExecuteScalarAsync<string>(existingLogoQuery, new { project.ID });

            string? fileName = existingLogo; // Default to current logo
            var uploadsFolder = Path.Combine(webRootPath, "ProjectLogo");
            //var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "ProjectLogo");
            Directory.CreateDirectory(uploadsFolder);
            if (project.ProjectLogoFile != null && project.ProjectLogoFile.Length > 0)
            {
                string fileExtension = Path.GetExtension(project.ProjectLogoFile.FileName).ToLowerInvariant();
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png"};

                if (!allowedExtensions.Contains(fileExtension))
                    return "Invalid file type.";

                if (string.IsNullOrWhiteSpace(project.Name))
                    return "Project name is required.";

                // Generate new file name
                fileName = $"{project.Name.Replace(" ", "_")}{fileExtension}";
                var uploadsFolder1 = Path.Combine(webRootPath, "ProjectLogo");
                Directory.CreateDirectory(uploadsFolder1);

              
                if (!string.IsNullOrEmpty(existingLogo))
                {
                    var oldFilePath = Path.Combine(uploadsFolder1, existingLogo);
                    if (File.Exists(oldFilePath)) File.Delete(oldFilePath);
                }

                var newFilePath = Path.Combine(uploadsFolder1, fileName);
                using var fileStream = new FileStream(newFilePath, FileMode.Create);
                await project.ProjectLogoFile.CopyToAsync(fileStream);
            }
            else if (string.IsNullOrEmpty(project.ProjectLogo) && !string.IsNullOrEmpty(existingLogo))
            {
                var uploadsFolder1 = Path.Combine(webRootPath, "ProjectLogo");
                var oldFilePath = Path.Combine(uploadsFolder1, existingLogo);

                if (File.Exists(oldFilePath))
                    File.Delete(oldFilePath);

                fileName = null; 
            }
            else if (!string.IsNullOrEmpty(existingLogo))
            {
                if (string.IsNullOrWhiteSpace(project.Name))
                    return "Project name is required.";

                string oldExtension = Path.GetExtension(existingLogo);
                string newFileName = $"{project.Name.Replace(" ", "_")}{oldExtension}";

                if (!string.Equals(existingLogo, newFileName, StringComparison.OrdinalIgnoreCase))
                {
                    string oldPath = Path.Combine(uploadsFolder, existingLogo);
                    string newPath = Path.Combine(uploadsFolder, newFileName);

                    if (File.Exists(oldPath))
                    {
                        File.Move(oldPath, newPath);
                        fileName = newFileName;
                    }
                }
            }
            project.ModifiedBy = _userInfo.UserId;
            project.ModifiedDate = DateTime.UtcNow;

            var existing = await connection.QueryFirstOrDefaultAsync<ProjectModel>("SELECT * FROM ProjectManagement WHERE ID = @ID", new { project.ID });

            if (existing == null) return "Project not found.";

            string updateQuery = ProjectSQLQuery.UpdateProject;

            string? clientApiLink = existing.ClientApiLink;
            string? clientUiLink = existing.ClientUiLink;
            string? configurationApiLink = existing.ConfigurationApiLink;
            string? configurationUiLink = existing.ConfigurationUiLink;
            string? clientAdminApiLink = existing.ClientAdminApiLink;
            string? clientAdminUiLink = existing.ClientAdminUiLink;

            if (project.TabType?.Equals("configuration", StringComparison.OrdinalIgnoreCase) == true)
            {
                configurationApiLink = project.ConfigurationApiLink;
                configurationUiLink = project.ConfigurationUiLink;
            }
            else if (project.TabType?.Equals("clientadmin", StringComparison.OrdinalIgnoreCase) == true)
            {
                clientApiLink = project.ClientApiLink;
                clientUiLink = project.ClientUiLink;
                clientAdminApiLink = project.ClientAdminApiLink;
                clientAdminUiLink = project.ClientAdminUiLink;
            }
            var rowsAffected = await connection.ExecuteAsync(updateQuery, new
            {
                project.Name,
                project.Description,
                project.ModifiedBy,
                ProjectLogo = fileName,
                project.ModifiedDate,
                project.ClientId,
                project.AlignmentType,
                ClientApiLink = clientApiLink,
                ClientUiLink = clientUiLink,
                ConfigurationApiLink = configurationApiLink,
                ConfigurationUiLink = configurationUiLink,
                ClientAdminApiLink = clientAdminApiLink,
                ClientAdminUiLink = clientAdminUiLink,
                project.IsActive,
                Id = project.ID
            });
            return rowsAffected > 0 ? "Application updated successfully." : "No Application found with the specified Id.";        
        }

        public async Task<string> DeleteProject(int id)
        {
            try
            {
                string? logoFileName;

                using (var connection = _context.CreateConnection())
                {
                    var referenceCount = await connection.ExecuteScalarAsync<int>($@"
                    SELECT 
                        (SELECT COUNT(*) FROM [{DatabaseSchema.Config.ToSchemaName()}].Form WHERE ProjectId = @Id) +
                        (SELECT COUNT(*) FROM [{DatabaseSchema.Config.ToSchemaName()}].Menu WHERE ProjectId = @Id) +
                        (SELECT COUNT(*) FROM [{DatabaseSchema.Config.ToSchemaName()}].TableDefination WHERE ProjectId = @Id)
                    ", new { Id = id });

                    if (referenceCount > 0)
                    {
                        return "Error: Cannot delete: Project is used in related tables.";
                    }
                }

                using (var connection = _context.CreateConnection())
                {

                    // Step 1: Get logo filename before deletion
                    logoFileName = await connection.ExecuteScalarAsync<string>("SELECT ProjectLogo FROM ProjectManagement WHERE ID = @Id", new { Id = id });
                }

                // Step 2: Delete logo file from wwwroot/ProjectLogo if it exists
                if (!string.IsNullOrEmpty(logoFileName))
                {
                    var logoPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "ProjectLogo", logoFileName);
                    if (File.Exists(logoPath))
                    {
                        File.Delete(logoPath);
                    }
                }

                // Step 3: Delete related menu (if needed)
                using (var connection = _context.CreateConnection())
                {
                    await connection.ExecuteAsync(ProjectSQLQuery.DeleteProjectupdateMenuQuery, new { Id = id });
                }

                // Step 4: Delete project
                using (var connection = _context.CreateConnection())
                {
                    var result = await connection.ExecuteAsync(ProjectSQLQuery.DeleteProjectdeleteProjectQuery, new { Id = id });

                    return result > 0
                        ? "Application deleted successfully"
                        : "Application not found or could not be deleted.";
                }
            }
            catch (Exception ex)
            {
                return $"Error: {ex.Message}";
            }
        }

        //public async Task<IEnumerable<Project>> GetAllProjectFromClient(int Id)
        //{
        //    string query = @"
        //SELECT 
        //    p.id,
        //    p.ClientID,
        //    p.Name,
        //    p.Description,
        //    p.CreatedBy,
        //    p.CreatedDate,
        //    p.ModifiedBy,
        //    p.ModifiedDate,
        //    c.ComapanyName
        //FROM ProjectManagement1 p
        //INNER JOIN ClientManagement c ON p.ClientID = c.Id
        //WHERE p.ClientID = @id";

        //    using (var connection = this._context.CreateConnection())
        //    {
        //        var projects = await connection.QueryAsync<Project>(query, new { id = Id });
        //        return projects.ToList();
        //    }
        //}



        public async Task<IEnumerable<ProjectModel>> GetAllProjectFromClient(int Id)
        {


            using var connection = _context.CreateConnection();
            var getFields = await connection.QueryAsync<ProjectModel>(ProjectSQLQuery.GetAllProjectFromClient, new { ClientID = Id });
            return getFields; // This will return a collection of FieldDefination
        }

        public async Task<IEnumerable<ProjectModel>> GetTableById(int Id)
        {
            using var connection = this._context.CreateConnection();

            var projects = await connection.QueryAsync<ProjectModel>(ProjectSQLQuery.GetTableById, new { id = Id });

            return projects.ToList();
        }
        public async Task<string> GetProjectName(int clientId, int projectId)
        {
            using var connection = _context.CreateConnection();
            // Query to get the ProjectName for a given clientId and projectId
            var projectName = await connection.QueryFirstOrDefaultAsync<string>(ProjectSQLQuery.GetProjectName, new { ClientId = clientId, ProjectId = projectId });

            if (projectName == null)
            {
                return $"Error: No project found for ClientId {clientId} and ProjectId {projectId}";
            }

            return projectName;
        }
        public async Task<IEnumerable<MenuModel>> GetMenuIcon(int ProjectId, string oldConnectionString)
        {
            using var connection = new SqlConnection(oldConnectionString);
            // Query to get the ProjectName for a given clientId and projectId
            var projectName = await connection.QueryAsync<MenuModel>(ProjectSQLQuery.GetMenuIcon, new { ProjectId });
            return projectName.ToList();
        }

        public async Task<string> GetProjectLogo(int projectId, string originalConnectionString)
        {
            using var connection = new SqlConnection(originalConnectionString);
            // Query to get the ProjectName for a given clientId and projectId
            var projectName = await connection.QueryFirstOrDefaultAsync<string>(ProjectSQLQuery.GetProjectLogo, new { ProjectId = projectId });

            if (projectName == null)
            {
                return $"Error: No project found for ProjectId {projectId}";
            }

            return projectName;
        }

        public async Task<Response> GetAllProjectByClientId(int clientId, Request request)
        {
            string whereClause = "WHERE p.ClientId = @ClientId";

            // Inline recursive field mapping
            void MapFilterFields(Filter filter)
            {
                var fieldMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                {
                    ["name"] = "p.Name",
                    ["companyName"] = "c.CompanyName"
                };

                if (!string.IsNullOrEmpty(filter.Field) && fieldMap.ContainsKey(filter.Field))
                {
                    filter.Field = fieldMap[filter.Field];
                }

                if (filter.Filters?.Any() == true)
                {
                    foreach (var subFilter in filter.Filters)
                        MapFilterFields(subFilter);
                }
            }

            if (request.Filter != null)
            {
                MapFilterFields(request.Filter); // convert UI fields to DB columns

                var filterClause = new Filter().BuildWhereClause(request.Filter);
                if (!string.IsNullOrEmpty(filterClause))
                {
                    whereClause += " AND " + filterClause;
                }
            }

            var parameters = new DynamicParameters();
            parameters.AddDynamicParams(request);
            parameters.Add("ClientId", clientId);

            using var connection = _context.CreateConnection();

            // Total count (after filter)
            var totalCountQuery = $@"
        SELECT COUNT(*)
        FROM ProjectManagement p
        INNER JOIN ClientManagement c ON p.ClientId = c.Id
        {whereClause};
    ";
            var total = await connection.ExecuteScalarAsync<int>(totalCountQuery, parameters);

            // Data with paging
            var baseQuery = $@"
        SELECT p.*, c.FirstName AS ClientName, c.CompanyName AS CompanyName
        FROM ProjectManagement p
        INNER JOIN ClientManagement c ON p.ClientId = c.Id
        {whereClause}
        {(request.Sort != null && request.Sort.Any()
                    ? "ORDER BY " + string.Join(',', request.Sort.Select(s => $"{s.Field} {s.Dir}"))
                    : "ORDER BY p.Id")}
        OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY;
    ";

            var result = await connection.QueryAsync<ProjectModel>(baseQuery, parameters);

            return new Response(result.ToList(), new Dictionary<string, Dictionary<string, string>>(), total, false);
        }

        public async Task<List<Dictionary<string, object>>> CheckProjectUsageAsync(int projectId)
        {
            using var connection = _context.CreateConnection();

            var result = await connection.QueryFirstOrDefaultAsync<(string ProjectName, string FirstName, string LastName, bool IsBuild, bool IsConfigure)>(
                @"SELECT p.Name, c.FirstName, c.LastName, p.IsBuild, p.IsConfigure FROM ProjectManagement p JOIN ClientManagement c ON p.ClientId = c.ID
                 WHERE p.ID = @projectId", new { projectId });

            if (string.IsNullOrEmpty(result.ProjectName))return
            [
                new() { { "found", false }, { "message", $"Project {projectId} not found." } }
            ];

            string dbName = $"{result.ProjectName}_{result.FirstName}{result.LastName}".Replace(" ", "_").Replace("-", "_").ToUpper();
            string configDbName = $"{result.ProjectName}_Configuration".Replace(" ", "_").Replace("-", "_").ToUpper();

            string clientBase = Path.Combine(@"C:\ClientProject", $"{result.FirstName}{result.LastName}");
            string clientFolder = Path.Combine(clientBase, result.ProjectName);
            string clientFolderAdmin = Path.Combine(clientBase, $"{result.ProjectName}_Admin"); 

            string configFolder = Path.Combine(@"C:\ClientConfigurationProject", $"{result.FirstName}{result.LastName}", result.ProjectName);

            string wwwrootBase = @"C:\inetpub\wwwroot";
            string wwwrootUI = Path.Combine(wwwrootBase, $"{result.ProjectName}_UI");
            string wwwrootAPI = Path.Combine(wwwrootBase, result.ProjectName);
            string wwwrootConfigUI = Path.Combine(wwwrootBase, $"{result.ProjectName}Configuration_UI");
            string wwwrootConfig = Path.Combine(wwwrootBase, $"{result.ProjectName}Configuration");
            string wwwrootAdmin = Path.Combine(wwwrootBase, $"{result.ProjectName}_Admin");
            string wwwrootAdminUI = Path.Combine(wwwrootBase, $"{result.ProjectName}_Admin_UI");

            var checks = new List<(string Key, string Path, bool Exists, string NotFoundMsg)>();
            
            if (result.IsBuild)
            {
                checks.Add(("clientdatabase", dbName,
                    await connection.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM sys.databases WHERE name = @dbName", new { dbName }) > 0,
                    $"Client database '{dbName}' not found."));

                checks.Add(("clientFolder", clientFolder, Directory.Exists(clientFolder), $"Client dynamic folder '{clientFolder}' not found."));
                checks.Add(("clientFolderAdmin", clientFolderAdmin, Directory.Exists(clientFolderAdmin), $"Client admin folder '{clientFolderAdmin}' not found.")); 

                checks.Add(("wwwrootUI", wwwrootUI, Directory.Exists(wwwrootUI), $"UI folder '{wwwrootUI}' not found."));
                checks.Add(("wwwrootAPI", wwwrootAPI, Directory.Exists(wwwrootAPI), $"API folder '{wwwrootAPI}' not found."));
                checks.Add(("wwwrootAdminUI", wwwrootAdmin, Directory.Exists(wwwrootAdmin), $"UI folder '{wwwrootAdmin}' not found."));
                checks.Add(("wwwrootAdminAPI", wwwrootAdminUI, Directory.Exists(wwwrootAdminUI), $"API folder '{wwwrootAdminUI}' not found."));
            }

            if (result.IsConfigure)
            {
                checks.Add(("configDatabase", configDbName,
                    await connection.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM sys.databases WHERE name = @configDbName", new { configDbName }) > 0,
                    $"Configuration database '{configDbName}' not found."));        
                checks.Add(("configFolder", configFolder, Directory.Exists(configFolder), $"Configuration folder '{configFolder}' not found."));
                checks.Add(("wwwrootConfigUI", wwwrootConfigUI, Directory.Exists(wwwrootConfigUI), $"Config UI folder '{wwwrootConfigUI}' not found."));
                checks.Add(("wwwrootConfig", wwwrootConfig, Directory.Exists(wwwrootConfig), $"Config API folder '{wwwrootConfig}' not found."));
            }

            return checks.Select(c => new Dictionary<string, object>
            {
                { "key", c.Key },
                { "path", c.Path },
                { "found", c.Exists },
                { "message", c.Exists ? "" : c.NotFoundMsg }
            }).ToList();
        }        

        public async Task<bool> DeleteProjectAsync(int projectId, bool deleteConfigDatabase = false, bool deleteConfigProject = false, bool deleteClientDatabase = false, bool deleteClientProject = false)
        {
            using var connection = _context.CreateConnection();
            if (connection.State != ConnectionState.Open) connection.Open();

            var result = await connection.QueryFirstOrDefaultAsync<(int ClientId, string ProjectName, string FirstName, string LastName, bool IsBuild, bool IsConfigure)>(
                @"SELECT p.ClientId, p.Name, c.FirstName, c.LastName, p.IsBuild, p.IsConfigure FROM ProjectManagement p JOIN ClientManagement c ON p.ClientId = c.ID 
                WHERE p.ID = @projectId", new { projectId });

            if (string.IsNullOrEmpty(result.ProjectName))
                return false;

            string dbName = $"{result.ProjectName}_{result.FirstName}{result.LastName}".Replace(" ", "_").Replace("-", "_").ToUpper();
            string configDbName = $"{result.ProjectName}_Configuration".Replace(" ", "_").Replace("-", "_").ToUpper();

            string clientBase = Path.Combine(@"C:\ClientProject", $"{result.FirstName}{result.LastName}");
            string clientFolder = Path.Combine(clientBase, result.ProjectName);
            string clientFolderAdmin = Path.Combine(clientBase, $"{result.ProjectName}_Admin");

            string configFolder = Path.Combine(@"C:\ClientConfigurationProject", $"{result.FirstName}{result.LastName}", result.ProjectName);

            string wwwrootBase = @"C:\inetpub\wwwroot";
            string wwwrootUI = Path.Combine(wwwrootBase, $"{result.ProjectName}_UI");
            string wwwrootAPI = Path.Combine(wwwrootBase, result.ProjectName);
            string wwwrootConfigUI = Path.Combine(wwwrootBase, $"{result.ProjectName}Configuration_UI");
            string wwwrootConfig = Path.Combine(wwwrootBase, $"{result.ProjectName}Configuration");
            string wwwrootAdmin = Path.Combine(wwwrootBase, $"{result.ProjectName}_Admin");
            string wwwrootAdminUI = Path.Combine(wwwrootBase, $"{result.ProjectName}_Admin_UI");

            string scriptPath = @"C:\inetpub\TechAhir\PublishClientPShellScript\Remove-IISResources.ps1";
            bool isPublishUsingScript = _configuration.GetValue<bool>("IsPublishClientUsingScript");

            bool isClientDbDeleted = false;
            bool isClientProjectDeleted = false;
            bool isClientAdminDeleted = false;
            bool isConfigDbDeleted = false;
            bool isConfigProjectDeleted = false;
            try
            {
                if (result.IsBuild)
                {
                    if (deleteClientDatabase)
                    {
                        var exists = await connection.ExecuteScalarAsync<int>(
                            "SELECT COUNT(1) FROM sys.databases WHERE name = @dbName", new { dbName });
                        if (exists > 0)
                        {
                            await connection.ExecuteAsync($"ALTER DATABASE [{dbName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{dbName}];");
                            isClientDbDeleted = true;
                        }
                    }
                    if (deleteClientProject)
                    {
                        if (Directory.Exists(clientFolder))
                        {
                            Directory.Delete(clientFolder, true);
                            isClientProjectDeleted = true;
                        }
                        if (Directory.Exists(clientFolderAdmin))
                        {
                            Directory.Delete(clientFolderAdmin, true);
                            isClientAdminDeleted = true;
                        }
                        if (isPublishUsingScript)
                        {
                            await RemoveIISResourcesAsync(scriptPath, result.ProjectName, true, false);
                            foreach (var path in new[] { wwwrootUI, wwwrootAPI, wwwrootAdmin, wwwrootAdminUI })
                                if (Directory.Exists(path))
                                    Directory.Delete(path, true);
                        }
                    }
                }
                // --- Configuration deletions ---
                if (result.IsConfigure)
                {
                    if (deleteConfigDatabase)
                    {
                        var exists = await connection.ExecuteScalarAsync<int>(
                            "SELECT COUNT(1) FROM sys.databases WHERE name = @configDbName", new { configDbName });
                        if (exists > 0)
                        {
                            await connection.ExecuteAsync($"ALTER DATABASE [{configDbName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{configDbName}];");
                            isConfigDbDeleted = true;
                        }
                    }
                    if (deleteConfigProject)
                    {
                        if (Directory.Exists(configFolder))
                        {
                            Directory.Delete(configFolder, true);
                            isConfigProjectDeleted = true;
                        }                       

                        if (isPublishUsingScript)
                        {
                            await RemoveIISResourcesAsync(scriptPath, result.ProjectName, false, true);

                            foreach (var path in new[] { wwwrootConfigUI, wwwrootConfig })
                                if (Directory.Exists(path))
                                    Directory.Delete(path, true);

                        }                            
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Resource deletion failed: {ex.Message}", ex);
            }
            connection.Close();
            using var connection2 = _context.CreateConnection();
            if (connection2.State != ConnectionState.Open) connection2.Open();
            using var transaction = connection2.BeginTransaction();
            try
            {
                var currentFlags = await connection2.QueryFirstOrDefaultAsync<(bool IsBuild, bool IsConfigure)>(
                    "SELECT IsBuild, IsConfigure FROM ProjectManagement WHERE ID = @projectId", new { projectId }, transaction);
                bool clientDbExists = false;
                bool clientFolderExists = false;
                bool clientAdminFolderExists = false;

                if (currentFlags.IsBuild)
                {
                    clientDbExists = await connection2.ExecuteScalarAsync<int>(
                        "SELECT COUNT(1) FROM sys.databases WHERE name = @dbName", new { dbName }, transaction) > 0;
                    clientFolderExists = Directory.Exists(clientFolder);
                    clientAdminFolderExists = Directory.Exists(clientFolderAdmin);
                }
                bool configDbExists = false;
                bool configFolderExists = false;

                if (currentFlags.IsConfigure)
                {
                    configDbExists = await connection2.ExecuteScalarAsync<int>(
                        "SELECT COUNT(1) FROM sys.databases WHERE name = @configDbName", new { configDbName }, transaction) > 0;
                    configFolderExists = Directory.Exists(configFolder);
                }

                bool finalIsBuild = currentFlags.IsBuild;
                if (currentFlags.IsBuild && !clientDbExists && !clientFolderExists && !clientAdminFolderExists)
                {
                    finalIsBuild = false;
                }

                bool finalIsConfigure = currentFlags.IsConfigure;
                if (currentFlags.IsConfigure && !configDbExists && !configFolderExists)
                {
                    finalIsConfigure = false;
                }

                await connection2.ExecuteAsync(
                    "UPDATE ProjectManagement SET IsBuild = @finalIsBuild, IsConfigure = @finalIsConfigure WHERE ID = @projectId",
                    new { finalIsBuild, finalIsConfigure, projectId }, transaction);

                // --- Insert history ---
                var deletedParts = new List<string>();
                if (isClientDbDeleted) deletedParts.Add("Client database");
                if (isClientProjectDeleted) deletedParts.Add("Client project");
                if (isClientAdminDeleted) deletedParts.Add("Client admin project");
                if (isConfigDbDeleted) deletedParts.Add("Configuration database");
                if (isConfigProjectDeleted) deletedParts.Add("Configuration project");

                string remark = deletedParts.Count > 0
                    ? $"{string.Join(" and ", deletedParts)} deleted successfully"
                    : "No deletion performed";

                bool anyDeleted = isClientDbDeleted || isClientProjectDeleted || isClientAdminDeleted || isConfigDbDeleted || isConfigProjectDeleted;
                if (anyDeleted)
                {
                    string insertSql = @"INSERT INTO ProjectPublishHistory 
                        (ProjectId, IsBuildConfig, IsBuildClient, IsConfigDatabase, IsConfigProject, 
                         IsClientDatabase, IsClientProject, IsClientAdmin, IsDeleted, CreatedDate, CreatedBy, Remark)
                        VALUES (@ProjectId, @IsBuildConfig, @IsBuildClient, @IsConfigDatabase, @IsConfigProject, 
                         @IsClientDatabase, @IsClientProject, @IsClientAdmin, @IsDeleted, @CreatedDate, @CreatedBy, @Remark)";

                    await connection2.ExecuteAsync(insertSql, new
                    {
                        ProjectId = projectId,
                        IsBuildConfig = finalIsConfigure ? 1 : 0,
                        IsBuildClient = finalIsBuild ? 1 : 0,
                        IsConfigDatabase = isConfigDbDeleted ? 1 : 0,
                        IsConfigProject = isConfigProjectDeleted ? 1 : 0,
                        IsClientDatabase = isClientDbDeleted ? 1 : 0,
                        IsClientProject = isClientProjectDeleted ? 1 : 0,
                        IsClientAdmin = isClientAdminDeleted ? 1 : 0,
                        IsDeleted = 1,
                        CreatedDate = DateTime.UtcNow,
                        CreatedBy = _userInfo.UserId,
                        Remark = remark
                    }, transaction);
                }

                transaction.Commit();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                throw new Exception($"Database update or history insert failed: {ex.Message}", ex);
            }

            return true;
        }

        public static async Task RemoveIISResourcesAsync(string scriptPath, string projectName, bool isBuild, bool isConfigure)
        {
            string args = $"-ExecutionPolicy Bypass -File \"{scriptPath}\" " +
                          $"-ProjectName \"{projectName}\" " +
                          $"-IsBuild \"{isBuild.ToString().ToLower()}\" " +
                          $"-IsConfigure \"{isConfigure.ToString().ToLower()}\"";

            var psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = args,
                Verb = "runas",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using var process = new Process { StartInfo = psi };

            var outputBuilder = new StringBuilder();
            process.OutputDataReceived += (sender, e) => { if (!string.IsNullOrEmpty(e.Data)) outputBuilder.AppendLine("[OUT] " + e.Data); };
            process.ErrorDataReceived += (sender, e) => { if (!string.IsNullOrEmpty(e.Data)) outputBuilder.AppendLine("[ERR] " + e.Data); };

            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
            await process.WaitForExitAsync();

            string output = outputBuilder.ToString();
            Console.WriteLine(output); // Optional: view script output

            if (process.ExitCode != 0)
            {
                throw new Exception($"PowerShell script failed with exit code {process.ExitCode}. Output:\n{output}");
            }
        }
    }

}
