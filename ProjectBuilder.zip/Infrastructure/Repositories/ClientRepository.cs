﻿using Application.Modules.Client.Queries;
using Dapper;
using Entities.Models.AppUser;
using Entities.Models.Client;
using Entities.Models.Request;
using Entities.Models.Response;
using Interfaces;
using static DapperDB.DapperDbContext;

namespace Repositories
{
    public class ClientRepository(DbContext context, UserInfo userInfo) : IClient
    {
        
            private readonly DbContext _context = context;
            private readonly UserInfo _userInfo= userInfo;        

        // Get Basic List of Clients
        public async Task<IEnumerable<ClientModel>> GetClient()
        {
            using var connection = _context.CreateConnection();
            return await connection.QueryAsync<ClientModel>(ClientSQLQuery.GetClient);
        }

        // Get Client by ID
        public async Task<ClientModel?> GetById(int Id)
        {
            using var connection = _context.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<ClientModel>(ClientSQLQuery.GetById, new { Id });
        }

        // Get All Clients for Dropdown
        public async Task<IEnumerable<ClientModel>> GetAllClient()
        {
            using var connection = _context.CreateConnection();
            return await connection.QueryAsync<ClientModel>(ClientSQLQuery.GetAllClient);
        }

        // Get Filtered + Paginated Clients
        public async Task<Response> GetAll(Request request)
        {           
            string whereClause = "";

            if (request.Filter != null)
            {
                request.Filter.TableName = "ClientManagement";
                request.Filter?.Filters?.ForEach(f => f.TableName = "ClientManagement");
                Filter filter = new();
                filter.TableName = "ClientManagement";
                whereClause = new Filter().BuildWhereClause(request.Filter);
                if (!string.IsNullOrEmpty(whereClause))
                {
                    whereClause = "WHERE " + whereClause;
                }
            }

            var totalCountQuery = $"SELECT COUNT(*) FROM ClientManagement {whereClause}";

            var baseQuery = $@"
                SELECT ID, CONCAT(FirstName, ' ', LastName) AS Name, Email, CompanyName, IsActive
                FROM ClientManagement
                {whereClause}
                ORDER BY {(request.Sort != null && request.Sort.Count != 0
                            ? string.Join(',', request.Sort.Select(s => $"{s.Field} {s.Dir}"))
                            : "ID")}
                OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY;
            ";

            using var connection = _context.CreateConnection();
            var total = await connection.ExecuteScalarAsync<int>(totalCountQuery);
            var result = await connection.QueryAsync<ClientModel>(baseQuery, request);

            var aggregates = new Dictionary<string, Dictionary<string, string>>();
            bool isGrouped = false;

            return new Response(result.ToList(), aggregates, total, isGrouped);
        }

        // Create a New Client
        public async Task<(string message, int clientId)> Create(ClientModel client)
        {
            if (client == null)
                return ("Invalid client data.", 0);

            const string checkNameQuery = @"
            SELECT COUNT(*) FROM ClientManagement
            WHERE LOWER(FirstName) = LOWER(@FirstName) 
            AND LOWER(LastName) = LOWER(@LastName);";

            const string checkEmailQuery = @"
            SELECT COUNT(*) FROM ClientManagement
            WHERE LOWER(Email) = LOWER(@Email);";

            const string checkPhoneQuery = @"
            SELECT COUNT(*) FROM ClientManagement
            WHERE PhoneNo = @PhoneNo;";

            const string checkCompanyQuery = @"
            SELECT COUNT(*) FROM ClientManagement
            WHERE LOWER(companyName) = LOWER(@companyName);";

            // insert currentuser id 
            client.CreatedBy = _userInfo.UserId;
            client.CreatedDate = DateTime.UtcNow;
            var insertQuery = @"
            INSERT INTO ClientManagement (FirstName, LastName, PhoneNo, Email, Password, CreatedBy, CreatedDate, companyName, IsActive)
            VALUES (@FirstName, @LastName, @PhoneNo, @Email, @Password, @CreatedBy, @CreatedDate, @companyName, @IsActive);
            SELECT CAST(SCOPE_IDENTITY() AS int);";

            try
            {
                using (var connection = _context.CreateConnection())
                {
                    var conflicts = new List<string>();

                    if (await connection.ExecuteScalarAsync<int>(checkNameQuery, client) > 0)
                        conflicts.Add("name");

                    if (await connection.ExecuteScalarAsync<int>(checkEmailQuery, client) > 0)
                        conflicts.Add("email");

                    if (await connection.ExecuteScalarAsync<int>(checkPhoneQuery, client) > 0)
                        conflicts.Add("phone number");

                    if (await connection.ExecuteScalarAsync<int>(checkCompanyQuery, client) > 0)
                        conflicts.Add("company name");

                    if (conflicts.Count > 0)
                    {
                        // Build a natural English sentence
                        string conflictMessage = string.Join(", ", conflicts.Take(conflicts.Count - 1));
                        if (conflicts.Count > 1)
                            conflictMessage += " and " + conflicts.Last();
                        else
                            conflictMessage = conflicts.First();

                        return ($"A client with the same {conflictMessage} already exists.", 0);
                    }

                    var insertedId = await connection.QuerySingleOrDefaultAsync<int>(insertQuery, client);
                    return insertedId > 0
                        ? ("Client created successfully.", insertedId)
                        : ("Client creation failed.", 0);
                }
            }
            catch (Exception ex)
            {
                return ("Error: " + ex.Message, 0);
            }
        }

        // Update Existing Client
        public async Task<string> Update(ClientModel client)
        {
            var checkQuery = @"
                SELECT COUNT(*) FROM ClientManagement
                WHERE Id != @Id AND
                ((LOWER(FirstName) = LOWER(@FirstName) AND LOWER(LastName) = LOWER(@LastName))
                OR LOWER(Email) = LOWER(@Email))";

            // current userid 
            client.ModifiedBy = _userInfo.UserId;
            client.ModifiedDate = DateTime.UtcNow;
            var updateQuery = @"
                UPDATE ClientManagement
                SET FirstName = @FirstName,
                    LastName = @LastName,
                    PhoneNo = @PhoneNo,
                    Email = @Email,
                    Password = @Password,
                    ModifiedBy = @ModifiedBy,
                    ModifiedDate = @ModifiedDate,
                    companyName = @companyName,
                    IsActive=@IsActive

                WHERE Id = @Id";

            using var connection = _context.CreateConnection();
            var existingCount = await connection.QuerySingleAsync<int>(checkQuery, new
            {
                Id = client.ID,
                client.FirstName,
                client.LastName,
                client.Email
            });

            if (existingCount > 0)
            {
                return "Client with the same First Name & Last Name combination or Email already exists.";
            }

            var rowsAffected = await connection.ExecuteAsync(updateQuery, client);

            return rowsAffected > 0
                ? "Client updated successfully."
                : "No client found with the specified Id.";
        }

        // Delete Client by ID
        public async Task<string> Delete(int Id)
        {
            using var connection = _context.CreateConnection();
            await connection.ExecuteAsync(ClientSQLQuery.Delete, new { Id });
            return "pass";
        }

        // Get Client Name (First + Last)
        public async Task<string?> GetClientName(int clientId)
        {
            using var connection = _context.CreateConnection();
            var client = await connection.QueryFirstOrDefaultAsync<dynamic>(
                ClientSQLQuery.GetClientName,
                new { ClientId = clientId });

            if (client != null)
            {
                return $"{client.FirstName}{client.LastName}";
            }

            return null;
        }


    }
}
