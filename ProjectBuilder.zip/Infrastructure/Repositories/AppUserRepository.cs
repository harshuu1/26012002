﻿using Application.Modules.AppUser.Queries;
using Dapper;
using Entities.Models.AppUser;
using Entities.Models.Request;
using Interfaces;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using static DapperDB.DapperDbContext;

namespace Repositories
{
    public class AppUserRepository : IAppUser
    {
        private readonly DbContext _context;
        private readonly IPasswordHasher<AppUserModel> _passwordHasher;
        private readonly IConfiguration _configuration;
        private readonly  IUserInfo _userInfo;

        public AppUserRepository(DbContext context, IPasswordHasher<AppUserModel> passwordHasher, IConfiguration configuration, IUserInfo userInfo)
        {
            _context = context;
            _passwordHasher = passwordHasher;
            _configuration = configuration;
            _userInfo = userInfo;
        }

        public async Task<IEnumerable<AppUserModel>> GetAllAppUser()
        {
            using var connection = _context.CreateConnection();
            return await connection.QueryAsync<AppUserModel>(AppUserSQLQuery.GetAllUser);
        }


        public async Task<AppUserModel> GetAppUserById(int id)
        {
            using var connection = _context.CreateConnection();
            //return await connection.QuerySingleOrDefaultAsync<AppUser>(query, new { id });
            var user = await connection.QuerySingleOrDefaultAsync<AppUserModel>(AppUserSQLQuery.GetUserById, new { id });

            return user ?? throw new InvalidOperationException($"User with ID {id} not found.");
        }


        public async Task<IEnumerable<AppUserModel>> GetAppUser(Request request)
        {
            var basequery = "select * from AppUser ";

            if (request.Filter != null)
            {
                var whereClause = new Filter().BuildWhereClause(request.Filter);
                if (!string.IsNullOrEmpty(whereClause))
                {
                    basequery += "WHERE " + whereClause;
                }
            }

            if (request.Sort != null && request.Sort.Count > 0)
            {
                var sorting = string.Join(',', request.Sort.Select(s => $"{s.Field} {s.Dir}"));
                basequery += $"ORDER BY {sorting} ";
            }
            else
            {
                basequery += "ORDER BY ID ";
            }

            basequery += "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY;";

            using var connection = _context.CreateConnection();
            return await connection.QueryAsync<AppUserModel>(basequery, request);
        }


        public async Task<string> CreateAppUser(AppUserModel appUser)
        {
            if (!Regex.IsMatch(appUser.FirstName ?? "", @"^[A-Za-z\s]+$"))
            {
                return "First name can contain only letters and spaces.";
            }

            if (!Regex.IsMatch(appUser.LastName ?? "", @"^[A-Za-z\s]+$"))
            {
                return "Last name can contain only letters and spaces.";
            }

            // Check if email already exists
            var existingUser = await GetUserByEmail(appUser.Email ?? "");
            if (existingUser != null)
            {
                return "Email is already in use.";
            }

            if (string.IsNullOrWhiteSpace(appUser.Password))
                throw new ArgumentException("Password is required");

            // Hash the password before saving
            appUser.Password = _passwordHasher.HashPassword(appUser, appUser.Password);
            appUser.CreatedBy = _userInfo.UserId;
            appUser.CreatedDate = DateTime.UtcNow;
            using var connection = _context.CreateConnection();
            var result = await connection.ExecuteAsync(AppUserSQLQuery.CreateUser, appUser);
            return result > 0 ? "User created successfully." : "Failed to create user.";
        }



        public async Task<string> UpdateAppUser(AppUserModel appUser, bool statusOnly = false)
        {
            // Check if email is already in use by another user

            if (string.IsNullOrWhiteSpace(appUser.Email))
                throw new ArgumentException("Email is required");

            var existingUser = await GetUserByEmail(appUser.Email);
            if (existingUser != null && existingUser.ID != appUser.ID)
            {
                return "Email is already in use by another user.";
            }

            if (string.IsNullOrWhiteSpace(appUser.Password))
                throw new ArgumentException("Password is required");
            // Validate password only for full update
            if (!statusOnly)
            {
                // Hash the password before updating
                appUser.Password = _passwordHasher.HashPassword(appUser, appUser.Password);
            }
            appUser.ModifiedBy = _userInfo.UserId;
            appUser.ModifiedDate = DateTime.UtcNow;
            using var connection = _context.CreateConnection();
            var result = await connection.ExecuteAsync(AppUserSQLQuery.UpdateUser, appUser);
            if (result > 0 && !appUser.IsActive)
            {
                await connection.ExecuteAsync(
                    "DELETE FROM UserToken WHERE UserId = @ID",
                    new { ID = appUser.ID });
            }
            return result > 0 ? "Employee updated successfully" : "Employee not found or update failed";
        }


        public async Task<string> DeleteAppUser(int id)
        {
            using var connection = _context.CreateConnection();
            var result = await connection.ExecuteAsync(AppUserSQLQuery.DeleteUser, new { id });
            return result > 0 ? "Employee deleted successfully" : "Employee not found";
        }

        public async Task<AppUserModel?> GetUserByEmail(string email)
        {
            using var connection = _context.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<AppUserModel>(AppUserSQLQuery.GetUserByEmail, new { Email = email });
        }


        public async Task<AuthUserModel> AuthenticateUser(string email, string password)
        {
            using var connection = _context.CreateConnection();
            var user = await connection.QuerySingleOrDefaultAsync<AppUserModel>(AppUserSQLQuery.GetUserByEmail, new { Email = email });
            var userByPassword = await connection.QuerySingleOrDefaultAsync<AppUserModel>(AppUserSQLQuery.GetUserByPassword, new { Password = password });

            var errors = new List<string>();

            if (user == null) // Email not found
            {
                if (userByPassword == null)
                {
                    // password also doesn't exist
                    errors.Add("email address and password");
                }
                else
                {
                    // password exists for someone, so only email is wrong
                    errors.Add("email address");
                }
            }
            else
            {
                // Handle LoginStatus returned by SQL
                if (user.LoginStatus != null && user.LoginStatus.StartsWith("ERROR", StringComparison.OrdinalIgnoreCase))
                    throw new UnauthorizedAccessException(user.LoginStatus.Substring(5).TrimStart(':', ' '));

                // email exists, now check password
                if (string.IsNullOrEmpty(user.Password))
                {
                    throw new UnauthorizedAccessException("User has no password set");
                }

                var verificationResult = _passwordHasher.VerifyHashedPassword(user, user.Password, password);
                if (verificationResult == PasswordVerificationResult.Failed)
                {
                    errors.Add("password");
                }
            }

            // Build error message if needed
            if (errors.Count > 0)
            {
                string errorMessage = string.Join(" and ", errors);
                throw new UnauthorizedAccessException($"The {errorMessage} you entered is incorrect.");
            }

            // ✅ Generate JWT
            var newToken = GenerateJwtToken(user, _configuration);

            // ✅ Save new token
            await connection.ExecuteAsync(AppUserSQLQuery.SaveJWT, new
            {
                UserId = user.ID,
                Token = newToken,
                ExpiryDate = DateTime.UtcNow.AddDays(365),
                CreatedDate = DateTime.UtcNow
            });

            // ✅ Return Authenticated User
            return new AuthUserModel
            {
                ID = user.ID,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                PhoneNo = user.PhoneNo,
                Token = newToken
            };
        }


        private static string GenerateJwtToken(AppUserModel user, IConfiguration _configuration)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"] ?? string.Empty));

            var credentials = new SigningCredentials(
                securityKey,
                SecurityAlgorithms.HmacSha256);

            // ✅ Add claims (user information)
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Email ?? string.Empty),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.NameIdentifier, user.ID.ToString()),
                new Claim(ClaimTypes.Name, user.FirstName + " " + user.LastName),
                new Claim(ClaimTypes.Email, user.Email ?? string.Empty),
                new Claim("userId", user.ID.ToString()),
                new Claim("firstName", user.FirstName ?? string.Empty),
                new Claim("lastName", user.LastName ?? string.Empty),
                new Claim("phoneNo", user.PhoneNo ?? string.Empty),
                new Claim("email", user.Email ?? string.Empty),
            };

            // ✅ Create token
            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(Convert.ToDouble(_configuration["Jwt:TokenExpiryInHours"])),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}