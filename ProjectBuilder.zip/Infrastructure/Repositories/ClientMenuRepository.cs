﻿using Dapper;
using Entities.Enums;
using Microsoft.Data.SqlClient;

namespace Repositories
{
    public class ClientMenuRepository(string connectionString)
    {
        private readonly string _connectionString = connectionString;

        // public void CreateMenuTable()
        // {
        //     // SQL to create the table
        //     string createTableQuery = @"
        //CREATE TABLE [dbo].[ClientMenu] (
        //    ID INT PRIMARY KEY,
        //    Name VARCHAR(MAX),
        //    Description VARCHAR(MAX),
        //    ParentID INT,
        //    CreatedBy VARCHAR(MAX),
        //    CreatedDate DATETIME,
        //    ModifiedBy VARCHAR(MAX),
        //    ModifiedDate DATETIME,
        //    FormPath VARCHAR(MAX),
        //    ClientId INT,
        //    ProjectId INT
        //)";

        //     using (SqlConnection connection = new SqlConnection(_connectionString))
        //     {
        //         connection.Open();

        //         SqlCommand command = new SqlCommand(createTableQuery, connection);
        //         command.ExecuteNonQuery();
        //     }
        // }
        public void CreateMenuTable(string databaseName)
        {
            // SQL to create the table
            string createTableQuery = $@"
       CREATE TABLE [{databaseName}].[dbo].[ClientMenu] (
           ID INT PRIMARY KEY IDENTITY(1, 1),
           Name VARCHAR(MAX),
           Description VARCHAR(MAX),
           ParentID INT,
           CreatedBy VARCHAR(MAX),
           CreatedDate DATETIME,
           ModifiedBy VARCHAR(MAX),
           ModifiedDate DATETIME,
           FormPath VARCHAR(MAX),
         ImportProfilePath VARCHAR(MAX), 
           ClientId INT,
           ProjectId INT,
           FormId INT,
           MenuIcon VARCHAR(MAX),
           IsCardView bit,
           IsClientMenu bit NOT NULL,
           InOrder INT NOT NULL,
           ImportProfile bit,           
           TableId INT
       )";

            using SqlConnection connection = new(_connectionString);
            connection.Open();

            SqlCommand command = new(createTableQuery, connection);
            command.ExecuteNonQuery();
        }

        // // Method to insert data from AdminMenu to ClientMenu
        // public void InsertDataIntoClientMenu()
        // {
        //     string insertDataQuery = @"
        //    INSERT INTO [ClientDatabase].[dbo].[ClientMenu] (
        //    ID, Name, Description, ParentID, CreatedBy, CreatedDate, 
        //    ModifiedBy, ModifiedDate, FormPath, ClientId, ProjectId
        //    )
        //      SELECT 
        //      m.ID,                           
        //      m.Name,                        
        //      m.Description,                 
        //      m.ParentID,                      
        //      m.CreatedBy,                     
        //      m.CreatedDate,                    
        //      m.ModifiedBy,                    
        //      m.ModifiedDate,                  
        //      f.Name + '/' + f.Name + 'List',             
        //      m.ClientId,                     
        //      m.ProjectId                     
        //      FROM [1-18-2025].[dbo].[Menu] m
        //      JOIN [1-18-2025].[dbo].[Form] f     
        //      ON m.FormId = f.ID               
        //";
        //     using (SqlConnection connection = new SqlConnection(_connectionString))
        //     {
        //         connection.Open();
        //         SqlCommand command = new SqlCommand(insertDataQuery, connection);
        //         command.ExecuteNonQuery();
        //     }
        // }

        public async Task InsertDataIntoClientMenu(string databaseName, int clientId, int projectId, string adminDatabaseName)
        {
            // The insert data query with parameterized values for clientId and projectId
            string insertDataQuery = $@"
                INSERT INTO [{databaseName}].[dbo].[ClientMenu] (
                    ID, Name, Description, ParentID, CreatedBy, CreatedDate, 
                    ModifiedBy, ModifiedDate, FormPath,ImportProfilePath, ClientId, ProjectId,FormId,MenuIcon,IsCardView,IsClientMenu,InOrder,ImportProfile,TableId
                )
                SELECT 
                    m.ID,                             
                    m.Name,                         
                    m.Description,                 
                    m.ParentID,                   
                    m.CreatedBy,                   
                    m.CreatedDate,                 
                    m.ModifiedBy,                  
                    m.ModifiedDate,                 
                    CASE 
                        WHEN m.FormId IS NULL THEN NULL
                        ELSE ISNULL(t.Name + '/', '') + ISNULL(f.Name, '') + 
                            CASE 
                                WHEN m.IsCardView = 1 THEN 'Details'
                                ELSE 'List'
                            END
                    END AS FormPath,
                   CASE 
                         WHEN m.ImportProfile = 1 THEN 
                            'ImportProfile/ImportProfileList' 
                           
                        ELSE NULL 
                    END AS ImportProfilePath,
                    m.ClientId,                   
                    m.ProjectId,
                    m.FormId,
                    m.MenuIcon,
                    m.IsCardView,
                    m.IsClientMenu,
                    m.InOrder,
                    m.ImportProfile,
	                t.ID AS TableId	 
                    FROM [{adminDatabaseName}].[{DatabaseSchema.Config.ToSchemaName()}].[Menu] m
                    LEFT JOIN [{adminDatabaseName}].[dbo].[Form] f ON m.FormId = f.ID 
                    LEFT JOIN [{adminDatabaseName}].[dbo].[TableDefination] t ON f.TableId = t.ID
                     OUTER APPLY (
                         SELECT md.*, ip.Name AS ProfileName,ip.TableId 
                         FROM [{adminDatabaseName}].[dbo].[MenuDetail] md 
                         LEFT JOIN [{adminDatabaseName}].[dbo].[ImportProfile] ip ON md.ImportProfileId = ip.ID
                         WHERE md.MenuId = m.ID
                     ) MI
                    WHERE 
                    m.ClientId = @ClientId 
                    AND m.ProjectId = @ProjectId
                    AND NOT (
                        m.FormId IS NULL AND m.ParentId IS NULL
                        AND NOT EXISTS (
                            SELECT 1 
                            FROM [{adminDatabaseName}].[dbo].[Menu] m2 
                            WHERE m2.ParentId = m.ID
                        ))
                    ORDER BY m.ParentId,m.FormId ASC";

            // Use Dapper to execute the insert query with parameters
            using SqlConnection connection = new(_connectionString);  // Assuming _context.CreateConnection() creates a valid connection
            var parameters = new { ClientId = clientId, ProjectId = projectId };  // Parameters to be passed to the query
            await connection.ExecuteAsync(insertDataQuery, parameters); // Execute the query asynchronously
        }
    }
}

