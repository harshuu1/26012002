﻿using Dapper;
using Interfaces;
using static DapperDB.DapperDbContext;

namespace Repositories
{
    public class TokenRepository(DbContext context) : ITokenRepository
    {
        private readonly DbContext _context = context;

        public async Task<bool> IsValidTokenAsync(string token) // Ensure method name matches
        {
            using var connection = _context.CreateConnection();
            var query = "SELECT COUNT(1) FROM UserToken WHERE Token = @Token AND ExpiryDate > GETUTCDATE()";

            var result = await connection.ExecuteScalarAsync<int>(query, new { Token = token });
            return result > 0;
        }
    }
}
