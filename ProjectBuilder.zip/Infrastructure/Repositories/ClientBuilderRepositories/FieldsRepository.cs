﻿using Dapper;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using Interfaces.ClientBuilderInterfaces;
using Microsoft.Data.SqlClient;

namespace Repositories.ClientBuilderRepositories
{
    public class FieldsRepository : IFields
    {
        public async Task<List<ClientDisplayField>> GetDisplayFieldByParentId(int formId, string oldConnectionString)
        {
            string query = $@"SELECT  [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.Name AS FieldName,[{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.DisplayName,[{DatabaseSchema.Config.ToSchemaName()}].Form.ID As FormId,[{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.SourceTableId,TBL.Name AS SourceTableName, [{DatabaseSchema.Config.ToSchemaName()}].DisplayField.*, [{DatabaseSchema.Config.ToSchemaName()}].FieldType.Name AS TypeId, [{DatabaseSchema.Config.ToSchemaName()}].Form.Name AS FormName ,TBL1.Name AS TableName FROM [{DatabaseSchema.Config.ToSchemaName()}].DisplayField INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination ON [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.id = [{DatabaseSchema.Config.ToSchemaName()}].DisplayField.FieldId INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldType ON [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.TypeId = [{DatabaseSchema.Config.ToSchemaName()}].FieldType.Id LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL ON TBL.ID = [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.SourceTableId LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL1 ON TBL1.ID = [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.TableId INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].Form ON [{DatabaseSchema.Config.ToSchemaName()}].Form.ListProfileId = [{DatabaseSchema.Config.ToSchemaName()}].DisplayField.ListProfileId WHERE [{DatabaseSchema.Config.ToSchemaName()}].Form.ParentId = @formId";


            using var connection = new SqlConnection(oldConnectionString);  // Dapper will use this connection
            var fields = await connection.QueryAsync<ClientDisplayField>(query, new { formId });
            return fields.ToList();
            // Explicitly open the connection                         
        }
        public async Task<List<ClientCardViewFields>> GetCardViewByCardViewProfileId(ClientCardViewFields cardViewFields, string oldConnectionString)
        {
            string query = $@"SELECT 
          FD.MinValue,
          FD.BarcodeType,
          FD.Max,
          FD.MaxValue,
          FD.SmallStep,
          FD.LargeStep,
          FD.FilterBy As FilterOption,
          FD.Scale,
          FD.Symbol,
          FD.Length,
          FD.IsCheckBox,
          FD.SymbolPosition,
          FD.Orientation,
          FD.ShowButton,
          FD.ID AS FieldId,
          FD.SwitchLabel1,
          FD.SwitchLabel2,
          FRM.CardViewLabel,
          FRM.Delimiter, 
          FD.DisplayName,
FD.IsAllowPositive,
         TBL.Name AS TableName, 
         FD.Name AS FieldName, 
CASE WHEN FT.Name IN ('dropdown', 'radiogroup', 'checkboxgroup', 'multiselect') THEN COALESCE(TBL2.Name, '') ELSE NULL END AS SourceTableName,
CASE WHEN FT.Name IN ('dropdown', 'radiogroup', 'checkboxgroup' ,'multiselect') THEN COALESCE(FD2.Name, '')  ELSE NULL END AS TextFieldName,
CASE WHEN FT.Name IN ('dropdown', 'radiogroup', 'checkboxgroup' ,'multiselect') THEN COALESCE(FD3.Name, '') ELSE NULL END AS ParentFieldName,
CASE WHEN FT.Name IN ('dropdown', 'radiogroup', 'checkboxgroup' ,'multiselect') THEN COALESCE(FD4.Name, '') ELSE NULL END AS FilterFieldName,
    FT.Name AS TypeId, FRM.Name AS FormName, FRM.TableId ,AEF.CardViewProfileId,FD.SourceTableId,FD.IsLazyLoaded,Fd.Link,FD.ToolTip
 
 
 
,FD.Mandatory,FD.DisplayName,AEF.DefaultValue,AEF.IsReadOnly,AEF.InOrder,FRM.Id as FormId,
       FD.IsMultiColumn,
S.Name AS SectionName,
    S.[Order] AS SectionOrder,
TBL2.Name AS ParentSourceTblName,
 ht.Name AS SourceHeaderTableName,

    -- MultiColumn values:
    FMCV.SourceFieldId,
    SrcFD.Name AS SourceFieldName,
SrcFD.DisplayName AS SourceDisplayFieldName
     FROM [{DatabaseSchema.Config.ToSchemaName()}].CardViewFields AEF
     INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD ON FD.id = AEF.FieldId
     INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldType FT ON FD.TypeId = FT.Id
     INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].Form FRM ON FRM.CardViewProfileId = AEF.CardViewProfileId
     INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination TBL ON FRM.TableId = TBL.Id
     LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD2 ON FD.TextFieldId = FD2.Id
     LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD3 ON FD.ParentFieldId = FD3.Id
     LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD4 ON FD.FilterFieldId = FD4.Id
         LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination TBL2 ON FD.SourceTableId = TBL2.Id
     LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].Section S ON FD.SectionId = S.ID
LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination ht ON TBL2.ParentId = ht.Id 
-- Multi-column field values
LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].Multi_Column_Dropdown_Fields FMCV ON FMCV.FieldDefinitionId = FD.ID
LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination SrcFD ON SrcFD.ID = FMCV.SourceFieldId
LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].CardViewControl CVC ON CVC.formid = FRM.Id AND CVC.cardviewid = FD.ID
WHERE FRM.Id =@id
ORDER BY AEF.InOrder,SrcFD.Name
";
            using var connection = new SqlConnection(oldConnectionString);  // Dapper will use this connection

            var fieldDict = new Dictionary<int, ClientCardViewFields>();

            var result = await connection.QueryAsync<ClientCardViewFields, ClientMultiColumnDropdownField, ClientCardViewFields>(
                query,
                (field, multiVal) =>
                {
                    if (!fieldDict.TryGetValue(field.FieldId, out var existing))
                    {
                        existing = field;
                        existing.MultiColumnFieldNames = [];
                        fieldDict.Add(field.FieldId, existing);
                    }

                    // Only add if SourceFieldId is valid
                    if (multiVal != null && multiVal.SourceFieldId > 0)
                    {
                        existing.MultiColumnFieldNames!.Add(multiVal);
                    }

                    return existing;
                },
                param: new { id = cardViewFields.FormId },
                splitOn: "SourceFieldId"
            );
            string cardViewControlQuery = $@"
SELECT FD.Name 
FROM [{DatabaseSchema.Config.ToSchemaName()}].CardViewControl CVC
INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD 
    ON CVC.cardviewid = FD.ID
WHERE CVC.formid = @formId
ORDER BY CVC.id";

            var cardViewControlFields = (await connection.QueryAsync<string>(
                cardViewControlQuery,
                new { formId = cardViewFields.FormId }
            )).ToList();

            fieldDict.Values.ToList().ForEach(field => field.CardViewControlFields = cardViewControlFields);

     // Corrected Reset Query 
            string resetQuery = $@"
        SELECT FD.Name
        FROM [{DatabaseSchema.Config.ToSchemaName()}].CardViewResetField RF
        INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].CardViewFields CF 
            ON RF.CardViewFieldId = CF.ID
        INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD 
            ON CF.FieldId = FD.ID
        WHERE RF.FormId = @FormId";

            var resetFieldNames = (await connection.QueryAsync<string>(
                resetQuery,
                new { formId = cardViewFields.FormId }
            )).ToList();

            fieldDict.Values.ToList().ForEach(f => f.ResetFieldNames = resetFieldNames);

            return fieldDict.Values.ToList();

            // Explicitly open the connection                         
        }
        public async Task<List<ClientDisplayField>> GetDisplayFieldBylistProfileId(ClientDisplayField displayField, string oldConnectionString)
        {
            string query = $@"SELECT  [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.Name AS FieldName,[{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.DisplayName,[{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.ToolTip,Form.ID As FormId,[{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.SourceTableId,TBL.Name AS SourceTableName, [{DatabaseSchema.Config.ToSchemaName()}].DisplayField.*, FieldType.Name AS TypeId, [{DatabaseSchema.Config.ToSchemaName()}].Form.Name AS FormName ,[{DatabaseSchema.Config.ToSchemaName()}].Form.ListLabel,TBL1.Name AS TableName FROM [{DatabaseSchema.Config.ToSchemaName()}].DisplayField INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination ON [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.id = [{DatabaseSchema.Config.ToSchemaName()}].DisplayField.FieldId INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldType ON [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.TypeId = FieldType.Id LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL ON TBL.ID = [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.SourceTableId LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL1 ON TBL1.ID = [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination.TableId INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].Form ON [{DatabaseSchema.Config.ToSchemaName()}].Form.ListProfileId = [{DatabaseSchema.Config.ToSchemaName()}].DisplayField.ListProfileId WHERE [{DatabaseSchema.Config.ToSchemaName()}].Form.ID =@Id ORDER BY [{DatabaseSchema.Config.ToSchemaName()}].DisplayField.InOrder";


            using var connection = new SqlConnection(oldConnectionString);  // Dapper will use this connection
            var fields = await connection.QueryAsync<ClientDisplayField>(query, new { id = displayField.FormId });
            return fields.ToList();
            // Explicitly open the connection                         
        }
        //public async Task<List<ClientSearchField>> GetSearchFields(ClientSearchField searchField, string oldConnectionString)
        //{
        //    string query = @" SELECT  
        //    SF.*, 
        //    FD.[Name] AS FieldName, 
        //    FT.[Name] AS FieldType,
        //    FT.Id AS FieldTypeId,
        //    FD.DisplayName,
        //    Form.[Name] AS FormName,
        //    TBL.[Name] AS TableName,
        //    Form.TableId,
        //    FD.SourceTableId,
        //    SrcTBL.[Name] AS SourceTableName,
        //    FD.IsMultiColumn, 
        //    FD2.[Name] AS TextFieldName,
        //    FD3.[Name] AS ParentFieldName,
        //    FMCV.SourceFieldId,
        //    SrcFD.[Name] AS SourceFieldName

        //    FROM SearchField SF
        //    INNER JOIN FieldDefination FD ON FD.Id = SF.FieldId 
        //    INNER JOIN FieldType FT  ON FD.TypeId = FT.Id  AND FT.[Name] NOT IN ('Bit', 'Slider')
        //    INNER JOIN Form ON Form.SearchProfileId = SF.SearchProfileId 
        //    INNER JOIN TableDefination AS TBL ON Form.TableId = TBL.Id 
        //    LEFT JOIN TableDefination AS SrcTBL ON SrcTBL.Id = FD.SourceTableId
        //    LEFT JOIN FieldDefination FD2 ON FD.TextFieldId = FD2.Id
        //    LEFT JOIN FieldDefination FD3 ON FD.ParentFieldId = FD3.Id
        //    LEFT JOIN Multi_Column_Dropdown_Fields FMCV ON FMCV.FieldDefinitionId = FD.Id
        //    LEFT JOIN FieldDefination SrcFD ON SrcFD.Id = FMCV.SourceFieldId
        //    WHERE Form.Id = @FormId 
        //    ORDER BY SF.InOrder;";

        //    using var connection = new SqlConnection(oldConnectionString);  // Dapper will use this connection
        //    var fields = await connection.QueryAsync<ClientSearchField>(query, new { searchField.FormId });
        //    return fields.ToList();
        //    // Explicitly open the connection                         
        //}

        public async Task<List<ClientSearchField>> GetSearchFieldsHierarchy(int formId, string oldConnectionString)
        {
            string query = $@"
    SELECT  
        SF.*, 
        FD.MinValue,
		FD.MaxValue,
		FD.Max,
        FD.[Name] AS FieldName, 
        FT.[Name] AS FieldType,
        FT.Id AS FieldTypeId,
          FD.SwitchLabel1,
          FD.SwitchLabel2,
		FD.IsCheckBox,
          FD.Orientation,
        FD.DisplayName,
		FRM.ID as FormID,
        FRM.[Name] AS FormName,
        TBL1.[Name] AS TableName,
        FRM.TableId,
        FD.SourceTableId,
        SrcTBL.[Name] AS SourceTableName,
        FD.IsMultiColumn, 
        FD2.[Name] AS TextFieldName,
        FD3.[Name] AS ParentFieldName,
        FMCV.SourceFieldId,
        SrcFD.[Name] AS SourceFieldName,
        FRM.ParentId

    FROM [{DatabaseSchema.Config.ToSchemaName()}].SearchField SF
    INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD ON FD.Id = SF.FieldId 
    INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldType FT ON FD.TypeId = FT.Id  
    INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].Form FRM ON FRM.SearchProfileId = SF.SearchProfileId
    INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination TBL1 ON FRM.TableId = TBL1.Id
    LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination SrcTBL ON SrcTBL.Id = FD.SourceTableId
    LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD2 ON FD.TextFieldId = FD2.Id
    LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD3 ON FD.ParentFieldId = FD3.Id
    LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].Multi_Column_Dropdown_Fields FMCV 
        ON FMCV.FieldDefinitionId = FD.Id
    LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination SrcFD ON SrcFD.Id = FMCV.SourceFieldId

    WHERE FRM.Id = @FormId 
       OR FRM.ParentId = @FormId

    ORDER BY FRM.Id, SF.InOrder;
    ";

            using var connection = new SqlConnection(oldConnectionString);

            var fieldDict = new Dictionary<int, ClientSearchField>();

            var result = await connection.QueryAsync<ClientSearchField, ClientMultiColumnDropdownField, ClientSearchField>(
                query,
                (field, multiVal) =>
                {
                    // does parent already exist?
                    if (!fieldDict.TryGetValue(field.FieldId, out var existing))
                    {
                        existing = field;
                        existing.MultiColumnFieldNames = new List<ClientMultiColumnDropdownField>();
                        fieldDict.Add(field.FieldId, existing);
                    }

                    // add child only if exists
                    if (multiVal != null && multiVal.SourceFieldId > 0)
                    {
                        existing.MultiColumnFieldNames.Add(multiVal);
                    }

                    return existing;
                },
                param: new { FormId = formId },
                splitOn: "SourceFieldId"
            );

            return fieldDict.Values.ToList();

        }

        public async Task<List<ClientSearchField>> GetDetailSearchByParentId(int FormId, string oldConnectionString)
        {
            string query = $@"
            SELECT 
            DS.Id AS DetailSearchId,
            DS.DetailTableId,
            DS.DetailSearchProfileId,
            DS.InOrder,
            DS.FormId AS ParentId,
            SP.[Name] AS SearchProfileName,
            SP.TableID,
            FD.[Name] AS FieldName,
            FD.DisplayName,
            FD.IsCheckBox,
            FD.SymbolPosition,
            FD.Orientation,
            FD.SourceTableId,
            TBL.[Name] AS SourceTableName,
            SF.InOrder,
            SF.FieldId,
            SF.SearchProfileId,
            FT.[Name] AS FieldType,
            FRM1.ID AS FormId,
            FRM1.[Name] AS FormName,
            TBL1.[Name] AS TableName,
            FT.Id AS FieldTypeId,
            FD.IsMultiColumn,
            FD2.[Name] AS TextFieldName, 
            FD3.[Name] AS ParentFieldName,
            FMCV.SourceFieldId,
            SrcFD.[Name] AS SourceFieldName
            FROM [{DatabaseSchema.Config.ToSchemaName()}].DetailSearch DS
            INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].SearchProfile SP ON SP.ID = DS.DetailSearchProfileId
            INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].SearchField SF ON SP.ID = SF.SearchProfileId
            INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD ON FD.Id = SF.FieldId
            INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldType FT ON FD.TypeId = FT.Id
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL ON TBL.ID = FD.SourceTableId
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL1 ON TBL1.ID = FD.TableId
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].DetailSearch FRM ON FRM.DetailSearchProfileId = SF.SearchProfileId AND FRM.FormId = DS.FormId
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].Form FRM1 ON FRM1.ID = FRM.FormId
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD2 ON FD.TextFieldId = FD2.Id
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD3 ON FD.ParentFieldId = FD3.Id
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].Multi_Column_Dropdown_Fields FMCV ON FMCV.FieldDefinitionId = FD.ID
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination SrcFD ON SrcFD.ID = FMCV.SourceFieldId
                        WHERE DS.FormId = @FormId
            ORDER BY DS.InOrder, SF.InOrder, SrcFD.[Name];";

            using var connection = new SqlConnection(oldConnectionString);

            var result = await connection.QueryAsync<ClientSearchField>(
                query, new { FormId }
            );

            return result.ToList();
        }
    }
}
