﻿using Application.Modules.Client.Queries;
using Application.Modules.Project.Queries;
using Dapper;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using Interfaces.ClientBuilderInterfaces;
using Microsoft.Data.SqlClient;
using static DapperDB.DapperDbContext;

namespace Repositories.ClientBuilderRepositories
{
    public class TableRepository(DbContext context) : ITable
    {
        private readonly DbContext _context = context;

        public async Task<IEnumerable<ClientTable>> GetTableById(int clientId, int projectId)
        {
            //var query = "SELECT TBL.Name AS Name,TBL.IsHierarchical,DT.HeaderTableId,DT1.DetailTableId,DT.CreatedDate, DT.ModifiedDate, DT.CreatedBy,DT.ModifiedBy,TBL.ClientId, TBL.ProjectId,TBL1.Name AS HeaderTablename,TBL2.Name AS DetailTableName,TBL.Id FROM TableDefination AS TBL Left JOIN DetailTable AS DT ON TBL.Id = DT.DetailTableId LEFT JOIN TableDefination AS TBL1 ON DT.HeaderTableId = TBL1.Id  LEFT JOIN DetailTable AS DT1 ON TBL.Id = DT1.HeaderTableId LEFT JOIN TableDefination AS TBL2 ON DT1.DetailTableId = TBL2.Id WHERE TBL.ClientId=@ClientId and TBL.ProjectId=@ProjectId; ";

            var query = $@"           
                SELECT    
                TBL.Id,
                TBL.Name AS Name,
                TBL.ParentId,
                TBL.IsHierarchical,
                PK.Type AS PrimaryKeyType,
                TBL1.Name AS HeaderTableName,
                TBL1.ID AS HeaderTableId,
                TBL2.Name AS DetailTableName,
                TBL2.ID AS DetailTableId,
                PK1.Type AS ParentPrimaryKeyType,
                CASE 
                    WHEN TBL.ParentId IS NULL 
                         AND EXISTS (
                            SELECT 1 
                            FROM [{DatabaseSchema.Config.ToSchemaName()}].Menu M
                            WHERE M.TableId = TBL.Id 
                              AND M.FormId IS NOT NULL
                         ) THEN 1
                    WHEN TBL.ParentId IS NOT NULL 
                         AND EXISTS (
                            SELECT 1
                            FROM [{DatabaseSchema.Config.ToSchemaName()}].Menu M
                            WHERE M.TableId = TBL1.Id 
                              AND M.FormId IS NOT NULL
                         ) THEN 1
                    ELSE 0
                END AS IsMenuCreated,
                CASE 
                    WHEN EXISTS (
                        SELECT 1 
                        FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD 
                        WHERE FD.SourceTableId = TBL.Id
                    ) THEN 1
                    ELSE 0
                   END AS IsSourceTable,

                -- 🆕 New column: Comma-separated list of all child table names
                (
                    SELECT STRING_AGG(C.Name, ', ') 
                    FROM [{DatabaseSchema.Config.ToSchemaName()}].TableDefination C
                    WHERE C.ParentId = TBL.Id
                ) AS ChildTableNames,

                -- 🆕 Comma-separated list of columns for all child tables
                   (
                    SELECT STRING_AGG(FD.Name , ', ')
                    FROM [{DatabaseSchema.Config.ToSchemaName()}].TableDefination C
                    INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD ON FD.TableId = C.Id
                    WHERE C.ParentId = TBL.Id
                ) AS ChildTableColumns

            FROM 
                [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL1 
                ON TBL.ParentId = TBL1.Id
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].PrimaryKeyType PK 
                ON PK.ID = TBL.PrimaryKeyType
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].PrimaryKeyType PK1 
                ON PK1.ID = TBL1.PrimaryKeyType
            OUTER APPLY (
                SELECT TOP 1 ID, Name
                FROM [{DatabaseSchema.Config.ToSchemaName()}].TableDefination
                WHERE ParentId = TBL.Id
            ) AS TBL2;
            ";
            using var connection = _context.CreateConnection();
            var recordList = await connection.QueryAsync<ClientTable>(query, new { ClientId = clientId, ProjectId = projectId });
            return recordList.ToList();
        }
        public async Task<string?> GetClientName(int clientId)
        {
            using var connection = _context.CreateConnection();
            var client = await connection.QueryFirstOrDefaultAsync<dynamic>(
                ClientSQLQuery.GetClientName,
                new { ClientId = clientId });

            if (client != null)
            {
                return $"{client.FirstName}{client.LastName}";
            }

            return null;
        }
        public async Task<string> GetProjectName(int clientId, int projectId)
        {
            using var connection = _context.CreateConnection();
            // Query to get the ProjectName for a given clientId and projectId
            var projectName = await connection.QueryFirstOrDefaultAsync<string>(ProjectSQLQuery.GetProjectName, new { ClientId = clientId, ProjectId = projectId });

            if (projectName == null)
            {
                return $"Error: No project found for ClientId {clientId} and ProjectId {projectId}";
            }

            return projectName;
        }
        public async Task<string> GetProjectLogo(int projectId, string originalConnectionString)
        {
            using var connection = new SqlConnection(originalConnectionString);
            // Query to get the ProjectName for a given clientId and projectId
            var projectName = await connection.QueryFirstOrDefaultAsync<string>(ProjectSQLQuery.GetProjectLogo, new { ProjectId = projectId });

            if (projectName == null)
            {
                return $"Error: No project found for ProjectId {projectId}";
            }

            return projectName;
        }
        public async Task<List<ClientActionDetail>> GetFormUpdateQueries(int TableId, string oldConnectionString)
        {
            //var actionDetails = new List<ActionDetail>();  // List to hold action name and value

            //            var actionsQuery = @"
            //         SELECT AA.[Name] AS ActionName, ActionID, FA.FormId,T.ID AS TableId, T.[Name] as TableName, FieldID, [Value]
            //FROM FormAction as FA 
            //INNER JOIN AppAction AA ON AA.ID = FA.ActionId
            //INNER JOIN Form F ON F.ID = FA.FormId
            //INNER JOIN TableDefination T ON T.ID = F.TableId
            //LEFT JOIN SetValueAction AS SVA ON SVA.ID = FA.ActionConfigurationId AND FA.ActionId = 1
            //INNER JOIN FieldDefination AS FD ON FD.Id = SVA.FieldID AND FA.ActionId = 1
            //WHERE FA.FormId = 1006";

            var actionsQuery = $@"
                SELECT
                    f.ID AS FormActionId,
                    f.ActionID,
                    f.ActionConfigurationId,
                    a.[Name] AS ActionName,
                    T.ID AS TableId, 
                    T.[Name] as TableName,
                    Frm.ID AS FormId,
                    FD.Name as FieldName,
                    sva.FieldId,
                    sva.value,

                    (CASE WHEN f.ActionId = 2 THEN sea1.EmailSubject ELSE sea.EmailSubject END) AS EmailSubject,
                    (CASE WHEN f.ActionId = 2 THEN sea1.EmailOptionId ELSE sea.EmailOptionId END) AS EmailOptionId,
                    (CASE WHEN f.ActionId = 2 THEN sea1.EmailMessage ELSE sea.EmailMessage END) AS EmailMessage,
                    (CASE WHEN f.ActionId = 2 THEN sea1.EmailTemplate ELSE sea.EmailTemplate END) AS EmailTemplate,
                    (CASE WHEN f.ActionId = 2 THEN sea1.EmailTo ELSE sea.EmailTo END) AS EmailTo,
                    (CASE WHEN f.ActionId = 2 THEN sea1.IndividualEmail ELSE sea.IndividualEmail END) AS IndividualEmail,
                    sea1.GenerateReportId,
                    gra.Report,
                    gra.ViewReport,
                    gra.EmailAttachment,

                    RoleAgg.RoleId --  Comma-separated RoleIds

                FROM [{DatabaseSchema.Config.ToSchemaName()}].formaction f
                INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].appaction a ON f.actionid = a.id
                INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].Form Frm ON Frm.ID = f.FormId
                INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination T ON T.ID = Frm.TableId

                -- Actions Table
                LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].setvalueaction sva ON f.actionconfigurationid = sva.id
                LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD on FD.ID = sva.FieldId
                LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].GenerateReportAction gra ON f.actionconfigurationid = gra.id 

                LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].sendemailaction sea ON sea.ID = f.ActionConfigurationId 
                LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].sendemailaction sea1 ON sea1.GenerateReportId = f.ActionConfigurationId

                --  Subquery to aggregate RoleIds
                LEFT JOIN (
                    SELECT
                        ActionId,
                        STRING_AGG(CAST(RoleId AS VARCHAR), ',') AS RoleId
                    FROM [{DatabaseSchema.Config.ToSchemaName()}].EmailActionRole
                    GROUP BY ActionId
                ) AS RoleAgg ON RoleAgg.ActionId = (CASE WHEN f.ActionId = 2 THEN sea1.Id ELSE sea.Id END)

                WHERE T.Id =  @TableId";

            using var connection = new SqlConnection(oldConnectionString);
            // Query database for actions
            //var actions = await connection.QueryAsync<ActionDetail>(
            //    actionsQuery,
            //    new { FormId = FormList}
            //);

            //// If actions exist, add them to the result list
            //if (actions.Any())
            //{
            //    foreach (var action in actions)
            //    {
            //        // Add action name and value to the list
            //        actionDetails.Add(new ActionDetail
            //        {
            //            ActionName = action.ActionName,  // Action's field name
            //            Value = action.Value // Action's value
            //        });
            //    }
            //}

            var fields = await connection.QueryAsync<ClientActionDetail>(actionsQuery, new { TableId });
            return fields.ToList();

            // Return the list of action details (name and value)

        }
        public async Task<IEnumerable<ClientFieldDefinition>> GetFieldNamesByTableId(int tableId, string oldConnectionString)
        {
            var sql = $@"SELECT f.Name,t.Name AS TableName,ft.Name AS TypeName,f.SourceTableId AS SourceTableType,PK.Type AS SourceTableType,f.IsLazyLoaded,t1.Name AS SourceTableName,t2.Name AS ParentSourceTblName,t1.PrimaryKeyType,FD3.Name AS ParentFieldName,ht.Name AS SourceHeaderTableName,f.Length,f.Max,f.Precision,f.Scale,f.Mandatory,FD2.Name AS TextFieldName,CASE WHEN EXISTS (SELECT 1  FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FDx WHERE FDx.TextFieldId = f.ID OR FDx.ParentFieldId = f.ID  OR FDx.FilterFieldId = f.ID ) THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT)END AS IsUsedAsSource,(SELECT STRING_AGG(td.Name, ', ')FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FDx JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination td ON FDx.TableId = td.ID WHERE FDx.TextFieldId = f.ID OR FDx.ParentFieldId = f.ID OR FDx.FilterFieldId = f.ID) AS MappedTableName,(SELECT STRING_AGG(FDx.Name, ', ')FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FDx WHERE FDx.TextFieldId = f.ID OR FDx.ParentFieldId = f.ID OR FDx.FilterFieldId = f.ID ) AS MappedFieldName,(SELECT STRING_AGG(ftype.Name, ', ') FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FDx INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldType ftype ON FDx.TypeId = ftype.ID WHERE FDx.TextFieldId = f.ID OR FDx.ParentFieldId = f.ID OR FDx.FilterFieldId = f.ID) AS MappedFieldTypeName FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination f INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination t ON f.TableId = t.ID LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination t1 ON f.SourceTableId = t1.ID LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD3 ON f.ParentFieldId = FD3.Id LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination t2 ON f.SourceTableId = t2.ID LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination ht ON t1.ParentId = ht.Id LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination FD2 ON f.TextFieldId = FD2.Id INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldType ft ON f.TypeId = ft.ID LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].PrimaryKeyType PK ON PK.ID = t1.PrimaryKeyType WHERE t.ID = @TableId;";
            using var connection = new SqlConnection(oldConnectionString);  // Dapper will use this connection
            await connection.OpenAsync();  // Explicitly open the connection              
            var fields = await connection.QueryAsync<ClientFieldDefinition>(sql, new { TableId = tableId });
            return fields.ToList();
        }
        public async Task<List<ClientCardViewFields>> GetRuleCriteriaList(int tableId, string oldConnectionString)
        {
            var query = $@"SELECT 
                 f.Name AS FormName, 
                 f.Id AS FormId, 
                 r.Id AS RuleId,
                 r.TableId,
                 r.Name AS RuleName,
                 r.ValidateCriteriaId AS ValidateCriteria,
                 rc.ConditionalRuleId, 
                 cr.Name AS ConditionalRuleName,
                 rc.Id AS RuleCriteria,
                 rc.Operator, 
                 rc.PredefineQueryId,
                 rc.PredefineQueryName,
                 rc.FieldValue, 
                 rc.FailMessage, 
                 fd.Name AS FieldName,
                 fd.DisplayName,
                 ft.Name AS FieldTypeName, 
                 cr.ValidateCriteriaId AS ConditionalRuleValidateCriteria  
            FROM [{DatabaseSchema.Config.ToSchemaName()}].[Rule] r
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].RuleCriteria rc ON r.Id = rc.RuleId
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination fd ON rc.FieldId = fd.Id
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].FieldType ft ON fd.TypeId = ft.Id 
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].Form f ON r.FormId = f.Id 
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].[Rule] cr ON rc.ConditionalRuleId = cr.Id
            WHERE  
                (r.TableId = @TableId 
                 OR r.FormId IN (SELECT Id FROM [{DatabaseSchema.Config.ToSchemaName()}].Form F WHERE F.TableId = @TableId))
                AND ISNULL(rc.Id,0) > 0;
            ";

            using var connection = new SqlConnection(oldConnectionString);
            var ruleList = await connection.QueryAsync<ClientCardViewFields>(query, new { TableId = tableId });
            return ruleList.ToList();
        }
        public async Task<IEnumerable<ClientMenu>> GetMenuIcon(int ProjectId, string oldConnectionString)
        {
            using var connection = new SqlConnection(oldConnectionString);
            // Query to get the ProjectName for a given clientId and projectId
            var projectName = await connection.QueryAsync<ClientMenu>(ProjectSQLQuery.GetMenuIcon, null);
            return projectName.ToList();
        }
        public async Task<IEnumerable<ClientForm>> GetFormByTableId(int clientId, int projectId, string oldConnectionString)
        {
            //var query = "SELECT FRM.Id,FRM.Name AS Name,FRM.ListProfileId,FRM.ClientId,FRM.TableId,TBL.Name AS TableName,FRM.ProjectId,FRM.ParentId,FRM1.Name AS HeaderFormName,FRM1.ID AS HeaderFormId, FRM2.Name AS DetailFormName,FRM2.ID AS DetailFormId, FRM.SaveReuse, FRM.SaveContinue ,  FRM.IsDocumentEnabled FROM Form AS FRM LEFT JOIN Form AS FRM1 ON FRM.ParentId = FRM1.Id LEFT JOIN TableDefination AS TBL ON FRM.TableId = TBL.ID OUTER APPLY (SELECT TOP 1 ID, Name FROM Form WHERE ParentId = FRM.Id) AS FRM2 WHERE FRM.ClientId = @ClientId AND FRM.ProjectId = @ProjectId order by ISNULL(FRM.TableId,0) ASC";
            //var query = "select * FROM Form WHERE ClientId = @ClientId AND ProjectId = @ProjectId and  TableId = @TableId";

            var query = $"SELECT FRM.Id,FRM.Name AS Name,FRM.ListLabel,FRM.DisplayName,FRM.SearchProfileId,FRM.TableId,TBL.Name AS TableName,FRM.ParentId,FRM1.Name AS HeaderFormName,FRM1.ID AS HeaderFormId, FRM2.Name AS DetailFormName,FRM2.ID AS DetailFormId,PARENT_TBL.Name AS ParentTableName, FRM.SaveReuse, FRM.SaveContinue , FRM.IsAddToList, FRM.IsBarcodePrinting, FRM.IsDocumentEnabled FROM [{DatabaseSchema.Config.ToSchemaName()}].Form AS FRM LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].Form AS FRM1 ON FRM.ParentId = FRM1.Id LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL ON FRM.TableId = TBL.ID  LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS PARENT_TBL ON FRM1.TableId = PARENT_TBL.Id  OUTER APPLY (SELECT TOP 1 ID, Name FROM [{DatabaseSchema.Config.ToSchemaName()}].Form WHERE ParentId = FRM.Id) AS FRM2 order by ISNULL(FRM.TableId,0) ASC";
            using var connection = new SqlConnection(oldConnectionString);  // Dapper will use this connection
            var recordList = await connection.QueryAsync<ClientForm>(query, null);
            return recordList.ToList();
            // Return the list of tables
        }

        public async Task<IEnumerable<ClientForm>> GetFormListByTableId(int clientId, int projectId, int tableId, string oldConnectionString)
        {
            //var query = "SELECT FRM.Id,FRM.Name AS Name,FRM.ListProfileId,FRM.ClientId,FRM.TableId,TBL.Name AS TableName,FRM.ProjectId,FRM.ParentId,FRM1.Name AS HeaderFormName,FRM1.ID AS HeaderFormId, FRM2.Name AS DetailFormName,FRM2.ID AS DetailFormId FROM Form AS FRM LEFT JOIN Form AS FRM1 ON FRM.ParentId = FRM1.Id LEFT JOIN TableDefination AS TBL ON FRM.TableId = TBL.ID OUTER APPLY (SELECT TOP 1 ID, Name FROM Form WHERE ParentId = FRM.Id) AS FRM2 WHERE FRM.ClientId = @ClientId AND FRM.ProjectId = @ProjectId AND FRM.TableId = @TableId";
            var query = $@"SELECT
                FRM.Id,
                FRM.Name AS Name,
                FRM.SearchProfileId,
                TBL.Name AS TableName,
                FRM.ParentId,
                FRM.SaveReuse,
                FRM.SaveContinue,
                FRM.IsAddToList, 
                FRM.IsBarcodePrinting,
                FRM.IsDocumentEnabled,
                FRM1.Name AS HeaderFormName,
                FRM1.ID AS HeaderFormId,
                FRM2.Name AS DetailFormName,
                FRM2.ID AS DetailFormId,

                -- Always show Form-level RuleId if it exists
                RLF.ValidRuleFormId AS RuleFormId,

                -- Table-level RuleId shown only when Form-level rule is NULL or different
                CASE
                    WHEN RLT.ValidRuleTableId IS NOT NULL
                         AND (RLF.ValidRuleFormId IS NULL OR RLF.ValidRuleFormId <> RLT.ValidRuleTableId)
                    THEN RLT.ValidRuleTableId
                    ELSE NULL
                END AS RuleTableId,

                -- Flag: Menu validation
                CASE
                    WHEN FRM.ParentId IS NULL 
                         AND EXISTS (
                             SELECT 1
                             FROM [{DatabaseSchema.Config.ToSchemaName()}].Menu M
                             WHERE M.FormId = FRM.Id
                         ) THEN 1
                    WHEN FRM.ParentId IS NOT NULL
                         AND EXISTS (
                             SELECT 1
                             FROM [{DatabaseSchema.Config.ToSchemaName()}].Menu M
                             WHERE M.FormId = FRM1.Id
                         ) THEN 1
                    ELSE 0
                END AS IsMenuValid

            FROM [{DatabaseSchema.Config.ToSchemaName()}].Form AS FRM
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].Form AS FRM1 ON FRM.ParentId = FRM1.Id
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination AS TBL ON FRM.TableId = TBL.ID

            -- Get first child form (Detail Form)
            OUTER APPLY (
                SELECT TOP 1 ID, Name
                FROM [{DatabaseSchema.Config.ToSchemaName()}].Form
                WHERE ParentId = FRM.Id
            ) AS FRM2

            -- Form-level Rule (only if it has criteria)
            OUTER APPLY (
                SELECT TOP 1 R.Id AS ValidRuleFormId
                FROM [{DatabaseSchema.Config.ToSchemaName()}].[Rule] R
                WHERE R.FormId = FRM.Id
                  AND EXISTS (
                      SELECT 1 FROM [{DatabaseSchema.Config.ToSchemaName()}].RuleCriteria RD WHERE RD.RuleId = R.Id
                  )
            ) AS RLF

            -- Table-level Rule (only if it has criteria and is not assigned to a specific form)
            OUTER APPLY (
                SELECT TOP 1 R.Id AS ValidRuleTableId
                FROM [{DatabaseSchema.Config.ToSchemaName()}].[Rule] R
                WHERE R.TableId = FRM.TableId
                  AND R.FormId IS NULL
                  AND EXISTS (
                      SELECT 1 FROM [{DatabaseSchema.Config.ToSchemaName()}].RuleCriteria RD WHERE RD.RuleId = R.Id
                  )
            ) AS RLT

            WHERE FRM.TableId = @TableId;";

            //var query = "select * FROM Form WHERE ClientId = @ClientId AND ProjectId = @ProjectId and  TableId = @TableId";
            using var connection = new SqlConnection(oldConnectionString);  // Dapper will use this connection
            var recordList = await connection.QueryAsync<ClientForm>(query, new { TableId = tableId });
            return recordList.ToList();
            // Return the list of tables
        }

        public async Task<int?> GetAlignmentTypeById(int id)
        {
            using var connection = _context.CreateConnection();
            var alignmentType = await connection.QuerySingleOrDefaultAsync<int?>(
                "SELECT AlignmentType FROM ProjectManagement WHERE ID = @Id",
                new { Id = id });

            return alignmentType;
        }

        public async Task<IEnumerable<ClientForm>> GetDocumentEnabledForms(int projectId, string oldConnectionString)
        {
            var formQuery = $@"SELECT 
                F.ID, 
                F.Name, 
                F.TableId, 
                F.ParentId, 
                F1.Name AS ParentFormName, 
                F.IsDocumentEnabled, 
                TD.Name AS TableName,
                TD.PrimaryKeyType AS KeyType,
                PKT.Type AS KeyTypeName, 
                TD2.Name AS ParentTableName,

                -- Flag: Menu validation
                CASE
                    WHEN F.ParentId IS NULL 
                         AND EXISTS (
                             SELECT 1 
                             FROM [{DatabaseSchema.Config.ToSchemaName()}].Menu M 
                             WHERE M.FormId = F.Id
                         ) THEN 1
                    WHEN F.ParentId IS NOT NULL
                         AND EXISTS (
                             SELECT 1 
                             FROM [{DatabaseSchema.Config.ToSchemaName()}].Menu M 
                             WHERE M.FormId = F1.Id
                         ) THEN 1
                    ELSE 0
                END AS IsMenuValid

            FROM [{DatabaseSchema.Config.ToSchemaName()}].[Form] AS F
            INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].[TableDefination] AS TD ON F.TableId = TD.ID 
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].[Form] AS F1 ON F.ParentId = F1.ID 
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].[TableDefination] AS TD2 ON F1.TableId = TD2.ID  
            LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].[PrimaryKeyType] AS PKT ON TD.PrimaryKeyType = PKT.ID 

            WHERE F.IsDocumentEnabled = 1;
";
            using var connection = new SqlConnection(oldConnectionString);
            var formList = await connection.QueryAsync<ClientForm>(formQuery, new { ProjectId = projectId });
            return formList.ToList();

        }

        public async Task<IEnumerable<ClientForm>> GetAddToListEnabledForms(int projectId, string oldConnectionString)
        {
            var formQuery = $"SELECT F.ID, F.Name, F.TableId, F.ParentId, F1.Name AS ParentFormName, F.IsAddToList, TD.Name AS TableName, TD2.Name AS ParentTableName FROM [{DatabaseSchema.Config.ToSchemaName()}].[Form] AS F INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].[TableDefination] AS TD ON F.TableId = TD.ID LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].[Form] AS F1 ON F.ParentId = F1.ID LEFT JOIN [{DatabaseSchema.Config.ToSchemaName()}].[TableDefination] AS TD2 ON F1.TableId = TD2.ID WHERE F.IsAddToList = 1";

            using var connection = new SqlConnection(oldConnectionString);
            var formList = await connection.QueryAsync<ClientForm>(formQuery, new { ProjectId = projectId });
            return formList.ToList();
        }
    }
}
