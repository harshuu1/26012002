﻿CREATE TABLE [dbo].[ProjectManagement] (
    [ID]                   INT            IDENTITY (1, 1) NOT NULL,
    [ClientId]             INT            NULL,
    [Name]                 VARCHAR (128)  NULL,
    [Description]          VARCHAR (MAX)  NULL,
    [CreatedBy]            INT            NULL,
    [CreatedDate]          DATETIME       NULL,
    [ModifiedBy]           INT            NULL,
    [ModifiedDate]         DATETIME       NULL,
    [ProjectLogo]          VARCHAR (MAX)  NULL,
    [AlignmentType]        INT            NULL,
    [ClientApiLink]        NVARCHAR (500) NULL,
    [ClientUiLink]         NVARCHAR (500) NULL,
    [IsActive]             BIT            NULL,
    [ConfigurationApiLink] NVARCHAR (500) NULL,
    [ConfigurationUiLink]  NVARCHAR (500) NULL,
    [IsConfigure]          BIT            NULL,
    [IsBuild]              BIT            NULL,
    [ClientAdminApiLink]   NVARCHAR (500) NULL,
    [ClientAdminUiLink]    NVARCHAR (500) NULL,
    CONSTRAINT [PK__ProjectM__3213E83F3FF74156] PRIMARY KEY CLUSTERED ([ID] ASC),
    CONSTRAINT [FK_ProjectManagement1_ClientManagement] FOREIGN KEY ([ClientId]) REFERENCES [dbo].[ClientManagement] ([ID])
);

