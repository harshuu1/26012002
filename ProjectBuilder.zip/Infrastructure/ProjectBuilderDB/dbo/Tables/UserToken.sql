﻿CREATE TABLE [dbo].[UserToken] (
    [ID]          INT            IDENTITY (1, 1) NOT NULL,
    [UserId]      INT            NOT NULL,
    [Token]       VARCHAR (4096) NOT NULL,
    [ExpiryDate]  DATETIME       NOT NULL,
    [CreatedDate] DATETIME       CONSTRAINT [DF__UserToken__Creat__04E4BC85] DEFAULT (getdate()) NULL,
    CONSTRAINT [PK__UserToke__3214EC07303393C6] PRIMARY KEY CLUSTERED ([ID] ASC),
    CONSTRAINT [FK_UserToken_AppUser] FOREIGN KEY ([UserId]) REFERENCES [dbo].[AppUser] ([ID]) ON DELETE CASCADE
);

