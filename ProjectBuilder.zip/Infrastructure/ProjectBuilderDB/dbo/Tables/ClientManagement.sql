﻿CREATE TABLE [dbo].[ClientManagement] (
    [ID]           INT            IDENTITY (1, 1) NOT NULL,
    [FirstName]    VARCHAR (128)  NOT NULL,
    [LastName]     VARCHAR (128)  NOT NULL,
    [PhoneNo]      VARCHAR (16)   NOT NULL,
    [Email]        VARCHAR (128)  NOT NULL,
    [Password]     VARCHAR (1024) NULL,
    [CompanyName]  VARCHAR (128)  NULL,
    [CreatedBy]    INT            NULL,
    [CreatedDate]  DATETIME       NULL,
    [ModifiedBy]   INT            NULL,
    [ModifiedDate] DATETIME       NULL,
    [IsActive]     BIT            NULL,
    CONSTRAINT [PK__ClientMa__3214EC078D7D4D7B] PRIMARY KEY CLUSTERED ([ID] ASC),
    CONSTRAINT [UQ__ClientMa__A9D105349BE9524B] UNIQUE NONCLUSTERED ([Email] ASC)
);

