﻿CREATE TABLE [dbo].[ZDatabaseLog] (
    [ID]              INT            IDENTITY (1, 1) NOT NULL,
    [CreatedDate]     DATETIME       DEFAULT (getdate()) NULL,
    [ChangedBy]       NVARCHAR (100) NULL,
    [ChangeType]      NVARCHAR (50)  NULL,
    [ObjectType]      NVARCHAR (50)  NULL,
    [TableName]       NVARCHAR (255) NULL,
    [Details]         NVARCHAR (MAX) NULL,
    [ScriptApplied]   NVARCHAR (MAX) NULL,
    [TicketReference] NVARCHAR (100) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

