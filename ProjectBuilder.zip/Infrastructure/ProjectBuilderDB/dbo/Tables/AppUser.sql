﻿CREATE TABLE [dbo].[AppUser] (
    [ID]           INT            IDENTITY (1, 1) NOT NULL,
    [FirstName]    VARCHAR (128)  NOT NULL,
    [LastName]     VARCHAR (128)  NOT NULL,
    [PhoneNo]      VARCHAR (16)   NOT NULL,
    [Email]        VARCHAR (128)  NOT NULL,
    [Password]     VARCHAR (1024) NOT NULL,
    [RoleId]       INT            NULL,
    [CreatedBy]    INT            NULL,
    [CreatedDate]  DATETIME       CONSTRAINT [DF__AppUser__Created__6EF57B66] DEFAULT (getdate()) NULL,
    [ModifiedBy]   INT            NULL,
    [ModifiedDate] DATETIME       NULL,
    CONSTRAINT [PK__AppUser__3214EC07EE4F321D] PRIMARY KEY CLUSTERED ([ID] ASC)
);

