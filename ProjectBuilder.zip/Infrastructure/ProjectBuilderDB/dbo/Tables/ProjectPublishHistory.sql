﻿CREATE TABLE [dbo].[ProjectPublishHistory] (
    [Id]               INT            IDENTITY (1, 1) NOT NULL,
    [ProjectId]        INT            NOT NULL,
    [IsBuildConfig]    BIT            CONSTRAINT [DF__ProjectPu__IsBui__4F47C5E3] DEFAULT ((0)) NOT NULL,
    [IsBuildClient]    BIT            CONSTRAINT [DF__ProjectPu__IsBui__503BEA1C] DEFAULT ((0)) NOT NULL,
    [IsConfigDatabase] BIT            CONSTRAINT [DF__ProjectPu__IsCon__51300E55] DEFAULT ((0)) NOT NULL,
    [IsConfigProject]  BIT            CONSTRAINT [DF__ProjectPu__IsCon__5224328E] DEFAULT ((0)) NOT NULL,
    [IsClientDatabase] BIT            CONSTRAINT [DF__ProjectPu__IsCli__531856C7] DEFAULT ((0)) NOT NULL,
    [IsClientProject]  BIT            CONSTRAINT [DF__ProjectPu__IsCli__540C7B00] DEFAULT ((0)) NOT NULL,
    [IsClientAdmin]    BIT            NOT NULL,
    [IsDeleted]        BIT            CONSTRAINT [DF__ProjectPu__IsDel__55009F39] DEFAULT ((0)) NOT NULL,
    [CreatedDate]      DATETIME       CONSTRAINT [DF__ProjectPu__Creat__55F4C372] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]        NVARCHAR (100) NULL,
    [Remark]           NVARCHAR (MAX) NULL,
    CONSTRAINT [PK__ProjectP__3214EC07F6169BE7] PRIMARY KEY CLUSTERED ([Id] ASC)
);

