﻿CREATE PROCEDURE [dbo].[ValidateProjectPorts]
(
    @ProjectId INT = NULL,
    @ClientApiLink NVARCHAR(500) = NULL,
    @ClientUiLink NVARCHAR(500) = NULL,
    @ClientAdminApiLink NVARCHAR(500) = NULL,
    @ClientAdminUiLink NVARCHAR(500) = NULL,
    @ConfigurationApiLink NVARCHAR(500) = NULL,
    @ConfigurationUiLink NVARCHAR(500) = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ErrorMessage NVARCHAR(4000);

    -- ========================================
    -- Prepare ports table
    -- ========================================
    DECLARE @Ports TABLE (Name NVARCHAR(100), Port NVARCHAR(500));
    INSERT INTO @Ports (Name, Port)
    SELECT 'Client API', @ClientApiLink WHERE @ClientApiLink IS NOT NULL UNION ALL
    SELECT 'Client UI', @ClientUiLink WHERE @ClientUiLink IS NOT NULL UNION ALL
    SELECT 'Client Admin API', @ClientAdminApiLink WHERE @ClientAdminApiLink IS NOT NULL UNION ALL
    SELECT 'Client Admin UI', @ClientAdminUiLink WHERE @ClientAdminUiLink IS NOT NULL UNION ALL
    SELECT 'Configuration API', @ConfigurationApiLink WHERE @ConfigurationApiLink IS NOT NULL UNION ALL
    SELECT 'Configuration UI', @ConfigurationUiLink WHERE @ConfigurationUiLink IS NOT NULL;

    -- ========================================
    -- Internal duplicate detection (within same project)
    -- ========================================
    IF EXISTS (
        SELECT Port
        FROM @Ports
        GROUP BY Port
        HAVING COUNT(*) > 1
    )
    BEGIN
        SELECT TOP 1 @ErrorMessage =
            STRING_AGG(Name, ' and ') + 
            ' cannot use the same port (' + Port + ').'
        FROM @Ports
        GROUP BY Port
        HAVING COUNT(*) > 1;

        THROW 51001, @ErrorMessage, 1;
    END

    -- ========================================
    -- Check against reserved system ports
    -- ========================================
    IF EXISTS (SELECT 1 FROM @Ports WHERE Port IN (N'44301', N'44302', N'22301', N'22302'))
    BEGIN
        SELECT TOP 1 @ErrorMessage =
            Name + ' is using reserved system port (' + Port + ').'
        FROM @Ports
        WHERE Port IN (N'44301', N'44302', N'22301', N'22302');

        THROW 51002, @ErrorMessage, 1;
    END

    -- ========================================
    -- Check against other projects (ignore same ProjectId)
    -- ========================================
    DECLARE @Conflict TABLE (ExistingProject NVARCHAR(200), Port NVARCHAR(500), Field NVARCHAR(100));

    INSERT INTO @Conflict (ExistingProject, Port, Field)
    SELECT 'Client API', ClientApiLink, 'ClientApiLink'
    FROM ProjectManagement
    WHERE ClientApiLink IN (SELECT Port FROM @Ports)
      AND (@ProjectId IS NULL OR ID <> @ProjectId)

    UNION ALL
    SELECT 'Client UI', ClientUiLink, 'ClientUiLink'
    FROM ProjectManagement
    WHERE ClientUiLink IN (SELECT Port FROM @Ports)
      AND (@ProjectId IS NULL OR ID <> @ProjectId)

    UNION ALL
    SELECT 'Client Admin API', ClientAdminApiLink, 'ClientAdminApiLink'
    FROM ProjectManagement
    WHERE ClientAdminApiLink IN (SELECT Port FROM @Ports)
      AND (@ProjectId IS NULL OR ID <> @ProjectId)

    UNION ALL
    SELECT 'Client Admin UI', ClientAdminUiLink, 'ClientAdminUiLink'
    FROM ProjectManagement
    WHERE ClientAdminUiLink IN (SELECT Port FROM @Ports)
      AND (@ProjectId IS NULL OR ID <> @ProjectId)

    UNION ALL
    SELECT 'Configuration API', ConfigurationApiLink, 'ConfigurationApiLink'
    FROM ProjectManagement
    WHERE ConfigurationApiLink IN (SELECT Port FROM @Ports)
      AND (@ProjectId IS NULL OR ID <> @ProjectId)

    UNION ALL
    SELECT 'Configuration UI', ConfigurationUiLink, 'ConfigurationUiLink'
    FROM ProjectManagement
    WHERE ConfigurationUiLink IN (SELECT Port FROM @Ports)
      AND (@ProjectId IS NULL OR ID <> @ProjectId);

    IF EXISTS (SELECT 1 FROM @Conflict)
    BEGIN
        SELECT TOP 1 @ErrorMessage =
            (SELECT Name FROM @Ports WHERE Port = c.Port) + 
            ' port (' + c.Port + ') is already used by another project (' + c.ExistingProject + ').'
        FROM @Conflict c;

        THROW 51003, @ErrorMessage, 1;
    END
END