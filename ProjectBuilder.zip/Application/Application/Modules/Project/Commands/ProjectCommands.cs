﻿using Entities.Models.Project;
using MediatR;
using System.Data;

namespace Application.Modules.Project.Commands
{
    public class ProjectCommands
    {
        // Create new project
        public sealed record CreateProjectCommand(ProjectModel Project, string WebRootPath, IDbConnection Connection, IDbTransaction Transaction) : IRequest<string>;

        // Update existing project
        public sealed record UpdateProjectCommand(ProjectModel Project, string WebRootPath) : IRequest<string>;

        // Delete project by ID
        public sealed record DeleteProjectCommand(int Id) : IRequest<string>;
    }
}
