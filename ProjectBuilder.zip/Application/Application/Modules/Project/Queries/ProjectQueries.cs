﻿using Entities.Models.Project;
using Entities.Models.Request;
using Entities.Models.Response;
using MediatR;

namespace Application.Modules.Project.Queries
{
    public class ProjectQueries
    {
        // Get Project by ID
        public sealed record GetProjectByIdQuery(int Id) : IRequest<ProjectModel?>;

        // Get Projects by Client
        public sealed record GetProjectsByClientQuery(int ClientId) : IRequest<IEnumerable<ProjectModel>>;

        // Get Project by Table ID
        public sealed record GetTableByIdQuery(int Id) : IRequest<IEnumerable<ProjectModel>>;

        // Get Project Usage
        public sealed record GetProjectUsageQuery(int ProjectId) : IRequest<List<Dictionary<string, object>>>;

        // Get All Project
        public record GetAllProjectCommand(Request Request) : IRequest<Response>;

        // Get All Project by Client Pagination
        public record GetProjectsByClientIdCommand(int ClientId, Request Request) : IRequest<Response>;
    }
}
