﻿using Entities.Enums;

namespace Application.Modules.Project.Queries
{
    public static class ProjectSQLQuery
    {
        public static string GetProjectById => @"SELECT PM.ID, PM.Name, PM.Description, PM.CreatedBy, PM.CreatedDate, PM.ModifiedBy, PM.ModifiedDate, PM.ProjectLogo, PM.AlignmentType, PM.ClientApiLink, PM.ClientUiLink, PM.ConfigurationApiLink, PM.ConfigurationUiLink, PM.ClientAdminApiLink, PM.ClientAdminUiLink, PM.IsConfigure, PM.IsBuild, PM.IsActive, CM.ID AS ClientId, CM.CompanyName  FROM ProjectManagement PM INNER JOIN ClientManagement CM ON PM.ClientId = CM.ID  WHERE PM.ID = @Id";

        //public static string CreateProject => @"INSERT INTO ProjectManagement (ClientId, Name, Description, CreatedBy, CreatedDate) VALUES (@ClientId, @Name, @Description, @CreatedBy, @CreatedDate)";
        public static string CreateProject => @"INSERT INTO ProjectManagement (ClientId, Name, Description, ProjectLogo, CreatedBy, CreatedDate, AlignmentType, ClientApiLink, ClientUiLink, ConfigurationApiLink, ConfigurationUiLink, ClientAdminApiLink, ClientAdminUiLink, IsActive) VALUES (@ClientId, @Name, @Description, @ProjectLogo, @CreatedBy, @CreatedDate, @AlignmentType, @ClientApiLink, @ClientUiLink, @ConfigurationApiLink, @ConfigurationUiLink, @ClientAdminApiLink, @ClientAdminUiLink, @IsActive);SELECT CAST(SCOPE_IDENTITY() AS INT);";

        public static string UpdateProject => @"UPDATE ProjectManagement SET Name = @Name, Description = @Description, ModifiedBy = @ModifiedBy, ProjectLogo = @ProjectLogo, ModifiedDate = @ModifiedDate, ClientId = @ClientId, AlignmentType = @AlignmentType, ClientApiLink = @ClientApiLink, ClientUiLink = @ClientUiLink, ConfigurationApiLink = @ConfigurationApiLink, ConfigurationUiLink = @ConfigurationUiLink, ClientAdminUiLink=@ClientAdminUiLink, ClientAdminApiLink=@ClientAdminApiLink, IsActive=@IsActive WHERE ID = @Id";

        public static string UpdateConfigureFlag => @"UPDATE ProjectManagement SET IsConfigure = @IsConfigure WHERE ID = @Id";
        public static string UpdateBuildFlag => @"UPDATE ProjectManagement SET IsBuild = @IsBuild WHERE ID = @Id";

        public static string InsertProjectPublishHistory => @"INSERT INTO ProjectPublishHistory
            (ProjectId,IsBuildConfig,IsBuildClient,IsConfigDatabase,IsConfigProject,IsClientDatabase,IsClientProject,IsClientAdmin,IsDeleted, CreatedDate,CreatedBy,Remark)
            VALUES
            (@ProjectId, @IsBuildConfig, @IsBuildClient, @IsConfigDatabase, @IsConfigProject, @IsClientDatabase, @IsClientProject,@IsClientAdmin,0, GETDATE(),@CreatedBy,@Remark);";

        

        public static string DeleteProjectdeleteProjectQuery => "DELETE FROM ProjectManagement WHERE ID = @Id";

        public static string DeleteProjectupdateMenuQuery => "UPDATE Menu SET ProjectId = NULL WHERE ProjectId = @Id";

        public static string GetAllProjectFromClient => "SELECT * FROM ProjectManagement WHERE ClientId = (CASE WHEN @ClientId = 0 THEN ClientId ELSE @ClientId END)";

        public static string GetTableById => "SELECT t.ProjectId, c.ID, c.CompanyName, p.Name FROM TableDefination t INNER JOIN ProjectManagement p ON t.ProjectId = p.ID INNER JOIN ClientManagement c ON p.ClientId = c.ID WHERE t.ID = @Id";

        public static string GetProjectName => "SELECT Name FROM ProjectManagement WHERE ClientId = @ClientId AND ID = @ProjectId";

        public static string GetMenuIcon => $@"SELECT MenuIcon FROM [{DatabaseSchema.Config.ToSchemaName()}].Menu";
        
        public static string GetProjectLogo => "SELECT ProjectLogo FROM ProjectManagement WHERE ID = @ProjectId";
    }
}
