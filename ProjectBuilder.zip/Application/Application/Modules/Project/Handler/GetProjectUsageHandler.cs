﻿using Interfaces;
using MediatR;
using static Application.Modules.Project.Queries.ProjectQueries;

namespace Application.Modules.Project.Handler
{
    public class GetProjectUsageHandler(IProject repository) : IRequestHandler<GetProjectUsageQuery, List<Dictionary<string, object>>>
    {
        private readonly IProject _repository = repository;

        public async Task<List<Dictionary<string, object>>> Handle(GetProjectUsageQuery request, CancellationToken cancellationToken)
        {
            return await _repository.CheckProjectUsageAsync(request.ProjectId);
        }
    }
}