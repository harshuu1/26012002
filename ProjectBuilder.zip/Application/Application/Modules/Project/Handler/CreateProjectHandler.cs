﻿using Interfaces;
using MediatR;
using static Application.Modules.Project.Commands.ProjectCommands;

namespace Application.Modules.Project.Handler
{
    public class CreateProjectHandler(IProject repository) : IRequestHandler<CreateProjectCommand, string>
    {
        private readonly IProject _repository = repository;

        public async Task<string> Handle(CreateProjectCommand request, CancellationToken cancellationToken)
        {
            return await _repository.CreateProject(
                request.Project,
                request.Connection,
                request.Transaction,
                request.WebRootPath
            );
        }
    }
}