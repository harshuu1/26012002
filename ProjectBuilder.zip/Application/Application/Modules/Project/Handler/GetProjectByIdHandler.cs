﻿using Entities.Models.Project;
using Interfaces;
using MediatR;
using Microsoft.Extensions.Configuration;
using static Application.Modules.Project.Queries.ProjectQueries;

namespace Application.Modules.Project.Handler
{
    public class GetProjectByIdHandler(IProject repository, IConfiguration configuration) : IRequestHandler<GetProjectByIdQuery, ProjectModel?>
    {
        private readonly IProject _repository = repository;
        private readonly IConfiguration _configuration = configuration;

        public async Task<ProjectModel?> Handle(GetProjectByIdQuery request, CancellationToken cancellationToken)
        {
            var project = await _repository.GetProjectById(request.Id);
            if (project != null)
                project.IsPublishEnabled = bool.Parse(_configuration["IsPublishClientUsingScript"] ?? "false");

            return project;
        }
    }
}