﻿using Entities.Models.Response;
using Interfaces;
using MediatR;
using static Application.Modules.Project.Queries.ProjectQueries;

namespace Application.Modules.Project.Handler
{
    public class GetAllProjectHandler(IProject repository) : IRequestHandler<GetAllProjectCommand, Response>
    {
        private readonly IProject _repository = repository;

        public async Task<Response> Handle(GetAllProjectCommand request, CancellationToken cancellationToken)
        {
            return await _repository.GetAllProject(request.Request);
        }
    }

}