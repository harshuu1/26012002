﻿using Entities.Models.Project;
using Interfaces;
using MediatR;
using static Application.Modules.Project.Queries.ProjectQueries;

namespace Application.Modules.Project.Handler
{
    public class GetTableByIdHandler(IProject repository) : IRequestHandler<GetTableByIdQuery, IEnumerable<ProjectModel>>
    {
        private readonly IProject _repository = repository;

        public async Task<IEnumerable<ProjectModel>> Handle(GetTableByIdQuery request, CancellationToken cancellationToken)
        {
            return await _repository.GetTableById(request.Id);
        }
    }
}