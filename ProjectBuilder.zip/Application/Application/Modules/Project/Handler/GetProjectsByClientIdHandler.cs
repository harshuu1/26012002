﻿using Entities.Models.Response;
using Interfaces;
using MediatR;
using static Application.Modules.Project.Queries.ProjectQueries;

namespace Application.Modules.Project.Handler
{
    public class GetProjectsByClientIdHandler(IProject repository) : IRequestHandler<GetProjectsByClientIdCommand, Response>
    {
        private readonly IProject _repository = repository;

        public async Task<Response> Handle(GetProjectsByClientIdCommand request, CancellationToken cancellationToken)
        {
            return await _repository.GetAllProjectByClientId(request.ClientId, request.Request);
        }
    }
}