﻿using Entities.Models.Project;
using Interfaces;
using MediatR;
using static Application.Modules.Project.Queries.ProjectQueries;

namespace Application.Modules.Project.Handler
{
    public class GetProjectsByClientHandler(IProject repository) : IRequestHandler<GetProjectsByClientQuery, IEnumerable<ProjectModel>>
    {
        private readonly IProject _repository = repository;

        public async Task<IEnumerable<ProjectModel>> Handle(GetProjectsByClientQuery request, CancellationToken cancellationToken)
        {
            return await _repository.GetAllProjectFromClient(request.ClientId);
        }
    }
}