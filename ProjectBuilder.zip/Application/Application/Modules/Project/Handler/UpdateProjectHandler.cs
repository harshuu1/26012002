﻿using Interfaces;
using MediatR;
using static Application.Modules.Project.Commands.ProjectCommands;

namespace Application.Modules.Project.Handler
{
    public class UpdateProjectHandler(IProject repository) : IRequestHandler<UpdateProjectCommand, string>
    {
        private readonly IProject _repository = repository;

        public async Task<string> Handle(UpdateProjectCommand request, CancellationToken cancellationToken)
        {
            return await _repository.UpdateProject(request.Project, request.WebRootPath);
        }
    }
}