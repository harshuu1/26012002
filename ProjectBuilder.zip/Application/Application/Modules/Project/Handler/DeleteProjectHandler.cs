﻿using Interfaces;
using MediatR;
using static Application.Modules.Project.Commands.ProjectCommands;

namespace Application.Modules.Project.Handler
{
    public class DeleteProjectHandler(IProject repository) : IRequestHandler<DeleteProjectCommand, string>
    {
        private readonly IProject _repository = repository;

        public async Task<string> Handle(DeleteProjectCommand request, CancellationToken cancellationToken)
        {
            return await _repository.DeleteProject(request.Id);
        }
    }
}