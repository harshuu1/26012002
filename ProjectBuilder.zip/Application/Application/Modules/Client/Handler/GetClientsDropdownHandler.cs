﻿using Application.Modules.Client.Queries;
using Entities.Models.Client;
using Interfaces;
using MediatR;

namespace Application.Modules.Client.Handler
{
    public class GetClientsDropdownHandler(IClient repository) : IRequestHandler<GetClientsDropdownQuery, IEnumerable<ClientModel>>
    {
        private readonly IClient _repository = repository;

        public async Task<IEnumerable<ClientModel>> Handle(GetClientsDropdownQuery request, CancellationToken ct) =>
            await _repository.GetAllClient();
    }
}
