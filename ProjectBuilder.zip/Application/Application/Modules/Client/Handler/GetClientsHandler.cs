﻿using Application.Modules.Client.Queries;
using Entities.Models.Client;
using Interfaces;
using MediatR;

namespace Application.Modules.Client.Handler
{
    public class GetClientsHandler(IClient repository) : IRequestHandler<GetClientsQuery, IEnumerable<ClientModel>>
    {
        private readonly IClient _repository = repository;

        public async Task<IEnumerable<ClientModel>> Handle(GetClientsQuery request, CancellationToken ct) =>
            await _repository.GetClient();
    }
}
