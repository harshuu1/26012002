﻿using Application.Modules.Client.Queries;
using Entities.Models.Response;
using Interfaces;
using MediatR;

namespace Application.Modules.Client.Handler
{
    public class GetClientsPagedHandler(IClient repository) : IRequestHandler<GetClientsPagedQuery, Response>
    {
        private readonly IClient _repository = repository;

        public async Task<Response> Handle(GetClientsPagedQuery request, CancellationToken ct) =>
            await _repository.GetAll(request.Request);
    }
}
