﻿using Application.Modules.Client.Queries;
using Entities.Models.Client;
using Interfaces;
using MediatR;

namespace Application.Modules.Client.Handler
{
    public class GetClientByIdHandler(IClient repository) : IRequestHandler<GetClientByIdQuery, ClientModel?>
    {
        private readonly IClient _repository = repository;

        public async Task<ClientModel?> Handle(GetClientByIdQuery request, CancellationToken ct) =>
            await _repository.GetById(request.Id);
    }

}
