﻿using Application.Modules.Client.Commands;
using Interfaces;
using MediatR;

namespace Application.Modules.Client.Handler
{
    public class UpdateClientHandler(IClient repository) : IRequestHandler<UpdateClientCommand, string>
    {
        private readonly IClient _repository = repository;

        public async Task<string> Handle(UpdateClientCommand request, CancellationToken ct) =>
            await _repository.Update(request.Client);
    }
}
