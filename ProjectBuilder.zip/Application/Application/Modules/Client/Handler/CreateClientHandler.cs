﻿using Application.Modules.Client.Commands;
using Interfaces;
using MediatR;

namespace Application.Modules.Client.Handler
{
    public class CreateClientHandler(IClient repository) : IRequestHandler<CreateClientCommand, (string message, int clientId)>
    {
        private readonly IClient _repository = repository;

        public async Task<(string message, int clientId)> Handle(CreateClientCommand request, CancellationToken ct) =>
            await _repository.Create(request.Client);
    }
}
