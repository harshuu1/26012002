﻿using Application.Modules.Client.Commands;
using Interfaces;
using MediatR;

namespace Application.Modules.Client.Handler
{
    public class DeleteClientHandler(IClient repository) : IRequestHandler<DeleteClientCommand, string>
    {
        private readonly IClient _repository = repository;

        public async Task<string> Handle(DeleteClientCommand request, CancellationToken ct) =>
            await _repository.Delete(request.Id);
    }
}
