﻿namespace Application.Modules.Client.Queries
{
    public static class ClientSQLQuery
    {
        public static string GetClient => "SELECT *, CONCAT(FirstName,' ',LastName,'_',CompanyName) as [Name] FROM ClientManagement ORDER BY [Name] ASC";

        public static string GetById => "Select *, CONCAT(FirstName,' ',LastName,'_',CompanyName) as [Name] From ClientManagement WHERE ID=@Id ORDER BY [Name] ASC";

        public static string GetAllClient => "SELECT *, CONCAT(FirstName,' ',LastName,'_',CompanyName) as [Name] FROM ClientManagement ORDER BY [Name] ASC";

        public static string Create_checkQuery => @" SELECT COUNT(*) FROM ClientManagement WHERE (Lower(FirstName) = Lower(@FirstName) AND Lower(LastName) = Lower(@LastName)) OR Lower(Email) = Lower(@Email)";

        public static string Create_insertQuery => @"INSERT INTO ClientManagement (FirstName, LastName, PhoneNo, Email, Password, CreatedBy, CreatedDate, CompanyName,IsActive) VALUES (@FirstName, @LastName, @PhoneNo, @Email, @Password, @CreatedBy, GETDATE(), @CompanyName , @IsActive);
          SELECT CAST(SCOPE_IDENTITY() AS int);";

        public static string Update_checkQuery => @"SELECT COUNT(*) FROM ClientManagement WHERE ID != @Id AND ((LOWER(FirstName) = LOWER(@FirstName) AND LOWER(LastName) = LOWER(@LastName))OR LOWER(Email) = LOWER(@Email))";

        public static string Update_updateQuery => @"UPDATE ClientManagement SET FirstName = @FirstName,LastName = @LastName,PhoneNo = @PhoneNo,Email = @Email,Password = @Password,ModifiedBy = @ModifiedBy,ModifiedDate = GETDATE(),CompanyName = @CompanyName,IsActive=@IsActive WHERE ID = @Id";

        public static string Delete => "DELETE  From ClientManagement WHERE ID=@Id";
        public static string GetClientName => "SELECT FirstName, LastName,'_',CompanyName FROM ClientManagement WHERE ID = @ClientId ";
    }
}
