﻿using Entities.Models.Client;
using Entities.Models.Request;
using Entities.Models.Response;
using MediatR;

namespace Application.Modules.Client.Queries
{
    // Get all clients
    public sealed record GetClientsQuery() : IRequest<IEnumerable<ClientModel>>;

    // Get client by Id
    public sealed record GetClientByIdQuery(int Id) : IRequest<ClientModel?>;

    // Get all clients (For dropdown)
    public sealed record GetClientsDropdownQuery() : IRequest<IEnumerable<ClientModel>>;

    // Get all clients (Pagination)
    public sealed record GetClientsPagedQuery(Request Request) : IRequest<Response>;
}
