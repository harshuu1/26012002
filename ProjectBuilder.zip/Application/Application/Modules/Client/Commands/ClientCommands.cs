﻿using Entities.Models.Client;
using MediatR;

namespace Application.Modules.Client.Commands
{
    // Create new client
    public sealed record CreateClientCommand(ClientModel Client) : IRequest<(string message, int clientId)>;

    // Update existing client
    public sealed record UpdateClientCommand(ClientModel Client) : IRequest<string>;

    // Delete client by ID
    public sealed record DeleteClientCommand(int Id) : IRequest<string>;
}
