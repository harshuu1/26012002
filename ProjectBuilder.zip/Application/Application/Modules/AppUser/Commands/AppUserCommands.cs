﻿using Entities.Models.AppUser;
using MediatR;

namespace Application.Modules.AppUser.Commands
{
    // Create new user
    public sealed record CreateAppUserCommand(AppUserModel AppUser) : IRequest<(string Message, bool Success)>;

    // Update existing user
    public sealed record UpdateAppUserCommand(AppUserModel AppUser, bool statusOnly = false) : IRequest<(string Message, bool Success)>;

    // Login user
    public sealed record LoginUserCommand(string Email, string Password) : IRequest<AuthUserModel?>;

    // Delete user by ID
    public sealed record DeleteAppUserCommand(int Id) : IRequest<(string Message, bool Success)>;
}
