﻿using Entities.Models.AppUser;
using MediatR;

namespace Application.Modules.AppUser.Queries
{
    // Get all users
    public sealed record GetAllAppUsers() : IRequest<List<AppUserModel>>;

    // Get user by Id
    public sealed record GetAppUserById(int Id) : IRequest<AppUserModel?>;

    // Check if email exists
    public sealed record CheckEmailExists(string Email, int UserId = 0) : IRequest<bool>;
}
