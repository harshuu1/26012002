﻿namespace Application.Modules.AppUser.Queries
{
    public static class AppUserSQLQuery
    {
        public static string GetAllUser => "SELECT ID, FirstName, LastName, (FirstName + ' ' + LastName) AS Name, PhoneNo, Email, RoleId,IsActive FROM AppUser";
        public static string GetUserById => "SELECT ID, FirstName, LastName, PhoneNo, Email, Password, RoleId, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate,IsActive FROM AppUser WHERE ID = @Id";
        public static string CreateUser => @"INSERT INTO AppUser(FirstName, LastName, PhoneNo, Email, Password, RoleId, CreatedBy, CreatedDate,IsActive)  
                  VALUES (@FirstName, @LastName, @PhoneNo, @Email, @Password, @RoleId, @CreatedBy, @CreatedDate, @IsActive)";
        public static string UpdateUser => @"
                UPDATE AppUser 
                SET 
                FirstName = @FirstName, 
                LastName = @LastName, 
                PhoneNo = @PhoneNo, 
                Email = @Email,
                Password = @Password,
                RoleId = @RoleId, 
                ModifiedBy = @ModifiedBy, 
                ModifiedDate = @ModifiedDate,
                IsActive = @IsActive
                WHERE ID = @id;";
        public static string DeleteUser => "DELETE FROM AppUser WHERE ID = @id";
        public static string GetUserByEmail => " SELECT AppUser.*, AppUser.IsActive, CASE WHEN AppUser.IsActive = 1 THEN 'OK'WHEN AppUser.IsActive = 0 THEN 'ERROR: User account is inactive.' ELSE 'ERROR: User not found.' END AS LoginStatus FROM AppUser WHERE Email = @Email";
        public static string GetUserByPassword => "SELECT * FROM AppUser WHERE Password = @Password";
        public static string SaveJWT => @"INSERT INTO UserToken (UserId, Token, ExpiryDate, CreatedDate) 
                                 VALUES (@UserId, @Token, @ExpiryDate, @CreatedDate)";

    }
}
