﻿using Application.Modules.AppUser.Queries;
using Entities.Models.AppUser;
using Interfaces;
using MediatR;

namespace Application.Modules.AppUser.Handler
{
    public class GetAllAppUsersHandler(IAppUser repository) : IRequestHandler<GetAllAppUsers, List<AppUserModel>>
    {
        private readonly IAppUser _repository = repository;

        public async Task<List<AppUserModel>> Handle(GetAllAppUsers request, CancellationToken cancellationToken)
        {
            var users = await _repository.GetAllAppUser();
            return users.ToList();
        }
    }
}
