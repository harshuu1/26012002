﻿using Application.Modules.AppUser.Commands;
using Interfaces;
using MediatR;

namespace Application.Modules.AppUser.Handler
{
    public class DeleteAppUserHandler(IAppUser repository) : IRequestHandler<DeleteAppUserCommand, (string Message, bool Success)>
    {
        private readonly IAppUser _repository = repository;

        public async Task<(string Message, bool Success)> Handle(DeleteAppUserCommand request, CancellationToken cancellationToken)
        {
            var result = await _repository.DeleteAppUser(request.Id);
            bool success = result.Contains("deleted successfully");
            return (result, success);
        }
    }
}
