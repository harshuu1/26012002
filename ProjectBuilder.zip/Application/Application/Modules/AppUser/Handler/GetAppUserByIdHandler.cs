﻿using Application.Modules.AppUser.Queries;
using Entities.Models.AppUser;
using Interfaces;
using MediatR;

namespace Application.Modules.AppUser.Handler
{
    public class GetAppUserByIdHandler(IAppUser repository) : IRequestHandler<GetAppUserById, AppUserModel?>
    {
        private readonly IAppUser _repository = repository;

        public async Task<AppUserModel?> Handle(GetAppUserById request, CancellationToken cancellationToken)
        {
            return await _repository.GetAppUserById(request.Id);
        }
    }
}
