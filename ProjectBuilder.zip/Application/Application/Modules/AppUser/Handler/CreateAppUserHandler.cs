﻿using Application.Modules.AppUser.Commands;
using Interfaces;
using MediatR;

namespace Application.Modules.AppUser.Handler
{
    public class CreateAppUserHandler(IAppUser repository) : IRequestHandler<CreateAppUserCommand, (string Message, bool Success)>
    {
        private readonly IAppUser _repository = repository;

        public async Task<(string Message, bool Success)> Handle(CreateAppUserCommand request, CancellationToken cancellationToken)
        {
            var result = await _repository.CreateAppUser(request.AppUser);

            bool success = !(result.Contains("already in use"));
            return (result, success);
        }
    }
}
