﻿using Application.Modules.AppUser.Queries;
using Interfaces;
using MediatR;

namespace Application.Modules.AppUser.Handler
{
    public class CheckEmailExistsHandler(IAppUser repository) : IRequestHandler<CheckEmailExists, bool>
    {
        private readonly IAppUser _repository = repository;

        public async Task<bool> Handle(CheckEmailExists request, CancellationToken cancellationToken)
        {
            var existingUser = await _repository.GetUserByEmail(request.Email);
            return existingUser != null && existingUser.ID != request.UserId;
        }
    }
}
