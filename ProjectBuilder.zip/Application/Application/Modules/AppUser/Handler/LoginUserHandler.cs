﻿using Application.Modules.AppUser.Commands;
using Entities.Models.AppUser;
using Interfaces;
using MediatR;

namespace Application.Modules.AppUser.Handler
{
    public class LoginUserHandler(IAppUser repository) : IRequestHandler<LoginUserCommand, AuthUserModel?>
    {
        private readonly IAppUser _repository = repository;

        public async Task<AuthUserModel?> Handle(LoginUserCommand request, CancellationToken cancellationToken)
        {
            return await _repository.AuthenticateUser(request.Email, request.Password);
        }
    }

}
