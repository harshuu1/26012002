﻿using Application.Modules.AppUser.Commands;
using Interfaces;
using MediatR;

namespace Application.Modules.AppUser.Handler
{
    public class UpdateAppUserHandler(IAppUser repository) : IRequestHandler<UpdateAppUserCommand, (string Message, bool Success)>
    {
        private readonly IAppUser _repository = repository;

        public async Task<(string Message, bool Success)> Handle(UpdateAppUserCommand request, CancellationToken cancellationToken)
        {
            var result = await _repository.UpdateAppUser(request.AppUser, request.statusOnly);

            bool success = result.Contains("successfully");
            return (result, success);
        }
    }
}
