﻿using Application.Modules.AppUser.Handler;
using Microsoft.Extensions.DependencyInjection;

namespace ApplicationDI
{
    public static class ApplicationDependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            // MediatR registration (scan Application assembly)
            services.AddMediatR(cfg =>
            {
                // Register handlers from AppUser module
                cfg.RegisterServicesFromAssemblyContaining<GetAllAppUsersHandler>();

            });

            //services.AddAutoMapper(cfg => { },
            //    Assembly.GetExecutingAssembly(),
            //    typeof(ProjectProfile).Assembly);

            return services;
        }
    }
}
