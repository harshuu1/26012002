﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.Text.Json;

namespace ProjectBuilder.MvcUI.Heplers
{
    public class PersistentCookieTempDataProvider : ITempDataProvider
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string _cookieName = ".AspNetCore.Mvc.CookieTempDataProvider";

        public PersistentCookieTempDataProvider(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public IDictionary<string, object> LoadTempData(HttpContext context)
        {
            if (context.Request.Cookies.TryGetValue(_cookieName, out var cookieValue))
            {
                try
                {
                    var dictionary = JsonSerializer.Deserialize<Dictionary<string, object>>(cookieValue);
                    return dictionary ?? new Dictionary<string, object>();
                }
                catch
                {
                    // If deserialization fails, return empty dictionary
                    return new Dictionary<string, object>();
                }
            }

            return new Dictionary<string, object>();
        }

        public void SaveTempData(HttpContext context, IDictionary<string, object> values)
        {
            if (values == null || values.Count == 0)
            {
                // Clear cookie if no data
                context.Response.Cookies.Delete(_cookieName);
                return;
            }

            var json = JsonSerializer.Serialize(values);

            var options = new CookieOptions
            {
                Expires = DateTimeOffset.UtcNow.AddDays(30), // persist for 30 days
                HttpOnly = true,
                Secure = true,
                IsEssential = true
            };

            context.Response.Cookies.Append(_cookieName, json, options);
        }
    }
}