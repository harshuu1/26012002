﻿let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".bx-menu");
let arrows = document.querySelectorAll(".arrow");

// Toggle menu on button click
sidebarBtn.addEventListener("click", () => {
    sidebar.classList.toggle("close");
});

// Expand sidebar on hover
sidebar.addEventListener("mouseenter", () => {
    sidebar.classList.remove("close");
});

// Collapse sidebar when mouse leaves
sidebar.addEventListener("mouseleave", () => {
    sidebar.classList.add("close");
});

// Dropdown functionality for submenus
arrows.forEach(arrow => {
    arrow.addEventListener("click", (e) => {
        let arrowParent = e.target.parentElement.parentElement; // Selecting main parent of arrow
        arrowParent.classList.toggle("showMenu");
    });
});