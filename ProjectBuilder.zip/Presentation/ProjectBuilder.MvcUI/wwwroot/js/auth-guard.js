﻿// auth-guard.js
(function () {
    'use strict';

    let expirationCheckInterval = null;

    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    }

    function parseJwt(token) {
        try {
            const base64Url = token.split('.')[1];
            const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
            const jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
            }).join(''));
            return JSON.parse(jsonPayload);
        } catch (e) {
            console.error('Error parsing JWT:', e);
            return null;
        }
    }

    function isTokenExpired(token) {
        if (!token) return true;

        const decoded = parseJwt(token);
        if (!decoded || !decoded.exp) {
            return true;
        }

        const expirationTime = decoded.exp * 1000; // Convert to milliseconds
        const currentTime = Date.now();

        return currentTime >= expirationTime;
    }

    function clearAuthCookies() {
        document.cookie = "jwtToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        document.cookie = "isAuthenticated=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    }

    function redirectToLogin(reason) {
        console.log(`⚠️ ${reason}. Redirecting to login...`);
        clearAuthCookies();

        // Stop the interval to prevent multiple redirects
        if (expirationCheckInterval) {
            clearInterval(expirationCheckInterval);
        }

        window.location.replace("/auth/login");
    }

    function checkTokenExpiration() {
        const token = getCookie("jwtToken");

        if (!token) {
            redirectToLogin("No token found");
            return false;
        }

        if (isTokenExpired(token)) {
            redirectToLogin("Token expired");
            return false;
        }

        return true;
    }

    function startTokenMonitoring() {
        console.log("✅ Token monitoring started");

        // Check immediately on page load
        if (!checkTokenExpiration()) {
            return;
        }

        // Check every 10 seconds (you can adjust this interval)
        expirationCheckInterval = setInterval(() => {
            checkTokenExpiration();
        }, 10000); // 10 seconds
    }

    // Initialize on page load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startTokenMonitoring);
    } else {
        startTokenMonitoring();
    }

    // Also check when page becomes visible again (user switches back to tab)
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) {
            checkTokenExpiration();
        }
    });

    // Check before page unload/refresh
    window.addEventListener('beforeunload', function () {
        checkTokenExpiration();
    });

    // Make functions globally available if needed
    window.checkTokenExpiration = checkTokenExpiration;

})();
