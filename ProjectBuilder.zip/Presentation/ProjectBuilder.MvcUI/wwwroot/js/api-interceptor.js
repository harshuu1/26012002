﻿// api-interceptor.js (add this AFTER auth-guard.js)
(function () {
    'use strict';

    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    }

    function clearAuthCookies() {
        document.cookie = "jwtToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        document.cookie = "isAuthenticated=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    }

    // Intercept fetch API
    const originalFetch = window.fetch;
    window.fetch = function (...args) {
        return originalFetch(...args).then(response => {
            if (response.status === 401) {
                console.log("⚠️ 401 Unauthorized received. Token expired. Redirecting...");
                clearAuthCookies();
                window.location.replace("/auth/login");
                return Promise.reject(new Error('Unauthorized'));
            }
            return response;
        }).catch(error => {
            // Handle network errors
            return Promise.reject(error);
        });
    };

    // Intercept XMLHttpRequest (for older code)
    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
        this._url = url;
        return originalOpen.apply(this, [method, url, ...rest]);
    };

    XMLHttpRequest.prototype.send = function (...args) {
        this.addEventListener('load', function () {
            if (this.status === 401) {
                console.log("⚠️ 401 Unauthorized received. Token expired. Redirecting...");
                clearAuthCookies();
                window.location.replace("/auth/login");
            }
        });
        return originalSend.apply(this, args);
    };

})();