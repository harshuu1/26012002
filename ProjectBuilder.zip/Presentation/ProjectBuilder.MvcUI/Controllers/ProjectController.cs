﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectBuilder.MvcUI.Controllers
{
    public class ProjectController : Controller
    {
        public IActionResult ProjectList()
        {
            return PartialView();
        }

        [HttpPost]
        public IActionResult ProjectDetails(int ProjectID, int ClientId, string ClientName)
        {
            TempData["ProjectID"] = ProjectID; // store for the redirect
            TempData["ClientId"] = ClientId;
            TempData["Name"] = ClientName;
            return Ok(); // AJAX post expects an OK response
        }

        [HttpGet]
        public IActionResult ProjectDetails()
        {      
           
      
            ViewBag.ProjectID = TempData["ProjectID"];
            ViewBag.ClientId = TempData["ClientId"];
            ViewBag.ClientName = TempData["Name"];
            TempData.Keep("ProjectID");
            TempData.Keep("ClientId");
            TempData.Keep("Name");
            return View();
        }

        [HttpPost]
        public IActionResult ClearProjectId()
        {
            TempData.Remove("ProjectID");
            return Ok();
        }
    }
}
