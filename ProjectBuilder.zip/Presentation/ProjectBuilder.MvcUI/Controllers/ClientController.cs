﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectBuilder.MvcUI.Controllers
{
    public class ClientController : Controller
    {
        public IActionResult ProjectList(int clientId)
        {
            ViewBag.ClientId = clientId;

            return PartialView("ProjectList"); // make sure this points to your grid view
        }

        public IActionResult ClientList()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ClientDetails(int clientId)
        {
            TempData["ClientId"] = clientId; // store for the redirect
            return Ok(); // AJAX post expects an OK response
        }

        [HttpGet]
        public IActionResult ClientDetails()
        {
            ViewBag.ClientId = TempData["ClientId"]; // retrieve it in the redirected request
            TempData.Keep("ClientId");
            return View();
        }

        [HttpPost]
        public IActionResult ClearClientId()
        {
            TempData.Remove("ClientId");
            return Ok();
        }

    }
}
