﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectBuilder.MvcUI.Controllers
{
    public class AuthController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
    }
}
