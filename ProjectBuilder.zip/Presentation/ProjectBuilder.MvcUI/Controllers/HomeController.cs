using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ProjectBuilder.MvcUI.Models;

namespace ProjectBuilder.MvcUI.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        
        public IActionResult Dashboard()
        {
            return View();
        }
        public IActionResult Drilldowns()
        {
            return View();
        }

        public IActionResult AreaChart()
        {
            return View();

        }
        public IActionResult PyramidChart()
        {
            return View();
        }

        public IActionResult LineChart()
        {
            return View();
        }
        public IActionResult StockChart()
        {
            return View();
        }


        public IActionResult KendoScatterChart()
        {
            return View();
        }
        public IActionResult BubbleChart()
        {
            return View();
        }

        public IActionResult BoxPlotChart()
        {
            return View();
        }

        public IActionResult BulletChart()
        {
            return View();
        }
        public IActionResult KendoDonutChart()
        {
            return View();
        }
        public IActionResult RadarChart()
        {
            return View();
        }

        public IActionResult BarChart()
        {
            return View();
        }
        public IActionResult WaterFallChart()
        {
            return View();
        }

        public IActionResult FunnelChart()
        {
            return View();
        }
        public IActionResult PolarChart()
        {
            return View();
        }

        public IActionResult RangeBarChart()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        //public IActionResult RadarChart()
        //{
        //    return View();
        //}
        //public IActionResult KendoDonutChart()
        //{
        //    return View();
        //}


    }
}

