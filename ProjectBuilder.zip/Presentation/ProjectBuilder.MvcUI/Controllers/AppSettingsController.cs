﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectBuilder.MvcUI.Controllers
{
    public class AppSettingsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetSettings()
        {
            return View();
        }

        public IActionResult CreateSettings()
        {
            return View();
        }
    }
}
