﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectBuilder.MvcUI.Controllers
{
    public class UserController : Controller
    {
        [HttpPost]
        public IActionResult UserDetail(int id)
        {
            TempData["id"] = id; // store for the redirect
            return Ok(); // AJAX post expects an OK response
        }

        [HttpGet]
        public IActionResult UserDetail()
        {
            ViewBag.id = TempData["id"];
            TempData.Keep("id");
            return View();
        }

        public IActionResult UserList()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ClearUserId()
        {
            TempData.Remove("id");
            return Ok();
        }
    }
}
