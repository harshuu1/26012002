namespace ProjectBuilder.MvcUI.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}

// Class to store backend settings
public class BackendSettings
{
    public string? BackendUrl { get; set; }
}
