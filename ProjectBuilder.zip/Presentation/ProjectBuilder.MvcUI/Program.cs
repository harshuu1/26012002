using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.FileProviders;
using ProjectBuilder.MvcUI.Heplers;

var builder = WebApplication.CreateBuilder(args);

var EnvironmentName = builder.Environment.EnvironmentName;
var configuration = new ConfigurationBuilder().AddJsonFile(EnvironmentName == "" ? $"appsettings.json" : $"appsettings.{EnvironmentName}.json", optional: true, reloadOnChange: true).Build();

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddHttpContextAccessor();

// Register our Persistent Cookie TempData Provider
builder.Services.AddSingleton<ITempDataProvider, PersistentCookieTempDataProvider>();

// Retrieve backend URL from appsettings.json
var backendUrl = builder.Configuration["BackendApiUrl"];

// Make backend URL available globally
builder.Services.AddSingleton(new BackendSettings { BackendUrl = backendUrl });



// Extract the first HTTPS URL from launchSettings.json
//var backendUrl = builder.Configuration["iisSettings:iisExpress:applicationUrl"] != null
//    ?
//    builder.Configuration["iisSettings:iisExpress:applicationUrl"]?.Split(':').FirstOrDefault(url => url.StartsWith("https://localhost")) + builder.Configuration["iisSettings:iisExpress:sslPort"]?.ToString()
//    :
//    null;
//builder.Configuration["BackendApiUrl"];




var app = builder.Build();


// Pass backend URL to views using middleware
app.Use(async (context, next) =>
{
    context.Items["BackendUrl"] = backendUrl;
    await next();
});

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

// Serve local Kendo backup folder
var kendoLocalPath = @"C:\Telerik\Kendo";
if (Directory.Exists(kendoLocalPath))
{
    app.UseStaticFiles(new StaticFileOptions
    {
        FileProvider = new PhysicalFileProvider(kendoLocalPath),
        RequestPath = "/Telerik/Kendo"
    });
}

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Auth}/{action=Login}/{id?}");

app.Run();
