﻿using Application.Modules.Client.Commands;
using Application.Modules.Client.Queries;
using Entities.Models.Client;
using Entities.Models.Request;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ProjectBuilder.Api.Controllers
{
    [Route("client")]
    [ApiController]
    public class ClientController(ISender sender) : ControllerBase
    {
        #region Member Variables

        private readonly ISender _sender = sender;

        #endregion

        #region GET

        [HttpGet("/clients")]
        public async Task<IActionResult> GetClient()
        {
            return Ok(await _sender.Send(new GetClientsQuery()));
        }

        [Authorize]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            return Ok(await _sender.Send(new GetClientByIdQuery(id)));
        }

        #endregion

        #region POST & PUT

        [Authorize]
        [HttpPost("dropdown")]
        public async Task<IActionResult> GetAllClient()
        {
            return Ok(await _sender.Send(new GetClientsDropdownQuery()));
        }

        [Authorize]
        [HttpPost("/clients")]
        public async Task<IActionResult> GetAll([FromBody] Request request)
        {
            return Ok((await _sender.Send(new GetClientsPagedQuery(request))).ToResult());
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] ClientModel client)
        {
            var (message, clientId) = await _sender.Send(new CreateClientCommand(client));
            return Ok(new { message, clientId });
        }

        [Authorize]
        [HttpPut]
        public async Task<IActionResult> Update([FromBody] ClientModel client)
        {
            if (client.ID == 0)
                return BadRequest("ID is required for update.");

            return Ok(await _sender.Send(new UpdateClientCommand(client)));
        }

        #endregion

        #region DELETE

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _sender.Send(new DeleteClientCommand(id)));
        }

        #endregion
    }
}
