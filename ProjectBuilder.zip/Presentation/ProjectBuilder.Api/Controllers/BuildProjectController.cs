﻿using Application.Modules.Project.Queries;
using Dapper;
using DapperDB;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientClasses;
using Entities.Models.ClientBuilderModels.ClientModels;
using Entities.Models.Project;
using Interfaces.ClientBuilderInterfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Serilog;
using System.Diagnostics;
using System.Reflection;

namespace ProjectBuilder.Api.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BuildProjectController(ITable table, IConfiguration configuration, DapperDbContext.DbContext context, IFields fields, IWebHostEnvironment env) : ControllerBase
    {

        private readonly ITable _table = table;
        private readonly IFields _fields = fields;
        private readonly DapperDbContext.DbContext _context = context;
        private readonly IWebHostEnvironment _env = env;
        private readonly IConfiguration _configuration = configuration;

        [HttpGet]
        [Route("/buildProject")]
        public async Task<IActionResult> Add(int ClientId, int ProjectId)
        {
            var clientName = await _table.GetClientName(ClientId);
            var projectName = await _table.GetProjectName(ClientId, ProjectId);
            int alignmentType = await _table.GetAlignmentTypeById(ProjectId) ?? 0;

            //Create config connectionstring
            string configDatabase = $"{projectName}_Configuration";
            var configConnectionString = string.Empty;
            string adminConnectionString = _configuration.GetConnectionString("DefaultConnection") ?? "";
            var currBuilder = new SqlConnectionStringBuilder(adminConnectionString);
            string currDatabase = currBuilder.InitialCatalog;
            configConnectionString = adminConnectionString.Replace($"{currDatabase}", configDatabase);

            _context.SetConnection(configConnectionString);
            var originalConnectionString = configConnectionString;

            using (var connection = _context.CreateConnection())
            {
                string checkMenuQuery = $@"SELECT COUNT(*) FROM [{DatabaseSchema.Config.ToSchemaName()}].Menu WHERE FormId IS NOT NULL OR TableId IS NOT NULL";
                //string checkMenuQuery = $@"SELECT COUNT(*) FROM [{configDatabase}].[dbo].[Menu]  WHERE FormId IS NOT NULL OR TableId IS NOT NULL";

                var existingCount = await connection.ExecuteScalarAsync<int>(checkMenuQuery);

                if (existingCount == 0)
                {
                    return BadRequest();
                }
            }

            var GetallTableList = await _table.GetTableById(ClientId, ProjectId);
            List<string> allCheckboxMappingSqls = [];
            List<string> mappingtableList = [];
            List<string> documentMappingTables = [];

            AlterFolderAndDatabaseClass alterFolderAndDatabaseClass = new(_context, configuration);
            BuildCreateTableQueryClass buildCreateTableQueryClass = new(_context, configuration);
            CopyFolderContentsClass copyFolderContentsClass = new();
            CreateMenuTableClass createMenuTableClass = new(_context);
            CreateFormTableClass createFormTableClass = new(_context);
            GenerateAddEditFormClass generateAddEditFormClass = new(_context, _configuration);
            GenerateControllerClass generateControllerClass = new();
            GenerateApplicationLayerClass generateApplicationLayerClass = new();
            GenerateDetailListingWithGridClass generateDetailListingWithGridClass = new();
            GenerateFormActionsClass generateFormActionsClass = new();
            GenerateImportProfileViews generateImportProfileViews = new();
            GenerateInterfaceCodeClass generateInterfaceCodeClass = new();
            GenerateListingWithSearchAndGridClass generateListingWithSearchAndGridClass = new(_context, _configuration);
            GenerateModelCodeClass generateModelCodeClass = new(_context);
            GenerateProgramCodeClass generateProgramCodeClass = new();
            GenerateRepositoryCodeForModelClass generateRepositoryCodeForModelClass = new(_context, _configuration);
            SendConnectionStringClass sendConnectionStringClass = new();
            GenerateRuleClass generateRuleClass = new();
            GenerateXUnitTest generateXUnitTest = new();
            GenerateFormDocumentClass generateFormDocumentClass = new();


            string fullFolderPath = string.Empty;
            try
            {
                string databaseName = $"{projectName}_{clientName}".Replace(" ", "_").Replace("-", "_").ToUpper();
                string? rootPath = _configuration.GetSection("ProjectRootPath")["RootPath"];
                string? baseProjectRoot = _configuration["BaseProjectRootPath:BaseClientProjectBuilderPath"];
                if (string.IsNullOrWhiteSpace(rootPath))
                {
                    return StatusCode(500, "Configuration value for 'ProjectRootPath:RootPath' is missing.");
                }

                if (string.IsNullOrWhiteSpace(baseProjectRoot))
                {
                    return StatusCode(500, "Configuration value for 'BaseProjectRootPath:BaseClientProjectBuilderPath' is missing.");
                }
                string folderName = $"{clientName}";
                fullFolderPath = Path.Combine(rootPath, folderName);
                string parentFolderPath = fullFolderPath;
                string childFolderPath = Path.Combine(parentFolderPath, projectName.Replace(" ", "_").Replace("-", "_"));

                //if folder is exist then delete first
                //if (Directory.Exists(childFolderPath))
                //{
                //    Directory.Delete(childFolderPath, recursive: true);
                //}
                // Then create the directory
                //Directory.CreateDirectory(childFolderPath);

                var foldersToDelete = new List<string>
                {
                    @"Application",
                    @"Domain",
                    @"Infrastructure",
                    @"Presentation\ClientProjectBuilder.Api\Controllers",
                    @"Presentation\ClientProjectBuilder.MvcUI",
                    @"Presentation\ClientAdmin.Api\Controllers",
                    @"Presentation\ClientAdmin.MvcUI",
                    @"XunitWeb"
                };

                if (Directory.Exists(childFolderPath))
                {
                    foreach (var folder in foldersToDelete)
                    {
                        string targetPath = Path.Combine(childFolderPath, folder);

                        if (Directory.Exists(targetPath))
                        {
                            Directory.Delete(targetPath, true);
                        }
                    }
                }
                else
                {
                    Directory.CreateDirectory(childFolderPath);
                }

                string? baseAdminClientRoot = _configuration["BaseProjectRootPath:BaseProjectPath"] ?? "";

                // Admin Folder In Client Project
                string childAdminFolderPath = Path.Combine(
                    parentFolderPath,
                    projectName.Replace(" ", "_").Replace("-", "_") + "_Admin"
                );

                if (Directory.Exists(childAdminFolderPath))
                {
                    foreach (var folder in foldersToDelete)
                    {
                        string targetPath = Path.Combine(childAdminFolderPath, folder);

                        if (Directory.Exists(targetPath))
                        {
                            Directory.Delete(targetPath, true);
                        }
                    }
                }
                else
                {
                    Directory.CreateDirectory(childFolderPath);
                }

                string newConnectionString = string.Empty;
                //string? originalConnectionString = _configuration.GetConnectionString("DefaultConnection");
                //if (string.IsNullOrWhiteSpace(originalConnectionString))
                //{
                //    return StatusCode(500, "Default connection string is missing in configuration.");
                //}
                var builder = new SqlConnectionStringBuilder(adminConnectionString);
                string adminDatabaseName = builder.InitialCatalog;
                newConnectionString = adminConnectionString.Replace($"{adminDatabaseName}", databaseName);// Store the new connection string

                int existDatabase;
                List<string> defaultTable = [];

                using (var connection = _context.CreateConnection())
                {
                    var existDbQuery = $"select DB_ID('{databaseName}')";
                    existDatabase = await connection.ExecuteScalarAsync<int>(existDbQuery);
                    foreach (ClientTable item in GetallTableList)
                    {
                        var result = await _table.GetFieldNamesByTableId(item.ID, originalConnectionString);
                        var mappingTableList = buildCreateTableQueryClass.GetCheckboxMappingTableNames(item, result);
                        mappingtableList.AddRange(mappingTableList);


                    }
                    var forms = (await _table.GetDocumentEnabledForms(ProjectId, originalConnectionString)).ToList();
                    // document mapping tablesNames
                    documentMappingTables = buildCreateTableQueryClass.GetDocumentMappingTableNames(forms);
                    if (existDatabase > 0)
                    {
                        await alterFolderAndDatabaseClass.AlterDatabase(existDatabase, databaseName, newConnectionString, GetallTableList, mappingtableList, documentMappingTables);
                    }
                    else
                    {
                        await buildCreateTableQueryClass.CreateDatabase(databaseName, newConnectionString);
                    }

                    _context.UpdateConnectionString(newConnectionString);

                    // Update LastPasswordChanged for all users 
                    using (var userConnection = _context.CreateConnection())
                    {
                        var updateQuery = @"
                        UPDATE AppUser 
                        SET LastPasswordChanged = @Now,
                        ModifiedDate = @Now
                        WHERE Id > 0"; // you can put condition if you want to update only specific users

                        await userConnection.ExecuteAsync(updateQuery, new { Now = DateTime.UtcNow });
                    }
                }

                if (string.IsNullOrWhiteSpace(baseProjectRoot))
                {
                    return StatusCode(500, "Base project root path is missing.");
                }

                if (string.IsNullOrWhiteSpace(childFolderPath))
                {
                    return StatusCode(500, "Destination folder path is missing.");
                }

                string sourceFolder = baseProjectRoot;
                string destinationFolder = childFolderPath;

                // ✅ Define which folders should NOT be overwritten during copy
                List<string> excludedFolders = new()
                 {
                      "Image",       // wwwroot/Image
                      "uploads",     // wwwroot/uploads
                      "Reports"         // Static/Data
                  };

                // ✅ Copy base project into generated project, skipping excluded folders
                copyFolderContentsClass.CopyFolderContents(sourceFolder, destinationFolder, excludedFolders);
                
                copyFolderContentsClass.CopyFolderContents(baseAdminClientRoot, childAdminFolderPath, excludedFolders);


                if (clientName == null)
                {
                    throw new ArgumentNullException(nameof(clientName));
                }

                // Set AlignmentType In _ViewStart.cshtml
                createMenuTableClass.SetAlignmentType(childAdminFolderPath, alignmentType);

                sendConnectionStringClass.SendConnectionString(newConnectionString, projectName, clientName);
                sendConnectionStringClass.setconnctionstringinconsole(newConnectionString, projectName, clientName);
                var projectLogo = await _table.GetProjectLogo(ProjectId, adminConnectionString);
                createMenuTableClass.SetProjectLogo(projectLogo, destinationFolder, childAdminFolderPath, _env.WebRootPath);
                List<int> list = GetallTableList.Select(x => x.ID).ToList();
                List<string> tableNames = [];
                List<ClientCardViewFields> allCardViewFields = [];


                foreach (ClientTable item in GetallTableList)
                {
                    bool isMenu = item.IsMenuCreated;
                    bool isSource = item.IsSourceTable;

                    List<ClientSearchField> SearchFields = [];
                    List<ClientDisplayField> DisplayFields = [];
                    List<ClientDisplayField> DisplayFieldsByParentId = [];
                    List<ClientCardViewFields> CardViewFields = [];
                    //List <ClientSearchField> SearchFieldsByParentId = [];
                    var forms = await _table.GetFormByTableId(ClientId, ProjectId, originalConnectionString);
                    var formList = await _table.GetFormListByTableId(ClientId, ProjectId, item.ID, originalConnectionString);
                    var formActionQuery = await _table.GetFormUpdateQueries(item.ID, originalConnectionString);
                    List<ClientSearchField> detailSearchByParentId = new();
                    //List<ClientSearchField> allChildSearchFields = new();
                    //List<ClientSearchField> allDetailSearchFields = new();
                    //List<ClientSearchField> allChildSearchFields = new();

                    foreach (var objForm in formList)
                    {

                        var displayListByParentId = await _fields.GetDisplayFieldByParentId(objForm.ID, originalConnectionString);

                        //var searchListByParentId = await _fields.GetSearchFieldsByParentId(objForm.ID, originalConnectionString);

                        //var detailSearchByParentId = await _fields.GetDetailSearchByParentId(objForm.ID, originalConnectionString);
                        detailSearchByParentId.AddRange(await _fields.GetDetailSearchByParentId(objForm.ID, originalConnectionString));

                        //var childSearchListByParentId = await _fields.GetChildSearchFields(objForm.ID, originalConnectionString);
                        //allDetailSearchFields.AddRange(searchListByParentId);
                        // allChildSearchFields.AddRange(childSearchListByParentId);
                        SearchFields = await _fields.GetSearchFieldsHierarchy(objForm.ID, originalConnectionString);

                        ClientSearchField searchfield = new()
                        {
                            FormId = objForm.ID,
                            FormName = objForm.Name
                        };
                        ClientDisplayField displayfield = new()
                        {
                            FormId = objForm.ID,
                            FormName = objForm.Name
                        };

                        ClientCardViewFields cardViewField = new()
                        {
                            FormId = objForm.ID,
                            FormName = objForm.Name
                        };

                        CardViewFields = await _fields.GetCardViewByCardViewProfileId(cardViewField, originalConnectionString);
                        //SearchFields = await _fields.GetSearchFields(searchfield, originalConnectionString);
                        DisplayFields = await _fields.GetDisplayFieldBylistProfileId(displayfield, originalConnectionString);
                        allCardViewFields.AddRange(CardViewFields);

                        if (objForm.IsMenuValid)
                        {
                            if (CardViewFields.Count != 0 && (item.HeaderTableId == null || item.HeaderTableId == 0))
                            {
                                await generateAddEditFormClass.GenerateAddEditForm(projectName, clientName, item, CardViewFields, DisplayFields, formActionQuery, false, forms, displayListByParentId, alignmentType, originalConnectionString);

                            }


                            //if ((SearchFields.Count != 0 || DisplayFields.Count != 0) && (item.HeaderTableId == null || item.HeaderTableId == 0))
                            //{
                            //    generateListingWithSearchAndGridClass.GenerateListingWithSearchAndGrid(item.Name, item.IsHierarchical, objForm.IsAddToList ?? false, objForm.IsBarcodePrinting ?? false, projectName, clientName, SearchFields, DisplayFields, detailSearchByParentId, CardViewFields, alignmentType, originalConnectionString,objForm.ID);
                            //}

                            if (item.HeaderTableId > 0)
                            {
                                await generateAddEditFormClass.GenerateAddEditForm(projectName, clientName, item, CardViewFields, DisplayFields, formActionQuery, true, forms, null, alignmentType, originalConnectionString);
                            }

                            //if (item.DetailTableId > 0)
                            //{
                            //    await generateDetailListingWithGridClass.GenerateDetailListingWithGridAsync(objForm, projectName, clientName, forms, SearchFields, displayListByParentId, item, alignmentType, item.IsHierarchical, originalConnectionString);
                            //}
                            await GenerateListPagesWithSearchAndGridClass.GenerateListPagesWithSearchAndGrid(item, item.Name, item.IsHierarchical, objForm, objForm.IsAddToList ?? false, objForm.IsBarcodePrinting ?? false, forms, projectName, clientName, SearchFields, DisplayFields, detailSearchByParentId, CardViewFields, alignmentType, originalConnectionString, objForm.ID, false);

                        }
                        ////
                        //await GenerateListPagesWithSearchAndGridClass.GenerateListPagesWithSearchAndGrid(item, item.Name, item.IsHierarchical, objForm, objForm.IsAddToList ?? false, objForm.IsBarcodePrinting ?? false, forms, projectName, clientName, SearchFields, DisplayFields, detailSearchByParentId, CardViewFields, alignmentType, originalConnectionString, objForm.ID,false);
                        /////

                    }

                    if (SearchFields.Count != 0 || DisplayFields.Count != 0 || CardViewFields.Count != 0)
                    {
                        if (item.ParentId == 0)
                        {
                            if (item.IsMenuCreated)
                            {
                                generateFormActionsClass.GenerateFormActions(item, projectName, clientName, forms, formList);
                            }
                        }
                    }

                    if (isMenu || isSource)
                    {
                        tableNames.Add(item.Name);
                    }

                    var result = await _table.GetFieldNamesByTableId(item.ID, originalConnectionString);

                    using (var connection = _context.CreateConnection())
                    {

                        var checkboxMappingSqls = buildCreateTableQueryClass.BuildCheckboxMappingTables(item, result);
                        allCheckboxMappingSqls.AddRange(checkboxMappingSqls);



                        var checkTable = $"SELECT TABLE_NAME  FROM {databaseName}.information_schema.tables WHERE table_schema = 'dbo' AND table_name = '{item.Name}';";
                        var checkExistTable = await connection.ExecuteScalarAsync<string>(checkTable);

                        if (checkExistTable != null)
                        {
                            await alterFolderAndDatabaseClass.AlterTableAndFields(item, databaseName, result, checkExistTable);
                        }
                        else
                        {
                            string createtablequery = buildCreateTableQueryClass.BuildCreateTableQuery(item, item.IsHierarchical, result, null, databaseName, null, null, null);

                            await connection.ExecuteAsync(createtablequery);
                        }
                    }
                        
                    generateModelCodeClass.GenerateModelCode(item, result, projectName, clientName, formList);
                    
                    if (isMenu || isSource)
                    {
                        // Generate other code files for the table
                        generateInterfaceCodeClass.GenerateInterfaceCode(item, projectName, clientName, formList, CardViewFields, result);
                    }
                    int? formId = CardViewFields
                       .Where(f => f.TableName == item.Name)
                       .Select(f => f.FormId)
                       .FirstOrDefault(); // Get the first match or null if no match



                    var RuleList = await _table.GetRuleCriteriaList(item.ID, originalConnectionString);
                    List<ClientActionDetail> formAction = [];

                    formAction = await _table.GetFormUpdateQueries(item.ID, originalConnectionString);
                    var childSearchListByParentIds = detailSearchByParentId;
                    if (isMenu || isSource)
                    {
                        generateRepositoryCodeForModelClass.GenerateRepositoryCodeForModel(item, projectName, clientName, CardViewFields, item.ID, result, DisplayFields, formList, forms, originalConnectionString, childSearchListByParentIds, SearchFields);

                        generateControllerClass.GenerateController(item, item.Name, projectName, clientName, formList, result, formAction);
                        
                        generateApplicationLayerClass.GenerateApplicationLayer(item, item.Name, projectName, clientName, formList, result, formAction);

                        await generateXUnitTest.GenerateXUnitTests(item, item.Name, projectName, clientName, formList, result, RuleList);

                    }
                        
                    generateRuleClass.GenerateRule(item, item.Name, projectName, clientName, formList, RuleList);
                }




                var formDocEnabled = (await _table.GetDocumentEnabledForms(ProjectId, originalConnectionString))?.ToList() ?? [];

                // Group forms by: either TableName or ParentTableName (whichever is present)
                var groupedByEffectiveTable = formDocEnabled
                    .GroupBy(f => !string.IsNullOrEmpty(f.ParentTableName) ? f.ParentTableName : f.TableName)
                    .ToList();

                foreach (var group in groupedByEffectiveTable)
                {
                    var formsInGroup = group.ToList();

                    // Find the parent (null or 0 ParentId), or fallback to first
                    var parent = formsInGroup.FirstOrDefault(f => f.ParentId == null || f.ParentId == 0) ?? formsInGroup.First();

                    if (parent.IsMenuValid)
                    {
                        // Filter out the parent from children
                        var children = formsInGroup.Where(f => f.ID != parent.ID).ToList();

                        // Proceed with controller generation
                        await generateFormDocumentClass.GenerateFormDocumentMvcController(parent, children, projectName, clientName);
                    }
                }

                using (var connection = _context.CreateConnection())
                {
                    foreach (var mappingSql in allCheckboxMappingSqls)
                    {
                        await connection.ExecuteAsync(mappingSql);
                    }
                }

                using (var connection = _context.CreateConnection())
                {

                    if (formDocEnabled.Count != 0)
                    {
                        string formDocQuery = buildCreateTableQueryClass.GenerateDocumentAndMappingTables(formDocEnabled);
                        await connection.ExecuteAsync(formDocQuery);
                    }

                    foreach (var document in formDocEnabled)
                    {
                        if (document.IsMenuValid)
                        {
                            await generateFormDocumentClass.GenerateDocumentFormFiles(document, projectName, clientName);
                        }
                    }

                }

                var formAddToListEnabled = (await _table.GetAddToListEnabledForms(ProjectId, originalConnectionString))?.ToList() ?? [];

                using (var connection = _context.CreateConnection())
                {
                    if (formAddToListEnabled.Count != 0)
                    {
                        string formAddToListQuery = buildCreateTableQueryClass.GenerateAddToListTable(formAddToListEnabled);
                        await connection.ExecuteAsync(formAddToListQuery);
                    }
                }
                //string currentPath = AppContext.BaseDirectory; // "C:\ProjectBuilder_New\WebApi\bin\Debug\net8.0"
                //string sourceRootFolder = Path.GetFullPath(Path.Combine(currentPath, @"..\..\..")); // "C:\ProjectBuilder_New\WebApi"
                //await generateImportProfileViews.CopyExcelFilesToTargetAsync(
                //    sourceRootFolder,
                //    @$"C:\ClientProject\{folderName}\{projectName}\DynamicFormBuilder",
                //    originalConnectionString,
                //    newConnectionString
                //);
                //await generateImportProfileViews.CopyExcelFilesToTargetAsync(
                //    @"C:\Kritika\ProjectBuilder\WebApi",
                //    @$"C:\ClientProject\{folderName}\{projectName}\DynamicFormBuilder",
                //    originalConnectionString,
                //    newConnectionString
                //);

                generateImportProfileViews.CopyProjectData(originalConnectionString,
                    newConnectionString, ClientId, ProjectId);

                //await generateImportProfileViews.CopyExcelFilesToTargetAsync(
                //    @"C:\Kritika\ProjectBuilder\WebApi",
                //    @$"C:\ClientProject\{folderName}\{projectName}\DynamicFormBuilder",
                //    originalConnectionString,
                //    newConnectionString
                //);

                //generateImportProfileViews.GenerateImportProfileAll(projectName, clientName);

                // generateImportProfileViews.GenerateImportViews(projectName, clientName);


                generateProgramCodeClass.GenerateProgramCode(tableNames, projectName, clientName, allCardViewFields, formDocEnabled);

                if (existDatabase > 0)
                {
                    await alterFolderAndDatabaseClass.ModifyClientMenu(databaseName, ClientId, ProjectId, configDatabase);
                    await alterFolderAndDatabaseClass.ModifyClientForm(databaseName, ClientId, ProjectId, configDatabase);
                }
                else
                {
                    //Create Client-Menu Table Schema With Data
                    //TODO: We Added [ClientMenu] Table in BaseProject bcoz of foreign key issue raised
                    //await createMenuTableClass.CreateMenuTable(databaseName);
                    //await createMenuTableClass.CreateMenuTable(databaseName);
                    await createMenuTableClass.InsertDataIntoClientMenu(databaseName, ClientId, ProjectId, configDatabase);

                    //Create Client-Form Table Schema With Data
                    //TODO: We Added [ClientForm] Table in BaseProject bcoz of foreign key issue raised
                    //await createFormTableClass.CreateConfigSchema(databaseName);
                    //await createFormTableClass.CreateFormTable(databaseName);
                    await createFormTableClass.InsertDataIntoClientForm(databaseName, ClientId, ProjectId, configDatabase);
                }
                var MenuIcon = await _table.GetMenuIcon(ProjectId, originalConnectionString);// for MenuIcon

                createMenuTableClass.CopyMenuIcon(MenuIcon, destinationFolder, _env.WebRootPath, projectName, clientName);

                // ✅ ALIGN EXISTING XUNIT PROJECT
                string testProjectName = "XunitWeb";
                RunCommand("dotnet", $"add {testProjectName} package Moq", childFolderPath);
                RunCommand("dotnet", $"add {testProjectName} package Microsoft.AspNetCore.Mvc", childFolderPath);
                RunCommand("dotnet", $"add {testProjectName} reference ../{projectName}/DynamicFormBuilder/DynamicFormBuilder.csproj", childFolderPath);
                RunCommand("dotnet", $"add {testProjectName} reference ../{projectName}/Interface/Interface.csproj", childFolderPath);
                RunCommand("dotnet", $"add {testProjectName} reference ../{projectName}/Models/Models.csproj", childFolderPath);
                RunCommand("dotnet", $"sln add {testProjectName}/{testProjectName}.csproj", childFolderPath);
                RunCommand("dotnet", $"restore {testProjectName}", childFolderPath);

                //var response = $"Database '{databaseName}' created, restored, and folder '{fullFolderPath}' created successfully, publish url is '{uiUrl}'";

                bool IsPublishEnabled = _configuration.GetValue<bool>("IsPublishClientUsingScript");
              
                using var connection1 = new SqlConnection(adminConnectionString);
                var project = await connection1.QuerySingleOrDefaultAsync<ProjectModel>(ProjectSQLQuery.GetProjectById, new { Id = ProjectId }); 
               
                await connection1.ExecuteAsync(ProjectSQLQuery.UpdateBuildFlag, new { Id = ProjectId, IsBuild = 1 });
                await connection1.ExecuteAsync(ProjectSQLQuery.InsertProjectPublishHistory, new
                {
                    ProjectId = project.ID,
                    IsBuildConfig = 1,
                    IsBuildClient = 1,
                    IsConfigDatabase = 0,
                    IsConfigProject = 0,
                    IsClientDatabase = 0,
                    IsClientProject = 0,
                    IsClientAdmin = 0,
                    CreatedBy = project.ClientId,
                    Remark = "IsBuild"
                });
                return Ok(new { success = true, childFolderPath, projectName,project.ClientApiLink,project.ClientUiLink, IsPublishEnabled, childAdminFolderPath, project.ClientAdminApiLink, project.ClientAdminUiLink });
            }

            catch (Exception ex)
            {
                Log.Error(ex, "❌ Exception in {Method} | RequestId: {RequestId}",
                    MethodBase.GetCurrentMethod()?.Name ?? "UnknownMethod",
                    HttpContext?.TraceIdentifier ?? "N/A");

                return StatusCode(500, ex.Message);
            }

         }

        private static void RunCommand(string fileName, string arguments, string workingDirectory)
        {
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    WorkingDirectory = workingDirectory,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };

            process.OutputDataReceived += (s, e) => { if (e.Data != null) Console.WriteLine(e.Data); };
            process.ErrorDataReceived += (s, e) => { if (e.Data != null) Console.Error.WriteLine(e.Data); };

            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
            process.WaitForExit();
        }
    }
}