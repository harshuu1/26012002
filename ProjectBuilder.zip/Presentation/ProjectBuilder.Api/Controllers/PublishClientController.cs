﻿using Entities.Models.Publish;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.Json;

namespace ProjectBuilder.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PublishController(IConfiguration configuration) : ControllerBase
    {
        private static readonly ConcurrentDictionary<string, PublishStatus> _publishStatuses = new();
        private static readonly ConcurrentDictionary<string, Process> _runningProcesses = new(); 
        private readonly IConfiguration _configuration = configuration;


        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult StartPublish([FromBody] PublishRequest request)
        {
            bool isCleanup = _configuration.GetValue<bool>("IsCleanupServerSolution");

            var publishId = Guid.NewGuid().ToString();
            var status = new PublishStatus
            {
                Id = publishId,
                CurrentStep = "preparing",
                Message = "Initializing build environment...",
                IsCompleted = false,
                HasError = false,
                StartTime = DateTime.UtcNow
            };

            _publishStatuses[publishId] = status;

            // Start the publish process in background
            _ = Task.Run(async () => await ExecutePublishProcess(publishId, request, isCleanup));

            return Ok(new { publishId });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="publishId"></param>
        /// <returns></returns>
        [HttpGet("status/{publishId}")]
        public IActionResult GetPublishStatus(string publishId)
        {
            if (_publishStatuses.TryGetValue(publishId, out var status))
            {
                return Ok(new
                {
                    status.Id,
                    status.CurrentStep,
                    status.Message,
                    status.IsCompleted,
                    status.HasError,
                    status.ApiUrl,
                    status.UiUrl,
                    status.ClientAdminApiUrl,
                    status.ClientAdminUiUrl,
                    status.Logs
                });
            }

            return NotFound();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="publishId"></param>
        /// <returns></returns>
        [HttpPost("cancel/{publishId}")]
        public IActionResult CancelPublish(string publishId)
        {
            if (_publishStatuses.TryGetValue(publishId, out var status))
            {
                status.IsCancelled = true;
                status.HasError = true;
                status.Message = "Publish cancelled by user";
                status.IsCompleted = true;

                // Kill the running process if it exists
                if (_runningProcesses.TryGetValue(publishId, out var process))
                {
                    try
                    {
                        if (!process.HasExited)
                        {
                            process.Kill(true); // Kill process tree
                            AppendLog(publishId, "Process terminated by user cancellation");
                        }
                    }
                    catch (Exception ex)
                    {
                        AppendLog(publishId, $"Error terminating process: {ex.Message}");
                    }
                    finally
                    {
                        _runningProcesses.TryRemove(publishId, out _);
                    }
                }

                return Ok();
            }

            return NotFound();
        }

        private static void AppendLog(string publishId, string message)
        {
            if (_publishStatuses.TryGetValue(publishId, out var status))
            {
                lock (status.Logs)
                {
                    status.Logs.Add($"{DateTime.Now:HH:mm:ss} - {message}");
                    if (status.Logs.Count > 1000)
                        status.Logs.RemoveAt(0); // limit memory usage
                }
            }
        }

        private static async Task ExecutePublishProcess(string publishId, PublishRequest request, bool isCleanup)
        {
            var status = _publishStatuses[publishId];

            try
            {
                // For Client 
                // Step 1: Preparing
                // Update Status - Id, Status, Message, IsComplete, HasError
                UpdateStatus(publishId, "preparing", "Preparing build environment...", false, false);
                AppendLog(publishId, "Starting build process...");
                AppendLog(publishId, $"Project: {request.ProjectName}");
                AppendLog(publishId, $"Client Path: {request.ClientSubPath}");
                AppendLog(publishId, $"API Port: {request.ApiPort}");
                AppendLog(publishId, $"UI Port: {request.UiPort}");

                await Task.Delay(1000); // Brief preparation time

                if (status.IsCancelled) return;

                // Step 2: Building
                // Update Status - Id, Status, Message, IsComplete, HasError
                UpdateStatus(publishId, "building", "Executing PowerShell script...", false, false);
                AppendLog(publishId, "Executing PowerShell build script...");

                if (string.IsNullOrEmpty(request.ClientSubPath))
                    throw new ArgumentNullException(nameof(request.ClientSubPath));

                if (string.IsNullOrEmpty(request.ProjectName))
                    throw new ArgumentNullException(nameof(request.ProjectName));
                // Call your existing RunPublishScript method with real-time logging
                var (apiUrl, uiUrl) = await RunPublishScript(
                    request.ClientSubPath,
                    request.ProjectName,
                    request.ApiPort,
                    request.UiPort,
                    publishId,
                    request.IsConfiguration,
                    false);

                if (status.IsCancelled) return;

                // Step 3: Completed
                // Update Status - Id, Status, Message, IsComplete, HasError, Api Port, Ui Port
                UpdateStatus(publishId, "completed", "Project published successfully!", true, false, apiUrl, uiUrl);
                AppendLog(publishId, "✅ Build completed successfully!");
                AppendLog(publishId, $"API URL: {apiUrl}");
                AppendLog(publishId, $"UI URL: {uiUrl}");

                if(isCleanup)
                {
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(request.ClientSubPath) && Directory.Exists(request.ClientSubPath))
                        {
                            Directory.Delete(request.ClientSubPath, recursive: true);
                            AppendLog(publishId, $"🧹 Temporary folder deleted: {request.ClientSubPath}");
                        }
                        else
                        {
                            AppendLog(publishId, $"⚠️ Folder not found: {request.ClientSubPath}");
                        }
                    }
                    catch (Exception ex)
                    {
                        AppendLog(publishId, $"❌ Failed to delete folder '{request.ClientSubPath}': {ex.Message}");
                    }
                }

                if (!request.IsConfiguration)
                {
                    //For Client Admin
                    // Step 1: Preparing
                    // Update Status - Id, Status, Message, IsComplete, HasError
                    UpdateStatus(publishId, "preparing", "Preparing build environment...", false, false);
                    AppendLog(publishId, "Starting build process...");
                    AppendLog(publishId, $"Project: {request.ProjectName}");
                    AppendLog(publishId, $"Client Path: {request.ClientSubPath}");
                    AppendLog(publishId, $"API Port: {request.ApiPort}");
                    AppendLog(publishId, $"UI Port: {request.UiPort}");

                    await Task.Delay(1000); // Brief preparation time

                    if (status.IsCancelled) return;

                    // Step 2: Building
                    // Update Status - Id, Status, Message, IsComplete, HasError
                    UpdateStatus(publishId, "building", "Executing PowerShell script...", false, false);
                    AppendLog(publishId, "Executing PowerShell build script...");

                    if (string.IsNullOrEmpty(request.ClientAdminSubPath))
                        throw new ArgumentNullException(nameof(request.ClientAdminSubPath));

                    // Call your existing RunPublishScript method with real-time logging
                    var (clientAdminApiUrl, clientAdminUiUrl) = await RunPublishScript(
                        request.ClientAdminSubPath,
                        request.ProjectName,
                        request.ClientAdminApiPort,
                        request.ClientAdminUiPort,
                        publishId,
                        request.IsConfiguration,
                        true);

                    if (status.IsCancelled) return;

                    // Step 3: Completed
                    // Update Status - Id, Status, Message, IsComplete, HasError, Api Port, Ui Port
                    UpdateStatus(publishId, "completed", "Project published successfully!", true, false, null, null, clientAdminApiUrl, clientAdminUiUrl);
                    AppendLog(publishId, "✅ Build completed successfully!");
                    AppendLog(publishId, $"API URL: {clientAdminApiUrl}");
                    AppendLog(publishId, $"UI URL: {clientAdminUiUrl}");

                    if (isCleanup)
                    {
                        try
                        {
                            if (!string.IsNullOrWhiteSpace(request.ClientAdminSubPath) && Directory.Exists(request.ClientAdminSubPath))
                            {
                                Directory.Delete(request.ClientAdminSubPath, recursive: true);
                                AppendLog(publishId, $"🧹 Temporary folder deleted: {request.ClientAdminSubPath}");
                            }
                            else
                            {
                                AppendLog(publishId, $"⚠️ Folder not found: {request.ClientAdminSubPath}");
                            }
                        }
                        catch (Exception ex)
                        {
                            AppendLog(publishId, $"❌ Failed to delete folder '{request.ClientAdminSubPath}': {ex.Message}");
                        }
                    }

                }


                // Clean up after 5 minutes
                _ = Task.Run(async () =>
                {
                    await Task.Delay(TimeSpan.FromMinutes(5));
                    _publishStatuses.TryRemove(publishId, out _);
                });
            }
            catch (Exception ex)
            {
                AppendLog(publishId, $"❌ Build failed: {ex.Message}");
                // Update Status - Id, Status, Message, IsComplete, HasError
                UpdateStatus(publishId, "error", $"Error: {ex.Message}", true, true);
            }
            finally
            {
                _runningProcesses.TryRemove(publishId, out _);
            }
        }

        private static void UpdateStatus(string publishId, string step, string message, bool isCompleted, bool hasError, string? apiUrl = null, string? uiUrl = null, string? clientAdminApiUrl = null, string? clientAdminUiUrl = null)
        {
            if (_publishStatuses.TryGetValue(publishId, out var status))
            {
                status.CurrentStep = step;
                status.Message = message;
                status.IsCompleted = isCompleted;
                status.HasError = hasError;
                status.LastUpdated = DateTime.UtcNow;
                
                if (apiUrl != null)
                    status.ApiUrl = apiUrl;

                if (uiUrl != null)
                    status.UiUrl = uiUrl;

                if (clientAdminApiUrl != null)
                    status.ClientAdminApiUrl = clientAdminApiUrl;

                if (clientAdminUiUrl != null)
                    status.ClientAdminUiUrl = clientAdminUiUrl;
            }
        }

        private static async Task<(string? apiUrl, string? uiUrl)> RunPublishScript(string clientSubPath, string projectName, int apiPort, int uiPort, string publishId, bool IsConfiguration, bool IsClientAdmin)
        {
            string scriptPath = string.Empty;

            // Get the full path to the PublishClient.ps1 file
            string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string projectRoot = Path.GetFullPath(Path.Combine(currentDirectory, @"..\..\.."));
            if (IsConfiguration)
            {
                scriptPath = Environment.UserInteractive ? Path.Combine(projectRoot, "PublishClientConfiguration.ps1") : @"C:\inetpub\TechAhir\PublishClientPShellScript\PublishClientConfiguration.ps1";
            }
            else
            {
                if(IsClientAdmin) {
                    scriptPath = Environment.UserInteractive ? Path.Combine(projectRoot, "PublishClientAdmin.ps1") : @"C:\inetpub\TechAhir\PublishClientPShellScript\PublishClientAdmin.ps1";
                }
                else
                {
                    scriptPath = Environment.UserInteractive ? Path.Combine(projectRoot, "PublishClient.ps1") : @"C:\inetpub\TechAhir\PublishClientPShellScript\PublishClient.ps1";
                }
            }
            string taskName = $"PublishClientScript_{publishId}";

            //bool isInteractive = Environment.UserInteractive;

            string? apiUrl = string.Empty;
            string? uiUrl = string.Empty;
            string? outputError = string.Empty;

            try
            {
                AppendLog(publishId, $"Script path: {scriptPath}");
                //AppendLog(publishId, $"Interactive mode: {isInteractive}");

                // Interactive mode - run PowerShell directly with real-time output capture
                var psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = $"-ExecutionPolicy Bypass -File \"{scriptPath}\" -relativeClientPath \"{clientSubPath}\" -projectName \"{projectName}\" -apiPort {apiPort} -uiPort {uiPort}",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (var process = new Process { StartInfo = psi })
                {
                    // Store the process for potential cancellation
                    _runningProcesses[publishId] = process;

                    // Set up real-time output capture
                    process.OutputDataReceived += (sender, e) =>
                    {
                        if (!string.IsNullOrWhiteSpace(e.Data))
                        {
                            AppendLog(publishId, e.Data);
                        }
                    };

                    process.ErrorDataReceived += (sender, e) =>
                    {
                        if (!string.IsNullOrWhiteSpace(e.Data))
                        {
                            AppendLog(publishId, $"[ERROR] {e.Data}");
                        }
                    };

                    AppendLog(publishId, "Starting PowerShell process...");
                    process.Start();

                    // Begin async reading
                    process.BeginOutputReadLine();
                    process.BeginErrorReadLine();

                    // Wait for process to complete
                    await process.WaitForExitAsync();

                    AppendLog(publishId, $"PowerShell process completed with exit code: {process.ExitCode}");

                    if (process.ExitCode != 0)
                    {
                        throw new Exception($"PowerShell script failed with exit code {process.ExitCode}");
                    }
                }

                // Read the output file
                await Task.Delay(2000); // Wait a bit for file to be written

                string outputPath = $@"C:\temp\publish-output-{projectName}.json";
                await WaitForOutputFile(outputPath, publishId);

                if (System.IO.File.Exists(outputPath))
                {
                    var json = await System.IO.File.ReadAllTextAsync(outputPath);
                    AppendLog(publishId, $"Output file content: {json}");

                    var result = JsonSerializer.Deserialize<Dictionary<string, string>>(json);

                    result?.TryGetValue("ApiUrl", out apiUrl);
                    result?.TryGetValue("UiUrl", out uiUrl);
                    result?.TryGetValue("Error", out outputError);

                    System.IO.File.Delete(outputPath);
                }

                if (!string.IsNullOrEmpty(outputError))
                {
                    throw new Exception(outputError);
                }

                return (apiUrl ?? "", uiUrl ?? "");

                //if (isInteractive)
                //{

                //}
                //else
                //{
                //    // Non-interactive mode - use scheduled task
                //    AppendLog(publishId, "Running in non-interactive mode, using scheduled task...");

                //    // PowerShell command to register or update the task
                //    string psCommand = $@"
                //        $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument '-ExecutionPolicy Bypass -File ""{scriptPath}"" -relativeClientPath ""{clientSubPath}"" -projectName ""{projectName}"" -apiPort {apiPort} -uiPort {uiPort}';
                //        $principal = New-ScheduledTaskPrincipal -UserId '{Environment.UserName}' -RunLevel Highest;
                //        $task = New-ScheduledTask -Action $action -Principal $principal;
                //        Register-ScheduledTask -TaskName '{taskName}' -InputObject $task -Force;
                //        ";

                //    // Step 1: Register or update the task
                //    AppendLog(publishId, "Registering scheduled task...");

                //    var registerTask = new ProcessStartInfo
                //    {
                //        FileName = "powershell.exe",
                //        Arguments = $"-ExecutionPolicy Bypass -Command \"{psCommand}\"",
                //        UseShellExecute = false,
                //        RedirectStandardOutput = true,
                //        RedirectStandardError = true,
                //        CreateNoWindow = true
                //    };

                //    using (var process = Process.Start(registerTask))
                //    {
                //        string output = await process.StandardOutput.ReadToEndAsync();
                //        string error = await process.StandardError.ReadToEndAsync();

                //        if (!string.IsNullOrEmpty(output))
                //            AppendLog(publishId, $"Task registration output: {output}");
                //        if (!string.IsNullOrEmpty(error))
                //            AppendLog(publishId, $"Task registration error: {error}");

                //        await process.WaitForExitAsync();
                //    }

                //    // Step 2: Run the task
                //    AppendLog(publishId, "Starting scheduled task...");

                //    var runTask = new ProcessStartInfo
                //    {
                //        FileName = "schtasks",
                //        Arguments = $"/Run /TN \"{taskName}\"",
                //        UseShellExecute = false,
                //        RedirectStandardOutput = true,
                //        RedirectStandardError = true,
                //        CreateNoWindow = true
                //    };

                //    using (var process = new Process { StartInfo = runTask })
                //    {
                //        _runningProcesses[publishId] = process;

                //        process.OutputDataReceived += (s, e) =>
                //        {
                //            if (!string.IsNullOrWhiteSpace(e.Data))
                //                AppendLog(publishId, e.Data);
                //        };

                //        process.ErrorDataReceived += (s, e) =>
                //        {
                //            if (!string.IsNullOrWhiteSpace(e.Data))
                //                AppendLog(publishId, $"[ERROR] {e.Data}");
                //        };

                //        process.Start();
                //        process.BeginOutputReadLine();
                //        process.BeginErrorReadLine();

                //        await process.WaitForExitAsync();

                //        AppendLog(publishId, $"Scheduled task completed with exit code: {process.ExitCode}");
                //    }

                //    // Wait for output file and read results
                //    string outputPath = @"C:\temp\publish-output.json";
                //    await WaitForOutputFile(outputPath, publishId);

                //    if (System.IO.File.Exists(outputPath))
                //    {
                //        var json = await System.IO.File.ReadAllTextAsync(outputPath);
                //        AppendLog(publishId, $"Output file content: {json}");

                //        var result = JsonSerializer.Deserialize<Dictionary<string, string>>(json);

                //        result?.TryGetValue("ApiUrl", out apiUrl);
                //        result?.TryGetValue("UiUrl", out uiUrl);
                //        result?.TryGetValue("Error", out outputError);

                //        System.IO.File.Delete(outputPath);
                //    }

                //    // Clean up task
                //    try
                //    {
                //        Process.Start("schtasks", $"/Delete /TN \"{taskName}\" /F");
                //        AppendLog(publishId, "Cleaned up scheduled task");
                //    }
                //    catch (Exception ex)
                //    {
                //        AppendLog(publishId, $"Error cleaning up task: {ex.Message}");
                //    }

                //    if (!string.IsNullOrEmpty(outputError))
                //    {
                //        throw new Exception(outputError);
                //    }
                //}

                //return (apiUrl, uiUrl);
            }
            catch (Exception ex)
            {
                AppendLog(publishId, $"Script execution failed: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        private static async Task WaitForOutputFile(string? outputPath, string publishId)
        {
            AppendLog(publishId, $"Waiting for output file: {outputPath}");

            string? outputDirectory = Path.GetDirectoryName(outputPath);
            if (!Directory.Exists(outputDirectory) && !string.IsNullOrEmpty(outputDirectory))
            {
                Directory.CreateDirectory(outputDirectory);
                AppendLog(publishId, $"Created output directory: {outputDirectory}");
            }

            int maxWait = 120; // Wait up to 2 minutes
            int waited = 0;

            while (!System.IO.File.Exists(outputPath) && waited < maxWait)
            {
                if (waited % 10 == 0) // Log every 10 seconds
                {
                    AppendLog(publishId, $"Still waiting for output file... ({waited}s/{maxWait}s)");
                }

                await Task.Delay(1000);
                waited++;

                // Check if process was cancelled
                if (_publishStatuses.TryGetValue(publishId, out var status) && status.IsCancelled)
                {
                    AppendLog(publishId, "Process was cancelled while waiting for output");
                    break;
                }
            }

            if (!System.IO.File.Exists(outputPath) && waited >= maxWait)
            {
                AppendLog(publishId, "⚠️ Timeout waiting for output file");
            }
            else if (System.IO.File.Exists(outputPath))
            {
                AppendLog(publishId, "✅ Output file found");
            }
        }
    }

    
}