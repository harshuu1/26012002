﻿using Application.Modules.AppUser.Commands;
using Application.Modules.AppUser.Queries;
using Entities.Models.AppUser;
using Entities.Models.Request;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ProjectBuilder.Api.Controllers
{
    [Route("user")]
    [ApiController]
    public class AppUserController(ISender sender, IConfiguration configuration, JwtModel jwtModel) : ControllerBase
    {

        #region Member Variables

        private readonly ISender Sender = sender;
        private readonly IConfiguration _configuration = configuration;
        private readonly JwtModel _jwtModel = jwtModel;

        #endregion

        #region GET

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetAllAppUser()
        {
            return Ok(await Sender.Send(new GetAllAppUsers()));
        }

        [Authorize]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetAppUserById(int id)
        {
            return Ok(await Sender.Send(new GetAppUserById(id)));
        }

        [HttpGet("checkEmail")]
        public async Task<IActionResult> CheckEmailExists([FromQuery] string email, [FromQuery] int userId = 0)
        {
            return Ok(await Sender.Send(new CheckEmailExists(email, userId)));
        }

        [HttpGet("jwt")]
        public IActionResult GetJwtConfig()
        {
            return Ok(new
            {
                maxIdleMinutes = _jwtModel.MaxIdleMinutes,
                expiryInHours = _jwtModel.JwtExpiryInHours
            });
        }

        #endregion

        #region POST & PUT

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> CreateAppUser(AppUserModel appUser)
        {
            var (message, success) = await Sender.Send(new CreateAppUserCommand(appUser));
            return success ? Ok(new { message }) : Conflict(new { message });
        }

        [Authorize]
        [HttpPut]                     // Full update
        [HttpPut("status")]           // Status-only update
        public async Task<IActionResult> UpdateAppUser([FromBody] AppUserModel appUser)
        {
            if (appUser.ID == 0) return BadRequest(new { message = "Employee ID is required." });

            // Detect if request used /status route
            bool isStatusUpdate = HttpContext.Request.Path.Value.EndsWith("/status");

            if (isStatusUpdate)
            {
                // ------- STATUS ONLY UPDATE -------                
                var existingUser = await Sender.Send(new GetAppUserById(appUser.ID));
                if (existingUser == null)
                    return NotFound(new { message = "User not found." });

                // Update only IsActive
                existingUser.IsActive = appUser.IsActive;

                //var resultStatus = await Sender.Send(new UpdateAppUserCommand(existingUser, isStatusUpdate));

                var (messageFull, successFull) = await Sender.Send(new UpdateAppUserCommand(existingUser, isStatusUpdate));

                return successFull
                    ? Ok(new { messageFull = "User status updated successfully." })
                    : Conflict(new { messageFull });

            }
            var (message, success) = await Sender.Send(new UpdateAppUserCommand(appUser, isStatusUpdate));
            return success ? Ok(new { message }) : Conflict(new { message });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Password))
                return BadRequest(new { message = "Email and Password are required." });

            var user = await Sender.Send(new LoginUserCommand(request.Email, request.Password));

            if (user != null)
            {
                var expiryHours = Convert.ToDouble(_configuration["Jwt:TokenExpiryInHours"]);
                var cookieExpiry = DateTimeOffset.UtcNow.AddHours(expiryHours);

                var tokenCookieOptions = new CookieOptions
                {
                    HttpOnly = false,
                    Secure = true,
                    Path = "/",
                    SameSite = SameSiteMode.None,
                    Expires = cookieExpiry
                };
                Response.Cookies.Append("jwtToken", user.Token ?? string.Empty, tokenCookieOptions);

                var authFlagCookieOptions = new CookieOptions
                {
                    HttpOnly = false,
                    Secure = true,
                    Path = "/",
                    SameSite = SameSiteMode.Lax,
                    Expires = cookieExpiry
                };
                Response.Cookies.Append("isAuthenticated", "true", authFlagCookieOptions);
            }

            return user != null
                ? Ok(user)
                : Unauthorized(new { message = "Invalid email or password." });
        }

        #endregion

        #region DELETE

        /// <summary>
        /// Deletes a user by ID.
        /// </summary>
        /// <param name="id">User ID to delete.</param>

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAppUser(int id)
        {
            var (message, success) = await Sender.Send(new DeleteAppUserCommand(id));
            return success ? Ok(new { message }) : NotFound(new { message });
        }

        /// <summary>
        /// Authenticates a user and returns a token.
        /// </summary>
        /// <param name="request">Login credentials.</param>

        #endregion

    }
}