﻿using Entities.Models.Project;
using Entities.Models.Request;
using Interfaces;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static Application.Modules.Project.Commands.ProjectCommands;
using static Application.Modules.Project.Queries.ProjectQueries;
using static DapperDB.DapperDbContext;

namespace ProjectBuilder.Api.Controllers
{
    [ApiController]
    [Route("/clients/project")]
    public class ProjectController(IProject context, DbContext dbContext, IConfiguration configuration, IWebHostEnvironment env, ISender sender) : ControllerBase
    {

        #region Member Variables

        private readonly IProject _context = context;
        private readonly DbContext _dbContext = dbContext;
        private readonly IConfiguration _configuration = configuration;
        private readonly IWebHostEnvironment _env = env;
        private readonly ISender Sender = sender;

        #endregion

        #region GET

        [Authorize]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProjectById(int id)
        {
            var project = await Sender.Send(new GetProjectByIdQuery(id));
            if (project == null)
                return NotFound($"Form with ID {id} not found.");
            return Ok(project);
        }

        [HttpGet("~/clients/{clientId}/projects")]
        public async Task<IActionResult> GetProjectsByClient(int clientId)
        {
            var projects = await Sender.Send(new GetProjectsByClientQuery(clientId));
            if (projects == null || !projects.Any())
                return NotFound($"No projects found for client with ID {clientId}.");
            return Ok(projects);
        }

        [HttpGet("getTable/{id}")]
        public async Task<IActionResult> GetAll(int id)
        {
            return Ok(await Sender.Send(new GetTableByIdQuery(id)));
        }

        [HttpGet("usage/{projectId}")]
        public async Task<IActionResult> GetProjectUsage(int projectId)
        {
            return Ok(await Sender.Send(new GetProjectUsageQuery(projectId)));
        }

        #endregion

        #region POST & PUT

        [Authorize]
        [HttpPost("/clients/projects")]
        public async Task<IActionResult> GetAllProject([FromBody] Request request)
        {
            return Ok((await Sender.Send(new GetAllProjectCommand(request))).ToResult());
        }

        [HttpPost("/client/{clientId}/projects")]
        public async Task<IActionResult> GetProjectsByClientId(int clientId, [FromBody] Request request)
        {
            return Ok((await Sender.Send(new GetProjectsByClientIdCommand(clientId, request))).ToResult());
        }        

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> CreateProject(ProjectModel project)
        {
            if (project == null)
            {
                return BadRequest("Project data is required.");
            }

            // Validate ProjectName
            if (string.IsNullOrEmpty(project.Name) || project.Name.Length > 50)
            {
                return BadRequest(new { message = "Name must be 50 characters or less." });
            }

            if (project.Name.StartsWith(" "))
            {
                return BadRequest(new { message = "Name must not start with a space." });
            }

            using var connection = _dbContext.CreateConnection();
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                var command = new CreateProjectCommand(project, _env.WebRootPath, connection, transaction);
                var result = await Sender.Send(command);

                transaction.Commit();

                if (result.Contains("Application created successfully."))
                {
                    return Ok(result);
                }
                else if (result == "A Application with the same name already exists.")
                {
                    return Ok(result);
                }
                else if (result.Contains("JPG") || result.Contains("PNG") || result.Contains("JPEG"))
                {
                    return Ok(result);
                }

                return BadRequest("Something went wrong while creating the Application.");
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return BadRequest(ex.Message);
            }
        }



        [Authorize]
        [HttpPut]
        public async Task<IActionResult> UpdateProject(ProjectModel project)
        {
            if (project.ID == 0)
                return BadRequest("ID mismatch.");

            if (string.IsNullOrEmpty(project.Name) || project.Name.Length > 50)
                return BadRequest(new { message = "Name cannot exceed 50 characters." });

            if (project.Name.StartsWith(" "))
                return BadRequest(new { message = "Name must not start with a space." });

            var result = await Sender.Send(new UpdateProjectCommand(project, _env.WebRootPath));

            if (result == "No Project found with the specified Id.")
                return NotFound(result);

            return Ok(result);
        }

        #endregion

        #region DELETE

        /// <summary>
        /// Deletes a Project by ID.
        /// </summary>
        /// <param name="id">Project ID to delete.</param>

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProject(int id)
        {
            var response = await Sender.Send(new DeleteProjectCommand(id));

            if (response.StartsWith("Error:"))
                return BadRequest(response);

            return Ok(response);
        }

        /// <summary>
        /// delete all site
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        [HttpDelete("DeleteProject/{projectId}")]
        public async Task<IActionResult> DeleteProjectAsync(int projectId, [FromQuery] bool deleteConfigDatabase = false, [FromQuery] bool deleteConfigProject = false, [FromQuery] bool deleteClientDatabase = false,[FromQuery] bool deleteClientProject = false)
        {
            // Call the DeleteProjectAsync method with the user-selected flags
            var result = await _context.DeleteProjectAsync(projectId, deleteConfigDatabase, deleteConfigProject,deleteClientDatabase,deleteClientProject);

            if (result)
                return Ok(new
                {
                    message = "Selected project resources deleted successfully.",
                    deletedItems = new
                    {
                        ConfigDatabase = deleteConfigDatabase,
                        ConfigProject = deleteConfigProject,
                        ClientDatabase = deleteClientDatabase,
                        ClientProject = deleteClientProject
                        
                    }
                });
            else
                return BadRequest(new { message = "Failed to delete project." });
        }


        #endregion

        #region Export Project

        //[HttpGet("exportproject/{projectId}")]
        //public async Task<IActionResult> ExportProject(int projectId)
        //{
        //    using var connection = _dbContext.CreateConnection();
        //    connection.Open();
        //    using var transaction = connection.BeginTransaction();

        //    try
        //    {
        //        // Load main Project
        //        var project = await connection.QueryFirstOrDefaultAsync<ProjectDetails>(
        //           @"SELECT pm.ID, pm.ClientId, cm.CompanyName, pm.Name, pm.Description,pm.IsActive, pm.ProjectLogo, pm.AlignmentType 
        //                FROM ProjectManagement pm 
        //                LEFT JOIN ClientManagement cm ON pm.ClientId = cm.ID 
        //                WHERE pm.ID = @ProjectId;",
        //        new { ProjectId = projectId }, transaction);

        //        if (project == null)
        //            return NotFound("Project not found.");

        //        var projectDetails = new ProjectDetails
        //        {
        //            ID = project.ID = 0,
        //            ClientId = project.ClientId,
        //            ProjectId = project.ProjectId,
        //            Name = project.Name,
        //            Description = project.Description,
        //            CompanyName = project.CompanyName,
        //            ProjectLogo = project.ProjectLogo,
        //            CreatedBy = project.CreatedBy,
        //            CreatedDate = project.CreatedDate,
        //            AlignmentType = project.AlignmentType,
        //        };

        //        // Tables
        //        var tables = (await connection.QueryAsync<TableWithDetails>(
        //            "SELECT t.ID, t.Name, t.ClientId,(c.FirstName + ' ' + c.LastName) AS ClientName,t.ProjectId,p.Name AS ProjectName,t.IsHierarchical,t.ParentId,t.PrimaryKeyType,tt.Name AS ParentName FROM TableDefination t LEFT JOIN ClientManagement c ON t.ClientId = c.ID LEFT JOIN ProjectManagement p ON t.ProjectId = p.ID LEFT JOIN TableDefination tt ON t.ParentId = tt.ID WHERE t.ProjectId = @projectId ORDER BY CASE WHEN t.ParentId = 0 or t.ParentId is null THEN 0 ELSE 1 END,t.ID", new { ProjectId = projectId }, transaction)).ToList();

        //        var tableIds = tables.Select(t => t.ID).ToList();

        //        foreach (var table in tables)
        //        {
        //            table.FieldDefinitionsList = (await connection.QueryAsync<FieldDefination>(
        //                "SELECT f.*, ft.Name AS TypeName,ft.ControlTypeId,s.Name AS SectionName FROM FieldDefination f INNER JOIN FieldType ft ON f.TypeId = ft.ID LEFT JOIN Section s ON f.SectionId = s.ID WHERE f.TableId = @TableId", new { TableId = table.ID }, transaction)).ToList();

        //            table.SectionsList = (await connection.QueryAsync<Model.Section>(
        //                "SELECT * FROM Section WHERE TableId = @TableId", new { TableId = table.ID }, transaction)).ToList();

        //            table.FormsList = (await connection.QueryAsync<FormDetails>(
        //                "SELECT fd.ID, fd.Name, fd.TableId,  fd.ClientId,  fd.ProjectId,  fd.DetailTableId,  fd.ParentId,  ff.Name AS ParentFormName,  fd.ListProfileId,  fd.CardViewProfileId,  fd.SearchProfileId,  fd.IsDocumentEnabled,  fd.SaveContinue,  fd.SaveReuse,  fd.IsAddToList,  fd.IsBarcodePrinting,  t.Name AS TableName,  c.CompanyName AS CompanyName,  p.Name AS ProjectName,  lvp.Name AS ListViewProfileName,  cvp.Name AS CardViewProfileName,  sec.Name AS SearchViewProfileName FROM Form fd LEFT JOIN ClientManagement c ON fd.ClientId = c.ID LEFT JOIN ProjectManagement p ON fd.ProjectId = p.ID INNER JOIN TableDefination t ON fd.TableId = t.ID LEFT JOIN ListProfile lvp ON fd.ListProfileId = lvp.ID LEFT JOIN CardViewProfile cvp ON fd.CardViewProfileId = cvp.ID LEFT JOIN SearchProfile sec ON fd.SearchProfileId = sec.ID LEFT JOIN Form ff ON fd.ParentId = ff.ID WHERE   ((fd.TableId = @TableId AND fd.ParentId IS NULL) OR (fd.TableId = @TableId) OR (fd.ParentId IN (SELECT f.ID FROM Form f WHERE f.TableId = @TableId))) AND (fd.Name NOT LIKE '%MasterForm%');", new { TableId = table.ID }, transaction)).ToList();

        //            foreach (var form in table.FormsList)
        //            {
        //                form.FormActionList = (await connection.QueryAsync<FormAction>(
        //                    "SELECT f.ID, f.ActionID, f.ActionConfigurationId, a.[Name] AS ActionName,FD.Name AS FieldName, sva.FieldId, sva.value,(CASE WHEN f.ActionId = 2 THEN sea1.EmailSubject ELSE sea.EmailSubject END) AS EmailSubject,(CASE WHEN f.ActionId = 2 THEN sea1.EmailMessage ELSE sea.EmailMessage END) AS EmailMessage,(CASE WHEN f.ActionId = 2 THEN sea1.EmailTemplate ELSE sea.EmailTemplate END) AS EmailTemplate,(CASE WHEN f.ActionId = 2 THEN sea1.EmailTo ELSE sea.EmailTo END) AS EmailTo,(CASE WHEN f.ActionId = 2 THEN sea1.IndividualEmail ELSE sea.IndividualEmail END) AS IndividualEmail,sea1.GenerateReportId,gra.Report, gra.ViewReport, gra.EmailAttachment FROM FormAction f INNER JOIN AppAction a ON f.ActionID = a.ID LEFT JOIN SetValueAction sva ON f.ActionConfigurationId = sva.ID AND a.Name = 'SetValue' LEFT JOIN FieldDefination FD ON FD.ID = sva.FieldId LEFT JOIN GenerateReportAction gra ON f.ActionConfigurationId = gra.ID AND a.Name = 'GenerateReportAction' LEFT JOIN SendEmailAction sea ON sea.ID = f.ActionConfigurationId AND a.Name = 'SendEmailAction' LEFT JOIN SendEmailAction sea1 ON sea1.GenerateReportId = f.ActionConfigurationId WHERE f.FormId = @FormId", new { FormId = form.ID }, transaction)).ToList();

        //                form.RulesList = (await connection.QueryAsync<RuleDetails>(
        //                    "SELECT r.ID,r.Name,r.Description,r.Formid,r.TableId,r.ValidateCriteriaId,f.Name AS FormName,r.CreatedBy FROM [Rule] r LEFT JOIN Form f On r.FormId = f.ID WHERE FormId = @FormId", new { FormId = form.ID }, transaction)).ToList();

        //                foreach (var rulecri in form.RulesList)
        //                {
        //                    rulecri.RuleCriteriasList = (await connection.QueryAsync<RuleCriteria>(
        //                        "SELECT rc.ID,rc.RuleId,rc.FieldId,rc.Operator,rc.FailMessage,rc.FieldValue,rc.ConditionalRuleId,r.Name AS RuleName, rr.Name as ConditionalRuleName,frc.Name AS FieldName FROM RuleCriteria rc LEFT JOIN [Rule] r ON rc.RuleId = r.ID LEFT JOIN FieldDefination frc On rc.FieldId = frc.ID LEFT JOIN [Rule] rr on rr.ID = rc.ConditionalRuleId WHERE rc.RuleId = @ruleId", new { ruleId = rulecri.ID }, transaction)).ToList();
        //                }

        //            }

        //            table.MenuList = (await connection.QueryAsync<Menu>(
        //                    "SELECT m.ID,m.Name,m.Description,m.ParentId,m.FormId,m.ClientId,m.ProjectId,m.TableId, m.IsCardView, mm.Name AS ParentName,td.Name AS TableName,cm.CompanyName AS CompanyName,pm.Name AS ProjectName,f.Name AS FormName From Menu m LEFT JOIN ClientManagement cm ON m.ClientId = cm.ID LEFT JOIN ProjectManagement pm ON m.ProjectId = pm.ID LEFT JOIN TableDefination td ON m.TableId = td.ID LEFT JOIN Form f ON m.FormId = f.ID LEFT JOIN Menu mm ON m.ParentId = mm.ID Where m.TableId = @TableId ORDER BY CASE WHEN m.ParentId = 0 or m.ParentId is null THEN 0 ELSE 1 END,m.ID",
        //                  new { TableId = table.ID }, transaction)).ToList();

        //            table.RuleDetailsList = (await connection.QueryAsync<RuleDetails>(
        //                "SELECT r.ID,r.Name,r.Description,r.Formid,r.TableId,r.ValidateCriteriaId,f.Name AS FormName,r.CreatedBy FROM [Rule] r LEFT JOIN Form f On r.FormId = f.ID WHERE r.TableId = @tableId", new { tableId = table.ID }, transaction)).ToList();

        //            foreach (var rule in table.RuleDetailsList)
        //            {
        //                rule.RuleCriteriasList = (await connection.QueryAsync<RuleCriteria>(
        //                    "SELECT rc.ID,rc.RuleId,rc.FieldId,rc.Operator,rc.FailMessage,rc.FieldValue,rc.ConditionalRuleId,r.Name AS RuleName, rr.Name as ConditionalRuleName,frc.Name AS FieldName FROM RuleCriteria rc LEFT JOIN [Rule] r ON rc.RuleId = r.ID LEFT JOIN FieldDefination frc On rc.FieldId = frc.ID LEFT JOIN [Rule] rr on rr.ID = rc.ConditionalRuleId WHERE rc.RuleId = @ruleId", new { ruleId = rule.ID }, transaction)).ToList();
        //            }

        //            //table.ImportProfilesList = (await connection.QueryAsync<ImportProfile>(
        //            //@"SELECT * FROM ImportProfile 
        //            //WHERE TableId IN @tableIds", new { tableIds }, transaction)).ToList();

        //            //foreach (var profile in table.ImportProfilesList)
        //            //{
        //            //    profile.ProfileFields = (await connection.QueryAsync<ImportProfileField>(
        //            //     "SELECT ip.ID,ip.ProfileId,ip.FieldId,fd.Name AS FieldName FROM ImportProfileField ip LEFT JOIN FieldDefination fd ON ip.FieldId = fd.ID Where ip.ProfileId = @ProfileId", new { ProfileId = profile.ID }, transaction)).ToList();
        //            //}

        //            table.SearchProfileList = (await connection.QueryAsync<SearchProfileDetails>(
        //            @"SELECT DISTINCT sp.ID,sp.Name,sp.TableID FROM SearchProfile sp LEFT JOIN TableDefination t ON sp.TableId = t.ID LEFT JOIN Form f ON sp.TableId = f.TableId LEFT JOIN Form ff ON f.ParentId = ff.ID WHERE sp.TableID = @tableId  AND sp.Name <> (t.Name + 'SearchProfile');",
        //            new { tableId = table.ID }, transaction)).ToList();

        //            foreach (var searchfield in table.SearchProfileList)
        //            {
        //                searchfield.SearchFielsList = (await connection.QueryAsync<SearchField>(
        //                    "SELECT s.ID,s.FieldId,s.DefaultValue,f.Name AS FieldName FROM SearchField s LEFT JOIN FieldDefination f ON s.FieldId = f.ID Where s.SearchProfileId = @SearchProfileId", new { SearchProfileId = searchfield.ID }, transaction)).ToList();
        //            }

        //            table.ListProfileDetails = (await connection.QueryAsync<ListProfileDetails>(
        //                @"SELECT DISTINCT 
        //            lp.*
        //            FROM ListProfile lp
        //            LEFT JOIN TableDefination t ON lp.TableId = t.ID
        //            LEFT JOIN Form f ON lp.TableId = f.TableId
        //            LEFT JOIN ListProfile ff ON f.ParentId = ff.ID
        //            WHERE lp.TableId = @tableId 
        //              AND lp.Name <> (t.Name + 'ListProfile');", new { tableId = table.ID },transaction)).ToList();


        //            foreach (var listprofile in table.ListProfileDetails)
        //            {
        //                listprofile.DisplayFieldList = (await connection.QueryAsync<DisplayField>(
        //                    "SELECT d.ID,d.FieldId,d.ListProfileId,f.Name AS FieldName FROM DisplayField d LEFT JOIN FieldDefination f ON d.FieldId = f.ID Where d.ListProfileId = @ListProfileId", new { ListProfileId = listprofile.ID }, transaction)).ToList();

        //            }

        //            // 9. Get CardViewProfileDetails
        //            table.CardViewProfileDetails = (await connection.QueryAsync<CardViewProfileDetails>(
        //            @"SELECT DISTINCT cvp.*
        //            FROM CardViewProfile cvp
        //            LEFT JOIN TableDefination t ON cvp.TableId = t.ID
        //            LEFT JOIN Form f ON cvp.TableId = f.TableId
        //            LEFT JOIN CardViewProfile ff ON f.ParentId = ff.ID
        //            WHERE cvp.TableId = @tableId 
        //            AND cvp.Name <> (t.Name + 'CardViewProfile'); ",
        //            new { tableId = table.ID }, transaction)).ToList();

        //            foreach (var cardprofile in table.CardViewProfileDetails)
        //            {
        //                cardprofile.CardViewFieldsList = (await connection.QueryAsync<CardViewFields>(
        //                   "SELECT c.ID,c.FieldId,c.CardViewProfileId,c.IsReadOnly,f.Name AS FieldName FROM CardViewFields c LEFT JOIN FieldDefination f ON c.FieldId = f.ID Where c.CardViewProfileId = @CardViewProfileId", new { CardViewProfileId = cardprofile.ID }, transaction)).ToList();
        //            }



        //        }
        //        foreach (var table in tables)
        //        {
        //            table.ID = 0;
        //            table.ParentId = 0;
        //            table.ProjectId = 0;
        //            foreach (var sec in table.SectionsList)
        //            {
        //                sec.ID = 0;
        //                sec.TableId = 0;
        //            }
        //            foreach (var fild in table.FieldDefinitionsList)
        //            {
        //                fild.ID = 0;
        //                fild.TableId = 0;
        //                fild.SectionId = 0;
        //            }
        //            foreach (var formsss in table.FormsList)
        //            {
        //                formsss.ID = 0;
        //                formsss.ProjectId = 0;
        //                formsss.TableId = 0;
        //                formsss.ListProfileId = 0;
        //                formsss.CardViewProfileId = 0;
        //                formsss.SearchProfileId = 0;
        //                formsss.ParentId = null;

        //                foreach (var action in formsss.FormActionList)
        //                {
        //                    action.ID = 0;
        //                    action.FormId = 0;
        //                    action.FieldID = 0;
        //                }
        //                foreach (var rule in formsss.RulesList)
        //                {
        //                    rule.ID = 0;
        //                    rule.TableId = 0;
        //                    rule.Formid = 0;

        //                    foreach (var criteria in rule.RuleCriteriasList)
        //                    {
        //                        criteria.ID = 0;
        //                        criteria.RuleId = 0;
        //                        criteria.FieldId = 0;
        //                        criteria.ConditionalRuleId = 0;
        //                    }
        //                }
        //            }
        //            foreach (var menus in table.MenuList)
        //            {
        //                menus.ID = 0;
        //                menus.ProjectId = 0;
        //                menus.TableId = 0;
        //                menus.FormId = 0;
        //                menus.ParentID = null;
        //            }
        //            foreach (var trule in table.RuleDetailsList)
        //            {
        //                trule.ID = 0;
        //                trule.TableId = 0;
        //                trule.Formid = 0;

        //                foreach (var tcriteria in trule.RuleCriteriasList)
        //                {
        //                    tcriteria.ID = 0;
        //                    tcriteria.RuleId = 0;
        //                    tcriteria.FieldId = 0;
        //                    tcriteria.ConditionalRuleId = 0;
        //                }
        //            }

        //            foreach (var Ifild in table.SearchProfileList)
        //            {
        //                Ifild.ID = 0;
        //                Ifild.TableId = 0;

        //                foreach (var Sfild in Ifild.SearchFielsList)
        //                {
        //                    Sfild.ID = 0;
        //                    Sfild.FieldId = 0;
        //                }
        //            }
        //            foreach (var listpro in table.ListProfileDetails)
        //            {
        //                listpro.ID = 0;
        //                listpro.TableId = 0;

        //                foreach (var Ifild in listpro.DisplayFieldList)
        //                {
        //                    Ifild.ID = 0;
        //                    Ifild.ListProfileId = 0;
        //                    Ifild.FieldId = 0;
        //                }
        //            }
        //            foreach (var card in table.CardViewProfileDetails)
        //            {
        //                card.ID = 0;
        //                card.TableId = 0;

        //                foreach (var Cfild in card.CardViewFieldsList)
        //                {
        //                    Cfild.ID = 0;
        //                    Cfild.CardViewProfileId = 0;
        //                    Cfild.FieldId = 0;
        //                }
        //            }
        //        }


        //            projectDetails.TableWithDetailsList = tables;

        //        // Users
        //        //projectDetails.UserModelsList = (await connection.QueryAsync<UserModel>(
        //        //    "SELECT * FROM AppUser WHERE ProjectId = @ProjectId", new { ProjectId = projectId }, transaction)).ToList();

        //        // SendEmailActions
        //        //projectDetails.SendEmailActionsList = (await connection.QueryAsync<SendEmailAction>(
        //        //    "SELECT * FROM SendEmailAction WHERE ProjectId = @ProjectId", new { ProjectId = projectId }, transaction)).ToList();

        //        // Serialize and return
        //        var json = JsonConvert.SerializeObject(projectDetails, Formatting.Indented);
        //        var bytes = Encoding.UTF8.GetBytes(json);
        //        var fileName = $"project_{projectId}_export.json";

        //        return File(bytes, "application/json", fileName);
        //    }
        //    catch (Exception ex)
        //    {
        //        transaction.Rollback();
        //        return StatusCode(500, $"Export failed: {ex.Message}");
        //    }
        //}


        //[HttpPost("importProject")]
        //public async Task<IActionResult> ImportProject(IFormFile file)
        //{
        //    if (file == null || file.Length == 0)
        //        return BadRequest("No file uploaded.");

        //    using var connection = _dbContext.CreateConnection();
        //    connection.Open();
        //    using var transaction = connection.BeginTransaction();

        //    try
        //    {
        //        using var streamReader = new StreamReader(file.OpenReadStream());
        //        var json = await streamReader.ReadToEndAsync();

        //        var project = JsonConvert.DeserializeObject<ProjectDetails>(json);

        //        if (project == null)
        //            return BadRequest("Invalid or empty project data.");

        //        var clientExists = await connection.ExecuteScalarAsync<int>(
        //        "SELECT COUNT(1) FROM ClientManagement WHERE ID = @Id",
        //        new { Id = project.ClientId }, transaction);
        //        if (clientExists == 0)
        //            return BadRequest($"Client with ID {project.ClientId} does not exist.");

        //        // Insert or update project
        //        int projectId;
        //        //if (project.ID == null || project.ID == 0)
        //        if (project.ID == 0)
        //        {
        //            var projectid = await _context.CreateProject(project, connection, transaction, _env.WebRootPath);
        //            //projectId = int.Parse(await _context.CreateProject(project));
        //            string[] words = projectid.Split(' ');
        //            projectId = int.Parse(words[^1]);
        //            project.ID = projectId; // <- assign here
        //        }
        //        else
        //        {
        //            var conflict = await connection.ExecuteScalarAsync<int>(@"
        //            SELECT COUNT(1) FROM ProjectManagement 
        //            WHERE Name = @Name AND ClientId = @ClientId AND ID != @Id",
        //                project, transaction);


        //            if (conflict > 0)
        //                return BadRequest($"A project with name '{project.Name}' already exists for this client.");

        //            await _context.UpdateProject(project, _env.WebRootPath);

        //            projectId = project.ID;
        //        }

        //        // Prepare ID maps
        //        var fieldIdMap = new Dictionary<int, int>();
        //        var tableIdMap = new Dictionary<int, int>();
        //        var formIdMap = new Dictionary<int, int>();


        //        //using var content = new MultipartFormDataContent();
        //        //using var fileStream = file.OpenReadStream();
        //        //var fileContent = new StreamContent(fileStream);
        //        //fileContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);

        //        //content.Add(fileContent, "file", file.FileName); // 'file' is the key expected by the Import API
        //        //content.Add(new StringContent(projectId.ToString()), "projectId");

        //        //var apiUrl = _configuration["BackendApiUrl"]; // cleaner than GetSection().Value

        //        //if (string.IsNullOrEmpty(apiUrl))
        //        //    throw new InvalidOperationException("BackendApiUrl is not configured.");

        //        //var responseTable = await _httpClient.PostAsync($"{apiUrl}/table/ImportTable", content);
        //        //var responseForm = await _httpClient.PostAsync($"{apiUrl}/tables/form/FormImport", content);
        //        var responseTable = await _tableController.TableJsonImport(connection, transaction, file);

        //        if (responseTable is ObjectResult objectResult && objectResult.StatusCode >= 400)
        //        {
        //            return StatusCode(400, "Failed to call FormImport API.");
        //        }

        //        //if (!responseTable.IsSuccessStatusCode)
        //        //    return StatusCode((int)responseTable.StatusCode, "Failed to call ImportTable API.");

        //        //if (!responseForm.IsSuccessStatusCode)
        //        //    return StatusCode((int)responseForm.StatusCode, "Failed to call FormImport API.");

        //        //var responseData = await responseTable.Content.ReadAsStringAsync();
        //        //var res = await responseForm.Content.ReadAsStringAsync();

        //        transaction.Commit();
        //        return Ok(new { message = "Project imported successfully", projectId });
        //    }
        //    catch (Exception ex)
        //    {
        //        transaction.Rollback();
        //        throw new Exception("Import failed" + ex.Message);
        //    }
        //}

        #endregion

    }
}
