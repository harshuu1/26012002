﻿using Application.Modules.Client.Queries;
using Application.Modules.Project.Queries;
using Dapper;
using DapperDB;
using Entities.Models.Client;
using Entities.Models.Project;
using Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System.Data;
using System.IO.Compression;
using System.Xml.Linq;

namespace ProjectBuilder.Api.Controllers
{
    [ApiController]
    [Route("ProjectConfiguration")]
    public class ProjectConfigurationController(DapperDbContext.DbContext context, IConfiguration configuration, IProject project) : ControllerBase
    {
        private readonly IProject _project = project;

        [HttpPost("ConfigureProject")]
        public async Task<IActionResult> ConfigureProject(int clientId, int projectId)
        {
            try
            {
                using var connection = context.CreateConnection();

                var project = await connection.QuerySingleOrDefaultAsync<ProjectModel>(
                    ProjectSQLQuery.GetProjectById,
                    new { Id = projectId }
                );

                var client = await connection.QuerySingleOrDefaultAsync<ClientModel>(
                    ClientSQLQuery.GetById,
                    new { Id = clientId }
                );

                string databaseName = $"{project?.Name}_Configuration";
                string backupPath = configuration["BaseDatabasePath"] + "\\DynamicClientConfiguration.bak";
                string dacpacPath = configuration["BaseDatabasePath"] + "\\DynamicClientConfiguration.dacpac";
                string SQLRestorePath = configuration["SQLRestorePath"] ?? string.Empty;
                string DACPACSerializationPath = configuration["DACPACSerializationPath"] ?? string.Empty;

                await ConfigureDatabaseWithSchemaCompareAsync(
                    connection,
                    backupPath,
                    databaseName,
                    configuration,
                    targetFolder: SQLRestorePath,
                    DACPACSerializationPath,
                    preserveData: true,
                    baseDacpacPath: dacpacPath
                );

                if (project == null)
                    throw new Exception($"Project with ID {projectId} not found.");

                var sourcePath = configuration["ClientConfigurationPath"];
                var destinationRoot = configuration["ClientConfigurationRootPath"];

                string filePath = Path.Combine(sourcePath ?? "", "Presentation", "ClientManagement.Api", "appsettings.Development.json");

                if (string.IsNullOrWhiteSpace(sourcePath) || string.IsNullOrWhiteSpace(destinationRoot))
                    throw new Exception("Configuration paths are not set in appsettings.json.");

                if (!Directory.Exists(sourcePath))
                    throw new DirectoryNotFoundException($"Source folder not found: {sourcePath}");

                // Append project name
                var destinationPath = Path.Combine(destinationRoot, client?.FirstName + client?.LastName, project.Name);

                if (Directory.Exists(destinationPath))
                {
                    Directory.Delete(destinationPath, recursive: true);
                }

                Directory.CreateDirectory(destinationPath);

                // Copy files while ignoring Git-related & hidden
                CopyDirectory(sourcePath, destinationPath);

                //This is the code for kendo labels-- Start//
                var alignmentType = await _project.GetAlignmentTypeById(projectId);

                // Determine alignmentId safely
                int alignmentId = 1; // default left
                if (alignmentType != null)
                {
                    alignmentId = Convert.ToInt32(alignmentType);
                }

                // Decide label class based on alignmentId
                string labelClassValue;
                if (alignmentId == 1)
                {
                    labelClassValue = "label-left"; // left
                }
                else if (alignmentId == 2)
                {
                    labelClassValue = "label-top"; // top
                }
                else
                {
                    labelClassValue = "label-left"; // fallback
                }

                // Path for DemoWeb _ViewStart.cshtml
                //string viewStartPath = @"C:\BaseConfigurationProject\ClientManagement\DemoWeb\Views\_ViewStart.cshtml";
                string viewStartPath = destinationPath + @"\Presentation\ClientManagement.MvcUI\Views\_ViewStart.cshtml";

                var existingContent = System.IO.File.ReadAllText(viewStartPath);
                string updatedContent = existingContent;

                // Step 1: If ViewBag.LabelClass exists → just update the value
                if (existingContent.Contains("ViewBag.LabelClass"))
                {
                    updatedContent = System.Text.RegularExpressions.Regex.Replace(
                        existingContent,
                        @"ViewBag\.LabelClass\s*=\s*""[^""]*"";",
                        $"ViewBag.LabelClass = \"{labelClassValue}\";"
                    );
                }
                // Step 2: Else inject both lines once (clean formatting)
                else if (!existingContent.Contains("TempData[\"LabelClass\"]"))
                {
                    updatedContent = existingContent.Replace(
                        "ViewData[\"BackendUrl\"] = BackendSettings.BackendUrl;",
                $@"ViewData[""BackendUrl""] = BackendSettings.BackendUrl;
    ViewBag.LabelClass = ""{labelClassValue}"";
    TempData[""LabelClass""] = ViewBag.LabelClass;
"
                    );
                }

                // Step 3: Optional cleanup — remove any accidental duplicates in existing file
                updatedContent = System.Text.RegularExpressions.Regex.Replace(
                    updatedContent,
                    @"(TempData\[""LabelClass""\]\s*=\s*ViewBag\.LabelClass;)+",
                    "TempData[\"LabelClass\"] = ViewBag.LabelClass;"
                );

                // Write file
                System.IO.File.WriteAllText(viewStartPath, updatedContent);

                // Update appsettings in both source and destination
                void UpdateAppSettings(string settingsPath)
                {
                    if (!System.IO.File.Exists(settingsPath))
                        return;

                    var jsonContent = System.IO.File.ReadAllText(settingsPath);
                    var jsonObject = JObject.Parse(jsonContent);
                    var serverIpAddress = configuration.GetValue<string>("ServerIpAddress");
                    jsonObject["ClientAdminApiUrl"] = serverIpAddress + project.ClientAdminApiLink + "/";
                    jsonObject["ClientApiUrl"] = serverIpAddress + project.ClientApiLink + "/";
                    jsonObject["ClientName"] = client?.FirstName + client?.LastName;
                    jsonObject["ProjectName"] = project.Name;
                    jsonObject["ProjectLogo"] = project.ProjectLogo;

                    // Update connection string
                    if (jsonObject["ConnectionStrings"] is JObject connectionStrings && connectionStrings["DefaultConnection"] != null)
                    {
                        // Example existing conn string: "Server=.;Database=OldDb;Trusted_Connection=True;"
                        string? currentConn = connectionStrings["DefaultConnection"]?.ToString();

                        if (!string.IsNullOrEmpty(currentConn))
                        {
                            // Replace only the Database=... part
                            var builder = new SqlConnectionStringBuilder(currentConn)
                            {
                                InitialCatalog = databaseName // this is the DB name
                            };
                            connectionStrings["DefaultConnection"] = builder.ConnectionString;
                        }
                    }

                    // Write atomically
                    var tempFile = Path.GetTempFileName();
                    System.IO.File.WriteAllText(tempFile, jsonObject.ToString(Newtonsoft.Json.Formatting.Indented));
                    System.IO.File.Copy(tempFile, settingsPath, true);
                    System.IO.File.Delete(tempFile);
                }

                // Update in source
                var sourceSettingsPath = Path.Combine(sourcePath, "Presentation", "ClientManagement.Api", "appsettings.Development.json");
                UpdateAppSettings(sourceSettingsPath);

                // Update in destination
                var destinationSettingsPath = Path.Combine(destinationPath, "Presentation", "ClientManagement.Api", "appsettings.Development.json");
                UpdateAppSettings(destinationSettingsPath);

                var childFolderPath = destinationPath;

                bool IsPublishEnabled = configuration.GetValue<bool>("IsPublishClientUsingScript");
                //int apiPort = 0;
                //int uiPort = 0;

                //if (IsPublishEnabled)
                //{
                //    var apiUri = new Uri(project.ConfigurationApiLink ?? "");
                //    var uiUri = new Uri(project.ConfigurationUiLink ?? "");

                //    apiPort = apiUri.IsDefaultPort ? apiUri.Scheme == "https" ? 443 : 80 : apiUri.Port;
                //    uiPort = uiUri.IsDefaultPort ? uiUri.Scheme == "https" ? 443 : 80 : uiUri.Port;
                //}

                await connection.ExecuteAsync(ProjectSQLQuery.UpdateConfigureFlag, new { Id = project.ID, IsConfigure = 1 });

                await connection.ExecuteAsync(ProjectSQLQuery.UpdateConfigureFlag, new
                {
                    Id = project.ID,
                    IsConfigure = 1
                });

                await connection.ExecuteAsync(ProjectSQLQuery.InsertProjectPublishHistory, new
                {
                    ProjectId = project.ID,
                    IsBuildConfig = 1,
                    IsBuildClient = 0,
                    IsConfigDatabase = 0,
                    IsConfigProject = 0,
                    IsClientDatabase = 0,
                    IsClientProject = 0,
                    IsClientAdmin = 0,
                    CreatedBy = project.ClientId,
                    Remark = "IsConfigure"
                });



                return Ok(new { success = true, childFolderPath, project?.Name, project.ConfigurationApiLink, project.ConfigurationUiLink, IsPublishEnabled });
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static void CopyDirectory(string sourceDir, string destinationDir)
        {
            var gitIgnoreList = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                ".git",
                ".gitignore",
                ".gitattributes",
                "bin",
                "obj",
                "node_modules",
                //".vs"
            };

            var fileExtensionsToSkip = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                ".dbmdl", // database design file (always locked)
                ".mdf",   // SQL Server data file
                ".ldf",   // SQL Server log file
                //".user",
                ".suo",
                ".jfm",
                ".log",
                ".pdb"    // optional (keep if you need debug symbols)
            };

            foreach (var filePath in Directory.GetFiles(sourceDir))
            {
                var fileName = Path.GetFileName(filePath);
                var attributes = System.IO.File.GetAttributes(filePath);
                var extension = Path.GetExtension(filePath);

                if (gitIgnoreList.Contains(fileName) ||
                fileExtensionsToSkip.Contains(extension) ||
                attributes.HasFlag(FileAttributes.Hidden))
                {
                    continue;
                }

                var destFilePath = Path.Combine(destinationDir, fileName);
                System.IO.File.Copy(filePath, destFilePath, true);
            }

            foreach (var dirPath in Directory.GetDirectories(sourceDir))
            {
                var dirName = Path.GetFileName(dirPath);
                var attributes = System.IO.File.GetAttributes(dirPath);

                if (gitIgnoreList.Contains(dirName) || attributes.HasFlag(FileAttributes.Hidden))
                    continue;

                var destDirPath = Path.Combine(destinationDir, dirName);
                Directory.CreateDirectory(destDirPath);
                CopyDirectory(dirPath, destDirPath);
            }
        }


        public static async Task ConfigureDatabaseWithSchemaCompareAsync(
            IDbConnection connection,
            string backupPath,
            string databaseName,
            IConfiguration configuration,
            string targetFolder,
            string DACPACSerializationPath,
            bool preserveData = true,
            string? baseDacpacPath = null
        )
        {
            try
            {
                // Validate inputs
                ArgumentNullException.ThrowIfNull(connection);
                if (string.IsNullOrEmpty(databaseName)) throw new ArgumentException("Database name cannot be empty", nameof(databaseName));
                if (string.IsNullOrEmpty(backupPath)) throw new ArgumentException("Backup path cannot be empty", nameof(backupPath));

                Console.WriteLine($"🔧 Starting database configuration for: {databaseName}");

                // 1) Check if DB exists
                var existsSql = "SELECT DB_ID(@dbName)";
                var dbExists = await connection.ExecuteScalarAsync<int?>(existsSql, new { dbName = databaseName });

                if (!dbExists.HasValue)
                {
                    Console.WriteLine($"🆕 Database {databaseName} not found. Restoring from backup...");

                    if (!System.IO.File.Exists(backupPath))
                    {
                        throw new FileNotFoundException($"Backup file not found: {backupPath}");
                    }

                    await RestoreDatabaseAsync(connection, backupPath, databaseName, targetFolder, replaceIfExists: true);
                    Console.WriteLine($"✅ Database {databaseName} restored successfully");
                }
                else
                {
                    Console.WriteLine($"🔄 Database {databaseName} exists. Checking for schema updates...");
                }

                var targetConnectionString = BuildTargetConnectionString(connection, databaseName, configuration);
                using var configConn = new SqlConnection(targetConnectionString);

                // 2) Schema comparison and update (without SqlPackage)
                if (preserveData && !string.IsNullOrEmpty(baseDacpacPath))
                {
                    await ProcessSchemaUpdatesDirectly(configConn, databaseName, baseDacpacPath, DACPACSerializationPath);
                }
                else if (preserveData)
                {
                    Console.WriteLine("⚠️  Schema comparison skipped: No DACPAC path provided");
                }
                else
                {
                    Console.WriteLine("ℹ️  Schema comparison skipped: preserveData is false");
                }

                Console.WriteLine($"✅ Database configuration completed for: {databaseName}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Database configuration failed for {databaseName}: {ex.Message}");
                throw;
            }
        }

        private static async Task ProcessSchemaUpdatesDirectly(IDbConnection connection, string databaseName, string baseDacpacPath, string DACPACSerializationPath)
        {
            try
            {
                if (!System.IO.File.Exists(baseDacpacPath))
                {
                    Console.WriteLine($"⚠️  DACPAC file not found: {baseDacpacPath}");
                    Console.WriteLine("Skipping schema comparison. Database will be used as-is.");
                    return;
                }

                // Verify DACPAC can be read
                if (!VerifyDacpacReadable(baseDacpacPath))
                {
                    Console.WriteLine($"⚠️  DACPAC file appears to be corrupted: {baseDacpacPath}");
                    Console.WriteLine("Skipping schema comparison. Database will be used as-is.");
                    return;
                }

                // Apply schema differences directly
                await ApplySchemaDifferencesDirectly(connection.ConnectionString, databaseName, baseDacpacPath, DACPACSerializationPath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"⚠️  Schema update process failed: {ex.Message}");
                Console.WriteLine("Database will be used as-is without schema updates.");
                // Don't throw here - we want the database to be usable even if schema update fails
            }
        }

        private static bool VerifyDacpacReadable(string dacpacPath)
        {
            try
            {
                Console.WriteLine($"🔍 Verifying DACPAC readability: {dacpacPath}");

                using var archive = ZipFile.OpenRead(dacpacPath);
                var entry = archive.GetEntry("model.xml");

                if (entry == null)
                {
                    Console.WriteLine("❌ model.xml not found in DACPAC");
                    return false;
                }

                using var stream = entry.Open();
                var doc = XDocument.Load(stream);

                Console.WriteLine("✅ DACPAC is readable");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ DACPAC verification failed: {ex.Message}");
                return false;
            }
        }

        private static string BuildTargetConnectionString(IDbConnection connection, string databaseName, IConfiguration configuration)
        {
            try
            {
                var connString = configuration["ConnectionStrings:DefaultConnection"];

                if (string.IsNullOrEmpty(connString))
                {
                    throw new InvalidOperationException("DefaultConnection string not found in configuration");
                }

                var connBuilder = new SqlConnectionStringBuilder(connString);

                // Build target connection string
                var builder = new SqlConnectionStringBuilder(connection.ConnectionString)
                {
                    InitialCatalog = databaseName,
                    Password = connBuilder.Password
                };

                return builder.ConnectionString;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to build target connection string: {ex.Message}", ex);
            }
        }

        public static async Task ApplySchemaDifferencesDirectly(
            string targetConnectionString,
            string databaseName,
            string baseDacpacPath,
            string DACPACSerializationPath)
        {
            Console.WriteLine($"🔄 Starting direct schema comparison for database: {databaseName}");

            try
            {
                // Test database connection first
                await TestDatabaseConnection(targetConnectionString);

                // 1️⃣ Read current schema from target DB
                Console.WriteLine("📖 Reading current database schema...");
                var currentSchema = await GetColumnsFromDatabase(targetConnectionString);

                // 2️⃣ Read desired schema from DACPAC
                Console.WriteLine("📖 Reading schema from DACPAC...");
                var desiredSchema = GetColumnsFromDacpac(baseDacpacPath, DACPACSerializationPath);

                if (desiredSchema.Count == 0)
                {
                    Console.WriteLine("⚠️  No schema found in DACPAC, skipping comparison");
                    return;
                }

                // 3️⃣ Apply schema changes directly
                await ApplySchemaChangesDirect(targetConnectionString, currentSchema, desiredSchema, baseDacpacPath, DACPACSerializationPath);

                Console.WriteLine("✅ Direct schema comparison and update completed successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Direct schema compare failed: {ex.Message}");
                throw;
            }
        }

        private static async Task ApplySchemaChangesDirect(
            string connectionString,
            List<(string Table, string ColumnName, string DataType, int? Length)> currentSchema,
            List<(string Table, string ColumnName, string DataType, int? Length)> desiredSchema, string baseDacpacPath, string DACPACSerializationPath)
        {
            using var conn = new SqlConnection(connectionString);
            await conn.OpenAsync();

            try
            {
                Console.WriteLine("🔄 Applying schema changes directly...");

                var currentFKs = await GetCurrentForeignKeys(conn);
                var desiredFKs = GetDesiredForeignKeys(baseDacpacPath, DACPACSerializationPath);

                var tableRenames = await HandleTableRenamesDirect(conn, currentSchema, desiredSchema);
                var updatedCurrentSchema = UpdateSchemaAfterTableRenames(currentSchema, tableRenames);
                var columnRenames = await HandleColumnRenamesDirect(conn, updatedCurrentSchema, desiredSchema);

                await HandleForeignKeyChanges(conn, currentFKs, desiredFKs);
                await AddNewTables(conn, currentSchema, desiredSchema);
                await AddNewColumns(conn, currentSchema, desiredSchema, columnRenames);
                await ModifyExistingColumns(conn, currentSchema, desiredSchema);

                Console.WriteLine("✅ All schema changes applied successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to apply schema changes: {ex.Message}");
                throw;
            }
        }

        private static async Task<List<ForeignKeyInfo>> GetCurrentForeignKeys(SqlConnection conn)
        {
            var sql = @"
            SELECT 
                fk.name as ConstraintName,
                tp.name as ParentTable,
                cp.name as ParentColumn,
                tr.name as ReferencedTable,
                cr.name as ReferencedColumn,
                fk.delete_referential_action_desc as DeleteAction,
                fk.update_referential_action_desc as UpdateAction
            FROM sys.foreign_keys fk
            INNER JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
            INNER JOIN sys.tables tp ON fkc.parent_object_id = tp.object_id
            INNER JOIN sys.columns cp ON fkc.parent_object_id = cp.object_id AND fkc.parent_column_id = cp.column_id
            INNER JOIN sys.tables tr ON fkc.referenced_object_id = tr.object_id
            INNER JOIN sys.columns cr ON fkc.referenced_object_id = cr.object_id AND fkc.referenced_column_id = cr.column_id
            WHERE tp.schema_id = SCHEMA_ID('config') AND tr.schema_id = SCHEMA_ID('config')
            ORDER BY fk.name";

            var result = await conn.QueryAsync<ForeignKeyInfo>(sql);
            return [.. result];
        }

        private static List<ForeignKeyInfo> GetDesiredForeignKeys(string dacpacPath, string DACPACSerializationPath)
        {
            var foreignKeys = new List<ForeignKeyInfo>();

            try
            {
                Console.WriteLine("Reading foreign key constraints from DACPAC...");

                using var archive = ZipFile.OpenRead(dacpacPath);
                var entry = archive.GetEntry("model.xml");
                if (entry == null) return foreignKeys;

                XDocument doc;
                using (var stream = entry.Open())
                {
                    doc = XDocument.Load(stream);
                }

                XNamespace ns = DACPACSerializationPath;

                // Find all foreign key constraints
                var fkElements = doc.Descendants(ns + "Element")
                                   .Where(e => e.Attribute("Type")?.Value == "SqlForeignKeyConstraint");

                Console.WriteLine($"Found {fkElements.Count()} foreign key constraints in DACPAC");

                foreach (var fkElement in fkElements)
                {
                    try
                    {
                        var fkInfo = ExtractForeignKeyInfo(fkElement, ns);
                        if (fkInfo != null)
                        {
                            foreignKeys.Add(fkInfo);
                            Console.WriteLine($"  FK: {fkInfo.ParentTable}.{fkInfo.ParentColumn} -> {fkInfo.ReferencedTable}.{fkInfo.ReferencedColumn}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Failed to extract foreign key info: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to read foreign keys from DACPAC: {ex.Message}");
            }

            return foreignKeys;
        }

        private static ForeignKeyInfo ExtractForeignKeyInfo(XElement fkElement, XNamespace ns)
        {
            // Constraint name comes from <Annotation>
            var constraintName = fkElement.Elements(ns + "Annotation")
                                          .FirstOrDefault(a => a.Attribute("Type")?.Value == "SqlInlineConstraintAnnotation")
                                          ?.Attribute("Name")?.Value;

            // Parent column
            var parentColumn = fkElement.Elements(ns + "Relationship")
                                        .FirstOrDefault(r => r.Attribute("Name")?.Value == "Columns")
                                        ?.Elements(ns + "Entry")
                                        .Elements(ns + "References")
                                        .FirstOrDefault()
                                        ?.Attribute("Name")?.Value;

            // Parent table
            var parentTable = fkElement.Elements(ns + "Relationship")
                                       .FirstOrDefault(r => r.Attribute("Name")?.Value == "DefiningTable")
                                       ?.Elements(ns + "Entry")
                                       .Elements(ns + "References")
                                       .FirstOrDefault()
                                       ?.Attribute("Name")?.Value;

            // Referenced column
            var referencedColumn = fkElement.Elements(ns + "Relationship")
                                            .FirstOrDefault(r => r.Attribute("Name")?.Value == "ForeignColumns")
                                            ?.Elements(ns + "Entry")
                                            .Elements(ns + "References")
                                            .FirstOrDefault()
                                            ?.Attribute("Name")?.Value;

            // Referenced table
            var referencedTable = fkElement.Elements(ns + "Relationship")
                                           .FirstOrDefault(r => r.Attribute("Name")?.Value == "ForeignTable")
                                           ?.Elements(ns + "Entry")
                                           .Elements(ns + "References")
                                           .FirstOrDefault()
                                           ?.Attribute("Name")?.Value;

            if (string.IsNullOrEmpty(parentColumn) || string.IsNullOrEmpty(referencedTable))
                return new ForeignKeyInfo();

            return new ForeignKeyInfo
            {
                ConstraintName = constraintName ?? string.Empty,
                ParentTable = ExtractTableNameFromColumn(parentColumn),
                ParentColumn = ExtractColumnName(parentColumn),
                ReferencedTable = ExtractTableName(referencedTable),
                ReferencedColumn = ExtractColumnName(referencedColumn ?? string.Empty),
                DeleteAction = "NO_ACTION", // If DACPAC has action info, extract it
                UpdateAction = "NO_ACTION"
            };
        }


        private static async Task HandleForeignKeyChanges(
        SqlConnection conn,
        List<ForeignKeyInfo> currentFKs,
        List<ForeignKeyInfo> desiredFKs)
        {
            Console.WriteLine("Handling foreign key constraint changes...");

            // Find foreign keys to drop
            var fksToRemove = currentFKs.Where(current =>
                !desiredFKs.Any(desired =>
                    string.Equals(desired.ParentTable, current.ParentTable, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(desired.ParentColumn, current.ParentColumn, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(desired.ReferencedTable, current.ReferencedTable, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(desired.ReferencedColumn, current.ReferencedColumn, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            // Find foreign keys to add
            var fksToAdd = desiredFKs.Where(desired =>
                !currentFKs.Any(current =>
                    string.Equals(current.ParentTable, desired.ParentTable, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(current.ParentColumn, desired.ParentColumn, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(current.ReferencedTable, desired.ReferencedTable, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(current.ReferencedColumn, desired.ReferencedColumn, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            Console.WriteLine($"Foreign keys to remove: {fksToRemove.Count}");
            Console.WriteLine($"Foreign keys to add: {fksToAdd.Count}");

            // Drop foreign keys first
            foreach (var fk in fksToRemove)
            {
                try
                {
                    var dropSql = $"ALTER TABLE [config].[{fk.ParentTable}] DROP CONSTRAINT [{fk.ConstraintName}]";
                    Console.WriteLine($"Dropping FK: {dropSql}");
                    await conn.ExecuteAsync(dropSql);
                    Console.WriteLine($"Successfully dropped FK: {fk.ConstraintName}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to drop FK {fk.ConstraintName}: {ex.Message}");
                }
            }

            // Add new foreign keys
            foreach (var fk in fksToAdd)
            {
                try
                {
                    // Generate constraint name if not provided
                    var constraintName = string.IsNullOrEmpty(fk.ConstraintName)
                        ? $"FK_{fk.ParentTable}_{fk.ParentColumn}_{fk.ReferencedTable}_{fk.ReferencedColumn}"
                        : fk.ConstraintName;

                    // Check if both tables exist
                    var tablesExistSql = @"
                SELECT 
                    (SELECT COUNT(*) FROM sys.objects WHERE name = @parentTable AND type = 'U' AND schema_id = SCHEMA_ID('config')) as ParentExists,
                    (SELECT COUNT(*) FROM sys.objects WHERE name = @referencedTable AND type = 'U' AND schema_id = SCHEMA_ID('config')) as ReferencedExists";

                    var tableCheck = await conn.QueryFirstAsync<dynamic>(tablesExistSql, new
                    {
                        parentTable = fk.ParentTable,
                        referencedTable = fk.ReferencedTable
                    });

                    if (tableCheck.ParentExists > 0 && tableCheck.ReferencedExists > 0)
                    {
                        var addSql = $@"
                    ALTER TABLE [config].[{fk.ParentTable}] 
                    ADD CONSTRAINT [{constraintName}] 
                    FOREIGN KEY ([{fk.ParentColumn}]) 
                    REFERENCES [config].[{fk.ReferencedTable}]([{fk.ReferencedColumn}])";

                        // Add cascading actions if specified
                        if (!string.IsNullOrEmpty(fk.DeleteAction) && fk.DeleteAction != "NO_ACTION")
                        {
                            addSql += $" ON DELETE {fk.DeleteAction.Replace("_", " ")}";
                        }
                        if (!string.IsNullOrEmpty(fk.UpdateAction) && fk.UpdateAction != "NO_ACTION")
                        {
                            addSql += $" ON UPDATE {fk.UpdateAction.Replace("_", " ")}";
                        }

                        Console.WriteLine($"Adding FK: {addSql}");
                        await conn.ExecuteAsync(addSql);
                        Console.WriteLine($"Successfully added FK: {constraintName}");
                    }
                    else
                    {
                        Console.WriteLine($"Skipping FK {constraintName} - missing tables (Parent:{tableCheck.ParentExists}, Referenced:{tableCheck.ReferencedExists})");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to add FK {fk.ConstraintName}: {ex.Message}");
                }
            }
        }

        private static async Task<List<(string OldTable, string NewTable)>> HandleTableRenamesDirect(
        SqlConnection conn,
        List<(string Table, string ColumnName, string DataType, int? Length)> currentSchema,
        List<(string Table, string ColumnName, string DataType, int? Length)> desiredSchema)
        {
            Console.WriteLine("🔍 Detecting table renames...");

            // Get distinct tables from both schemas
            var currentTables = currentSchema
                .Select(c => c.Table)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            var desiredTables = desiredSchema
                .Select(c => c.Table)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            Console.WriteLine($"\n=== TABLE COMPARISON ===");
            Console.WriteLine($"Current tables: {string.Join(", ", currentTables)}");
            Console.WriteLine($"Desired tables: {string.Join(", ", desiredTables)}");

            // Find tables that disappeared
            var disappearedTables = currentTables
                .Where(ct => !desiredTables.Any(dt => string.Equals(dt, ct, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            // Find new tables
            var newTables = desiredTables
                .Where(dt => !currentTables.Any(ct => string.Equals(ct, dt, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            Console.WriteLine($"Disappeared tables: {string.Join(", ", disappearedTables)}");
            Console.WriteLine($"New tables: {string.Join(", ", newTables)}");

            var tableRenameOperations = new List<(string OldTable, string NewTable)>();

            // Try to match disappeared tables with new tables based on column structure
            foreach (var disappearedTable in disappearedTables)
            {
                Console.WriteLine($"\n🔍 Analyzing disappeared table: {disappearedTable}");

                var disappearedColumns = currentSchema
                    .Where(c => string.Equals(c.Table, disappearedTable, StringComparison.OrdinalIgnoreCase))
                    .Select(c => new { c.ColumnName, c.DataType, c.Length })
                    .OrderBy(c => c.ColumnName)
                    .ToList();

                Console.WriteLine($"  Columns: {string.Join(", ", disappearedColumns.Select(c => $"{c.ColumnName}({c.DataType})"))}");

                var bestMatch = "";
                var bestMatchScore = 0;

                foreach (var newTable in newTables)
                {
                    var newColumns = desiredSchema
                        .Where(c => string.Equals(c.Table, newTable, StringComparison.OrdinalIgnoreCase))
                        .Select(c => new { c.ColumnName, c.DataType, c.Length })
                        .OrderBy(c => c.ColumnName)
                        .ToList();

                    // Calculate similarity score
                    var matchingColumns = 0;
                    var totalColumns = Math.Max(disappearedColumns.Count, newColumns.Count);

                    foreach (var oldCol in disappearedColumns)
                    {
                        if (newColumns.Any(newCol =>
                            string.Equals(newCol.ColumnName, oldCol.ColumnName, StringComparison.OrdinalIgnoreCase) &&
                            string.Equals(newCol.DataType, oldCol.DataType, StringComparison.OrdinalIgnoreCase) &&
                            newCol.Length == oldCol.Length))
                        {
                            matchingColumns++;
                        }
                    }

                    var similarityScore = totalColumns > 0 ? matchingColumns * 100 / totalColumns : 0;

                    Console.WriteLine($"  Comparing with {newTable}: {matchingColumns}/{totalColumns} columns match ({similarityScore}%)");

                    // If more than 70% columns match, consider it a rename candidate
                    if (similarityScore > 70 && similarityScore > bestMatchScore)
                    {
                        bestMatch = newTable;
                        bestMatchScore = similarityScore;
                    }
                }

                if (!string.IsNullOrEmpty(bestMatch) && bestMatchScore > 70)
                {
                    Console.WriteLine($"✅ TABLE RENAME DETECTED: {disappearedTable} -> {bestMatch} ({bestMatchScore}% match)");
                    tableRenameOperations.Add((disappearedTable, bestMatch));
                    newTables.Remove(bestMatch); // Remove from new tables list to prevent multiple matches
                }
                else
                {
                    Console.WriteLine($"❌ No suitable rename candidate found for {disappearedTable}");
                }
            }

            // Execute table renames
            Console.WriteLine($"\n📊 TABLE RENAME SUMMARY: {tableRenameOperations.Count} table renames detected");

            foreach (var rename in tableRenameOperations)
            {
                try
                {
                    // Check if old table exists and new table doesn't
                    var checkSql = @"
                SELECT 
                    (SELECT COUNT(*) FROM sys.objects WHERE name = @oldTable AND type = 'U' AND schema_id = SCHEMA_ID('config')) as OldExists,
                    (SELECT COUNT(*) FROM sys.objects WHERE name = @newTable AND type = 'U' AND schema_id = SCHEMA_ID('config')) as NewExists";

                    var result = await conn.QueryFirstAsync<dynamic>(checkSql, new
                    {
                        oldTable = rename.OldTable,
                        newTable = rename.NewTable
                    });

                    Console.WriteLine($"🔍 Checking table rename feasibility: {rename.OldTable} -> {rename.NewTable}");
                    Console.WriteLine($"    Old table exists: {result.OldExists}, New table exists: {result.NewExists}");

                    if (result.OldExists > 0 && result.NewExists == 0)
                    {
                        var sql = $"EXEC sp_rename 'config.[{rename.OldTable}]', '{rename.NewTable}'";
                        Console.WriteLine($"🚀 Executing table rename: {sql}");
                        await conn.ExecuteAsync(sql);
                        Console.WriteLine($"✅ Successfully renamed table {rename.OldTable} -> {rename.NewTable}");
                    }
                    else
                    {
                        Console.WriteLine($"⚠️ Skipped table rename {rename.OldTable} -> {rename.NewTable} (Old:{result.OldExists}, New:{result.NewExists})");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Failed to rename table {rename.OldTable} -> {rename.NewTable}: {ex.Message}");
                }
            }

            return tableRenameOperations;
        }

        private static async Task<List<(string Table, string OldColumn, string NewColumn)>> HandleColumnRenamesDirect(
        SqlConnection conn,
        List<(string Table, string ColumnName, string DataType, int? Length)> currentSchema,
        List<(string Table, string ColumnName, string DataType, int? Length)> desiredSchema)
        {
            Console.WriteLine("🔍 Detecting column renames...");

            string Normalize(string dt, int? len)
            {
                if (string.IsNullOrWhiteSpace(dt)) return "";
                dt = dt.ToLower().Trim();

                return dt switch
                {
                    "nvarchar" or "varchar" or "varbinary" or "char" or "nchar" => len is null or -1 ? $"{dt}(max)" : $"{dt}({len})",
                    "decimal" or "numeric" => len.HasValue ? $"{dt}({len},0)" : $"{dt}(18,0)",
                    _ => dt,
                };
            }


            // Debug: Print all current and desired schemas
            Console.WriteLine("\n=== CURRENT SCHEMA ===");
            foreach (var col in currentSchema)
            {
                Console.WriteLine($"  {col.Table}.{col.ColumnName} -> {col.DataType}({col.Length}) -> Normalized: {Normalize(col.DataType, col.Length)}");
            }

            Console.WriteLine("\n=== DESIRED SCHEMA ===");
            foreach (var col in desiredSchema)
            {
                Console.WriteLine($"  {col.Table}.{col.ColumnName} -> {col.DataType}({col.Length}) -> Normalized: {Normalize(col.DataType, col.Length)}");
            }

            var disappearedColumns = currentSchema
                .Where(c => !desiredSchema.Any(d =>
                    string.Equals(d.Table, c.Table, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(d.ColumnName, c.ColumnName, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            var newColumns = desiredSchema
                .Where(d => !currentSchema.Any(c =>
                    string.Equals(c.Table, d.Table, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(c.ColumnName, d.ColumnName, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            Console.WriteLine("\n=== DISAPPEARED COLUMNS ===");
            foreach (var col in disappearedColumns)
            {
                Console.WriteLine($"  {col.Table}.{col.ColumnName} ({col.DataType}, {col.Length}) -> Normalized: {Normalize(col.DataType, col.Length)}");
            }

            Console.WriteLine("\n=== NEW COLUMNS ===");
            foreach (var col in newColumns)
            {
                Console.WriteLine($"  {col.Table}.{col.ColumnName} ({col.DataType}, {col.Length}) -> Normalized: {Normalize(col.DataType, col.Length)}");
            }

            var renameOperations = new List<(string Table, string OldColumn, string NewColumn)>();

            // Enhanced rename detection with detailed logging
            foreach (var disappeared in disappearedColumns.ToList()) // ToList() creates a copy for safe iteration
            {
                var disappearedNorm = Normalize(disappeared.DataType, disappeared.Length);
                Console.WriteLine($"\n🔍 Looking for matches for disappeared column: {disappeared.Table}.{disappeared.ColumnName} ({disappearedNorm})");

                var potentialMatches = newColumns
                    .Where(n => string.Equals(n.Table, disappeared.Table, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                Console.WriteLine($"  Found {potentialMatches.Count} potential matches in same table:");
                foreach (var match in potentialMatches)
                {
                    var matchNorm = Normalize(match.DataType, match.Length);
                    var isTypeMatch = string.Equals(matchNorm, disappearedNorm, StringComparison.OrdinalIgnoreCase);
                    Console.WriteLine($"    {match.ColumnName} ({matchNorm}) -> Type match: {isTypeMatch}");
                }

                var exactMatches = potentialMatches
                    .Where(n => string.Equals(Normalize(n.DataType, n.Length), disappearedNorm, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                Console.WriteLine($"  Exact type matches: {exactMatches.Count}");

                if (exactMatches.Count == 1)
                {
                    var match = exactMatches.First();
                    renameOperations.Add((disappeared.Table, disappeared.ColumnName, match.ColumnName));

                    Console.WriteLine($"✅ RENAME DETECTED: {disappeared.Table}.{disappeared.ColumnName} -> {match.ColumnName}");

                    // Remove from processing lists
                    disappearedColumns.Remove(disappeared);
                    newColumns.Remove(match);
                }
                else if (exactMatches.Count > 1)
                {
                    Console.WriteLine($"⚠️  Multiple exact matches found for {disappeared.ColumnName}, skipping automatic rename");
                }
                else
                {
                    Console.WriteLine($"❌ No exact type matches found for {disappeared.ColumnName}");
                }
            }

            Console.WriteLine($"\n📊 RENAME SUMMARY: {renameOperations.Count} renames detected");
            foreach (var rename in renameOperations)
            {
                Console.WriteLine($"  {rename.Table}.{rename.OldColumn} -> {rename.NewColumn}");
            }

            // Execute the rename operations
            foreach (var rename in renameOperations)
            {
                try
                {
                    var checkSql = @"
                SELECT 
                    (SELECT COUNT(*) FROM sys.columns c 
                     INNER JOIN sys.objects o ON c.object_id = o.object_id 
                     WHERE c.name = @oldName AND o.name = @tableName AND o.schema_id = SCHEMA_ID('config')) as OldExists,
                    (SELECT COUNT(*) FROM sys.columns c 
                     INNER JOIN sys.objects o ON c.object_id = o.object_id 
                     WHERE c.name = @newName AND o.name = @tableName AND o.schema_id = SCHEMA_ID('config')) as NewExists";

                    var result = await conn.QueryFirstAsync<dynamic>(checkSql, new
                    {
                        oldName = rename.OldColumn,
                        newName = rename.NewColumn,
                        tableName = rename.Table
                    });

                    Console.WriteLine($"🔍 Checking rename feasibility: {rename.Table}.{rename.OldColumn} -> {rename.NewColumn}");
                    Console.WriteLine($"    Old column exists: {result.OldExists}, New column exists: {result.NewExists}");

                    if (result.OldExists > 0 && result.NewExists == 0)
                    {
                        var sql = $"EXEC sp_rename 'config.[{rename.Table}].[{rename.OldColumn}]', '{rename.NewColumn}', 'COLUMN'";
                        Console.WriteLine($"🚀 Executing: {sql}");
                        await conn.ExecuteAsync(sql);
                        Console.WriteLine($"✅ Successfully renamed {rename.Table}.{rename.OldColumn} -> {rename.NewColumn}");
                    }
                    else
                    {
                        Console.WriteLine($"⚠️  Skipped rename {rename.Table}.{rename.OldColumn} -> {rename.NewColumn} (Old:{result.OldExists}, New:{result.NewExists})");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Failed to rename {rename.Table}.{rename.OldColumn} -> {rename.NewColumn}: {ex.Message}");
                }
            }

            return renameOperations;
        }


        private static List<(string Table, string ColumnName, string DataType, int? Length)> UpdateSchemaAfterTableRenames(
        List<(string Table, string ColumnName, string DataType, int? Length)> currentSchema,
        List<(string OldTable, string NewTable)> tableRenames)
        {
            if (!tableRenames.Any()) return currentSchema;

            var updatedSchema = new List<(string Table, string ColumnName, string DataType, int? Length)>();

            foreach (var item in currentSchema)
            {
                var rename = tableRenames.FirstOrDefault(r =>
                    string.Equals(r.OldTable, item.Table, StringComparison.OrdinalIgnoreCase));

                if (rename != default)
                {
                    // Update table name in schema
                    updatedSchema.Add((rename.NewTable, item.ColumnName, item.DataType, item.Length));
                }
                else
                {
                    // Keep original
                    updatedSchema.Add(item);
                }
            }

            Console.WriteLine($"📝 Updated current schema references after {tableRenames.Count} table renames");
            return updatedSchema;
        }


        private static async Task AddNewTables(
            SqlConnection conn,
            List<(string Table, string ColumnName, string DataType, int? Length)> currentSchema,
            List<(string Table, string ColumnName, string DataType, int? Length)> desiredSchema)
        {

            var currentTables = currentSchema.Select(c => c.Table).Distinct(StringComparer.OrdinalIgnoreCase).ToHashSet();
            var desiredTables = desiredSchema.Select(c => c.Table).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

            var newTables = desiredTables.Where(table => !currentTables.Contains(table)).ToList();

            foreach (var tableName in newTables)
            {
                try
                {
                    Console.WriteLine($"🆕 Creating new table: {tableName}");

                    var tableColumns = desiredSchema.Where(c =>
                        string.Equals(c.Table, tableName, StringComparison.OrdinalIgnoreCase)).ToList();

                    var columnDefinitions = tableColumns.Select(col =>
                        $"[{col.ColumnName}] {GetSqlDataTypeDefinition(col.DataType, col.Length)}").ToList();

                    var createTableSql = $@"
                CREATE TABLE [config].[{tableName}] (
                    {string.Join(",\n    ", columnDefinitions)}
                )";

                    await conn.ExecuteAsync(createTableSql);
                    Console.WriteLine($"✅ Created table: {tableName}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Failed to create table {tableName}: {ex.Message}");
                }
            }
        }

        private static async Task AddNewColumns(
        SqlConnection conn,
        List<(string Table, string ColumnName, string DataType, int? Length)> currentSchema,
        List<(string Table, string ColumnName, string DataType, int? Length)> desiredSchema,
        List<(string Table, string OldColumn, string NewColumn)> renameOperations)
        {
            Console.WriteLine("🔄 Adding new columns...");

            var renamedTargets = renameOperations.Select(r => (r.Table, r.NewColumn)).ToHashSet();

            var newColumns = desiredSchema
                .Where(d =>
                    !currentSchema.Any(c =>
                        string.Equals(c.Table, d.Table, StringComparison.OrdinalIgnoreCase) &&
                        string.Equals(c.ColumnName, d.ColumnName, StringComparison.OrdinalIgnoreCase)) &&
                    !renamedTargets.Contains((d.Table, d.ColumnName)) // ✅ skip renamed
                )
                .ToList();

            foreach (var col in newColumns)
            {
                try
                {
                    var tableExistsSql = "SELECT COUNT(*) FROM sys.objects WHERE name = @tableName AND type = 'U'";
                    var tableExists = await conn.ExecuteScalarAsync<int>(tableExistsSql, new { tableName = col.Table });

                    if (tableExists > 0)
                    {
                        var def = GetSqlDataTypeDefinition(col.DataType, col.Length);
                        var sql = $"ALTER TABLE [config].[{col.Table}] ADD [{col.ColumnName}] {def} NULL";

                        await conn.ExecuteAsync(sql);
                        Console.WriteLine($"✅ Added column: {col.Table}.{col.ColumnName} ({def})");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Failed to add column {col.Table}.{col.ColumnName}: {ex.Message}");
                }
            }
        }



        private static async Task ModifyExistingColumns(
        SqlConnection conn,
        List<(string Table, string ColumnName, string DataType, int? Length)> currentSchema,
        List<(string Table, string ColumnName, string DataType, int? Length)> desiredSchema)
        {
            Console.WriteLine("🔄 Checking for column modifications...");

            foreach (var desired in desiredSchema)
            {
                var current = currentSchema.FirstOrDefault(c =>
                    string.Equals(c.Table, desired.Table, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(c.ColumnName, desired.ColumnName, StringComparison.OrdinalIgnoreCase));

                if (current != default &&
                    (!string.Equals(current.DataType, desired.DataType, StringComparison.OrdinalIgnoreCase) ||
                     current.Length != desired.Length))
                {
                    try
                    {
                        var newDataTypeDef = GetSqlDataTypeDefinition(desired.DataType, desired.Length);
                        var alterSql = $"ALTER TABLE [config].[{desired.Table}] ALTER COLUMN [{desired.ColumnName}] {newDataTypeDef}";

                        await conn.ExecuteAsync(alterSql);
                        Console.WriteLine($"✅ Modified column: {desired.Table}.{desired.ColumnName} -> {newDataTypeDef}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"❌ Failed to modify column {desired.Table}.{desired.ColumnName}: {ex.Message}");
                    }
                }
            }
        }


        private static string GetSqlDataTypeDefinition(string dataType, int? length)
        {
            return dataType.ToLower() switch
            {
                "nvarchar" => length.HasValue ? $"NVARCHAR({(length == -1 ? "MAX" : length.ToString())})" : "NVARCHAR(255)",
                "varchar" => length.HasValue ? $"VARCHAR({(length == -1 ? "MAX" : length.ToString())})" : "VARCHAR(255)",
                "char" => length.HasValue ? $"CHAR({length})" : "CHAR(1)",
                "nchar" => length.HasValue ? $"NCHAR({length})" : "NCHAR(1)",
                "int" => "INT",
                "bigint" => "BIGINT",
                "smallint" => "SMALLINT",
                "tinyint" => "TINYINT",
                "bit" => "BIT",
                "decimal" => "DECIMAL(18,2)",
                "numeric" => "NUMERIC(18,2)",
                "float" => "FLOAT",
                "real" => "REAL",
                "datetime" => "DATETIME",
                "datetime2" => "DATETIME2",
                "date" => "DATE",
                "time" => "TIME",
                "uniqueidentifier" => "UNIQUEIDENTIFIER",
                "text" => "TEXT",
                "ntext" => "NTEXT",
                "image" => "IMAGE",
                "varbinary" => length.HasValue ? $"VARBINARY({(length == -1 ? "MAX" : length.ToString())})" : "VARBINARY(MAX)",
                "binary" => length.HasValue ? $"BINARY({length})" : "BINARY(1)",
                _ => dataType.ToUpper()
            };
        }

        private static async Task TestDatabaseConnection(string connectionString)
        {
            try
            {
                using var testConn = new SqlConnection(connectionString);
                await testConn.OpenAsync();
                Console.WriteLine("✅ Database connection verified");
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Cannot connect to target database: {ex.Message}", ex);
            }
        }

        // Get existing DB schema
        private static async Task<List<(string Table, string ColumnName, string DataType, int? Length)>>
            GetColumnsFromDatabase(string connString)
        {
            try
            {
                using var conn = new SqlConnection(connString);
                await conn.OpenAsync();

                string sql = @"
                SELECT 
                    t.TABLE_NAME,
                    c.COLUMN_NAME,
                    c.DATA_TYPE,
                    c.CHARACTER_MAXIMUM_LENGTH
                FROM INFORMATION_SCHEMA.TABLES t
                INNER JOIN INFORMATION_SCHEMA.COLUMNS c ON t.TABLE_NAME = c.TABLE_NAME
                WHERE t.TABLE_TYPE = 'BASE TABLE'
                AND t.TABLE_SCHEMA = 'config'
                ORDER BY t.TABLE_NAME, c.ORDINAL_POSITION";

                var rows = await conn.QueryAsync(sql);

                return rows.Select(r => (
                    Table: (string)r.TABLE_NAME,
                    ColumnName: (string)r.COLUMN_NAME,
                    DataType: (string)r.DATA_TYPE,
                    Length: (int?)r.CHARACTER_MAXIMUM_LENGTH
                )).ToList();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to read database schema: {ex.Message}", ex);
            }
        }

        // Get new schema from DACPAC
        private static List<(string Table, string ColumnName, string DataType, int? Length)> GetColumnsFromDacpac(string dacpacPath, string DACPACSerializationPath)
        {
            var columns = new List<(string Table, string ColumnName, string DataType, int? Length)>();

            try
            {
                Console.WriteLine($"🔍 Reading DACPAC schema from: {dacpacPath}");

                using var archive = ZipFile.OpenRead(dacpacPath);
                var entry = archive.GetEntry("model.xml") ?? throw new InvalidOperationException("model.xml not found in DACPAC.");
                XDocument doc;
                using (var stream = entry.Open())
                {
                    doc = XDocument.Load(stream);
                }

                XNamespace ns = DACPACSerializationPath;

                // Find all tables
                var tables = doc.Descendants(ns + "Element")
                                .Where(e => e.Attribute("Type")?.Value == "SqlTable");

                Console.WriteLine($"📊 Found {tables.Count()} tables in DACPAC");

                foreach (var table in tables)
                {
                    try
                    {
                        // Extract table name
                        var tableNameAttr = table.Attribute("Name")?.Value;
                        var tableName = ExtractTableName(tableNameAttr);
                        if (string.IsNullOrEmpty(tableName)) continue;

                        Console.WriteLine($"\n🔍 Processing table: {tableNameAttr} -> {tableName}");

                        // Get columns
                        var columnElements = GetColumnElements(table, ns);
                        Console.WriteLine($"  Found {columnElements.Count()} columns");

                        foreach (var column in columnElements)
                        {
                            try
                            {
                                var columnInfo = ExtractColumnInfo(column, ns);
                                if (columnInfo.HasValue)
                                {
                                    columns.Add((tableName, columnInfo.Value.Name, columnInfo.Value.DataType, columnInfo.Value.Length));
                                    Console.WriteLine($"  ✅ {columnInfo.Value.Name}: {columnInfo.Value.DataType}({columnInfo.Value.Length})");
                                }
                                else
                                {
                                    var colName = column.Attribute("Name")?.Value;
                                    Console.WriteLine($"  ❌ Failed to extract column info for: {colName}");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"  ⚠️  Failed to extract column info: {ex.Message}");
                                // Continue with other columns
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"⚠️  Failed to process table: {ex.Message}");
                        // Continue with other tables
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to read DACPAC schema: {ex.Message}", ex);
            }

            Console.WriteLine($"\n📊 DACPAC Schema Summary: {columns.Count} columns across {columns.Select(c => c.Table).Distinct().Count()} tables");

            return columns;
        }

        private static string ExtractTableName(string? fullName)
        {
            if (string.IsNullOrEmpty(fullName)) return "";

            var cleanName = fullName.Replace("[", "").Replace("]", "");
            var parts = cleanName.Split('.');

            var tableName = parts.Length > 0 ? parts[^1] : cleanName;

            Console.WriteLine($"🔍 Extracted table name: '{fullName}' -> '{tableName}'");
            return tableName;
        }

        private static IEnumerable<XElement> GetColumnElements(XElement table, XNamespace ns)
        {
            var relationship = table.Elements(ns + "Relationship")
                                   .FirstOrDefault(r => r.Attribute("Name")?.Value == "Columns");

            if (relationship == null) return [];

            return relationship.Elements(ns + "Entry")
                              .Elements(ns + "Element")
                              .Where(c => c.Attribute("Type")?.Value?.Contains("Column") == true);
        }

        private static (string Name, string DataType, int? Length)? ExtractColumnInfo(XElement column, XNamespace ns)
        {
            var fullColumnName = column.Attribute("Name")?.Value;
            if (string.IsNullOrEmpty(fullColumnName))
            {
                Console.WriteLine("    ⚠️  Column element has no Name attribute");
                return null;
            }

            var columnName = ExtractColumnName(fullColumnName);
            Console.WriteLine($"    🔍 Processing column: {fullColumnName} -> {columnName}");

            // Navigate to SqlTypeSpecifier - try multiple paths
            var typeSpecifier = column
                .Descendants(ns + "Element")
                .FirstOrDefault(e => e.Attribute("Type")?.Value == "SqlTypeSpecifier");

            if (typeSpecifier == null)
            {
                // Alternative path - sometimes the structure is different
                typeSpecifier = column
                    .Elements(ns + "Relationship")
                    .Where(r => r.Attribute("Name")?.Value == "DataType")
                    .Elements(ns + "Entry")
                    .Elements(ns + "Element")
                    .FirstOrDefault(e => e.Attribute("Type")?.Value == "SqlTypeSpecifier");
            }

            string dataType = "unknown";
            int? length = null;

            if (typeSpecifier != null)
            {
                Console.WriteLine("      ✅ Found SqlTypeSpecifier");

                // Get the DataType - try multiple approaches
                var typeRef = typeSpecifier
                    .Descendants(ns + "References")
                    .FirstOrDefault();

                if (typeRef != null)
                {
                    var rawDataType = typeRef.Attribute("Name")?.Value;
                    dataType = ExtractDataTypeName(rawDataType);
                    Console.WriteLine($"      📝 Raw data type: {rawDataType} -> {dataType}");
                }
                else
                {
                    Console.WriteLine("      ⚠️  No References element found for data type");
                }

                // Get Length property (if exists)
                var lengthProp = typeSpecifier
                    .Descendants(ns + "Property")
                    .FirstOrDefault(p => p.Attribute("Name")?.Value == "Length");

                if (lengthProp != null && int.TryParse(lengthProp.Attribute("Value")?.Value, out var len))
                {
                    length = len;
                    Console.WriteLine($"      📏 Length: {length}");
                }
                else
                {
                    Console.WriteLine("      📏 No length property found");
                }
            }
            else
            {
                Console.WriteLine("      ❌ SqlTypeSpecifier not found - using fallback approach");

                // Fallback: try to extract from the column element directly
                var typeAttr = column.Attribute("Type")?.Value;
                if (!string.IsNullOrEmpty(typeAttr))
                {
                    dataType = ExtractDataTypeName(typeAttr);
                    Console.WriteLine($"      📝 Fallback data type: {dataType}");
                }
            }

            var result = (columnName, dataType, length);
            Console.WriteLine($"      ✅ Final result: {result.columnName} ({result.dataType}, {result.length})");
            return result;
        }

        private static string ExtractDataTypeName(string? rawDataType)
        {
            if (string.IsNullOrEmpty(rawDataType)) return "unknown";

            // Handle full type names like "[sys].[nvarchar]" or "SqlSimpleColumn"
            if (rawDataType.Contains('.'))
            {
                var parts = rawDataType.Split('.');
                var typeName = parts.Last().Trim('[', ']');
                return typeName;
            }

            // Handle SqlXXXColumn types
            if (rawDataType.StartsWith("Sql") && rawDataType.EndsWith("Column"))
            {
                // SqlSimpleColumn, SqlComputedColumn, etc. - need different approach
                return "unknown";
            }

            return rawDataType.Trim('[', ']');
        }

        private static string ExtractColumnName(string fullName)
        {
            // Converts [dbo].[Table].[Column] → Column
            if (string.IsNullOrEmpty(fullName)) return string.Empty;
            var parts = fullName.Trim('[', ']').Split(["].["], StringSplitOptions.None);
            return parts.LastOrDefault() ?? string.Empty;
        }


        public static async Task RestoreDatabaseAsync(
            IDbConnection connection,
            string backupPath,
            string databaseName,
            string targetFolder,
            bool replaceIfExists = true)
        {
            if (string.IsNullOrWhiteSpace(backupPath) || !Path.IsPathRooted(backupPath))
                throw new ArgumentException("backupPath must be an absolute path.", nameof(backupPath));
            if (string.IsNullOrWhiteSpace(databaseName))
                throw new ArgumentException("databaseName must be provided.", nameof(databaseName));

            Directory.CreateDirectory(targetFolder);

            // 1) Discover logical file names from the .bak
            const string fileListSql = @"RESTORE FILELISTONLY FROM DISK = @backupPath;";
            var fileList = (await connection.QueryAsync<FileListRow>(fileListSql, new { backupPath })).ToList();
            if (fileList.Count == 0)
                throw new InvalidOperationException("The backup does not contain any files.");

            // Split into data and log files
            var dataFiles = fileList.Where(f => string.Equals(f.Type, "D", StringComparison.OrdinalIgnoreCase)).ToList();
            var logFiles = fileList.Where(f => string.Equals(f.Type, "L", StringComparison.OrdinalIgnoreCase)).ToList();
            if (dataFiles.Count == 0 || logFiles.Count == 0)
                throw new InvalidOperationException("Backup must contain at least one data file (Type='D') and one log file (Type='L').");

            // 2) Build MOVE clauses
            var moveClauses = new List<string>();
            for (int i = 0; i < dataFiles.Count; i++)
            {
                var df = dataFiles[i];
                var ext = i == 0 ? "mdf" : "ndf";
                var destPath = Path.Combine(targetFolder, i == 0 ? $"{databaseName}.{ext}" : $"{databaseName}_{i}.{ext}");
                moveClauses.Add($"MOVE N'{EscapeSql(df.LogicalName ?? "")}' TO N'{EscapeSql(destPath)}'");
            }
            for (int i = 0; i < logFiles.Count; i++)
            {
                var lf = logFiles[i];
                var destPath = Path.Combine(targetFolder, i == 0 ? $"{databaseName}_log.ldf" : $"{databaseName}_log_{i}.ldf");
                moveClauses.Add($"MOVE N'{EscapeSql(lf.LogicalName ?? "")}' TO N'{EscapeSql(destPath)}'");
            }

            // 3) Compose RESTORE command
            var options = new List<string>(moveClauses);
            if (replaceIfExists) options.Add("REPLACE");
            options.Add("RECOVERY");

            var restoreSql = $@"
            USE master;
            RESTORE DATABASE [{databaseName}]
            FROM DISK = @backupPath
            WITH
                 {string.Join(",\n     ", options)};";

            // 4) Handle database replacement
            if (replaceIfExists)
            {
                string singleUserSql = $@"
                IF DB_ID(@db) IS NOT NULL
                BEGIN
                    ALTER DATABASE [{databaseName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
                END";
                await connection.ExecuteAsync(singleUserSql, new { db = databaseName });
            }

            try
            {
                await connection.ExecuteAsync(restoreSql, new { backupPath });
                Console.WriteLine($"✅ Database {databaseName} restored successfully");
            }
            finally
            {
                // Always try to set MULTI_USER afterwards
                string multiUserSql = $@"
                IF DB_ID(@db) IS NOT NULL
                BEGIN
                    ALTER DATABASE [{databaseName}] SET MULTI_USER;
                END";
                await connection.ExecuteAsync(multiUserSql, new { db = databaseName });
            }
        }

        private static string EscapeSql(string input)
        {
            return input?.Replace("'", "''") ?? string.Empty;
        }

        public class FileListRow
        {
            public string? LogicalName { get; set; }
            public string? PhysicalName { get; set; }
            public string? Type { get; set; }
            public string? FileGroupName { get; set; }
            public long Size { get; set; }
            public long MaxSize { get; set; }
        }

        private static string ExtractConstraintName(string fullName)
        {
            if (string.IsNullOrEmpty(fullName)) return "";
            var parts = fullName.Replace("[", "").Replace("]", "").Split('.');
            return parts.LastOrDefault() ?? "";
        }

        private static string ExtractTableNameFromColumn(string columnFullName)
        {
            if (string.IsNullOrEmpty(columnFullName)) return "";
            var parts = columnFullName.Replace("[", "").Replace("]", "").Split('.');
            return parts.Length >= 2 ? parts[^2] : ""; // Second to last part
        }

        // Foreign key info class
        public class ForeignKeyInfo
        {
            public string ConstraintName { get; set; } = "";
            public string ParentTable { get; set; } = "";
            public string ParentColumn { get; set; } = "";
            public string ReferencedTable { get; set; } = "";
            public string ReferencedColumn { get; set; } = "";
            public string DeleteAction { get; set; } = "NO_ACTION";
            public string UpdateAction { get; set; } = "NO_ACTION";
        }
    }
}
