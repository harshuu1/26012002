﻿using ApplicationDI;
using Entities.Models.AppUser;
using InfrastructureDI;
using Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using ProjectBuilder.Api.Extensions;
using Repositories;
using Serilog;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

var EnvironmentName = builder.Environment.EnvironmentName;
var configuration = new ConfigurationBuilder().AddJsonFile(EnvironmentName == "" ? $"appsettings.json" : $"appsettings.{EnvironmentName}.json", optional: true, reloadOnChange: true).Build();

var jwtModel = new JwtModel
{
    JwtIssuer = configuration["Jwt:Issuer"] ?? string.Empty,
    JwtAudience = configuration["Jwt:Audience"] ?? string.Empty,
    JwtKey = configuration["Jwt:Key"] ?? string.Empty,
    JwtExpiryInHours = configuration.GetValue<int>("Jwt:TokenExpiryInHours"),
    MaxIdleMinutes = configuration.GetValue<int>("Jwt:IdleTimeOutMinutes")
};
builder.Services.AddSingleton<JwtModel>(jwtModel);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerDocumentation();

// Application DI (MediatR, Behaviors, etc.)
builder.Services.AddApplication();

// Infrastructure DI (DbContext, Repositories, etc.)
builder.Services.AddInfrastructure(builder.Configuration);

builder.Services.AddHttpContextAccessor(); 
builder.Services.AddHttpClient();
builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(configuration.GetValue<int>("Jwt:IdleTimeOutMinutes"));
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = configuration["Jwt:Issuer"],
        ValidAudience = configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(configuration["Jwt:Key"] ?? string.Empty))
    };
    options.Events = new JwtBearerEvents
    {
        OnMessageReceived = context =>
        {
            if (context.Request.Cookies.ContainsKey("jwtToken"))
            {
                context.Token = context.Request.Cookies["jwtToken"];
            }
            return Task.CompletedTask;
        }
    };
});

var frontendUrl = builder.Configuration["BackendUiUrl"];

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", builder =>
    {
        builder.WithOrigins(frontendUrl ?? string.Empty)
            .AllowCredentials()
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

// Setup Serilog logger using your custom logic
builder.Host.UseSerilog((context, services, configuration) =>
{
    configuration
        .ReadFrom.Configuration(context.Configuration)
        .ReadFrom.Services(services)
        .Enrich.FromLogContext();
});


var app = builder.Build();

// ✅ Correct middleware order
app.UseHttpsRedirection();
app.UseStaticFiles();

// ✅ CORS must be before routing
app.UseCors("AllowFrontend");

app.UseRouting();
app.UseSession();

// ✅ Custom middleware after routing
app.UseMiddleware<TokenValidationMiddleware>();
app.UseMiddleware<ErrorHandlerMiddleware>();

// ❌ REMOVED THE PROBLEMATIC REDIRECT MIDDLEWARE
// Backend API should ONLY return JSON responses, never redirect

app.UseAuthentication();
app.UseAuthorization();

// Ensure Excel directory exists
var excelDir = Path.Combine(app.Environment.WebRootPath, "ImportProfileExcelSheets");
if (!Directory.Exists(excelDir))
{
Directory.CreateDirectory(excelDir);
}

// Swagger
app.UseSwaggerDocumentation(app.Environment);
app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

app.Run();

public partial class Program { }