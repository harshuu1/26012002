﻿using Microsoft.AspNetCore.Http;
using System.IdentityModel.Tokens.Jwt;


namespace Repositories
{
    public class TokenValidationMiddleware(RequestDelegate next)
    {
        private readonly RequestDelegate _next = next;
        private readonly HashSet<string> _excludedPaths =
        [
            "/user/login",
            "/user/register",
            "/user/validate", // allow this path even if token is expired
            "/user/jwt",       // for idle timer config
            "/swagger",        // ✅ allow swagger UI
            "/swagger/index.html", // ✅ allow direct swagger URL
            "/swagger/v1/swagger.json" // ✅ allow swagger docs
        ];

        public async Task InvokeAsync(HttpContext context)
        {
            var path = context.Request.Path.Value;

            // Skip validation for excluded paths
            if (_excludedPaths.Any(p => path?.StartsWith(p, StringComparison.OrdinalIgnoreCase) == true))
            {
                await _next(context);
                return;
            }

            // Try to get token from cookie first, then Authorization header
            var token = context.Request.Cookies["jwtToken"]
                        ?? context.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();

            if (!string.IsNullOrEmpty(token))
            {
                JwtSecurityToken jwtToken;
                try
                {
                    var handler = new JwtSecurityTokenHandler();
                    jwtToken = handler.ReadJwtToken(token);
                }
                catch
                {
                    await HandleUnauthorized(context, "Invalid token format");
                    return;
                }

                // Check token expiration
                if (jwtToken.ValidTo < DateTime.UtcNow)
                {
                    await HandleUnauthorized(context, "Token expired");
                    return;
                }

                // Add token to Authorization header for downstream middleware/controllers
                if (!context.Request.Headers.ContainsKey("Authorization"))
                {
                    context.Request.Headers.Append("Authorization", $"Bearer {token}");
                }
            }
            else
            {
                // No token found
                await HandleUnauthorized(context, "Token expired");
                return;
            }

            await _next(context);
        }

        private static async Task HandleUnauthorized(HttpContext context, string message)
        {
            // Check if request is AJAX / API call
            bool isAjax = context.Request.Headers.XRequestedWith == "XMLHttpRequest" ||
              context.Request.Headers.Accept.Any(a => a?.Contains("application/json", StringComparison.OrdinalIgnoreCase) == true);

            // Clear any pending response before redirecting
            context.Response.Clear();

            if (isAjax)
            {
                // Return 401 JSON for AJAX/API
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsync($"{{\"error\": \"{message}\"}}");
            }
            //else
            //{
            //    context.Response.Redirect("/swagger/index.html");
            //}
        }

    }
}
