﻿using Entities.Exceptions;
using Serilog;
using System.Net;
using System.Text;
using System.Text.Json;

namespace ProjectBuilder.Api.Extensions
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        private static bool _logFolderChecked = false;
        private static readonly string _logDirectory = Path.Combine(AppContext.BaseDirectory, "Logs");
        private const int _logRetentionDays = 15;

        public ErrorHandlerMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            string requestBody = string.Empty;

            try
            {
                context.Request.EnableBuffering();

                using (var reader = new StreamReader(
                    context.Request.Body, Encoding.UTF8, detectEncodingFromByteOrderMarks: false, bufferSize: 1024, leaveOpen: true))
                {
                    requestBody = await reader.ReadToEndAsync();
                    context.Request.Body.Position = 0;
                }

                await _next(context);
            }
            catch (Exception ex)
            {
                EnsureLogDirectoryAndCleanup();
                await HandleExceptionAsync(context, requestBody, ex);
            }
        }

        private static void EnsureLogDirectoryAndCleanup()
        {
            if (_logFolderChecked) return;

            // Create folder if not exists
            if (!Directory.Exists(_logDirectory))
                Directory.CreateDirectory(_logDirectory);

            // Delete files older than 15 days
            var files = Directory.GetFiles(_logDirectory);
            foreach (var file in files)
            {
                var creationTime = File.GetCreationTime(file);
                if (creationTime < DateTime.Now.AddDays(-_logRetentionDays))
                {
                    try
                    {
                        File.Delete(file);
                    }
                    catch
                    {
                    }
                }
            }

            _logFolderChecked = true;
        }

        private static async Task HandleExceptionAsync(HttpContext context, string requestBody, Exception exception)
        {
            var response = context.Response;
            response.ContentType = "application/json";

            response.StatusCode = exception switch
            {
                AppException => (int)HttpStatusCode.UnprocessableEntity,
                KeyNotFoundException => (int)HttpStatusCode.NotFound,
                InvalidDataException => (int)HttpStatusCode.Forbidden,
                _ => (int)HttpStatusCode.InternalServerError,
            };

            var logContext = new
            {
                Method = context.Request.Method,
                Path = context.Request.Path,
                Query = context.Request.QueryString.ToString(),
                Headers = context.Request.Headers.ToDictionary(h => h.Key, h => h.Value.ToString()),
                Body = requestBody
            };

            Log.ForContext("RequestContext", logContext, destructureObjects: true)
               .Error(exception, "Unhandled exception occurred in API");

            var errorMessage = exception.InnerException?.Message ?? exception.Message;
            var result = JsonSerializer.Serialize(new { message = errorMessage });

            await response.WriteAsync(result);
        }
    }
}
