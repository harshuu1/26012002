﻿using DapperDB;
using Entities.Models.AppUser;
using Interfaces;
using Microsoft.AspNetCore.Identity;
using Repositories;

namespace ProjectBuilder.Api.Extensions
{
    public static class DataAccessService
    {
        public static IServiceCollection AddDataAccessServices(this IServiceCollection services, IConfiguration configuration)
        {
            // Register Dapper DbContext for DI
            services.AddScoped<DapperDbContext.DbContext>(sp =>
            {
                // Inject IConfiguration into your DbContext constructor
                return new DapperDbContext.DbContext(configuration);
            });

            // Repositories
            services.AddScoped<IAppUser, AppUserRepository>();
            services.AddScoped<ITokenRepository, TokenRepository>();

            // Password hashing for AppUser
            services.AddScoped<IPasswordHasher<AppUserModel>, PasswordHasher<AppUserModel>>();

            // Other repositories (uncomment when needed)
            // services.AddScoped<IClient, ClientRepository>();
            // services.AddScoped<IProject, ProjectRepository>();
            // services.AddScoped<IFields, FieldsRepository>();
            // services.AddScoped<ITable, TableRepository>();

            return services;
        }
    }
}
