param(
    [string]$relativeClientPath,
    [string]$projectName,
    [int]$apiPort,
    [int]$uiPort,
    [switch]$SkipDataBackup = $false  # Option to skip backup if needed
)

if (-not $relativeClientPath) {
    Write-Host "No relativeClientPath provided."
    exit 1
}

Import-Module WebAdministration

# Global variables for tracking backups
$script:backupBasePath = "C:\temp\wwwroot-backup\$(Get-Date -Format 'yyyyMMdd-HHmmss')"
$script:dataBackups = @{}

function Is-PortUsedByAnotherSite {
    param (
        [int]$port,
        [string]$expectedSiteName
    )

    $bindings = Get-WebBinding | Where-Object { $_.protocol -eq 'https' }
    foreach ($binding in $bindings) {
        $bindingPort = $binding.bindingInformation.Split(':')[1]
        $bindingSite = $binding.ItemXPath -replace "^.*name='([^']+)'.*$", '$1'

        if ($bindingPort -eq "$port" -and $bindingSite -ne $expectedSiteName) {
            return $true
        }
    }

    return $false
}

function Write-LogMessage {
    param(
        [string]$message,
        [string]$level = "INFO"
    )
    
    $timestamp = Get-Date -Format "HH:mm:ss"
    $logMessage = "$timestamp - [$level] $message"
    Write-Host $logMessage
}

function Backup-EntireDirectory {
    param(
        [string]$sourcePath,
        [string]$backupKey
    )
    
    if (-not (Test-Path $sourcePath)) {
        Write-LogMessage "Source path does not exist: $sourcePath" "INFO"
        return $false
    }
    
    if ($SkipDataBackup) {
        Write-LogMessage "Data backup skipped as requested" "INFO"
        return $false
    }
    
    # Create unique backup path for this directory
    $backupDestination = Join-Path -Path $script:backupBasePath -ChildPath $backupKey
    
    try {
        # Create backup directory
        if (-not (Test-Path $backupDestination)) {
            New-Item -ItemType Directory -Path $backupDestination -Force | Out-Null
        }
        
        # Copy entire directory structure
        robocopy $sourcePath $backupDestination /E /R:3 /W:1 /NP /NDL /NFL > $null
        
        # Store backup info
        $script:dataBackups[$sourcePath] = $backupDestination
        
        Write-LogMessage "Backed up entire directory: $sourcePath -> $backupDestination" "INFO"
        return $true
    }
    catch {
        Write-LogMessage "Failed to backup $sourcePath : $($_.Exception.Message)" "ERROR"
        return $false
    }
}

function Restore-EntireDirectory {
    param(
        [string]$originalPath
    )
    
    if (-not $script:dataBackups.ContainsKey($originalPath)) {
        Write-LogMessage "No backup found for: $originalPath" "INFO"
        return
    }
    
    $backupPath = $script:dataBackups[$originalPath]
    
    if (-not (Test-Path $backupPath)) {
        Write-LogMessage "Backup path does not exist: $backupPath" "WARN"
        return
    }
    
    try {
        # Ensure destination exists
        if (-not (Test-Path $originalPath)) {
            New-Item -ItemType Directory -Path $originalPath -Force | Out-Null
        }
        
        # Restore everything EXCEPT application files (keep new deployment files safe)
        # Get list of files that were just deployed (application files)
        $deployedFiles = Get-ChildItem -Path $originalPath -File -Recurse | Select-Object -ExpandProperty FullName
        $deployedDirs = Get-ChildItem -Path $originalPath -Directory -Recurse | Select-Object -ExpandProperty FullName
        
        # Get all backed up items
        $backupItems = Get-ChildItem -Path $backupPath -Recurse
        
        foreach ($item in $backupItems) {
            $relativePath = $item.FullName.Substring($backupPath.Length + 1)
            $restoreTargetPath = Join-Path -Path $originalPath -ChildPath $relativePath
            
            if ($item.PSIsContainer) {
                # Directory - create if doesn't exist
                if (-not (Test-Path $restoreTargetPath)) {
                    New-Item -ItemType Directory -Path $restoreTargetPath -Force | Out-Null
                }
            } else {
                # File - only restore if it doesn't exist or if it's not an application file
                $shouldRestore = $true
                
                # Don't overwrite core application files
                $appFileExtensions = @('.dll', '.exe', '.pdb', '.deps.json', '.runtimeconfig.json', '.web.config')
                $fileExtension = [System.IO.Path]::GetExtension($item.Name).ToLower()
                
                if ($appFileExtensions -contains $fileExtension) {
                    $shouldRestore = $false
                    Write-LogMessage "Skipping application file: $relativePath" "DEBUG"
                }
                
                # Also skip appsettings files as they get updated by the script
                if ($item.Name -like "appsettings*.json") {
                    $shouldRestore = $false
                    Write-LogMessage "Skipping appsettings file: $relativePath" "DEBUG"
                }
                
                if ($shouldRestore) {
                    # Create parent directory if needed
                    $parentDir = Split-Path $restoreTargetPath -Parent
                    if (-not (Test-Path $parentDir)) {
                        New-Item -ItemType Directory -Path $parentDir -Force | Out-Null
                    }
                    
                    Copy-Item -Path $item.FullName -Destination $restoreTargetPath -Force
                    Write-LogMessage "Restored file: $relativePath" "DEBUG"
                }
            }
        }
        
        Write-LogMessage "Restored data directory: $backupPath -> $originalPath" "INFO"
    }
    catch {
        Write-LogMessage "Failed to restore $originalPath : $($_.Exception.Message)" "ERROR"
    }
}

function Remove-IISSiteAndAppPoolIfPortExists {
    param(
        [int]$portToFind
    )

    $sites = Get-Website

    foreach ($site in $sites) {
        foreach ($binding in $site.Bindings.Collection) {
            $bindingParts = $binding.bindingInformation.Split(':')
            $bindingPort = [int]$bindingParts[1]

            if ($bindingPort -eq $portToFind) {
                $siteName = $site.Name
                $appPoolName = $site.applicationPool
                $physicalPath = $site.physicalPath

                Write-LogMessage "Port $portToFind is in use by '$siteName'. Backing up data..." "WARN"

                # Backup entire directory before deletion
                $backupKey = "site-$siteName-port-$portToFind"
                Backup-EntireDirectory -sourcePath $physicalPath -backupKey $backupKey

                # Remove App Pool
                if (Test-Path "IIS:\AppPools\$appPoolName") {
                    Remove-WebAppPool -Name $appPoolName -ErrorAction SilentlyContinue
                }

                # Remove IIS site
                Remove-Website -Name $siteName -ErrorAction SilentlyContinue

                # Remove physical directory
                if (Test-Path $physicalPath) {
                    Remove-Item -Path $physicalPath -Recurse -Force -ErrorAction SilentlyContinue
                    Write-LogMessage "Deleted directory: $physicalPath" "INFO"
                }

                return
            }
        }
    }

    Write-LogMessage "No site using port $portToFind found. Nothing to delete."
}

function Get-SitePhysicalPathByPort {
    param (
        [int]$port
    )
    $site = Get-Website | Where-Object {
        ($_ | Get-WebBinding).bindingInformation -match ":${port}:"
    }

    return $site.physicalPath
}

function Remove-FolderIfExists {
    param (
        [string]$path
    )
    
    if (Test-Path $path) {
        # Backup entire folder before deletion
        $folderName = Split-Path $path -Leaf
        $backupKey = "folder-$folderName"
        Backup-EntireDirectory -sourcePath $path -backupKey $backupKey
        
        Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
        Write-LogMessage "Deleted directory: $path (data backed up)" "INFO"
    }
}

# === Normalize project name ===
$relativeClientPath = $relativeClientPath -replace '/', '\'
$projectNameSafe = $projectName -replace '\s', ''  # remove spaces

# === Configuration ===
$configuration = "Release"
$selfContained = $false
$appPoolApi = "${projectNameSafe}_AdminApiPool"
$appPoolUi = "${projectNameSafe}_AdminUiPool"
$apiSiteName = "${projectNameSafe}_AdminApi"
$uiSiteName = "${projectNameSafe}_AdminUi"

Write-LogMessage "Starting deployment with data backup to: $script:backupBasePath" "INFO"

# === Pre-cleanup: Delete any existing site/app pool using these ports ===
Remove-IISSiteAndAppPoolIfPortExists -portToFind $apiPort
Remove-IISSiteAndAppPoolIfPortExists -portToFind $uiPort

# === Delete API physical folder ===
$apiPhysicalPath = Get-SitePhysicalPathByPort -port $apiPort
if ($apiPhysicalPath) {
    Remove-FolderIfExists -path $apiPhysicalPath
}

# === Delete UI physical folder ===
$uiPhysicalPath = Get-SitePhysicalPathByPort -port $uiPort
if ($uiPhysicalPath) {
    Remove-FolderIfExists -path $uiPhysicalPath
}

# === Project Paths - Fixed project structure ===
$projectsPath = @(
    "\Presentation\ClientAdmin.MvcUI\ClientAdmin.MvcUI.csproj",
    "\Presentation\ClientAdmin.Api\ClientAdmin.Api.csproj"
)

# Join full paths
$projects = $projectsPath | ForEach-Object {
    Join-Path -Path $relativeClientPath -ChildPath $_
}

# === Ensure App Pools Exist ===
foreach ($pool in @($appPoolApi, $appPoolUi)) {
    if (-not (Test-Path "IIS:\AppPools\$pool")) {
        New-WebAppPool -Name $pool
        Set-ItemProperty "IIS:\AppPools\$pool" -Name managedRuntimeVersion -Value ""
        Write-Host "Created App Pool: $pool"
    }
}

# === Stop App Pools ===
foreach ($pool in @($appPoolApi, $appPoolUi)) {
    if (Test-Path "IIS:\AppPools\$pool") {
        $state = Get-WebAppPoolState -Name $pool
        if ($state.Value -ne "Stopped") {
            Stop-WebAppPool -Name $pool
            Write-Host "Stopped App Pool: $pool"
        }
    }
}

# === Publish Projects ===
foreach ($proj in $projects) {
    $originalProjectName = [System.IO.Path]::GetFileNameWithoutExtension($proj)
    
    # Map original project names to dynamic output names
    if ($originalProjectName -eq "ClientAdmin.MvcUI") {
        $outputProjectName = "${projectNameSafe}_Admin_UI"
    } elseif ($originalProjectName -eq "ClientAdmin.Api") {
        $outputProjectName = "${projectNameSafe}_Admin"
    } else {
        $outputProjectName = $originalProjectName
    }
    
    $outputPath = "C:\inetpub\wwwroot\$outputProjectName"

    if (-not (Test-Path $outputPath)) {
        New-Item -ItemType Directory -Path $outputPath -Force | Out-Null
    }

    Write-LogMessage -message "Starting publish for $originalProjectName" -level "INFO"

    try {
        dotnet publish $proj `
            --configuration $configuration `
            --output $outputPath `
            --self-contained:$selfContained `
            -p:TreatWarningsAsErrors=false `
            -p:EnvironmentName=Development

        if ($LASTEXITCODE -ne 0) {
            throw "dotnet publish failed with exit code $LASTEXITCODE"
        }
        
        Write-LogMessage -message "Successfully published $originalProjectName to $outputPath" -level "INFO"
        
        # === Manually copy appsettings files ===
        $projectFolder = Split-Path $proj -Parent
        $appSettingsFiles = Get-ChildItem -Path $projectFolder -Filter "appsettings*.json" -File -ErrorAction SilentlyContinue

        foreach ($file in $appSettingsFiles) {
            Copy-Item -Path $file.FullName -Destination $outputPath -Force -ErrorAction SilentlyContinue
            Write-LogMessage -message "Copied $($file.Name) to $outputPath" -level "INFO"
        }
        
        # === RESTORE DATA AFTER PUBLISH ===
        Write-LogMessage "Restoring backed up data to: $outputPath" "INFO"
        Restore-EntireDirectory -originalPath $outputPath
        
    }
    catch {
        $errorMsg = "Failed to publish $originalProjectName : $($_.Exception.Message)"
        Write-LogMessage -message $errorMsg -level "ERROR"
        throw $errorMsg
    }
}

# === Update appsettings BackendApiUrl ===
function Update-BackendApiUrl {
    param (
        [string]$filePath,
        [int]$apiPort,
        [int]$uiPort
    )

    if (Test-Path $filePath) {
        $fileContent = Get-Content $filePath -Raw
        if ([string]::IsNullOrWhiteSpace($fileContent)) {
            Write-Host "Skipping empty file: $filePath"
            return
        }

        try {
            $json = $fileContent | ConvertFrom-Json
        } catch {
            Write-Host "Failed to parse JSON in $filePath"
            Write-Host $_.Exception.Message
            return
        }
        
        if ($json.BackendApiUrl -or $json.BackendUiUrl) {
            if ($json.BackendApiUrl) {
                $uri = [System.Uri]::new($json.BackendApiUrl)
                $originalPath = $uri.AbsolutePath

                if ($originalPath -match "^/api/?$") {
                    $json.BackendApiUrl = "https://172.16.16.130:$apiPort/api/"
                } else {
                    $json.BackendApiUrl = "https://172.16.16.130:$apiPort"
                }
            }

            if ($json.BackendUiUrl) {
                $uri = [System.Uri]::new($json.BackendUiUrl)
                $originalPath = $uri.AbsolutePath

                # Always preserve the path for UI (do not add /api/)
                $json.BackendUiUrl = "https://172.16.16.130:$uiPort"
            }

            # Save JSON back to file
            $json | ConvertTo-Json -Depth 10 | Set-Content $filePath -Encoding UTF8
        }
    } else {
        Write-Host "File not found: $filePath"
    }
}

# === Paths - Now dynamic based on projectName ===
$WebPath = "C:\inetpub\wwwroot\${projectNameSafe}_Admin_UI"
$webApiPath  = "C:\inetpub\wwwroot\${projectNameSafe}_Admin"

# === Update appsettings files ===
$allAppSettingsFiles = @(
    "$WebPath\appsettings.json",
    "$WebPath\appsettings.Development.json",
    "$webApiPath\appsettings.json",
    "$webApiPath\appsettings.Development.json"
)

foreach ($file in $allAppSettingsFiles) {
    Update-BackendApiUrl -filePath $file -apiPort $apiPort -uiPort $uiPort
}

Start-WebAppPool -Name $appPoolApi
Start-WebAppPool -Name $appPoolUi

# Ensure W3SVC and WAS are running
$requiredServices = @("W3SVC", "WAS")

foreach ($svc in $requiredServices) {
    $service = Get-Service -Name $svc -ErrorAction SilentlyContinue
    if ($service -and $service.Status -ne 'Running') {
        try {
            Start-Service $svc -ErrorAction Stop
            Write-Host "Started service: $svc"
        } catch {
            Write-Host "Failed to start service $svc. Run PowerShell as Administrator."
            exit 1
        }
    }
}

# === HTTPS Cert Setup ===
$certificateStore = "My"
$ipAddress = "172.16.16.130"
$certSubjectMatch = "CN=$ipAddress"
 
# Try to find existing valid certificate
$cert = Get-ChildItem -Path Cert:\LocalMachine\$certificateStore |
    Where-Object {
        $_.Subject -like "*$certSubjectMatch*" -and $_.NotAfter -gt (Get-Date)
    } | Sort-Object NotAfter -Descending | Select-Object -First 1
 
# If not found, create a new IP certificate
if (-not $cert) {
	Write-Host "Creating new self-signed certificate for IP: $ipAddress"
 
    $cert = New-SelfSignedCertificate `
        -Subject "CN=$ipAddress" `
        -TextExtension @("2.5.29.17={text}IPAddress=$ipAddress") `
        -KeyLength 2048 `
        -KeyExportPolicy Exportable `
        -CertStoreLocation "cert:\LocalMachine\$certificateStore" `
        -NotAfter (Get-Date).AddYears(5)
    #$cert = New-SelfSignedCertificate -DnsName "localhost" -CertStoreLocation "cert:\LocalMachine\$certificateStore"
    #Write-Host "Created self-signed certificate: $($cert.Thumbprint)"
}
 
$certificateThumbprint = $cert.Thumbprint
 
# === Add Certificate to Trusted Root ===
Write-Host "Adding certificate to Trusted Root Certification Authorities..."
 
$rootStore = New-Object System.Security.Cryptography.X509Certificates.X509Store("Root","LocalMachine")
$rootStore.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
 
# Check if certificate exists already
$existingRootCert = $rootStore.Certificates | Where-Object { $_.Thumbprint -eq $certificateThumbprint }
 
if ($existingRootCert) {
    Write-Host "Certificate already exists in Trusted Root. No action required."
} 
else {
    Write-Host "Adding certificate to Trusted Root Certification Authorities..."
    $rootStore.Add($cert)
    Write-Host "Certificate added to Trusted Root store."
}
 
$rootStore.Close()
 
# === Function to Create IIS Site ===
function Create-IISSite {
    param (
        [string]$siteName,
        [int]$port,
        [string]$physicalPath,
        [string]$appPool
    )
 
    if (-not (Test-Path $physicalPath)) {
        Write-Host "Path not found: $physicalPath"
        return
    }
 
    if (-not (Test-Path "IIS:\Sites\$siteName")) {
        New-Website -Name $siteName `
                    -Port $port `
                    -IPAddress "*" `
                    -PhysicalPath $physicalPath `
                    -ApplicationPool $appPool
        Write-Host "Created IIS Site: $siteName on port $port"
    } else {
        Write-Host "IIS Site already exists: $siteName"
    }
 
    # Remove HTTP binding
    $httpBinding = Get-WebBinding -Name $siteName | Where-Object { $_.protocol -eq "http" -and $_.bindingInformation -like "*:$port*" }
    if ($httpBinding) {
        Remove-WebBinding -Name $siteName -Protocol http -Port $port -IPAddress "*" -HostHeader ""
        Write-Host "Removed HTTP binding for $siteName"
    }
 
    # Setup HTTPS Binding (with retries and null check)
    Remove-WebBinding -Name $siteName -Protocol https -Port $port -ErrorAction SilentlyContinue
 
    #$bindingPath = "IIS:\SslBindings\0.0.0.0!$port"
	$bindingPath = "IIS:\SslBindings\$ipAddress!$port"
 
    if (Test-Path $bindingPath) {
        Remove-Item $bindingPath -Force -ErrorAction SilentlyContinue
    }
 
    if (-not $certificateThumbprint) {
        throw "Certificate thumbprint is null. Cannot create HTTPS binding."
    }
 
    $maxRetries = 3
    for ($i = 0; $i -lt $maxRetries; $i++) {
        try {
            New-WebBinding -Name $siteName -Protocol https -Port $port -IPAddress "*" -HostHeader "" | Out-Null
            New-Item -Path $bindingPath -Thumbprint $certificateThumbprint -SSLFlags 0 | Out-Null
            break
        } catch {
            if ($i -eq ($maxRetries - 1)) {
                throw "Failed to bind HTTPS to port $port for $siteName after $maxRetries attempts. Error: $($_.Exception.Message)"
            }
            Write-Host "Retrying HTTPS binding for $siteName on port $port (attempt $($i + 1))..."
            Start-Sleep -Seconds 2
        }
    }
 
    Write-Host "HTTPS binding updated for $siteName on port $port"
 
    # Open firewall port
    try {
        if (-not (Get-NetFirewallRule -DisplayName "Allow HTTPS on $port" -ErrorAction SilentlyContinue)) {
            Write-Host "Creating firewall rule for port $port..."
            New-NetFirewallRule -DisplayName "Allow HTTPS on $port" `
                                -Direction Inbound `
                                -Protocol TCP `
                                -LocalPort $port `
                                -Action Allow
            Write-Host "Opened firewall for port $port"
        } else {
            Write-Host "Firewall rule already exists for port $port"
        }
    }
    catch {
        Write-Warning "Failed to create firewall rule: $_"
    }
 
    # Restart Site
    if (Test-Path "IIS:\Sites\$siteName") {
        Restart-WebItem "IIS:\Sites\$siteName"
        Write-Host "Restarted IIS Site: $siteName"
    }
}

# Acquire a global mutex lock to prevent race conditions
$mutex = New-Object System.Threading.Mutex($false, "Global\IISPublishLock")
try {
    if ($mutex.WaitOne(30000)) {
        # === Critical section ===
        # === Create API Site (WebApi) ===
        Create-IISSite -siteName $apiSiteName -port $apiPort -physicalPath $webApiPath -appPool $appPoolApi
        # === Create UI Site (Web) ===
        Create-IISSite -siteName $uiSiteName -port $uiPort -physicalPath $WebPath -appPool $appPoolUi
    } else {
        throw "Timeout acquiring IIS publish lock"
    }
} finally {
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}

# === Remove WebDAVModule from API site only ===
$apiSiteModulesPath = "IIS:\Sites\$apiSiteName"

if (Test-Path $apiSiteModulesPath) {
    $module = Get-WebConfigurationProperty -pspath "IIS:\Sites\$apiSiteName" -filter "system.webServer/modules/add[@name='WebDAVModule']" -name "name" -ErrorAction SilentlyContinue
    if ($module) {
        Remove-WebConfigurationProperty -pspath "IIS:\Sites\$apiSiteName" -filter "system.webServer/modules" -name "." -AtElement @{name='WebDAVModule'}
    }
}

# === Clean up old backup files (keep only last 3 deployments) ===
$backupRootPath = "C:\temp\wwwroot-backup"
if (Test-Path $backupRootPath) {
    $backupFolders = Get-ChildItem -Path $backupRootPath -Directory | Sort-Object CreationTime -Descending
    if ($backupFolders.Count -gt 3) {
        $foldersToDelete = $backupFolders | Select-Object -Skip 3
        foreach ($folder in $foldersToDelete) {
            Remove-Item -Path $folder.FullName -Recurse -Force -ErrorAction SilentlyContinue
            Write-LogMessage "Cleaned up old backup: $($folder.Name)" "INFO"
        }
    }
}

Write-LogMessage "Deployment complete! Data backup location: $script:backupBasePath" "INFO"

$output = @{
    ApiUrl = "https://172.16.16.130:${apiPort}/swagger"
    UiUrl  = "https://172.16.16.130:${uiPort}"
    BackupLocation = $script:backupBasePath
}
# Write to JSON file
$outputPath = "C:\temp\publish-output-$projectNameSafe.json"
$output | ConvertTo-Json -Depth 3 | Set-Content -Path $outputPath -Encoding UTF8