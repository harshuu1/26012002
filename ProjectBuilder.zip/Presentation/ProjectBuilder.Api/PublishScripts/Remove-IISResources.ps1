﻿param(
    [string]$ProjectName,
    [string]$IsBuild,
    [string]$IsConfigure
)

$ErrorActionPreference = "Stop"
Import-Module WebAdministration

# --- Convert string parameters to boolean ---
$IsBuildBool = if ([string]::IsNullOrWhiteSpace($IsBuild)) { $false } else { $IsBuild -match "^(true|1)$" }
$IsConfigureBool = if ([string]::IsNullOrWhiteSpace($IsConfigure)) { $false } else { $IsConfigure -match "^(true|1)$" }

Write-Host " Starting IIS cleanup for project: $ProjectName"
Write-Host "Flags => IsBuild: $IsBuild, IsConfigure: $IsConfigure"

# --- Construct IIS resource names ---
$apiSite       = "${ProjectName}Api"
$uiSite        = "${ProjectName}Ui"
$apiPool       = "${ProjectName}ApiPool"
$uiPool        = "${ProjectName}UiPool"

$adminapiSite  = "${ProjectName}_AdminApi"
$adminuiSite   = "${ProjectName}_AdminUi"
$adminapiPool  = "${ProjectName}_AdminApiPool"
$adminuiPool   = "${ProjectName}_AdminUiPool"

$configApiSite = "${ProjectName}ConfigurationApi"
$configUiSite  = "${ProjectName}ConfigurationUi"
$configApiPool = "${ProjectName}ConfigurationApiPool"
$configUiPool  = "${ProjectName}ConfigurationUiPool"

function Stop-SiteSafe($siteName) {
    if (Test-Path "IIS:\Sites\$siteName") {
        $site = Get-Item "IIS:\Sites\$siteName"
        if ($site.state -eq "Started") {
            Write-Host "Stopping IIS Site: $siteName..."
            Stop-Website -Name $siteName -ErrorAction SilentlyContinue

            # Wait up to 10 seconds for site to stop
            $attempts = 0
            while ((Get-Item "IIS:\Sites\$siteName").state -ne "Stopped" -and $attempts -lt 10) {
                Start-Sleep -Seconds 1
                $attempts++
            }

            if ((Get-Item "IIS:\Sites\$siteName").state -ne "Stopped") {
                Write-Host "Site '$siteName' did not stop after 10s, continuing anyway..."
            } else {
                Write-Host "Site '$siteName' stopped successfully."
            }
        } else {
            Write-Host "Site '$siteName' already stopped."
        }
    }
}

function Stop-AppPoolSafe($poolName) {
    if (Test-Path "IIS:\AppPools\$poolName") {
        $pool = Get-Item "IIS:\AppPools\$poolName"
        if ($pool.state -eq "Started") {
            Write-Host "Stopping App Pool: $poolName..."
            Stop-WebAppPool -Name $poolName -ErrorAction SilentlyContinue

            # Wait up to 10 seconds for pool to stop
            $attempts = 0
            while ((Get-Item "IIS:\AppPools\$poolName").state -ne "Stopped" -and $attempts -lt 10) {
                Start-Sleep -Seconds 1
                $attempts++
            }

            if ((Get-Item "IIS:\AppPools\$poolName").state -ne "Stopped") {
                Write-Host "  App Pool '$poolName' did not stop, killing any attached w3wp.exe..."
                Get-Process w3wp -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            } else {
                Write-Host " App Pool '$poolName' stopped successfully."
            }
        } else {
            Write-Host "App Pool '$poolName' already stopped."
        }
    }
}

function Delete-Site($siteName) {
    try {
        if (Test-Path "IIS:\Sites\$siteName") {
            Stop-SiteSafe $siteName
            Remove-WebSite -Name $siteName -Confirm:$false -ErrorAction Stop
            Write-Host "  Deleted IIS Site: $siteName"
        } else {
            Write-Host "Site not found: $siteName"
        }
    }
    catch {
        Write-Host "  Error deleting site '$siteName': $($_.Exception.Message)"
    }
}

function Delete-AppPool($poolName) {
    try {
        if (Test-Path "IIS:\AppPools\$poolName") {
            Stop-AppPoolSafe $poolName
            Remove-WebAppPool -Name $poolName -Confirm:$false -ErrorAction Stop
            Write-Host "  Deleted App Pool: $poolName"
        } else {
            Write-Host "App Pool not found: $poolName"
        }
    }
    catch {
        Write-Host " Error deleting App Pool '$poolName': $($_.Exception.Message)"
    }
}

try {
    if ($IsBuildBool) {
        Write-Host "`n Deleting main project sites and pools..."
        Delete-Site $apiSite
        Delete-Site $uiSite
        Delete-AppPool $apiPool
        Delete-AppPool $uiPool

        Write-Host "`n Deleting admin project sites and pools..."
        Delete-Site $adminapiSite
        Delete-Site $adminuiSite
        Delete-AppPool $adminapiPool
        Delete-AppPool $adminuiPool
    }

    if ($IsConfigureBool) {
        Write-Host "`n  Deleting configuration project sites and pools..."
        Delete-Site $configApiSite
        Delete-Site $configUiSite
        Delete-AppPool $configApiPool
        Delete-AppPool $configUiPool
    }

    Write-Host "`n IIS cleanup completed successfully for project '$ProjectName'."
    exit 0
}
catch {
    Write-Host " Error in Remove-IISResources.ps1: $($_.Exception.Message)"
    exit 1
}
