﻿using System.Net.Http.Headers;
using System.Text;
using System.Net;
using Microsoft.AspNetCore.Mvc.Testing;
using Newtonsoft.Json;

namespace TestProject
{
    public class BaseTest : IClassFixture<WebApplicationFactory<Program>>
    {
        protected readonly HttpClient _client;

        public BaseTest(WebApplicationFactory<Program> factory)
        {
            _client = factory.CreateClient();

            var token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjEiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9lbWFpbGFkZHJlc3MiOiJhZG1pbkBhZG1pbi5jb20iLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiIiLCJleHAiOjE3ODYxODY3NDcsImlzcyI6InlvdXJkb21haW4uY29tIiwiYXVkIjoieW91cmRvbWFpbi5jb20ifQ._-62NMPA_Q38439fmAMQkOVzq8CiZbl8SRyqo8kMSaw"; // You can load from config if needed
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        protected StringContent GetJsonContent(object obj)
        {
            return new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
        }

        protected async Task<HttpResponseMessage> CreateApiAsync(string apiUrl, object objValue)
        {
            var content = GetJsonContent(objValue);
            return await _client.PostAsync(apiUrl, content);
        }

        protected async Task<HttpResponseMessage> UpdateApiAsync(string apiUrl, object objValue)
        {
            var content = GetJsonContent(objValue);
            return await _client.PutAsync(apiUrl, content);
        }
        protected async Task<HttpResponseMessage> DeleteApiAsync(string apiUrl)
        {
            return await _client.DeleteAsync(apiUrl);
        }
        protected async Task<HttpResponseMessage> GetByIdAsync(string apiUrl)
        {
            return await _client.GetAsync(apiUrl);
        }
        // Helper method to verify the response status and body
        protected async Task VerifyResponse(HttpResponseMessage response, HttpStatusCode expectedStatusCode, string? expectedResponseBody = null)
        {
            Assert.Equal(expectedStatusCode, response.StatusCode);

            if (expectedResponseBody != null)
            {
                var responseBody = await response.Content.ReadAsStringAsync();
                Assert.Equal(expectedResponseBody, responseBody.Trim('"'));
            }
        }

    }
}

