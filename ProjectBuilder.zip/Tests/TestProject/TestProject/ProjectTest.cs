﻿using Entities.Models.Project;
using Microsoft.AspNetCore.Mvc.Testing;
using Newtonsoft.Json;
using System.Net;

namespace TestProject
{
    public class ProjectTest : BaseTest
    {
        public ProjectTest(WebApplicationFactory<Program> factory) : base(factory) { }

        // GET: /clients/project/{id}
        [Fact]
        public async Task GetProjectById_ReturnsExpectedProject()
        {
            var response = await _client.GetAsync("/clients/project/1");
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

            var jsonString = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<ProjectModel>(jsonString);

            Assert.NotNull(result);

        }

        // POST: /clients/project
        [Fact]
        public async Task CreateProject_ShouldReturnSuccess_WhenValidDataWithoutFile()
        {

            var form = new MultipartFormDataContent
    {
        { new StringContent("4"), "ClientId" },
        { new StringContent("devops"), "Name" },
        { new StringContent("Testing creation without logo file"), "Description" }

    };

            var response = await _client.PostAsync("/clients/project", form);
            var responseBody = await response.Content.ReadAsStringAsync();

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        }
        [Fact]
        public async Task CreateProject_ShouldReturnError_WhenProjectWithNameExists()
        {

            var form = new MultipartFormDataContent
    {
        { new StringContent("4"), "ClientId" },
        { new StringContent("devops"), "Name" },
        { new StringContent("Testing creation without logo file"), "Description" }
    };


            var response = await _client.PostAsync("/clients/project", form);
            var responseBody = await response.Content.ReadAsStringAsync();

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        }



        [Fact]
        public async Task UpdateProject_ShouldReturnBadRequest_OnIdMismatch()
        {
            var project = new
            {
                ID = 9999,
                Name = "Mismatch Project",
                Description = "Should fail",
                ClientId = 1,
            };

            var response = await UpdateApiAsync("/clients/project", project);

            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
            var responseBody = await response.Content.ReadAsStringAsync();
            Assert.Contains("ID mismatch.", responseBody);
        }

        [Fact]
        public async Task UpdateProject_ShouldReturnNotFound_WhenProjectDoesNotExist()
        {

            var project = new
            {
                ID = 5,
                Name = "NotFoundProject",
                Description = "Does not exist",
                ClientId = 4
            };

            var response = await UpdateApiAsync("/clients/project", project);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var body = await response.Content.ReadAsStringAsync();

        }

        [Fact]
        public async Task UpdateProject_ShouldReturnOk_WhenValid()
        {
            var project = new
            {
                ID = 4,
                Name = "UpdatedProject",
                Description = "Updated Desc",
                ClientId = 4
            };

            var response = await UpdateApiAsync("/clients/project", project);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var body = await response.Content.ReadAsStringAsync();

        }

        // DELETE: /clients/project/{id}
        [Fact]
        public async Task DeleteProject_ReturnsOk_WhenProjectIsDeleted()
        {
            var response = await _client.DeleteAsync("/clients/project/10");

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

            var responseContent = await response.Content.ReadAsStringAsync();

        }

        // GET: /clients/{clientId}/projects
        [Fact]
        public async Task GetProjectsByClient_ReturnsOk_WhenProjectsExist()
        {
            int clientId = 1;

            var response = await _client.GetAsync($"/clients/{clientId}/projects");

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var content = await response.Content.ReadAsStringAsync();
            Assert.False(string.IsNullOrWhiteSpace(content));
        }

        [Fact]
        public async Task GetProjectsByClient_ReturnsOk_WithEmptyList_WhenNoProjectsExist()
        {
            int clientId = 99999;

            var response = await _client.GetAsync($"/clients/{clientId}/projects");

            await VerifyResponse(response, HttpStatusCode.OK, "[]");
        }

        // GET: /clients/project/getTable/{id}
        [Fact]
        public async Task GetTable_ReturnsOk_WhenDataExists()
        {
            int id = 1;

            var response = await _client.GetAsync($"/clients/project/getTable/{id}");

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var content = await response.Content.ReadAsStringAsync();
            Assert.False(string.IsNullOrWhiteSpace(content));
        }

        [Fact]
        public async Task GetTable_ReturnsNotFound_WhenNoDataExists()
        {
            int id = 9999;

            var response = await _client.GetAsync($"/clients/project/getTable/{id}");

            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }

        // POST: /clients/projects
        [Fact]
        public async Task GetFilteredProjects_ReturnsOk()
        {
            var request = new { /* filter parameters */ };
            var response = await CreateApiAsync("/clients/projects", request);
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        // GET: /clients/project/exportproject/{projectId}
        [Fact]
        public async Task ExportProject_ReturnsOk_WhenProjectExists()
        {
            var response = await _client.GetAsync("/clients/project/exportproject/1");

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        // POST: /clients/project/importProject
        [Fact]
        public async Task ImportProject_ShouldReturnOk_WhenSuccessful()
        {
            var project = new
            {
                ClientId = 1,
                Name = "Imported Project " + Guid.NewGuid(),
                Description = "Imported via test"
            };

            var response = await CreateApiAsync("/clients/project/importProject", project);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }
    }
}