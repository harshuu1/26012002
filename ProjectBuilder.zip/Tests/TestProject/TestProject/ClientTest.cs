﻿using Entities.Models.Client;
using Microsoft.AspNetCore.Mvc.Testing;
using Newtonsoft.Json;
using System.Net;

namespace TestProject
{
    public class ClientTest : BaseTest
    {
        public ClientTest(WebApplicationFactory<Program> factory) : base(factory) { }

        [Fact]
        public async Task CreateClient_ShouldReturnSuccess_WhenValidData()
        {
            var client = new ClientModel
            {

                FirstName = "kamya",
                LastName = "sahar",
                PhoneNo = "8524567539",
                Email = "k@gmail.com@gmail.com",
                CompanyName = "karff"
            };

            var response = await CreateApiAsync("client", client);  // POST /client
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);


        }

        [Fact]
        public async Task CreateClient_ShouldReturnBadRequest_WhenNameAndEmailAlreadyExists()
        {
            var existingClient = new ClientModel
            {
                FirstName = "Siddhi",
                LastName = "Vaishnav",
                PhoneNo = "9874561235",
                Email = "kffd123@gmail.com",
                CompanyName = "Test1"
            };

            var response = await CreateApiAsync("client", existingClient);  // POST /client
            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        }

        [Fact]
        public async Task UpdateClient_ShouldreturnBadRequest_WhenNameAndEmailAlreadyExists()
        {
            var existingClient = new ClientModel
            {
                ID = 137,
                FirstName = "dhruv",
                LastName = "vvvvv",
                PhoneNo = "7894561234",
                Email = "s@gmail.com",
                CompanyName = "Test2"
            };

            var response = await UpdateApiAsync("client", existingClient); // PUT /client
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

            var responseBody = await response.Content.ReadAsStringAsync();

        }

        [Fact]
        public async Task UpdateClient_ShouldReturnSuccess()
        {
            var updateClient = new ClientModel
            {
                ID = 137,
                FirstName = "Siddhi",
                LastName = "vvvvv",
                PhoneNo = "78945612345",
                Email = "s@gmail.com",
                CompanyName = "Test"
            };

            var response = await UpdateApiAsync("client", updateClient);  // PUT /client
            await VerifyResponse(response, HttpStatusCode.OK);
        }

        [Fact]
        public async Task GetClientById_ShouldReturnCorrectClient_FromAPI()
        {
            var response = await GetByIdAsync("client/4");  // GET /client/{id}
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

            var jsonString = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<ClientModel>(jsonString);

            Assert.NotNull(result);
            Assert.Equal("Man", result.FirstName, ignoreCase: true);
        }

        [Fact]
        public async Task GetClientName_FromAPI()
        {
            var response = await GetByIdAsync("clients");  // GET /clients
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

            var jsonString = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<List<ClientModel>>(jsonString);

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetAllClientList_FromAPI()
        {
            var response = await CreateApiAsync("/client/dropdown", null);  // POST /clients
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

            var jsonString = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<List<ClientModel>>(jsonString);

            Assert.NotNull(result);
        }

        [Fact]
        public async Task DeleteClient_ValidId_ShouldReturnOk()
        {
            var response = await DeleteApiAsync("client/138");  // DELETE /client/{id}
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

            var responseContent = await response.Content.ReadAsStringAsync();
            Assert.Equal("pass", responseContent);
        }
    }
}
