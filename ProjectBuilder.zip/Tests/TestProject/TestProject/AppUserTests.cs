﻿using System.Net;
using System.Text;
using Entities.Models.AppUser;
using Entities.Models.Request;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using Newtonsoft.Json;
using Xunit.Abstractions;

namespace TestProject
{
    public class AppUserTests : BaseTest

    {

        private readonly ITestOutputHelper _output;

        public AppUserTests(WebApplicationFactory<Program> factory, ITestOutputHelper output) : base(factory)

        {

            _output = output;

        }

        [Fact]

        public async Task CreateAppUser_ShouldReturnSuccess()

        {

            var newUser = new AppUserModel

            {

                FirstName = "Jai",

                LastName = "Doe",

                Email = $"jai{Guid.NewGuid()}@example.com",

                PhoneNo = "9876543210",

                Password = "SecurePass123!"

            };

            var response = await CreateApiAsync("user", newUser);

            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();

            Assert.Contains("User created successfully", responseBody);

        }

        [Fact]

        public async Task UpdateAppUser_ShouldReturnSuccess()

        {

            var updatedUser = new AppUserModel

            {

                ID = 1088,

                FirstName = "Johy",

                LastName = "Smith",

                Email = "john.smith@example.com",

                PhoneNo = "1234567890",

                Password = "123456!"

            };

            var response = await UpdateApiAsync("user", updatedUser);

            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();

            Assert.Contains("updated successfully", responseBody);

        }

        [Fact]

        public async Task DeleteAppUser_ShouldReturnSuccess()

        {

            var userIdToDelete = 1091;

            var response = await DeleteApiAsync($"user/{userIdToDelete}");

            await VerifyResponse(response, HttpStatusCode.OK, "Employee deleted successfully");

        }

        [Fact]

        public async Task Login_ShouldReturnToken()

        {

            var loginRequest = new LoginRequest

            {

                Email = "admin@admin.com",

                Password = "123456"

            };

            var response = await CreateApiAsync("user/login", loginRequest);

            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();

            Assert.Contains("token", responseBody.ToLower());

        }

        [Fact]

        public async Task GetAppUserById_ShouldReturnCorrectUser_FromAPI()

        {

            var userId = 2;

            var response = await GetByIdAsync($"user/{userId}");

            await VerifyResponse(response, HttpStatusCode.OK);

            var jsonString = await response.Content.ReadAsStringAsync();

            var result = JsonConvert.DeserializeObject<AppUserModel>(jsonString);

            Assert.NotNull(result);

            Assert.Equal("Tech", result.FirstName, ignoreCase: true);

        }

        [Fact]

        public async Task GetAllAppUsers_ShouldReturnNonEmptyList()

        {

            var response = await _client.GetAsync("user");

            response.EnsureSuccessStatusCode();

            var jsonString = await response.Content.ReadAsStringAsync();

            var result = JsonConvert.DeserializeObject<List<AppUserModel>>(jsonString);

            Assert.NotNull(result);

            Assert.True(result.Count > 0);

        }

        [Fact]

        public async Task CheckEmailExists_ShouldReturnTrue()

        {

            var response = await _client.GetAsync("user/checkEmail?email=lp@gmail.com&userId=2");

            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();

            Assert.Equal("true", responseBody.ToLower());

        }

        [Fact]

        public async Task CheckEmailExists_ShouldReturnFalse_WhenEmailNotTaken()

        {

            var response = await _client.GetAsync("user/checkEmail?email=unique_email@example.com&userId=0");

            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();

            Assert.Equal("false", responseBody.ToLower());

        }

        [Fact]

        public async Task CreateAppUser_ShouldFail_IfEmailAlreadyExists()

        {

            var user = new AppUserModel

            {

                FirstName = "Test",

                LastName = "User",

                Email = "lp@gmail.com", // existing email

                PhoneNo = "1234567890",

                Password = "Password123!"

            };

            var response = await CreateApiAsync("user", user);

            Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);

        }

        [Fact]

        public async Task Login_ShouldFailWithInvalidCredentials()

        {

            var loginRequest = new LoginRequest

            {

                Email = "wrong@example.com",

                Password = "wrongpass"

            };

            var response = await CreateApiAsync("user/login", loginRequest);

            Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);

        }

        [Fact]

        public async Task DeleteAppUser_ShouldReturnNotFound_WhenUserDoesNotExist()

        {

            var response = await DeleteApiAsync("user/9999");

            await VerifyResponse(response, HttpStatusCode.NotFound);

        }

        [Fact]

        public async Task UpdateAppUser_ShouldReturnNotFound_WhenUserDoesNotExist()

        {

            var updatedUser = new AppUserModel

            {

                ID = 9999,

                FirstName = "Ghost",

                LastName = "User",

                Email = "ghost@example.com",

                PhoneNo = "0000000000",

                Password = "None"

            };

            var response = await UpdateApiAsync("user", updatedUser);

            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);

        }

        [Fact]

        public async Task GetAppUser_ByValidFilter_ReturnsExpectedUsers()

        {

            var request = new { skip = 0, take = 3 };

            var httpContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");

            var response = await _client.PostAsync("users", httpContent);

            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var json = await response.Content.ReadAsStringAsync();

            _output.WriteLine("Response JSON:");

            _output.WriteLine(json);

            dynamic result = JsonConvert.DeserializeObject(json);

            if (result?.data != null)

            {

                ((int)result.total).Should().BeGreaterThanOrEqualTo(0);

                _output.WriteLine($"Total Records: {result.total}");

                _output.WriteLine($"Returned Records: {result.data.Count}");

            }

            else

            {

                _output.WriteLine("No data returned.");

                Assert.Empty((IEnumerable<object>)result?.data);

            }

        }

        [Fact]

        public async Task GetAppUser_ByValidFilter_ReturnsSortedUsers()

        {

            var request = new

            {

                skip = 0,

                take = 2,

                sort = new[]

                {

                new { field = "FirstName", dir = "asc" }

            }

            };

            var httpContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");

            var response = await _client.PostAsync("users", httpContent);

            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var json = await response.Content.ReadAsStringAsync();

            _output.WriteLine("Response JSON:");

            _output.WriteLine(json);

            dynamic result = JsonConvert.DeserializeObject(json);

            if (result?.data != null)

            {

                ((int)result.total).Should().BeGreaterThanOrEqualTo(0);

                _output.WriteLine($"Total Records: {result.total}");

                _output.WriteLine($"Returned Records: {result.data.Count}");

                var firstNames = ((IEnumerable<dynamic>)result.data)

                    .Where(u => u.firstName != "string")

                    .Select(u => (string)u.firstName)

                    .ToList();

                var sorted = firstNames.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();

                firstNames.Should().BeEquivalentTo(sorted, options => options.WithStrictOrdering());

            }

            else

            {

                _output.WriteLine("No data returned.");

                Assert.Empty((IEnumerable<object>)result?.data);

            }

        }

    }
}