﻿using Newtonsoft.Json;

namespace Entities.Models.Request
{
    public class Request
    {
        [JsonProperty("skip")]
        public int Skip { get; set; }

        [JsonProperty("take")]
        public int Take { get; set; }

        [JsonProperty("groupPaging")]
        public bool GroupPaging { get; set; }

        [JsonProperty("sort")]
        public List<Sort>? Sort { get; set; }

        [JsonProperty("filter")]
        public Filter? Filter { get; set; }

        [JsonProperty("group")]
        public List<GroupRequest>? Groups { get; set; }

        [JsonProperty("aggregate")]
        public List<AggregateRequest>? Aggregates { get; set; }
    }
}
