﻿using Newtonsoft.Json;

namespace Entities.Models.Request
{
    public class Filter
    {
        [JsonProperty("logic")]
        public string? Logic { get; set; }

        [JsonProperty("field")]
        public string? Field { get; set; }

        [JsonProperty("operator")]
        public string? Operator { get; set; }

        [JsonProperty("tablename")]
        public string? TableName { get; set; }

        [JsonProperty("value")]
        public object? Value { get; set; }

        [JsonProperty("filters")]
        public List<Filter>? Filters { get; set; }

        public bool IsDescriptor
        {
            get
            {
                return Field != null && Operator != null;
            }
        }

        public static readonly IDictionary<string, string> Operaters = new Dictionary<string, string>
        {
            { "eq", "=" },
            { "neq", "!=" },
            { "lt", "<" },
            { "lte", "<=" },
            { "gt", ">" },
            { "gte", ">=" },
            { "startswith", "StartsWith" },
            { "endswith", "EndsWith" },
            { "contains", "Contains" },
            { "doesnotcontain", "NotContains" }, // Changed this
            { "isnull", "=" },
            { "isnotnull", "!=" },
            { "isempty", "=" },
            { "isnotempty", "!=" },
            { "isnullorempty", "" },
            { "isnotnullorempty", "!" }
        };

        public static readonly string[] StringOperators = ["startswith", "endswith", "contains", "doesnotcontain", "isempty", "isnotempty", "isnullorempty", "isnotnullorempty"];

        public IList<Filter> All()
        {
            var filters = new List<Filter>();
            Collect(filters);
            return filters;
        }

        private void Collect(IList<Filter> filters)
        {
            if (Filters?.Any() == true)
            {
                foreach (var filter in Filters)
                {
                    filter.Collect(filters);
                }
            }
            else
            {
                filters.Add(this);
            }
        }

        public string BuildWhereClause(Filter filter)
        {
            if (filter.Filters?.Any() == true)
            {
                var filterExpressions = filter.Filters
                    .Select(BuildWhereClause)
                    .Where(expression => !string.IsNullOrEmpty(expression));
                filter.TableName = filter.TableName;
                return $"({string.Join($" {filter.Logic?.ToUpper() ?? "AND"} ", filterExpressions)})";
            }

            if (string.IsNullOrEmpty(filter.Operator))
            {
                throw new ArgumentException("Operator cannot be null or empty");
            }

            if (filter.IsDescriptor)
            {
                var sqlOperator = Operaters.ContainsKey(filter.Operator.ToLower())
                    ? Operaters[filter.Operator.ToLower()]
                    : "=";

                // Handle client management specific filtering
                if (StringOperators.Contains(filter.Operator.ToLower()))
                {
                    return BuildStringFilterClause(filter);
                }

                return $"{filter.Field} {sqlOperator} '{filter.Value}' ";
            }

            return string.Empty;
        }

        private static string BuildStringFilterClause(Filter filter)
        {
            // Handle client management search across multiple fields
            if (filter.TableName == "ClientManagement")
            {
                return BuildClientManagementFilter(filter);
            }

            // Handle other table filtering
            var fieldMap = new Dictionary<string, string>
            {
                ["fieldName"] = "f.Name",
                ["displayName"] = "f.DisplayName",
                ["fieldTypeName"] = "ft.Name",
                ["mandatory"] = "f.Mandatory"
            };

            var actualField = fieldMap.TryGetValue(filter.Field ?? "", out var dbField)
                ? dbField
                : filter.Field;

            if (actualField == null)
            {
                return string.Empty;
            }

            // Handle doesnotcontain operator
            if (filter.Operator?.ToLower() == "doesnotcontain")
            {
                return $"{actualField} NOT LIKE '%{filter.Value}%'";
            }

            return $"{actualField} LIKE '%{filter.Value}%'";
        }

        private static string BuildClientManagementFilter(Filter filter)
        {
            var searchValue = filter.Value?.ToString();
            if (string.IsNullOrEmpty(searchValue))
                return string.Empty;

            // Handle specific field filtering
            if (!string.IsNullOrEmpty(filter.Field))
            {
                var baseCondition = filter.Field.ToLower() switch
                {
                    "name" => $"CONCAT(ISNULL(FirstName, ''), ' ', ISNULL(LastName, '')) LIKE '%{searchValue}%'",
                    "email" => $"Email LIKE '%{searchValue}%'",
                    "companyname" => $"CompanyName LIKE '%{searchValue}%'",
                    _ => $"{filter.Field} LIKE '%{searchValue}%'"
                };

                // Handle doesnotcontain operator
                if (filter.Operator?.ToLower() == "doesnotcontain")
                {
                    return filter.Field.ToLower() switch
                    {
                        "name" => $"CONCAT(ISNULL(FirstName, ''), ' ', ISNULL(LastName, '')) NOT LIKE '%{searchValue}%'",
                        "email" => $"Email NOT LIKE '%{searchValue}%'",
                        "companyname" => $"CompanyName NOT LIKE '%{searchValue}%'",
                        _ => $"{filter.Field} NOT LIKE '%{searchValue}%'"
                    };
                }

                return baseCondition;
            }

            // Handle global search across all searchable fields
            if (filter.Operator?.ToLower() == "doesnotcontain")
            {
                return $"(CONCAT(ISNULL(FirstName, ''), ' ', ISNULL(LastName, '')) NOT LIKE '%{searchValue}%' " +
                       $"AND Email NOT LIKE '%{searchValue}%' " +
                       $"AND CompanyName NOT LIKE '%{searchValue}%')";
            }

            return $"(CONCAT(ISNULL(FirstName, ''), ' ', ISNULL(LastName, '')) LIKE '%{searchValue}%' " +
                   $"OR Email LIKE '%{searchValue}%' " +
                   $"OR CompanyName LIKE '%{searchValue}%')";
        }

        private static void SetTableNameRecursively(Filter filter, string tableName)
        {
            if (filter == null) return;

            filter.TableName = tableName;

            if (filter.Filters?.Any() == true)
            {
                foreach (var subFilter in filter.Filters)
                {
                    SetTableNameRecursively(subFilter, tableName);
                }
            }
        }
    }
}