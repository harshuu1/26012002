﻿namespace Entities.Models.Table
{
    public class TableModel : CommonField
    {

        /// <summary>
        /// Selected row identification field ID (from FieldDefination)
        /// </summary>
        public List<int>? SelectedFieldIds { get; set; }
        public int? PrimaryKeyType { get; set; }
        /// <summary>
        /// Name of the table.
        /// </summary>
        public required string Name { get; set; }
        public int? ParentId { get; set; }

        public string? ParentName { get; set; }
        /// <summary>
        ///  Add this property for selected parent table Ids from dropdown
        /// </summary>
        public List<int> SelectedParentTableIds { get; set; } = [];

        /// <summary>
        /// Identifier for the client who owns this table.
        /// </summary>
        public required int ClientId { get; set; }
        /// <summary>
        /// Identifier for the associated project.
        /// </summary>
        public int? ProjectId { get; set; }
        /// <summary>
        /// Name of the associated project.
        /// </summary>
        public string? Projectname { get; set; }
        /// <summary>
        /// Name of the client.
        /// </summary>
        public string? Clientname { get; set; }
        public string? HeaderTableName { get; set; }
        /// <summary>
        /// Indicates whether the table is hierarchical (e.g., master-detail relationship).
        /// </summary>
        public bool IsHierarchical { get; set; }





        //public int? SearchProfileId { get; set; }
        //public int? CardViewProfileId { get; set; }
        //public int? ListProfileId { get; set; }


        /// <summary>
        /// Name of the detail table in a hierarchical relationship.
        /// </summary>
        public string? DetailTableName { get; set; }
        /// <summary>
        /// ID of the header table.
        /// </summary>
        public int? HeaderTableId { get; set; }
        /// <summary>
        /// ID of the detail table.
        /// </summary>
        public int? DetailTableId { get; set; }

        /// <summary>
        /// List of associated detail tables.
        /// </summary>
        public List<DetailTable>? DetailTableList { get; set; }

        public bool isDragDrop { get; set; }

    }

    //TODO: need to Remove
    public class DetailTable
    {
        public int? HeaderTableId { get; set; }
    }


    //For Import / Export
    //public class TableWithDetails : Table
    //{
    //    [JsonProperty(Order = 47)]
    //    public List<Section> SectionsList { get; set; } = [];

    //    [JsonProperty(Order = 48)]
    //    public List<FieldDefination> FieldDefinitionsList { get; set; } = [];

    //    [JsonProperty(Order = 49)]
    //    public List<FormDetails> FormsList { get; set; } = [];

    //    [JsonProperty(Order = 50)]
    //    public List<Menu> MenuList { get; set; } = [];

    //    [JsonProperty(Order = 51)]
    //    public List<RuleDetails> RuleDetailsList { get; set; } = [];

    //    [JsonProperty(Order = 52)]
    //    public List<SearchProfileDetails> SearchProfileList { get; set; } = [];

    //    [JsonProperty(Order = 53)]
    //    public List<ListProfileDetails> ListProfileDetails { get; set; } = [];

    //    [JsonProperty(Order = 54)]
    //    public List<CardViewProfileDetails> CardViewProfileDetails { get; set; } = [];

    //}


    public class RelatedDataDto
    {
        public List<ProfileFieldDto>? CardViewProfiles { get; set; }
        public List<ProfileFieldDto>? ListProfiles { get; set; }
        public List<ProfileFieldDto>? SearchProfiles { get; set; }
        public List<ProfileFieldDto>? TableRules { get; set; }
        public List<ProfileFieldDto>? FormRules { get; set; }
        public List<FormActionDto>? FormActions { get; set; }
        public List<string>? FieldNames { get; set; }
        public List<string>? SectionNames { get; set; }
        public List<string>? MenuNames { get; set; }
    }

    public class ProfileFieldDto
    {
        public string? ProfileName { get; set; }
        public string? FieldName { get; set; }
    }

    public class FormActionDto
    {
        public string? FormName { get; set; }
        public string? FormActionName { get; set; }
    }

}
