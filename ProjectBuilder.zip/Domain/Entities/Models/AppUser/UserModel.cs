﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models.AppUser
{
    public class UserModel
    {
        public int Id { get; set; }

        /// <summary>
        /// The username used for login and identification.
        /// </summary>
        public string? Username { get; set; }

        /// <summary>
        /// The hashed version of the user's password for secure storage.
        /// </summary>
        public string? PasswordHash { get; set; }

        /// <summary>
        /// The role assigned to the user (e.g., Admin, User, Manager).
        /// </summary>
        public string? Role { get; set; }
    }
}
