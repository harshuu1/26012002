﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models.AppUser
{
    public class UserTokenModel
    {
        /// <summary> The unique identifier of the token record.</summary>
        public int Id { get; set; }
        /// <summary> The identifier of the user to whom the token belongs.</summary>
        public int UserId { get; set; }
        /// <summary> The JWT token string used for authentication.</summary>
        public string? Token { get; set; }
        /// <summary> The UTC expiry date and time of the token.</summary>
        public DateTime ExpiryDate { get; set; }
        /// <summary> The UTC date and time when the token was created.</summary>
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    }
}
