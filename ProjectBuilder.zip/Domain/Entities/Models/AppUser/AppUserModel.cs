﻿using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace Entities.Models.AppUser
{
    public class AppUserModel : CommonField
    {
        /// <summary>User's First name.</summary>       
        public string? FirstName { get; set; }
        /// <summary>User's Last name.</summary>
        public string? LastName { get; set; }
        /// <summary>User's Phone NO.</summary>
        public string? PhoneNo { get; set; }
        /// <summary>User's Email.</summary>
        public string? Email { get; set; }
        //public string PasswordHash { get; set; } // Store hashed password instead of plain text
        /// <summary>User's Password.</summary>
        public string? Password { get; set; }
        /// <summary>User's Role ID.</summary>
        public int? RoleId { get; set; }
        public bool IsActive { get; set; }
        public string? LoginStatus { get; set; }
    }

    public class AuthUserModel : CommonField
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PhoneNo { get; set; }
        public string? Email { get; set; }
        public int RoleId { get; set; }
        public bool IsActive { get; set; }
        public string? Token { get; set; }
    }

    public interface IUserInfo
    {
        public int? UserId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PhoneNo { get; set; }
        public string? Email { get; set; }
        public bool IsActive { get; set; }
        //public int? RoleId { get; set; }
        public string? Token { get; set; }
    }

    public class UserInfo : IUserInfo
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserInfo(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;

            var user = _httpContextAccessor.HttpContext?.User;

            FirstName = user?.Claims.FirstOrDefault(x => x.Type == "firstName")?.Value;
            LastName = user?.Claims.FirstOrDefault(x => x.Type == "lastName")?.Value;
            PhoneNo = user?.Claims.FirstOrDefault(x => x.Type == "phoneNo")?.Value;
            Email = user?.Claims.FirstOrDefault(x => x.Type == "email")?.Value;
            //RoleId = Convert.ToInt32(user?.Claims.FirstOrDefault(x => x.Type == "roleId")?.Value ?? "0");
            Token = user?.FindFirst("token")?.Value;
            UserId = Convert.ToInt32(user?.Claims.FirstOrDefault(x => x.Type == "userId")?.Value);

            foreach (var claim in user?.Claims ?? Enumerable.Empty<Claim>())
            {
                Console.WriteLine($"[CLAIM] {claim.Type} = {claim.Value}");
            }
        }

        public int? UserId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PhoneNo { get; set; }
        public string? Email { get; set; }
        public bool IsActive { get; set; }
        public string? Token { get; set; }
    }

    public class JwtModel
    {
        public int MaxIdleMinutes { get; set; }
        public string JwtIssuer { get; set; } = string.Empty;
        public string JwtAudience { get; set; } = string.Empty;
        public string JwtKey { get; set; } = string.Empty;
        public int JwtExpiryInHours { get; set; }
    }

}
