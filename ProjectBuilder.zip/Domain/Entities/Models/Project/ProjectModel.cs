﻿using Microsoft.AspNetCore.Http;

namespace Entities.Models.Project
{
    public class ProjectModel : CommonField
    {
        public object? ClientID;

        //public object ClientID;
        /// <summary>
        /// The Client ID associated with the project.
        /// </summary>
        public int ClientId { get; set; }

        /// <summary>
        /// The unique ID of the project.
        /// </summary>
        public int? ProjectId { get; set; }

        /// <summary>
        /// The name of the project (e.g., "Web Development", "Database Setup").
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// A description of the project, explaining its scope, goals, and details.
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// The name of the company associated with the project. This field is optional.
        /// </summary>
        public string? CompanyName { get; set; }

        /// <summary>
        /// The logo file for the project. It can be uploaded through a form.
        /// </summary>
        public IFormFile? ProjectLogoFile { get; set; }  // For uploading logo via form

        /// <summary>
        /// The URL or path to the project logo. This can be used to display the logo in the application.
        /// </summary>
        public string? ProjectLogo { get; set; }

        /// <summary>
        /// The alignment type of the project (e.g., Left, Right, Top, Bottom).
        /// </summary>
        //[JsonConverter(typeof(StringEnumConverter), new object[] { true })] // Serialize as integer
        //public AlignmentType AlignmentType { get; set; }
        public int? AlignmentType { get; set; }

        /// <summary>
        /// get client swagger publish url
        /// </summary>
        public string? ClientApiLink { get; set; }

        /// <summary>
        /// get client ui publish url
        /// </summary>
        public string? ClientUiLink { get; set; }
        public string? ConfigurationApiLink { get; set; }
        public string? ConfigurationUiLink { get; set; }
        public bool IsPublishEnabled { get; set; }
        public string? ClientAdminApiLink { get; set; }
        public string? ClientAdminUiLink { get; set; }
        public bool? IsActive { get; set; }
        public bool IsConfigure { get; set; }
        public bool IsBuild { get; set; }
        public string? TabType { get; set; }
    }
}

