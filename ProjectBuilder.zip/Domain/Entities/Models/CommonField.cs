﻿namespace Entities.Models
{
    public class CommonField
    {
        /// <summary>The primary key for the entity. </summary>
        public int ID { get; set; }
        /// <summary>The ID of the user who created the entity.</summary>
        public int? CreatedBy { get; set; }
        /// <summary>The date when the entity was created.</summary>
        public DateTime? CreatedDate { get; set; }
        /// <summary>The ID of the user who last modified the entity .</summary>
        public int? ModifiedBy { get; set; }
        /// <summary>The date when the entity was last modified.</summary>
        public DateTime? ModifiedDate { get; set; }
    }
}
