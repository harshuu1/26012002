﻿namespace Entities.Models.MultiColumnDropdownField
{
    public class MultiColumnDropdownFieldModel : CommonField
    {
        public int FieldDefinitionId { get; set; }
        //public int SourceFieldId { get; set; }
        public List<int> SourceFieldIds { get; set; } = [];
        public int? SourceFieldId { get; set; }
        public string? SourceFieldName { get; set; }
        //public List<int> MultiColumnIds { get; set; } // This will hold the selected IDs
    }
}
