﻿namespace Entities.Models.Client
{
    public class ClientModel : CommonField
    {
        /// <summary> Client's First Name.</summary>
        public string? FirstName { get; set; }
        /// <summary> Client's Last Name.</summary>
        public string? LastName { get; set; }
        /// <summary> Client's Phone No.</summary>
        public string? PhoneNo { get; set; }
        /// <summary> Client's Email .</summary>
        public string? Email { get; set; }
        /// <summary> Client's Password.</summary>
        public string? Password { get; set; }
        /// <summary> Name.</summary>
        public string? Name { get; set; }
        /// <summary> Company Name.</summary>
        public string? CompanyName { get; set; }
        public bool? IsActive { get; set; }
    }
}
