﻿namespace Entities.Models.Publish
{
    public class PublishRequest
    {
        /// <summary>
        /// Gets or sets the client sub path.
        /// </summary>
        public string? ClientSubPath { get; set; } = null;
        /// <summary>
        /// Gets or sets the ProjectName.
        /// </summary>
        public string? ProjectName { get; set; }
        /// <summary>
        /// Gets or sets the ApiPort.
        /// </summary>
        public int ApiPort { get; set; }
        /// <summary>
        /// Gets or sets the UiPort.
        /// </summary>
        public int UiPort { get; set; }
        /// <summary>
        /// Gets or sets the ClientAdminApiPort.
        /// </summary>
        public int ClientAdminApiPort { get; set; }
        /// <summary>
        /// Gets or sets the ClientAdminUiPort.
        /// </summary>
        public int ClientAdminUiPort { get; set; }
        /// <summary>
        /// Gets or sets the Client Admin Sub Path.
        /// </summary>
        public string? ClientAdminSubPath { get; set; } = null;
        /// <summary>
        /// Gets or sets Configuration.
        /// </summary>
        public bool IsConfiguration { get; set; }
    }
}
