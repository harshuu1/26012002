﻿namespace Entities.Models.Publish
{
    public class PublishStatus
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        public string? Id { get; set; }
        /// <summary>
        /// Gets or sets the CurrentStep.
        /// </summary>
        public string? CurrentStep { get; set; }
        /// <summary>
        /// Gets or sets the Message.
        /// </summary>
        public string? Message { get; set; }
        /// <summary>
        /// Gets or sets the Completed.
        /// </summary>
        public bool IsCompleted { get; set; }
        /// <summary>
        /// Gets or sets the HasError.
        /// </summary>
        public bool HasError { get; set; }
        /// <summary>
        /// Gets or sets the IsCancelled.
        /// </summary>
        public bool IsCancelled { get; set; }
        /// <summary>
        /// Gets or sets the ApiUrl.
        /// </summary>
        public string? ApiUrl { get; set; }
        /// <summary>
        /// Gets or sets the UiUrl.
        /// </summary>
        public string? UiUrl { get; set; }
        /// <summary>
        /// Gets or sets the StartTime.
        /// </summary>
        public DateTime StartTime { get; set; }
        /// <summary>
        /// Gets or sets the LastUpdated.
        /// </summary>
        public DateTime LastUpdated { get; set; }
        /// <summary>
        /// Gets or sets the Logs.
        /// </summary>
        public List<string> Logs { get; set; } = [];
        /// <summary>
        /// Gets or sets the ClientAdminApiUrl.
        /// </summary>
        public string? ClientAdminApiUrl { get; set; }
        /// <summary>
        /// Gets or sets the ClientAdminUiUrl.
        /// </summary>
        public string? ClientAdminUiUrl { get; set; }
    }
}