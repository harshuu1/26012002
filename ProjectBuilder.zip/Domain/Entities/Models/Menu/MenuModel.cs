﻿using Microsoft.AspNetCore.Http;

namespace Entities.Models.Menu
{
    public class MenuModel : CommonField
    {
        /// <summary>
        /// The name of the menu (e.g., "Dashboard", "Settings").
        /// </summary>
        public string? Name { get; set; }

        /// <summary>
        /// A description for the menu (optional), which can provide more context about the menu item.
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// The ID of the parent menu. If this menu item is a top-level menu, the value will be null.
        /// </summary>
        public int? ParentID { get; set; }

        /// <summary>
        /// The ID of the form associated with this menu item, if applicable.
        /// </summary>
        public int? FormId { get; set; }

        /// <summary>
        /// The ID of the client this menu belongs to.
        /// </summary>
        public int ClientId { get; set; }

        /// <summary>
        /// The ID of the project this menu belongs to.
        /// </summary>
        public int ProjectId { get; set; }

        /// <summary>
        /// The name of the form associated with this menu item, if applicable.
        /// </summary>
        public string? FormName { get; set; }

        /// <summary>
        /// The name of the company this menu is related to, if applicable.
        /// </summary>
        public string? CompanyName { get; set; }

        /// <summary>
        /// The name of the project this menu is related to, if applicable.
        /// </summary>
        public string? ProjectName { get; set; }

        /// <summary>
        /// The image file for the menu icon, if the menu has an associated icon image.
        /// </summary>
        public IFormFile? MenuIconImg { get; set; }

        /// <summary>
        /// The icon associated with the menu (a string representing the icon, for example, using a CSS class name).
        /// </summary>
        public string? MenuIcon { get; set; }

        /// <summary>
        /// A list of submenus under this menu, representing a hierarchical structure.
        /// </summary>
        public List<MenuModel>? MenuList { get; set; }
        // This property will hold the child menus for hierarchical structure
        //public List<Menu> Children { get; set; } = new List<Menu>()

        //public int? ListProfileId { get; set; }

        public bool? IsCardView { get; set; }
        public bool? ImportProfile { get; set; }
        public bool? IsClientMenu { get; set; }
        public int? InOrder { get; set; }
        //public string? ListViewProfileName { get; set; }

        //public string? CardViewProfileName { get; set; }

        public int? TableId { get; set; }

        public string? TableName { get; set; }

        public string? ParentName { get; set; }
    }
}
