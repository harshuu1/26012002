﻿using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class SendConnectionStringClass
    {
        public void SendConnectionString(string newConnectionString, string ProjectName, string ClientName)
        {
            string projectfoldername = $@"{ClientName}\{ProjectName}";

            // Path for Client appsettings.json
            string clientPath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.Api\appsettings.json";

            // Path for Admin appsettings.json
            string adminPath = $@"C:\ClientProject\{projectfoldername}_Admin\Presentation\ClientAdmin.Api\appsettings.json";

            // Ensure the client appsettings.json exists before proceeding
            if (!File.Exists(clientPath))
            {
                Console.WriteLine("Client appsettings.json file does not exist.");
                return;
            }

            // Read the existing content of the client appsettings.json
            string jsonContent = File.ReadAllText(clientPath);
            JObject jsonObject = JObject.Parse(jsonContent);

            // Ensure "ConnectionStrings" section exists
            if (jsonObject["ConnectionStrings"] == null)
            {
                jsonObject["ConnectionStrings"] = new JObject();
            }

            // Update or create the "connection" key
            if (jsonObject["ConnectionStrings"] is JObject connectionStrings)
            {
                connectionStrings["connection"] = newConnectionString;
            }
            else
            {
                jsonObject["ConnectionStrings"] = new JObject
                {
                    ["connection"] = newConnectionString
                };
            }

            // Write the updated JSON back to both client and admin appsettings.json files
            string updatedJson = jsonObject.ToString(Formatting.Indented);

            File.WriteAllText(clientPath, updatedJson);
            Console.WriteLine(" Updated Client appsettings.json with new connection string.");

            // If the Admin file exists, update it; if not, optionally create it
            string? adminDir = Path.GetDirectoryName(adminPath);
            if (!string.IsNullOrEmpty(adminDir))
            {
                if (!Directory.Exists(adminDir))
                    Directory.CreateDirectory(adminDir);
            }

            File.WriteAllText(adminPath, updatedJson);
            Console.WriteLine("Updated Admin appsettings.json with new connection string.");
        }

        public void setconnctionstringinconsole(string newconnectionstring, string projectname, string clientname)
        {
            string escapedConnectionString = newconnectionstring.Replace("\\", "\\\\");
            StringBuilder sb = new();
            sb.AppendLine("{");
            sb.AppendLine("\"ConnectionStrings\": {");
            sb.AppendLine($"\"connection\": \"{escapedConnectionString}\"");
            sb.AppendLine("  },");
            sb.AppendLine("  \"ScheduledTasks\": {");
            sb.AppendLine($"    \"ExecutablePath\": \"C:\\\\ClientProject\\\\{clientname}\\\\{projectname}\\\\BackGroundServices\\\\bin\\\\Release\\\\net8.0\\\\BackGroundServices.exe\",");
            sb.AppendLine($"    \"WorkingDirectory\": \"C:\\\\ClientProject\\\\{clientname}\\\\{projectname}\\\\BackGroundServices\\\\bin\\\\Release\\\\net8.0\",");
            sb.AppendLine("    \"Importer\": {");
            sb.AppendLine($"      \"TaskName\": \"Run Importer {projectname}\",");
            sb.AppendLine("      \"TaskDescription\": \"Runs the Importer job\",");
            sb.AppendLine("      \"StartHour\": 11,");
            sb.AppendLine("      \"StartMinute\": 0,");
            sb.AppendLine("      \"TriggerType\": \"Daily\",");
            sb.AppendLine("      \"RepeatEveryXDays\": 1,");
            sb.AppendLine("      \"RepeatEveryXWeeks\": 1,");
            sb.AppendLine("      \"DaysOfWeek\": \"Monday,Wednesday,Friday\",");
            sb.AppendLine("      \"RepetitionIntervalMinutes\": 5,");
            sb.AppendLine("      \"RepetitionDurationHours\": 8,");
            sb.AppendLine("      \"RunWithHighestPrivileges\": true,");
            sb.AppendLine("      \"RunWhetherUserLoggedIn\": false,");
            sb.AppendLine("      \"Username\": \"desktop-gqm2c7s\\\\admin\",");
            sb.AppendLine("      \"Password\": \"1234\"");
            sb.AppendLine("    },");
            sb.AppendLine("    \"Kpi\": {");
            sb.AppendLine($"      \"TaskName\": \"Run KPI Update {projectname}\",");
            sb.AppendLine("      \"TaskDescription\": \"Runs the KPI update job\",");
            sb.AppendLine("      \"StartHour\": 11,");
            sb.AppendLine("      \"StartMinute\": 0,");
            sb.AppendLine("      \"TriggerType\": \"Daily\",");
            sb.AppendLine("      \"RepeatEveryXDays\": 1,");
            sb.AppendLine("      \"RepeatEveryXWeeks\": 1,");
            sb.AppendLine("      \"DaysOfWeek\": \"Tuesday,Thursday\",");
            sb.AppendLine("      \"RepetitionIntervalMinutes\": 5,");
            sb.AppendLine("      \"RepetitionDurationHours\": 8,");
            sb.AppendLine("      \"RunWithHighestPrivileges\": true,");
            sb.AppendLine("      \"RunWhetherUserLoggedIn\": false,");
            sb.AppendLine("      \"Username\": \"desktop-gqm2c7s\\\\admin\",");
            sb.AppendLine("      \"Password\": \"1234\"");
            sb.AppendLine("    }");
            sb.AppendLine("  }");
            sb.AppendLine("}");
            string projectfoldername = $@"{clientname}\{projectname}";
            string directorypath = $@"c:\clientproject\{projectfoldername}\BackGroundServices\appsettings.json";
            if (!Directory.Exists(Path.GetDirectoryName(directorypath)))
            {
                Console.WriteLine("Directory does not exist.");
                return;
            }
            File.WriteAllText(directorypath, sb.ToString());
        }
    }
}
