﻿using System.Text;
using Dapper;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using Entities.Models.Table;
using Microsoft.Data.SqlClient;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class SearchCriteriaHelper
    {
        private static string GetLabelClass(int AlignmentType)
        {
            switch (AlignmentType)
            {
                case 1: return "label-left";
                case 2: return "label-top";
                // case 3: return "floating-label"; // Uncomment if needed
                default: return "";
            }
        }
        public static async Task<TableModel?> GetTableData(int? id, string configConnectionString)
        {
            try
            {
                //string? originalConnectionString = _configuration.GetConnectionString("DefaultConnection");

                using var connection = new SqlConnection(configConnectionString); // Use directly here
                await connection.OpenAsync();

                var result = await connection.QuerySingleOrDefaultAsync<TableModel>(
                    "SELECT * FROM TableDefination WHERE ID=@id", new { id });

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }
        public static string RenderSearchPanel(
            string tableName,
            IEnumerable<ClientSearchField> allFields,
            //List<ClientSearchField> searchListByParentId,
            string cssClass,
            bool showButtons = true,
            int alignmentType = 0 // optional if you already have GetLabelClass(alignmentType)
        )
        {
            //var fieldsToRender = (searchListByParentId != null && searchListByParentId.Any())
            //    ? searchListByParentId
            //    : allFields;
            var fieldsToRender = allFields;

            cssClass = GetLabelClass(alignmentType);

            if (fieldsToRender == null || !fieldsToRender.Any())
                return $"<div class='alert alert-warning mt-3 mb-3'>No search criteria defined for {tableName}.</div>";

            var sb = new StringBuilder();

            sb.AppendLine($"<div id='{tableName}Panel'>");
            sb.AppendLine("<div class='mt-4 main-section w-100 mb-4'>");
            sb.AppendLine("<div class='row'>");

            foreach (var field in fieldsToRender)
            {
                var fieldName = (field.FieldName ?? "").Trim();
                var alignmentClass = GetLabelClass(alignmentType);
                var rowlabel = $"<div class=\"col-md-4\">";
                var rowcontrol = $"<div class=\"col-md-8\">";
                var rowend = $"</div>";
                var defaultValue = !string.IsNullOrWhiteSpace(field.DefaultValue)
                   ? $" value='{System.Net.WebUtility.HtmlEncode(field.DefaultValue)}'"
                   : string.Empty;

                var isChecked = string.Equals(field.DefaultValue?.Trim(), "1", StringComparison.OrdinalIgnoreCase)
           || string.Equals(field.DefaultValue?.Trim(), "true", StringComparison.OrdinalIgnoreCase);

                var checkedAttr = isChecked ? " checked" : string.Empty;




                //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                if (!Enum.TryParse<FieldTypeEnums>(field.FieldType, true, out var fieldType))
                {
                    continue; // Skip unknown / unmapped types
                }
                sb.AppendLine("<div class='col-lg-4 d-flex'>");

                if (fieldType != FieldTypeEnums.DropDown && fieldType != FieldTypeEnums.Switches && fieldType != FieldTypeEnums.Checkboxgroup && fieldType != FieldTypeEnums.Radiogroup && fieldType != FieldTypeEnums.Multiselect && fieldType != FieldTypeEnums.Slider && fieldType != FieldTypeEnums.Colorpicker && fieldType != FieldTypeEnums.Bit)
                {
                    sb.AppendLine($"<div class='form-group {cssClass} mb-3 me-2' style='width: 30%;'>");
                    sb.AppendLine($"<select class='inputcontrol' id='{fieldNameLowerCase}Criteria' name='{fieldNameLowerCase}Criteria'></select>");

                    if (cssClass == "label-top" || cssClass == "label-bottom")
                    {
                        sb.AppendLine($"<label for='{fieldNameLowerCase}' class='form-label-text'>&nbsp;</label>");
                    }

                    sb.AppendLine("</div>");
                }
                else if (fieldType == FieldTypeEnums.Slider || fieldType == FieldTypeEnums.Bit || fieldType == FieldTypeEnums.Switches)
                {
                    if (fieldType == FieldTypeEnums.Switches)
                    {
                        sb.AppendLine("        <label  class='custom-label mt-2' style='width: 46%;'>");
                    }
                    else
                    {
                        sb.AppendLine("        <label  class='custom-label mt-2' style='width: 32%;'>");
                    }
                    sb.AppendLine($"            <input type='checkbox' id='isfilter_{fieldNameLowerCase}' class='form-check-input' style='padding:2px;'>");
                    sb.AppendLine("            In Filter");
                    sb.AppendLine("        </label>");

                }

                if (cssClass == "label-top")
                {
                    if (fieldType != FieldTypeEnums.DropDown && fieldType != FieldTypeEnums.Switches && fieldType != FieldTypeEnums.Checkboxgroup && fieldType != FieldTypeEnums.Radiogroup && fieldType != FieldTypeEnums.Multiselect && fieldType != FieldTypeEnums.Slider && fieldType != FieldTypeEnums.Colorpicker && fieldType != FieldTypeEnums.Datetime && fieldType != FieldTypeEnums.Bit)
                    {

                        sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 68%;bottom: 29px;'>");
                    }
                    else if (fieldType == FieldTypeEnums.Datetime)
                    {
                        sb.AppendLine($"<div class='form-group {cssClass} mb-3 {fieldNameLowerCase}' style='width: 68%; bottom:29px; height:20px'>");
                    }
                    else if (fieldType == FieldTypeEnums.Slider || fieldType == FieldTypeEnums.Rangeslider)
                    {
                        sb.AppendLine($" <div class='form-group {cssClass} mb-3 slider_search' style='width: 70%;bottom: 30px;'>");
                    }
                    else if (fieldType == FieldTypeEnums.Bit)
                    {
                        sb.AppendLine($"<div class='form-group mb-3' style='width: 68%'>");
                    }
                    else
                    {
                        sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 100%;bottom: 32px;'>");
                    }
                }
                else
                {
                    if (fieldType != FieldTypeEnums.DropDown && fieldType != FieldTypeEnums.Switches && fieldType != FieldTypeEnums.Checkboxgroup && fieldType != FieldTypeEnums.Multiselect && fieldType != FieldTypeEnums.Radiogroup && fieldType != FieldTypeEnums.Slider && fieldType != FieldTypeEnums.Colorpicker && fieldType != FieldTypeEnums.Datetime)
                    {

                        sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 68%;'>");
                    }
                    else if (fieldType == FieldTypeEnums.Datetime)
                    {
                        sb.AppendLine($"<div class='form-group {cssClass} mb-3 {fieldNameLowerCase}' style='width: 68%;'>");
                    }
                    else if (fieldType == FieldTypeEnums.Slider || fieldType == FieldTypeEnums.Rangeslider)
                    {
                        sb.AppendLine($" <div class='form-group {cssClass} mb-3 slider_search' style='width: 70%;'>");
                    }
                    else
                    {
                        sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 100%;'>");
                    }
                }

                string labeldiv = "";
                if (fieldType == FieldTypeEnums.Bit)
                {
                    labeldiv = $"<label for='{fieldNameLowerCase}' class='form-label-text mt-2'>";
                }
                else
                {
                    labeldiv = $"<label for='{fieldNameLowerCase}' class='form-label-text'>{(field.DisplayName ?? "").Trim()}</label>";
                }

                if (alignmentClass == "label-left")
                {
                    sb.AppendLine(rowlabel);
                    sb.AppendLine(labeldiv);
                    sb.AppendLine(rowend);
                    sb.AppendLine(rowcontrol);
                }
                else
                {
                    sb.AppendLine(labeldiv);

                }

                // Input control rendering
                switch (fieldType)
                {
                    case FieldTypeEnums.Int:
                        sb.AppendLine($"<input type='number' class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' {defaultValue}/>");
                        break;

                    case FieldTypeEnums.Varchar:
                    case FieldTypeEnums.Nvarchar:
                        sb.AppendLine($"<input type='text' class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' {defaultValue}/>");
                        break;

                    case FieldTypeEnums.Decimal:
                    case FieldTypeEnums.Float:
                        sb.AppendLine($"<input type='number' step='0.01' class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' {defaultValue}/>");
                        break;

                    case FieldTypeEnums.Date:
                        sb.AppendLine($"<input type='date' class='inputcontrol datepicker {fieldNameLowerCase}' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' value='{field.DefaultValue}'/>");
                        if (alignmentClass == "label-left")
                        {
                            sb.AppendLine($" <div id=\"{fieldNameLowerCase}Picker\" style=\"bottom:0%\"></div>");
                        }
                        else
                        {
                            sb.AppendLine($" <div id=\"{fieldNameLowerCase}Picker\" style=\"position:absolute; bottom:0%; width:158%\"></div>");
                        }
                        break;

                    case FieldTypeEnums.Datetime:
                        sb.AppendLine($"<input type='datetime-local' class='inputcontrol datetimepicker' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' {defaultValue}/>");
                        break;

                    case FieldTypeEnums.Switches:

                        sb.AppendLine($"<input type='checkbox' class='form-check-input' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}'  {checkedAttr} />");
                        break;
                    case FieldTypeEnums.Bit:

                        sb.AppendLine($"<input type='checkbox' class='form-check-input' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}'  {checkedAttr} />");
                        sb.AppendLine($"{(field.DisplayName ?? "").Trim()}");
                        sb.AppendLine("</label>");
                        break;

                    case FieldTypeEnums.Timeduration:
                        sb.AppendLine("<div class=\"kendo-timer-wrapper\" style=\"width:100%\">");
                        sb.AppendLine($"<input class='form-control1' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}'  {defaultValue} />");
                        sb.AppendLine("</div>");
                        break;

                    case FieldTypeEnums.DropDown:
                        sb.AppendLine($"<input class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' {defaultValue} />");
                        break;

                    default:
                        sb.AppendLine($"<input type='text' class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}'  {defaultValue} />");
                        break;
                }
                //var labeldiv = $"<label for='{fieldNameLowerCase}' class='form-label-text'>{(field.DisplayName ?? "").Trim()}</label>";

                //    sb.AppendLine(labeldiv);

                if (alignmentClass == "label-left")
                {
                    sb.AppendLine(rowend); // Close col-md-10                    
                }

                sb.AppendLine("</div>"); // close form-group
                sb.AppendLine("</div>"); // close col-lg-4 d-flex
            }

            sb.AppendLine("</div>"); // close row

            // ✅ Conditional Search / Clear buttons
            if (showButtons)
            {
                sb.AppendLine("<div class='form-submit text-end mt-2 mb-2'>");
                sb.AppendLine("<button type='button' id='search' class='btn btn-primary me-2 text-white' onclick=\"applySearchFilter()\">");
                sb.AppendLine("<i class='k-icon k-font-icon k-i-search'></i> Search</button>");
                sb.AppendLine("<button type='button' id='clear' class='btn btn-primary text-white' onclick=\"clearSearch()\">");
                sb.AppendLine("<i class='k-icon k-font-icon k-i-cancel'></i> Clear</button>");
                sb.AppendLine("</div>");
            }

            sb.AppendLine("</div>"); // close main-section
            sb.AppendLine("</div>"); // close outer panel

            return sb.ToString();
        }

        public static async Task<string> GenerateFieldScriptsAsync(IEnumerable<ClientSearchField> fields, string configConnectionString, int alignmentType = 0)
        {
            if (fields == null || !fields.Any())
                return string.Empty;

            var sb = new StringBuilder();

            foreach (var field in fields)
            {
                if (!Enum.TryParse<FieldTypeEnums>(field.FieldType, true, out var fieldType))
                    continue;

                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;

                // Skip empty or dropdown fields (unless special handling)
                if (string.IsNullOrEmpty(fieldNameLowerCase))
                    continue;

                string staticCriteriaJson = "";

                switch (fieldType)
                {
                    case FieldTypeEnums.Varchar:
                    case FieldTypeEnums.Nvarchar:
                    case FieldTypeEnums.Richtexteditor:
                    case FieldTypeEnums.Captcha:
                    case FieldTypeEnums.Hyperlink:
                    case FieldTypeEnums.Rangeslider:
                    case FieldTypeEnums.Signature:
                        staticCriteriaJson = "[{ id: 1, name: \"Equals\" }, { id: 2, name: \"Contains\" }, { id: 3, name: \"StartsWith\" }, { id: 4, name: \"EndsWith\" }]";
                        break;

                    case FieldTypeEnums.Barcode:
                        staticCriteriaJson =
                            "[{ id: 1, name: \"Equals\" }, { id: 2, name: \"Contains\" }, { id: 3, name: \"StartsWith\" }, { id: 4, name: \"EndsWith\" }]";
                        break;

                    case FieldTypeEnums.Int:
                    case FieldTypeEnums.Bigint:
                    case FieldTypeEnums.Float:
                    case FieldTypeEnums.Decimal:
                    case FieldTypeEnums.Numeric:
                    case FieldTypeEnums.Money:
                    case FieldTypeEnums.Smallint:
                    case FieldTypeEnums.Tinyint:
                    case FieldTypeEnums.Rating:
                    case FieldTypeEnums.Timeduration:
                        staticCriteriaJson = "[{ id: 1, name: \"=\" }, { id: 2, name: \">\" }, { id: 3, name: \"<\" }]";
                        break;

                    case FieldTypeEnums.Datetime:
                    case FieldTypeEnums.Date:
                        staticCriteriaJson = "[{ id: 1, name: \"=\" }, { id: 2, name: \">\" }, { id: 3, name: \"<\" }, { id: 4, name: \"Between\" }]";
                        break;
                }


                // Render criteria dropdown if applicable
                if (fieldType != FieldTypeEnums.DropDown && fieldType != FieldTypeEnums.Switches && fieldType != FieldTypeEnums.Radiogroup && fieldType != FieldTypeEnums.Checkboxgroup && fieldType != FieldTypeEnums.Multiselect && fieldType != FieldTypeEnums.Slider && fieldType != FieldTypeEnums.Colorpicker && fieldType != FieldTypeEnums.Bit)
                {
                    sb.AppendLine($"$('#{fieldNameLowerCase}Criteria').kendoDropDownList({{");
                    sb.AppendLine("    optionLabel: '-- Select --',");
                    sb.AppendLine("    dataTextField: 'name',");
                    sb.AppendLine("    dataValueField: 'name',");
                    sb.AppendLine("    filter: 'contains',");
                    sb.AppendLine($"    dataSource: {staticCriteriaJson}");
                    sb.AppendLine("});");
                }

                // Special handling for date/datetime fields
                if (string.Equals(field.FieldType, FieldTypeEnums.Date.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    //var alignmentClass = GetLabelClass(alignmentType);
                    sb.AppendLine($"$('#{fieldNameLowerCase}Criteria').data('kendoDropDownList').bind('change', function () {{");
                    sb.AppendLine("    const selectedText = this.text();");
                    sb.AppendLine($"    const $labelDiv = $(\"label[for='{fieldNameLowerCase}']\").closest('.col-md-4');");
                    sb.AppendLine($"    const $input{fieldNameLowerCase} = $('.{fieldNameLowerCase}');");
                    sb.AppendLine("");
                    sb.AppendLine($"    const existingRange = $('#{fieldNameLowerCase}Picker').data('kendoDateRangePicker');");
                    sb.AppendLine("    if (existingRange) {");
                    sb.AppendLine("        existingRange.destroy();");
                    sb.AppendLine($"        $('#{fieldNameLowerCase}Picker').empty();");
                    sb.AppendLine("    }");
                    sb.AppendLine("");
                    sb.AppendLine("    if (selectedText === 'Between') {");
                    sb.AppendLine($"        $('#{fieldNameLowerCase}Picker').kendoDateRangePicker({{");
                    sb.AppendLine("            messages: { startLabel: '', endLabel: '' }");
                    sb.AppendLine("        });");
                    sb.AppendLine($"        $('#{fieldNameLowerCase}Picker').css('height', '42px');");
                    sb.AppendLine("    } else {");
                    sb.AppendLine($"        $('#{fieldNameLowerCase}Picker').css('height', '');");
                    sb.AppendLine("    }");
                    sb.AppendLine("");
                    sb.AppendLine($"    $labelDiv.toggle(selectedText !== 'Between');");
                    sb.AppendLine($"    $input{fieldNameLowerCase}.toggle(selectedText !== 'Between');");
                    sb.AppendLine($"    $('#{fieldNameLowerCase}Picker').toggle(selectedText === 'Between');");
                    sb.AppendLine("");
                    sb.AppendLine("    $('.k-floating-label-container .k-input, .k-floating-label-container .k-input-solid')");
                    sb.AppendLine("        .css('height', '42px');");
                    sb.AppendLine("});");
                }

                else if (string.Equals(field.FieldType, FieldTypeEnums.Datetime.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"$('#{fieldNameLowerCase}Criteria').data('kendoDropDownList').bind('change', function () {{");
                    sb.AppendLine("    const selectedText = this.text();");
                    sb.AppendLine($"    const container = $('.{fieldNameLowerCase}');");
                    sb.AppendLine();
                    sb.AppendLine($"    $('#{fieldNameLowerCase}').data('kendoDateTimePicker')?.destroy();");
                    sb.AppendLine($"    $('#start_{fieldNameLowerCase}').data('kendoDateTimePicker')?.destroy();");
                    sb.AppendLine($"    $('#end_{fieldNameLowerCase}').data('kendoDateTimePicker')?.destroy();");
                    sb.AppendLine("    container.empty();");
                    sb.AppendLine();
                    sb.AppendLine("    if (selectedText === 'Between') {");
                    sb.AppendLine("        container.html(`");
                    sb.AppendLine("<div class='d-flex justify-content-between' style='gap:10px;'>");
                    sb.AppendLine($"    <input type='text' class='inputcontrol' id='start_{fieldNameLowerCase}' name='start_{fieldNameLowerCase}' />");
                    sb.AppendLine("    <div class='mt-2 form-label-text'>To:</div>");
                    sb.AppendLine($"    <input type='text' class='inputcontrol' id='end_{fieldNameLowerCase}' name='end_{fieldNameLowerCase}' />");
                    sb.AppendLine("</div>");
                    sb.AppendLine("        `);");
                    sb.AppendLine();

                    if (alignmentType == 2)
                    {
                        sb.AppendLine("        container.css('bottom', '');");
                    }

                    sb.AppendLine($"        $('#start_{fieldNameLowerCase}').kendoDateTimePicker({{");
                    sb.AppendLine("            dateInput: true,");
                    sb.AppendLine("        });");
                    sb.AppendLine($"        $('#end_{fieldNameLowerCase}').kendoDateTimePicker({{");
                    sb.AppendLine("            dateInput: true,");
                    sb.AppendLine("        });");
                    sb.AppendLine("    } else {");
                    sb.AppendLine("        container.html(`");

                    sb.AppendLine("                 <div class=\"col-md-4\">");
                    sb.AppendLine($"            <label for=\"{fieldNameLowerCase}\" class=\"form-label-text\">{field.DisplayName}</label>");
                    sb.AppendLine("                 </div>");

                    if (alignmentType == 2)
                    {
                        sb.AppendLine("                 <div class=\"col-md-8\" style=\"width:100%\">");
                    }

                    sb.AppendLine($"            <input type=\"text\" class=\"inputcontrol datetimepicker\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" />");
                    sb.AppendLine("                 </div>");

                    sb.AppendLine("        `);");
                    sb.AppendLine();

                    if (alignmentType == 2)
                    {
                        sb.AppendLine("        container.css('bottom', '29px');");
                    }

                    sb.AppendLine($"        $('#{fieldNameLowerCase}').kendoDateTimePicker({{");
                    sb.AppendLine("            dateInput: true,");
                    sb.AppendLine("        });");
                    sb.AppendLine("    }");
                    sb.AppendLine();
                    //sb.AppendLine("    $('.k-floating-label-container').css('width', '100%');");
                    sb.AppendLine("    $('.k-floating-label-container .k-input, .k-floating-label-container .k-input-solid')");
                    //sb.AppendLine("        .css('width', '100%')");
                    sb.AppendLine("        .css('height', '43px');");
                    sb.AppendLine("});");

                }
                //else if (fieldType == FieldTypeEnums.Timeduration)
                //{
                //    sb.AppendLine($"$('#{fieldNameLowerCase}').kendoTimeDurationPicker({{");
                //    sb.AppendLine("    columns: [");
                //    sb.AppendLine("        { name: 'hours', format: '## Hours ', min: 0, max: 23 },");
                //    sb.AppendLine("        { name: 'minutes', format: ' ## Minutes ', min: 0, max: 59, step: 1 },");
                //    sb.AppendLine("        { name: 'seconds', format: ' ## Seconds', min: 0, max: 59, step: 1 }");
                //    sb.AppendLine("    ],");
                //    sb.AppendLine("    separator: ':'");
                //    sb.AppendLine("}).data('kendoTimeDurationPicker');");
                //}
            }

            foreach (var detailsFields in fields)
            {
                // **Set dropdown values dynamically**
                //foreach (var field in fields)
                //{
                //   if (Detailsfields?.san == "startswith" || Detailsfields?.san == "contains")
                if (string.Equals(detailsFields.FieldType, FieldTypeEnums.DropDown.ToString(), StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(detailsFields.FieldType, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(detailsFields.FieldType, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(detailsFields.FieldType, FieldTypeEnums.Radiogroup.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    //var fieldNameLowerCase = char.ToLower(Detailsfields.FieldName.Trim()[0]) + Detailsfields.FieldName.Trim()[1..];
                    //string fieldNameLowerCase = !string.IsNullOrWhiteSpace(Detailsfields.FieldName) && Detailsfields.FieldName.Trim().Length > 1
                    //                            ? char.ToLower(Detailsfields.FieldName.Trim()[0]) + Detailsfields.FieldName.Trim()[1..]
                    //                            : string.Empty;
                    var fieldNameLowerCase = !string.IsNullOrWhiteSpace(detailsFields.FieldName) && detailsFields.FieldName.Trim().Length > 1
                                              ? detailsFields.FieldName?.Trim().ToLower() : string.Empty;

                    //var textFieldLowerCase = char.ToLower(Detailsfields.TextFieldName.Trim()[0]) + Detailsfields.TextFieldName.Trim()[1..];
                    //string textFieldLowerCase = !string.IsNullOrWhiteSpace(Detailsfields.TextFieldName) && Detailsfields.TextFieldName.Trim().Length > 1
                    //                            ? char.ToLower(Detailsfields.TextFieldName.Trim()[0]) + Detailsfields.TextFieldName.Trim()[1..]
                    //                            : string.Empty;
                    var textFieldLowerCase = !string.IsNullOrWhiteSpace(detailsFields.TextFieldName) && detailsFields.TextFieldName.Trim().Length > 1
                                             ? detailsFields.TextFieldName?.Trim().ToLower() : string.Empty;
                    TableModel? sourcetable = await GetTableData(detailsFields.SourceTableId, configConnectionString);
                    if (sourcetable != null && sourcetable.IsHierarchical && string.IsNullOrEmpty(detailsFields.ParentFieldName))
                    {
                        sb.AppendLine($"$('#{fieldNameLowerCase}').kendoDropDownTree({{");
                        sb.AppendLine("    placeholder: 'Select Parent',");
                        sb.AppendLine("    height: 'auto',");
                        sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
                        sb.AppendLine("    dataValueField: 'id',");

                        //if (detailsFields?.san == "startswith" || detailsFields?.san == "contains")
                        //{
                        //    sb.AppendLine($"filter: '{detailsFields.san}',");
                        //}

                        if (detailsFields?.FilterOption?.ToLower() == "startswith" || detailsFields?.FilterOption?.ToLower() == "contains")
                        {
                            sb.AppendLine($"filter: '{detailsFields.FilterOption.ToLower()}',");
                        }

                        sb.AppendLine("    dataSource: new kendo.data.HierarchicalDataSource({");
                        sb.AppendLine($"   sort: {{ field: \"{textFieldLowerCase}\", dir: 'asc' }},");
                        sb.AppendLine("        transport: {");
                        sb.AppendLine("            read: function (options) {");
                        sb.AppendLine("                $.ajax({");
                        sb.AppendLine($"                    url: backendUrl + '/{detailsFields?.SourceTableName?.ToLower() ?? ""}/hierarchy',");
                        sb.AppendLine("                    type: 'GET',");
                        sb.AppendLine("                    dataType: 'json',");
                        sb.AppendLine("                    success: function (response) {");
                        sb.AppendLine("                        options.success(response);");
                        sb.AppendLine($"                        $('#{fieldNameLowerCase}').data('kendoDropDownTree').value('{detailsFields.DefaultValue}');");
                        sb.AppendLine("                    },");
                        sb.AppendLine("                    error: function (xhr, status, error) {");
                        sb.AppendLine("                        console.error('Error fetching hierarchy:', error);");
                        sb.AppendLine("                        options.error(xhr);");
                        sb.AppendLine("                    }");
                        sb.AppendLine("                });");
                        sb.AppendLine("            }");
                        sb.AppendLine("        },");
                        sb.AppendLine("        schema: {");
                        sb.AppendLine("            model: { id: 'id', children: 'items' }");
                        sb.AppendLine("        }");
                        sb.AppendLine("    })");
                        sb.AppendLine("});");
                    }

                    if (detailsFields?.IsMultiColumn == true && string.IsNullOrEmpty(detailsFields.ParentFieldName))
                    {
                        sb.AppendLine($"$('#{fieldNameLowerCase}').kendoMultiColumnComboBox({{");
                        sb.AppendLine("    placeholder: '--Select--',");
                        sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
                        sb.AppendLine("    dataValueField: 'id',");
                        sb.AppendLine($"        filter: '{detailsFields.FilterOption?.ToLowerInvariant()}',");
                        sb.AppendLine("    columns: [");

                        if (detailsFields.MultiColumnFieldNames != null && detailsFields.MultiColumnFieldNames.Count != 0)
                        {
                            for (int i = 0; i < detailsFields.MultiColumnFieldNames.Count; i++)
                            {
                                var column = detailsFields.MultiColumnFieldNames[i];
                                var comma = i < detailsFields.MultiColumnFieldNames.Count - 1 ? "," : "";

                                //var fieldNameCamelCase = char.ToLower(column.SourceFieldName[0]) + column.SourceFieldName[1..];
                                //string fieldNameCamelCase = !string.IsNullOrWhiteSpace(column.SourceFieldName) && column.SourceFieldName.Length > 1
                                //                            ? char.ToLower(column.SourceFieldName[0]) + column.SourceFieldName[1..]
                                //                            : string.Empty;
                                var fieldNameCamelCase = !string.IsNullOrWhiteSpace(column.SourceFieldName) && column.SourceFieldName.Length > 1 ? column.SourceFieldName?.Trim().ToLower() : string.Empty;

                                sb.AppendLine($"        {{ field: '{fieldNameCamelCase}', title: '{column.SourceFieldName}' }}{comma}");
                            }
                        }

                        else
                        {
                            // Fallback if no fields provided
                            sb.AppendLine("        { field: 'id', title: 'ID' },");
                            sb.AppendLine("        { field: 'name', title: 'Name' }");
                        }

                        sb.AppendLine("    ],");
                        sb.AppendLine("    dataSource: {");
                        sb.AppendLine("        transport: {");
                        sb.AppendLine("            read: function (options) {");
                        sb.AppendLine("                $.ajax({");
                        sb.AppendLine($"                    url: backendUrl + '/{(detailsFields.SourceTableName ?? "").ToLower()}',");
                        sb.AppendLine("                    type: 'GET',");
                        sb.AppendLine("                    dataType: 'json',");
                        sb.AppendLine("                    success: function (response) {");
                        sb.AppendLine("                        options.success(response);");
                        sb.AppendLine($"                        $('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').value('{detailsFields.DefaultValue}');");
                        sb.AppendLine("                    },");
                        sb.AppendLine("                    error: function (xhr, status, error) {");
                        sb.AppendLine("                        console.error('Error fetching data:', error);");
                        sb.AppendLine("                        options.error(xhr);");
                        sb.AppendLine("                    }");
                        sb.AppendLine("                });");
                        sb.AppendLine("            }");
                        sb.AppendLine("        }");
                        sb.AppendLine("    }");
                        sb.AppendLine("});");
                        sb.AppendLine($"$('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').input.attr('readonly', true);");
                    }
                    if (detailsFields?.IsMultiColumn == true && string.IsNullOrEmpty(detailsFields.ParentFieldName))
                    {
                        sb.AppendLine($"$('#{fieldNameLowerCase}').kendoMultiColumnComboBox({{");
                        sb.AppendLine("    placeholder: '--Select--',");
                        sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
                        sb.AppendLine("    dataValueField: 'id',");
                        sb.AppendLine($"    filter: '{detailsFields.FilterOption?.ToLowerInvariant()}',");

                        // Build filterFields dynamically
                        if (detailsFields.MultiColumnFieldNames != null && detailsFields.MultiColumnFieldNames.Count > 0)
                        {
                            var fieldList = string.Join(", ", detailsFields.MultiColumnFieldNames
                                .Select(f => $"'{f.SourceFieldName?.Trim().ToLower()}'"));
                            sb.AppendLine($"    filterFields: [{fieldList}],");
                        }

                        sb.AppendLine("    minLength: 1,");
                        sb.AppendLine("    autoBind: true,");
                        sb.AppendLine("    suggest: true,");
                        sb.AppendLine("    columns: [");

                        if (detailsFields.MultiColumnFieldNames != null && detailsFields.MultiColumnFieldNames.Count > 0)
                        {
                            for (int i = 0; i < detailsFields.MultiColumnFieldNames.Count; i++)
                            {
                                var column = detailsFields.MultiColumnFieldNames[i];
                                var comma = i < detailsFields.MultiColumnFieldNames.Count - 1 ? "," : "";

                                // field name in lowercase
                                var fieldNameCamelCase = column.SourceFieldName?.Trim().ToLower() ?? string.Empty;

                                // formatted title: add spaces between capitals
                                var formattedTitle = System.Text.RegularExpressions.Regex
                                    .Replace(column.SourceFieldName ?? string.Empty, "(\\B[A-Z])", " $1").Trim();

                                // remove trailing " Data" (case-insensitive)
                                if (formattedTitle.EndsWith(" Data", StringComparison.OrdinalIgnoreCase))
                                    formattedTitle = formattedTitle.Substring(0, formattedTitle.Length - 5).Trim();

                                sb.AppendLine($"        {{ field: '{fieldNameCamelCase}', title: '{formattedTitle}' }}{comma}");
                            }
                        }
                        else
                        {
                            sb.AppendLine("        { field: 'id', title: 'ID' },");
                            sb.AppendLine("        { field: 'name', title: 'Name' }");
                        }

                        sb.AppendLine("    ],");
                        sb.AppendLine("    dataSource: {");
                        sb.AppendLine("        sort: { field: 'datafield', dir: 'asc' },");
                        sb.AppendLine("        transport: {");
                        sb.AppendLine("            read: function (options) {");
                        sb.AppendLine("                $.ajax({");
                        sb.AppendLine($"                    url: backendUrl + '/{(detailsFields.SourceTableName ?? "").ToLower()}',");
                        sb.AppendLine("                    type: 'GET',");
                        sb.AppendLine("                    dataType: 'json',");
                        sb.AppendLine("                    success: function (response) {");
                        sb.AppendLine("                        options.success(response);");
                        sb.AppendLine($"                        $('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').value('{detailsFields.DefaultValue}');");
                        sb.AppendLine("                    },");
                        sb.AppendLine("                    error: function (xhr, status, error) {");
                        sb.AppendLine("                        console.error('Error fetching data:', error);");
                        sb.AppendLine("                        options.error(xhr);");
                        sb.AppendLine("                    }");
                        sb.AppendLine("                });");
                        sb.AppendLine("            }");
                        sb.AppendLine("        }");
                        sb.AppendLine("    },");
                        sb.AppendLine("    noDataTemplate: 'No matching records found'");
                        sb.AppendLine("});");
                        sb.AppendLine($"$('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').input.attr('readonly', false);");
                    }
                    // Parent Dropdown(StudentID)
                    //if (field != null && sourcetable != null)
                    //{
                    if (string.IsNullOrEmpty(detailsFields?.ParentFieldName) && detailsFields?.IsMultiColumn == false || string.IsNullOrEmpty(detailsFields?.ParentFieldName) && detailsFields?.IsMultiColumn == false && sourcetable?.IsHierarchical == false)
                    {
                        if (string.Equals(detailsFields.FieldType, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) ||
                           string.Equals(detailsFields.FieldType, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                        {
                            sb.AppendLine($"$('#{fieldNameLowerCase}').kendoMultiSelect({{");
                            sb.AppendLine("    placeholder: '-- Select --',");
                        }
                        else
                        {
                            sb.AppendLine($"$('#{fieldNameLowerCase}').kendoDropDownList({{");
                            sb.AppendLine("    optionLabel: '-- Select --',");
                        }
                        sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
                        sb.AppendLine("    dataValueField: 'id',");
                        if (string.Equals(detailsFields.FieldType, FieldTypeEnums.DropDown.ToString(), StringComparison.OrdinalIgnoreCase))
                        {
                            sb.AppendLine($"        filter: '{(string.IsNullOrEmpty(detailsFields.san) ? "contains" : detailsFields.san)}',");
                        }
                        else
                        {
                            sb.AppendLine($"        filter: 'contains',");
                        }
                        sb.AppendLine("    dataSource: {");
                        sb.AppendLine($"   sort: {{ field: \"{textFieldLowerCase}\", dir: 'asc' }},");
                        sb.AppendLine("        transport: {");
                        sb.AppendLine("            read: function (options) {");
                        sb.AppendLine($"                $.ajax({{");
                        sb.AppendLine($"                    url: backendUrl + '/{(detailsFields.SourceTableName ?? "").ToLower()}',"); // Adjust URL to get Student IDs
                        sb.AppendLine("                    type: 'GET',");
                        sb.AppendLine("                    dataType: 'json',");
                        sb.AppendLine("                    success: function (response) {");
                        sb.AppendLine("                        options.success(response);");
                        if (string.Equals(detailsFields.FieldType, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) ||
                           string.Equals(detailsFields.FieldType, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                        {
                            sb.AppendLine($" $('#{fieldNameLowerCase}').data('kendoMultiSelect').value('{detailsFields.DefaultValue}'); ");
                        }
                        else
                        {
                            sb.AppendLine($" $('#{fieldNameLowerCase}').data('kendoDropDownList').value('{detailsFields.DefaultValue}'); ");
                        }
                        sb.AppendLine("                    },");
                        sb.AppendLine("                    error: function (xhr, status, error) {");
                        sb.AppendLine("                        console.error('Error fetching data:', error);");
                        sb.AppendLine("                        options.error(xhr);");
                        sb.AppendLine("                    }");
                        sb.AppendLine("                });");
                        sb.AppendLine("            }");
                        sb.AppendLine("        }");
                        sb.AppendLine("    },");
                        if (string.Equals(detailsFields.FieldType, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) || string.Equals(detailsFields.FieldType, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                        {
                            sb.AppendLine("dataBound: function () {");
                            sb.AppendLine("    fnSyncCheckboxes(this);");
                            sb.AppendLine("    updateSelectAllState(this); // keep select all synced initially");
                            sb.AppendLine("},");
                            sb.AppendLine("change: function () {");
                            sb.AppendLine("    fnSyncCheckboxes(this);");
                            sb.AppendLine("    updateSelectAllState(this); // sync after every change");
                            sb.AppendLine("},");
                            sb.AppendLine("headerTemplate:");
                            sb.AppendLine("    \"<div class='select-all-wrapper'>\" +");
                            sb.AppendLine("    \"  <label><input type='checkbox' id='selectAllCheckbox' /> Select All</label>\" +");
                            sb.AppendLine("    \"</div>\",");
                            sb.AppendLine("");
                            sb.AppendLine($"itemTemplate: \"<label class='custom-checkbox-wrapper'> <input type='checkbox' class='custom-checkbox' value='#: id #' /> #: {textFieldLowerCase} # </label>\"");
                            sb.AppendLine("});");
                            sb.AppendLine("");
                            sb.AppendLine("$(document).on(\"change\", \"#selectAllCheckbox\", function () {");
                            sb.AppendLine($"    var multiSelect = $(\"#{fieldNameLowerCase}\").data(\"kendoMultiSelect\");");
                            sb.AppendLine("");
                            sb.AppendLine("    if (this.checked) {");
                            sb.AppendLine("        var allValues = multiSelect.dataSource.view().map(function (item) {");
                            sb.AppendLine("            return item.id;");
                            sb.AppendLine("        });");
                            sb.AppendLine("        multiSelect.value(allValues);");
                            sb.AppendLine("    } else {");
                            sb.AppendLine("        multiSelect.value([]);");
                            sb.AppendLine("    }");
                            sb.AppendLine("");
                            sb.AppendLine("    fnSyncCheckboxes(multiSelect);");
                            sb.AppendLine("    updateSelectAllState(multiSelect); // sync checkbox state");

                        }
                        else if (string.Equals(detailsFields.FieldType, FieldTypeEnums.Radiogroup.ToString(), StringComparison.OrdinalIgnoreCase))
                        {
                            sb.AppendLine("template:");
                            sb.AppendLine("    \"<label class='custom-radio-wrapper'>\" +");
                            sb.AppendLine($"    \" <input type='radio' name='ccRadio' value='#: id #' /> #: {textFieldLowerCase} #\" +");
                            sb.AppendLine("    \"</label>\",");
                            sb.AppendLine("dataBound: function () {");
                            sb.AppendLine("    updateRadios(this);");
                            sb.AppendLine("},");
                            sb.AppendLine("change: function () {");
                            sb.AppendLine("    updateRadios(this);");
                            sb.AppendLine("}");
                        }
                        sb.AppendLine("});");
                    }



                    // Child Dropdown (LastName) - Cascading based on selected StudentID
                    if (!string.IsNullOrEmpty(detailsFields?.ParentFieldName))
                    {
                        // var fieldNameLowerCase1 = char.ToLower(Detailsfields.FieldName.Trim()[0]) + Detailsfields.FieldName.Trim()[1..];
                        string fieldNameLower = !string.IsNullOrWhiteSpace(detailsFields.FieldName) && detailsFields.FieldName.Trim().Length > 1 ? char.ToLower(detailsFields.FieldName.Trim()[0]) + detailsFields.FieldName.Trim()[1..] : string.Empty;

                        var parentFieldNameLowerCase = char.ToLower(detailsFields.ParentFieldName.Trim()[0]) + detailsFields.ParentFieldName.Trim()[1..];

                        //var textFieldLowerCase1 = char.ToLower(Detailsfields.TextFieldName.Trim()[0]) + Detailsfields.TextFieldName.Trim()[1..];
                        string textFieldLowerCase1 = !string.IsNullOrWhiteSpace(detailsFields.TextFieldName) && detailsFields.TextFieldName.Trim().Length > 1 ? char.ToLower(detailsFields.TextFieldName.Trim()[0]) + detailsFields.TextFieldName.Trim()[1..] : string.Empty;

                        if (detailsFields.IsMultiColumn == true)
                        {
                            sb.AppendLine($"$('#{fieldNameLowerCase}').kendoMultiColumnComboBox({{");
                        }
                        else
                        {
                            sb.AppendLine($"$('#{fieldNameLowerCase}').kendoDropDownList({{");
                        }
                        sb.AppendLine("    optionLabel: '-- Select --',");
                        sb.AppendLine($"    dataTextField: '{textFieldLowerCase1}',");
                        sb.AppendLine("    dataValueField: 'id',");
                        sb.AppendLine($"        filter: '{detailsFields.FilterOption}',");
                        sb.AppendLine("    autoBind: false,");
                        sb.AppendLine("    enable: true,");
                        if (detailsFields.IsMultiColumn == true)
                        {
                            sb.AppendLine("    columns: [");
                            if (detailsFields.MultiColumnFieldNames != null && detailsFields.MultiColumnFieldNames.Count != 0)
                            {
                                for (int i = 0; i < detailsFields.MultiColumnFieldNames.Count; i++)
                                {
                                    var column = detailsFields.MultiColumnFieldNames[i];
                                    var comma = i < detailsFields.MultiColumnFieldNames.Count - 1 ? "," : "";
                                    //var trimmedFieldName = (column.SourceFieldName ?? "").TrimEnd();
                                    //var fieldNameCamelCase = char.ToLower(trimmedFieldName[0]) + trimmedFieldName[1..];
                                    var fieldNameCamelCase = !string.IsNullOrWhiteSpace(column.SourceFieldName) && column.SourceFieldName.Length > 1 ? column.SourceFieldName?.Trim().ToLower() : string.Empty;
                                    sb.AppendLine($"        {{ field: '{fieldNameCamelCase}', title: '{column.SourceFieldName}' }}{comma}");
                                }
                            }
                            sb.AppendLine("    ],");
                        }

                        sb.AppendLine("    dataSource: {");
                        sb.AppendLine($"   sort: {{ field: \"{textFieldLowerCase1}\", dir: 'asc' }},");
                        sb.AppendLine("        transport: {");
                        sb.AppendLine("            read: function (options) {");
                        sb.AppendLine("                var parentId = options.data.parentId;");
                        sb.AppendLine("                if (parentId) {");
                        sb.AppendLine("                    $.ajax({");
                        if (detailsFields.SourceTableName != null)
                        {
                            sb.AppendLine($"                        url: backendUrl + '/{(detailsFields.SourceTableName ?? "").ToLower()}/' + parentId,");
                        }
                        if (!string.IsNullOrEmpty(detailsFields.ParentFieldName) && detailsFields.ParentFieldName == detailsFields.SourceTableName)
                        {
                            sb.AppendLine($"                        url: backendUrl + '/{detailsFields?.TableName?.ToLower()}/' + parentId,");
                        }
                        sb.AppendLine("                        type: 'GET',");
                        sb.AppendLine("                        dataType: 'json',");
                        sb.AppendLine("                        success: function (response) {");
                        sb.AppendLine("                            if (!Array.isArray(response)) {");
                        sb.AppendLine("                                response = [response];");
                        sb.AppendLine("                            }");
                        sb.AppendLine("                            options.success(response);");
                        sb.AppendLine("                        },");
                        sb.AppendLine("                        error: function (jqXHR, textStatus, errorThrown) {");
                        sb.AppendLine("                            console.error('Error fetching data: ' + textStatus + ' ' + errorThrown);");
                        sb.AppendLine("                        }");
                        sb.AppendLine("                    });");
                        sb.AppendLine("                } else {");
                        sb.AppendLine("                    // No parent selected: clear dropdown");
                        sb.AppendLine("                    options.success([]);");
                        sb.AppendLine("                }");
                        sb.AppendLine("            }");
                        sb.AppendLine("        }");
                        sb.AppendLine("    }");
                        sb.AppendLine("});");

                        // Add change event on the Parent dropdown (StudentID)
                        sb.AppendLine($"$('#{parentFieldNameLowerCase}').bind('change', function(e) {{");
                        sb.AppendLine($"        var selectedValue = $('#{parentFieldNameLowerCase}').val();");
                        if (detailsFields?.IsMultiColumn == true)
                        {
                            sb.AppendLine($"        var childDropDown = $('#{fieldNameLower}').data('kendoMultiColumnComboBox');");
                        }
                        else
                        {
                            sb.AppendLine($"        var childDropDown = $('#{fieldNameLower}').data('kendoDropDownList');");
                        }
                        sb.AppendLine("        if (selectedValue) {");
                        sb.AppendLine("            if (childDropDown) {");
                        //  sb.AppendLine("                childDropDown.enable(true);");       commented code due to enable  dd  so that it not desabled but  show no data
                        sb.AppendLine("                childDropDown.dataSource.read({ parentId: selectedValue });");
                        sb.AppendLine("            }");
                        sb.AppendLine("        } else {");
                        sb.AppendLine("            if (childDropDown) {");
                        // sb.AppendLine("                childDropDown.enable(false);");  commented code due to enable  dd  so that it not desabled but  show no data
                        sb.AppendLine("                childDropDown.value('');");
                        sb.AppendLine("                childDropDown.dataSource.data([]);");  // Clear the data
                        sb.AppendLine("                childDropDown.text('');");  // Clear the text
                        sb.AppendLine($"            $('#{fieldNameLower}').trigger('change');");
                        sb.AppendLine("            }");
                        sb.AppendLine("        }");
                        sb.AppendLine("});");
                    }
                }
            }

            return sb.ToString();
        }

    }
}
