﻿using System.Text;
using System.Data;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;


namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateFormActionsClass
    {
        public  void GenerateFormActions(ClientTable table, string projectName, string clientName, IEnumerable<ClientForm> forms, IEnumerable<ClientForm> formList)
        {
            var sb = new StringBuilder();

            sb.AppendLine("using Microsoft.AspNetCore.Mvc;");
            sb.AppendLine();
            sb.AppendLine($"namespace DynamicFormBuilder_UI.Controllers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class {table.Name}Controller : Controller");
            sb.AppendLine("    {");

            // Get all form IDs from formList
            var formIdsInList = formList.Select(f => f.ID).ToHashSet();

            // Filter only parent forms from formList
            var parentForms = formList.Where(f => f.ParentId == null).ToList();

            // If no parent, treat any form without its parent in list as a root
            if (parentForms.Count == 0)
            {
                parentForms = formList
                    .Where(f => f.ParentId == null || !formIdsInList.Contains(f.ParentId.Value))
                    .ToList();
            }

            foreach (var parentForm in parentForms)
            {
                if (parentForm.IsMenuValid)
                {
                    var childForms = forms
                        .Where(f => f.HeaderFormId == parentForm.ID)
                        .ToList();
                    if (!string.IsNullOrWhiteSpace(parentForm.Name))
                    {
                        sb.AppendLine($"   {GenerateControllerMvcCode(parentForm.Name, childForms,table)}");
                    }                
                }
            }



            sb.AppendLine("    }");

            sb.AppendLine("}");
            // Output or save the generated code
            string projectfoldername = $@"{clientName}\{projectName}";

            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.MvcUI\Controllers";

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
            string filePath = "";



            filePath = Path.Combine(directoryPath, $"{table.Name}Controller.cs");


            // Create the file path (using the table name as the file name)
            //  string filePath = Path.Combine(directoryPath, $"{tableName}.cs");

            // Write the model code to the file
            File.WriteAllText(filePath, sb.ToString());
            Console.WriteLine(sb);
        }
        private static string GetCSharpType(string dbType)
        {
            dbType = (dbType ?? "").Trim().ToLower();
            return Enum.TryParse<PKTypeEnum>(dbType, true, out var type)
                ? type.GetDescription()
                : PKTypeEnum.Int.GetDescription();
        }
        private static string GenerateControllerMvcCode(string formName, List<ClientForm>? childForms, ClientTable table)
        {
            var returnType = GetCSharpType((table.PrimaryKeyType ?? "").Trim().ToLower());

            // Generate List Action

            var sb = new StringBuilder();

            sb.AppendLine($"        public IActionResult {formName}List()");
            sb.AppendLine("        {");
            sb.AppendLine("            return View();");
            sb.AppendLine("        }");
            sb.AppendLine();
            sb.AppendLine($"        public IActionResult {formName}Details()");
            sb.AppendLine("        {");
            sb.AppendLine("            return View();");
            sb.AppendLine("        }");
            sb.AppendLine();


            if (childForms?.Count > 0)
            {
                foreach (var form in childForms)
                {
                    sb.AppendLine($"        public IActionResult {form.Name}List1({returnType} id)");
                    sb.AppendLine("        {");
                    sb.AppendLine("            ViewBag.Id = id;");
                    sb.AppendLine("            return PartialView();");
                    sb.AppendLine("        }");
                    sb.AppendLine($"        public IActionResult {form.Name}Details1()");
                    sb.AppendLine("        {");
                    sb.AppendLine("            return View();");
                    sb.AppendLine("        }");
                }
                return sb.ToString();
            }
            return sb.ToString();
        }
    }
}
