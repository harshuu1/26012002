﻿using Dapper;
using DapperDB;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using Entities.Models.Table;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Reflection.Emit;
using System.Text;
using System.Text.RegularExpressions;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class ImagePreviewScript
    {
        public static void AppendImagePreviewScript(StringBuilder sb, string fieldNameLowerCase, string displayName, string tableName)
        {
            sb.AppendLine($"    var {fieldNameLowerCase}imageWindow;");
            sb.AppendLine($"    $('#{tableName}Grid').on('click', '.{fieldNameLowerCase}preview-btn', function (e) {{");
            sb.AppendLine("        e.preventDefault();");
            sb.AppendLine("        const imageData = $(this).data('image');");
            sb.AppendLine();
            sb.AppendLine("        if (!imageData) return;");
            sb.AppendLine();
            sb.AppendLine("        const base64Image = decodeURIComponent(imageData);");
            sb.AppendLine($"        {fieldNameLowerCase}showImagePreview(base64Image);");
            sb.AppendLine("    });");
            sb.AppendLine();
            sb.AppendLine($"    function {fieldNameLowerCase}showImagePreview(base64Image) {{");
            sb.AppendLine($"        if (!{fieldNameLowerCase}imageWindow) {{");
            sb.AppendLine($"            {fieldNameLowerCase}imageWindow = $(\"#{fieldNameLowerCase}imagePreviewWindow\").kendoWindow({{");
            sb.AppendLine("                width: \"100%\",");
            sb.AppendLine("                height: \"100%\",");
            sb.AppendLine("                modal: true,");
            sb.AppendLine("                visible: false,");
            sb.AppendLine("                actions: [\"Maximize\", \"Close\"],");
            sb.AppendLine("                resizable: false,");
            sb.AppendLine($"                title: \"{displayName} Preview\",");
            sb.AppendLine($"                activate: {fieldNameLowerCase}adjustImagePreviewWindow,");
            sb.AppendLine($"                maximize: {fieldNameLowerCase}adjustImagePreviewWindow,");
            sb.AppendLine($"                resize: {fieldNameLowerCase}adjustImagePreviewWindow");
            sb.AppendLine("            }).data(\"kendoWindow\");");
            sb.AppendLine("        }");
            sb.AppendLine();
            sb.AppendLine($"        $(\"#{fieldNameLowerCase}imagePreviewContent\").html(`");
            sb.AppendLine("            <div class=\"image-preview-wrapper\">");
            sb.AppendLine("                <img src=\"data:image/png;base64,${base64Image}\" alt=\"Image Preview\" class=\"kendo-default-image\" />");
            sb.AppendLine("            </div>");
            sb.AppendLine("        `);");
            sb.AppendLine();
            sb.AppendLine($"        {fieldNameLowerCase}imageWindow.center().open();");
            sb.AppendLine($"        {fieldNameLowerCase}adjustImagePreviewWindow();");
            sb.AppendLine("    }");
            sb.AppendLine();
            sb.AppendLine($"    function {fieldNameLowerCase}adjustImagePreviewWindow() {{");
            sb.AppendLine($"        const $win = $(\"#{fieldNameLowerCase}imagePreviewWindow\").closest(\".k-window\"),");
            sb.AppendLine($"              $content = $(\"#{fieldNameLowerCase}imagePreviewContent\"),");
            sb.AppendLine("              isMax = $win.hasClass(\"k-window-maximized\");");
            sb.AppendLine("        if (isMax) {");
            sb.AppendLine("            const h = $(window).height();");
            sb.AppendLine("            $content.css({");
            sb.AppendLine("                maxHeight: (h - 90) + \"px\",");
            sb.AppendLine("                overflowY: \"auto\"");
            sb.AppendLine("            });");
            sb.AppendLine("        } else {");
            sb.AppendLine("            $content.css({");
            sb.AppendLine("                maxHeight: \"auto\",");
            sb.AppendLine("                overflow: \"hidden\",");
            sb.AppendLine("                height: \"100%\"");
            sb.AppendLine("            });");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
        }
    }

    public class GenerateListingWithSearchAndGridClass(DapperDbContext.DbContext context, IConfiguration configuration)
    {
        private readonly DapperDbContext.DbContext _context = context;


        private readonly IConfiguration _configuration = configuration;

        public async Task<TableModel?> GetTableData(int? id, string configConnectionString)
        {
            try
            {
                //string? originalConnectionString = _configuration.GetConnectionString("DefaultConnection");

                using var connection = new SqlConnection(configConnectionString); // Use directly here
                await connection.OpenAsync();

                var result = await connection.QuerySingleOrDefaultAsync<TableModel>(
                    "SELECT * FROM TableDefination WHERE ID=@id", new { id });

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public async Task<bool> IsCascadingFieldAsync(int fieldId, int formId, string configConnectionString)
        {
            string query = $@"
        SELECT COUNT(*)
        FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination AS f
        WHERE f.ParentFieldId = @FieldId
          AND f.TableId = (
              SELECT TOP 1 TableId FROM [{DatabaseSchema.Config.ToSchemaName()}].Form WHERE Id = @FormId
          )"
            ;

            //string? originalConnectionString = _configuration.GetConnectionString("DefaultConnection");

            using SqlConnection connection = new(configConnectionString);
            SqlCommand command = new(query, connection);
            command.Parameters.AddWithValue("@FieldId", fieldId);
            command.Parameters.AddWithValue("@FormId", formId);

            await connection.OpenAsync();
            object? result = await command.ExecuteScalarAsync();
            int count = Convert.ToInt32(result);
            //int count = (int)await command.ExecuteScalarAsync();
            return count > 0;
        }

        public static string GetLabelClass(int AlignmentType)
        {
            switch (AlignmentType)
            {
                case 1: return "label-left";
                case 2: return "label-top";
                //case 3: return "floating-label";
                default: return "";
            }
        }


        public async void GenerateListingWithSearchAndGrid(string tableName, bool isHierarchical, bool isAddToList, bool isBarcodePrinting, string projectName, string clientName, List<ClientSearchField> fields, List<ClientDisplayField> displayfields, List<ClientSearchField> childSearchListByParentId, List<ClientCardViewFields> detailFields, int alignmentType, string configConnectionString, int searchParent)
        
        {
            string cssClass = GetLabelClass(alignmentType);
            var sb = new StringBuilder();


            sb.AppendLine("<style>");
            sb.AppendLine("    .k-expander { background-color: white; border-radius: 10px; }");
            /*slider css start*/
            sb.AppendLine("    .slider_search{height: 46px;} .k-slider-horizontal {width: 100% !important;}");
            sb.AppendLine("</style>");

            //TODO : Need to Set Search Expansion Panel Id as Dynamic Base on FormName
            //sb.AppendLine("<div id='siteListPanel'>");
            //sb.AppendLine("<div class='mt-4 main-section w-100 mb-4'>");
            //sb.AppendLine("<div class='row'>");

            //foreach (var field in fields)
            //{
            //    var fieldName = (field.FieldName ?? "").Trim();
            //    var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];

            //    sb.AppendLine("<div class='col-lg-4 d-flex'>");

            //    if (field.FieldType != "dropdown" && field.FieldType != "switches")
            //    {
            //        sb.AppendLine($"<div class='form-group {cssClass} mb-3 me-2' style='width: 40%;'>");
            //        sb.AppendLine($"<select class='form-control1' id='{fieldNameLowerCase}Criteria' name='{fieldNameLowerCase}Criteria'></select>");

            //        if (cssClass == "label-top" || cssClass == "label-bottom")
            //        {
            //            sb.AppendLine($"<label for='{fieldNameLowerCase}' class='form-label1'>&nbsp;</label>");
            //        }

            //        sb.AppendLine("</div>");
            //    }
            //    sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 60%;'>");

            //    switch ((field.FieldType ?? "").ToLower())
            //    {
            //        case "int":
            //            sb.AppendLine($"<input type='number' class='form-control1' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' />");
            //            break;
            //        case "varchar":
            //        case "nvarchar":
            //            sb.AppendLine($"<input type='text' class='form-control1' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' />");
            //            break;
            //        case "decimal":
            //        case "float":
            //            sb.AppendLine($"<input type='number' step='0.01' class='form-control1' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' />");
            //            break;
            //        case "date":
            //            sb.AppendLine($"<input type='date' class='form-control1 datepicker' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' />");
            //            break;
            //        case "datetime":
            //            sb.AppendLine($"<input type='datetime-local' class='form-control1 datetimepicker' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' />");
            //            break;
            //        case "bit":
            //        case "boolean":
            //            sb.AppendLine($"<input type='checkbox' class='form-control1' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' />");
            //            break;
            //        case "dropdown":
            //            sb.AppendLine($"<input class='form-control1' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' />");
            //            break;
            //        default:
            //            sb.AppendLine($"<input type='text' class='form-control1' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' />");
            //            break;
            //    }

            //    sb.AppendLine($"<label for='{fieldNameLowerCase}' class='form-label1'>{(field.DisplayName ?? "").Trim()}</label>");
            //    sb.AppendLine("</div>");
            //    sb.AppendLine("</div>");
            //}

           // foreach (var field in fields)
           // {
           //     var fieldName = (field.FieldName ?? "").Trim();
           //     var alignmentClass = GetLabelClass(alignmentType);
           //     var rowlabel = $"<div class=\"col-md-4\">";
           //     var rowcontrol = $"<div class=\"col-md-8\">";
           //     var rowend = $"</div>";
           //     var defaultValue = !string.IsNullOrWhiteSpace(field.DefaultValue)
           //        ? $" value='{System.Net.WebUtility.HtmlEncode(field.DefaultValue)}'"
           //        : string.Empty;

           //     var isChecked = string.Equals(field.DefaultValue?.Trim(), "1", StringComparison.OrdinalIgnoreCase)
           //|| string.Equals(field.DefaultValue?.Trim(), "true", StringComparison.OrdinalIgnoreCase);

           //     var checkedAttr = isChecked ? " checked" : string.Empty;




           //     //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
           //     var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
           //     if (!Enum.TryParse<FieldTypeEnums>(field.FieldType, true, out var fieldType))
           //     {
           //         continue; // Skip unknown / unmapped types
           //     }
           //     sb.AppendLine("<div class='col-lg-4 d-flex'>");

           //     if (fieldType != FieldTypeEnums.DropDown && fieldType != FieldTypeEnums.Switches && fieldType != FieldTypeEnums.Checkboxgroup && fieldType != FieldTypeEnums.Radiogroup && fieldType != FieldTypeEnums.Multiselect && fieldType != FieldTypeEnums.Slider && fieldType != FieldTypeEnums.Colorpicker && fieldType != FieldTypeEnums.Bit)
           //     {
           //         sb.AppendLine($"<div class='form-group {cssClass} mb-3 me-2' style='width: 30%;'>");
           //         sb.AppendLine($"<select class='inputcontrol' id='{fieldNameLowerCase}Criteria' name='{fieldNameLowerCase}Criteria'></select>");

           //         if (cssClass == "label-top" || cssClass == "label-bottom")
           //         {
           //             sb.AppendLine($"<label for='{fieldNameLowerCase}' class='form-label-text'>&nbsp;</label>");
           //         }

           //         sb.AppendLine("</div>");
           //     }
           //     else if (fieldType == FieldTypeEnums.Slider || fieldType == FieldTypeEnums.Bit || fieldType == FieldTypeEnums.Switches)
           //     {
           //         if (fieldType == FieldTypeEnums.Switches)
           //          {
           //              sb.AppendLine("        <label  class='custom-label mt-2' style='width: 46%;'>");
           //          }
           //          else
           //          {
           //              sb.AppendLine("        <label  class='custom-label mt-2' style='width: 32%;'>");
           //          }
           //         sb.AppendLine($"            <input type='checkbox' id='isfilter_{fieldNameLowerCase}' class='form-check-input' style='padding:2px;'>");
           //         sb.AppendLine("            In Filter");
           //         sb.AppendLine("        </label>");

           //     }

           //     if (cssClass == "label-top")
           //     {
           //         if (fieldType != FieldTypeEnums.DropDown && fieldType != FieldTypeEnums.Switches && fieldType != FieldTypeEnums.Checkboxgroup && fieldType != FieldTypeEnums.Radiogroup && fieldType != FieldTypeEnums.Multiselect && fieldType != FieldTypeEnums.Slider && fieldType != FieldTypeEnums.Colorpicker && fieldType != FieldTypeEnums.Datetime && fieldType != FieldTypeEnums.Bit)
           //         {

           //             sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 68%;bottom: 29px;'>");
           //         }
           //         else if (fieldType == FieldTypeEnums.Datetime)
           //         {
           //             sb.AppendLine($"<div class='form-group {cssClass} mb-3 {fieldNameLowerCase}' style='width: 68%; bottom:29px; height:20px'>");
           //         }
           //         else if (fieldType == FieldTypeEnums.Slider || fieldType == FieldTypeEnums.Rangeslider)
           //         {
           //             sb.AppendLine($" <div class='form-group {cssClass} mb-3 slider_search' style='width: 70%;bottom: 30px;'>");
           //         }
           //         else if (fieldType == FieldTypeEnums.Bit)
           //         {
           //             sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 68%;bottom: 22px;'>");
           //         }
           //         else
           //         {
           //             sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 100%;bottom: 32px;'>");
           //         }
           //     }
           //     else
           //     {
           //         if (fieldType != FieldTypeEnums.DropDown && fieldType != FieldTypeEnums.Switches && fieldType != FieldTypeEnums.Checkboxgroup && fieldType != FieldTypeEnums.Multiselect && fieldType != FieldTypeEnums.Radiogroup && fieldType != FieldTypeEnums.Slider && fieldType != FieldTypeEnums.Colorpicker && fieldType != FieldTypeEnums.Datetime)
           //         {

           //             sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 68%;'>");
           //         }
           //         else if(fieldType == FieldTypeEnums.Datetime)
           //         {
           //             sb.AppendLine($"<div class='form-group {cssClass} mb-3 {fieldNameLowerCase}' style='width: 68%;'>");
           //         }
           //         else if (fieldType == FieldTypeEnums.Slider || fieldType == FieldTypeEnums.Rangeslider)
           //         {
           //             sb.AppendLine($" <div class='form-group {cssClass} mb-3 slider_search' style='width: 70%;'>");
           //         }
           //         else
           //         {
           //             sb.AppendLine($"<div class='form-group {cssClass} mb-3' style='width: 100%;'>");
           //         }
           //     }
           //     var labeldiv = $"<label for='{fieldNameLowerCase}' class='form-label-text'>{(field.DisplayName ?? "").Trim()}</label>";
           //     if (alignmentClass == "label-left")
           //     {  
           //         sb.AppendLine(rowlabel);
           //         sb.AppendLine(labeldiv);
           //         sb.AppendLine(rowend);                    
           //         sb.AppendLine(rowcontrol);
           //     }
           //     else
           //     {
           //         sb.AppendLine(labeldiv);
                   
           //     }
           //     //  sb.AppendLine($"<label for='{fieldNameLowerCase}' class='form-label-text'>{(field.DisplayName ?? "").Trim()}</label>");

           //     switch (fieldType)
           //     {
           //         case FieldTypeEnums.Int:
           //             sb.AppendLine($"<input type='number' class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' {defaultValue}/>");
           //             break;

           //         case FieldTypeEnums.Varchar:
           //         case FieldTypeEnums.Nvarchar:
           //             sb.AppendLine($"<input type='text' class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' {defaultValue}/>");
           //             break;

           //         case FieldTypeEnums.Decimal:
           //         case FieldTypeEnums.Float:
           //             sb.AppendLine($"<input type='number' step='0.01' class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' {defaultValue}/>");
           //             break;

                    //case FieldTypeEnums.Date:
                    //    sb.AppendLine($"<input type='date' class='inputcontrol datepicker {fieldNameLowerCase}' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}'/>");
                    //    if (alignmentClass == "label-left")
                    //    {
                    //        sb.AppendLine($" <div id=\"{fieldNameLowerCase}Picker\" style=\"bottom:0%\"></div>");
                    //    }
                    //    else
                    //    {
                    //        sb.AppendLine($" <div id=\"{fieldNameLowerCase}Picker\" style=\"position:absolute; bottom:0%; width:158%\"></div>");
                    //    }
                    //    break;

                    //case FieldTypeEnums.Datetime:
                    //    sb.AppendLine($"<input type='datetime-local' class='inputcontrol datetimepicker' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}'/>");
                    //    break;

           //         case FieldTypeEnums.Bit:
           //         case FieldTypeEnums.Switches:

           //             sb.AppendLine($"<input type='checkbox' class='form-check-input' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}'  {checkedAttr} />");
           //             break;

                    //case FieldTypeEnums.Timeduration:
                    //    sb.AppendLine("<div class=\"kendo-timer-wrapper\" style=\"width:100%\">");
                    //    sb.AppendLine($"<input class='form-control1' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}'/>");
                    //    sb.AppendLine("</div>");
                    //    break;

           //         case FieldTypeEnums.DropDown:
           //             sb.AppendLine($"<input class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}' {defaultValue} />");
           //             break;

           //         default:
           //             sb.AppendLine($"<input type='text' class='inputcontrol' id='{fieldNameLowerCase}' name='{fieldNameLowerCase}'  {defaultValue} />");
           //             break;
           //     }
           //     if (alignmentClass == "label-left")
           //     {
           //         sb.AppendLine(rowend); // Close col-md-10                    
           //     }
           //     sb.AppendLine("</div>"); // close form-group
           //     sb.AppendLine("</div>"); // close col-lg-4 d-flex


           // }


            //sb.AppendLine("</div>");
            //sb.AppendLine("<div class='form-submit text-end mt-2 mb-2'>");
            //sb.AppendLine("<button type='button' id='search' class='btn btn-primary me-2 text-white' onclick=\"applySearchFilter()\">");
            //sb.AppendLine("<i class='k-icon k-font-icon k-i-search'></i> Search</button>");
            //sb.AppendLine($"<button type='button' id='clear' class='btn btn-primary text-white' onclick=\"clearSearch({tableName}Grid)\">");
            //sb.AppendLine("<i class='k-icon k-font-icon k-i-cancel'></i> Clear</button>");
            //sb.AppendLine("</div>");
            //sb.AppendLine("</div>");
            //sb.AppendLine("</div>");


            //sb.AppendLine("<script>");
            //sb.AppendLine("$(document).ready(function () {");
            //sb.AppendLine("  $('#siteListPanel').kendoExpansionPanel({ title: 'Search Criteria', expanded: true });");
            //sb.AppendLine("  $('#search').kendoButton({ icon: 'search', themeColor: 'primary', rounded: 'medium' });");
            //sb.AppendLine("  $('#clear').kendoButton({ icon: 'cancel', themeColor: 'primary', rounded: 'medium' });");
            //sb.AppendLine("});");
            //sb.AppendLine("</script>");


            var ListLableName = displayfields.Select(list => list.ListLabel ?? "").FirstOrDefault();

            var parentLessFields = fields.Where(x => x.ParentId == null || x.ParentId == 0).ToList();

            var searchPanelHtml = SearchCriteriaHelper.RenderSearchPanel(
                tableName,
                parentLessFields,
                cssClass,
                showButtons: false,
                alignmentType
            );

            var parentFormId = parentLessFields.Select(x => x.FormId).Distinct().FirstOrDefault();

            sb.AppendLine(searchPanelHtml);

            if (childSearchListByParentId != null && childSearchListByParentId.Any())
            {
                // Get unique child forms for this parent
                var uniqueChildForms = childSearchListByParentId
                    .GroupBy(c => new { c.FormName, c.TableName, c.FormId })
                    .Select(g => g.First())
                    .ToList();

                foreach (var childForm in uniqueChildForms)
                {
                    // Filter fields for THIS child form only
                    var fieldsForForm = childSearchListByParentId
                    .Where(f => f.FormName == childForm.FormName && f.TableName == childForm.TableName && f.FormId == searchParent)
                    .ToList();


                    if (!fieldsForForm.Any())
                        continue;

                    if (childForm != null)
                    {
                        var childPanelHtml = SearchCriteriaHelper.RenderSearchPanel(
                        childForm.SearchProfileName ?? string.Empty,
                        //Enumerable.Empty<ClientSearchField>(), // no parent fields
                        fieldsForForm,                          // child fields
                        cssClass,
                        showButtons: false,
                        alignmentType
                    );

                        sb.AppendLine(childPanelHtml);
                    }
                }
            }

            // Step 3: New User Button Section
            HashSet<string> processedFormNames = [];

            foreach (var field in detailFields)
            {
                if (processedFormNames.Add(field.FormName ?? ""))
                {
                    sb.AppendLine("<div class=\"listsection\">");
                    sb.AppendLine($"    <h4 style='font-weight:bold; font-size:28px;align-content:center;margin-bottom:20px;'>{ListLableName}</h4>");
                    if (isAddToList)
                    {
                        sb.AppendLine(" <div id=\"example\">");
                        sb.AppendLine("     <div class=\"demo-section\">");
                        sb.AppendLine("         <div id=\"tabstrip\">");                      
                        sb.AppendLine("             <ul>");
                        sb.AppendLine("                 <li class=\"k-active\">Summary</li>");
                        sb.AppendLine("                 <li>List</li>");
                        sb.AppendLine("             </ul>");
                        sb.AppendLine("             <div>");
                    }
                    sb.AppendLine(" <div id=\"errorMessageContainer\" style=\"display: none; margin-top: 15px; margin-bottom: 15px;\"></div>");
                    sb.AppendLine("<div class=\"d-flex justify-content-between mb-2\">");
                    //sb.AppendLine($" <h4 class=\"text-primary my-1 p-\">{tableName}List</h4>");
                    //   < h4 class="text-primary my-1 p-1">SiteList</h4>
                    sb.AppendLine("<div>");
                    sb.AppendLine("<button type='button' id='textButton'" +
                        " class='btn btn-primary me-2 text-white' onclick=\"location.href='/" + tableName + "/" + field.FormName + "Details'\">");
                    sb.AppendLine("<i class='k-icon k-font-icon k-i-plus'></i> New</button>");
                    if (isAddToList)
                    {
                        sb.AppendLine("<button type='button' id='addToListBtn' class='btn btn-primary me-2 text-white addtoListButton' \">");
                        sb.AppendLine("<i class='k-icon k-font-icon k-i-plus'></i><span>Add to List</span></button>");
                    }
                    sb.AppendLine("</div>");
                    if (parentLessFields.Any() || childSearchListByParentId.Any())
                    {
                        sb.AppendLine("<div>");
                        sb.AppendLine("    <button type=\"button\" class=\"btn btn-primary me-2 text-white Search\" onclick=\"applyGlobalSearch()\">");
                        sb.AppendLine("        <i class=\"k-icon k-font-icon k-i-search\"></i> Search");
                        sb.AppendLine("    </button>");
                        sb.AppendLine($"    <button type=\"button\" class=\"btn btn-primary text-white Search\" onclick=\"clearSearch({tableName}Grid)\">");
                        sb.AppendLine("        <i class=\"k-icon k-font-icon k-i-cancel\"></i> Clear");
                        sb.AppendLine("    </button>");
                        sb.AppendLine("</div>");
                    }
                    

                    sb.AppendLine("</div>");
                }
            }

            // Step 4: Kendo Grid/TreeView Section         
            sb.AppendLine($"<div id='{tableName}Grid' class='card p-4 rounded'></div>");
            if (isAddToList)
            {
                sb.AppendLine("</div>");
                sb.AppendLine("          <div>");
                sb.AppendLine("              <div id=\"List\" class=\"p-3\">");
                sb.AppendLine("                  <div>");
                sb.AppendLine("                      <div id=\"SelectedGrid\" class=\"card p-4 rounded\"></div>");
                sb.AppendLine("                  </div>");
                sb.AppendLine("              </div>");
                sb.AppendLine("          </div>");
                sb.AppendLine("      </div>");
                sb.AppendLine("  </div>");
            }
            sb.AppendLine("<span id='fnShowNotification'></span>");
            foreach (var field in displayfields)
            {
                var fieldName = (field.FieldName ?? "").Trim();
                //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                if (field.TypeId?.ToLower() == "richtexteditor")
                {
                    sb.AppendLine($"  <div id=\"{fieldNameLowerCase}richTextPreviewWindow\"class=\"preview-content\" style=\"display:none;\">");
                    sb.AppendLine($"  <div id=\"{fieldNameLowerCase}richTextPreviewContent\"class=\"preview-content\" style=\"padding: 10px; overflow-x: visible;\"></div>");
                    sb.AppendLine("  </div>");
                }
            


              else if (field.TypeId?.ToLower() == "image")
            {
                sb.AppendLine($"  <div id=\"{fieldNameLowerCase}imagePreviewWindow\"class=\"preview-content\" style=\"display:none;\">");
                sb.AppendLine($"  <div id=\"{fieldNameLowerCase}imagePreviewContent\"class=\"preview-content\" style=\"padding: 10px; overflow-x: visible;\"></div>");
                sb.AppendLine("  </div>");
            }
            }
            sb.AppendLine("</div>");
            if (isAddToList)
            {
                sb.AppendLine("</div>");
            }

            // Step 5: JavaScript block for Kendo UI Grid and Search functionality
            sb.AppendLine("<script>");
            sb.AppendLine($"var isHierarchical = {(isHierarchical ? "true" : "false")};");
            sb.AppendLine($"var backendUrl = '@ViewData[\"BackendUrl\"]';");

            sb.AppendLine($"  $('#{tableName}Panel').kendoExpansionPanel({{ title: '{tableName} Search Criteria', expanded: true }});");

            var uniqueChildForm = (childSearchListByParentId ?? new List<ClientSearchField>())
             .Where(x => x.FormId == searchParent)
             .GroupBy(x => new { x.FormName, x.TableName, x.FormId, x.TableId })
             .Select(g => g.First())
             .ToList();

            foreach (var childSearch in uniqueChildForm)
            {
                sb.AppendLine($"$('#{childSearch.SearchProfileName}Panel').kendoExpansionPanel({{ title: \"{childSearch.TableName} Search Criteria\", expanded: false }});");
            }

            if (childSearchListByParentId != null && childSearchListByParentId.Any())
            {
                // Get unique child forms for this parent
                var uniqueChildForms = childSearchListByParentId
                    .GroupBy(c => new { c.FormName, c.TableName, c.FormId })
                    .Select(g => g.First())
                    .ToList();

                foreach (var childForm in uniqueChildForms)
                {
                    // Filter fields for THIS child form only
                    var fieldsForForm = childSearchListByParentId
                    .Where(f => f.FormName == childForm.FormName && f.TableName == childForm.TableName && f.FormId == searchParent)
                    .ToList();

                    if (!fieldsForForm.Any())
                        continue;


                    var detailSearch = await SearchCriteriaHelper.GenerateFieldScriptsAsync(fieldsForForm, configConnectionString,alignmentType);
                    sb.AppendLine(detailSearch);

                }

            }

            if (isAddToList)
            {
                sb.AppendLine("   var tabStrip = $(\"#tabstrip\").kendoTabStrip({");
                sb.AppendLine("    animation: {");
                sb.AppendLine("        open: { effects: \"fadeIn\" }");
                sb.AppendLine("    },");
                sb.AppendLine("    activate: function (e) {");
                sb.AppendLine("        const tabText = $.trim($(e.item).text());");
                sb.AppendLine("        const urlParams = new URLSearchParams(window.location.search);");
                sb.AppendLine("        urlParams.set('tab', tabText);");
                sb.AppendLine("        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;");
                sb.AppendLine("        window.history.replaceState(null, '', newUrl);");
                sb.AppendLine("    }");
                sb.AppendLine("   }).data(\"kendoTabStrip\");");

                sb.AppendLine("   function disableTabWithClear(tabIndex) {");
                sb.AppendLine("    $.ajax({");
                sb.AppendLine($"        url: backendUrl + '/{tableName.ToLower()}/clearlist',");
                sb.AppendLine("        method: 'DELETE',");
                sb.AppendLine("        success: function (response) {");
               // sb.AppendLine("            //showNotification(\"success\", response);");
                sb.AppendLine("            tabStrip.enable(tabStrip.tabGroup.children().eq(tabIndex), false);");
                sb.AppendLine("        },");
                sb.AppendLine("        error: function () {");
                sb.AppendLine("            fnShowNotification(\"Failed to clear list\",\"error\");");
                sb.AppendLine("        }");
                sb.AppendLine("    });");
                sb.AppendLine("  }");

                // disable 2nd tab (index 1) and clear records
                sb.AppendLine("  disableTabWithClear(1);");

                sb.AppendLine("  const tabParam = new URLSearchParams(window.location.search).get('tab');");
                sb.AppendLine("  if (tabParam) {");
                sb.AppendLine("    const tabIndex = $(\"#tabstrip ul li\").filter(function () {");
                sb.AppendLine("        return $.trim($(this).text()) === tabParam;");
                sb.AppendLine("    }).index();");
                sb.AppendLine("    if (tabIndex >= 0) {");
                sb.AppendLine("        tabStrip.select(tabIndex);");
                sb.AppendLine("    }");
                sb.AppendLine("  }");
                sb.AppendLine("");

                sb.AppendLine("  var selectedDataMap = {}; // { id: dataItem }");
                sb.AppendLine("  var allSelected = false;");
                sb.AppendLine("");

                var kendoWidgetType = isHierarchical ? "kendoTreeList" : "kendoGrid";
                // Row checkbox change
                sb.AppendLine("  $(document).on(\"change\", \".rowCheckbox\", function () {");
                sb.AppendLine("    var id = $(this).data(\"id\");");
                sb.AppendLine($"    var {tableName}Grid = $(\"#{tableName}Grid\").data(\"{kendoWidgetType}\");");
                sb.AppendLine($"    var dataItem = {tableName}Grid.dataSource.get(id);");
                sb.AppendLine("");
                sb.AppendLine("    if ($(this).is(\":checked\")) {");
                sb.AppendLine("        if (dataItem) {");
                sb.AppendLine("            selectedDataMap[id] = dataItem.toJSON();");
                sb.AppendLine("        }");
                sb.AppendLine("    } else {");
                sb.AppendLine("        delete selectedDataMap[id];");
                sb.AppendLine("        allSelected = false; // cancel global select");
                sb.AppendLine("        $(\"#selectAll\").prop(\"checked\", false);");
                sb.AppendLine("    }");
                sb.AppendLine("  });");
                sb.AppendLine("");

                sb.AppendLine("  $(document).on(\"change\", \"#selectAll\", function () {");
                sb.AppendLine("    var isChecked = $(this).is(\":checked\");");
                sb.AppendLine($"    var {tableName}Grid = $(\"#{tableName}Grid\").data(\"{kendoWidgetType}\");");
                sb.AppendLine("    if (isChecked) {");
              
                sb.AppendLine($"        {tableName}Grid.dataSource.view().forEach(function (item) {{ ");
                sb.AppendLine("            selectedDataMap[item.id] = item.toJSON();");
                sb.AppendLine("        });");
                sb.AppendLine("        $(\".rowCheckbox\").prop(\"checked\", true);");
               // sb.AppendLine("       // console.log(\"Selected current page items. Total selected:\", Object.keys(selectedDataMap).length);");
                sb.AppendLine("    } else {");
              
                sb.AppendLine($"        {tableName}Grid.dataSource.view().forEach(function (item) {{ ");
                sb.AppendLine("            delete selectedDataMap[item.id];");
                sb.AppendLine("        });");
                sb.AppendLine("        $(\".rowCheckbox\").prop(\"checked\", false);");
               // sb.AppendLine("       // console.log(\"Deselected current page items. Total selected:\", Object.keys(selectedDataMap).length);");
                sb.AppendLine("    }");
               
                sb.AppendLine("  });");
                sb.AppendLine("");

                sb.AppendLine("   $(\"#addToListBtn\").on(\"click\", function () {");
                sb.AppendLine("    var selectedRows = Object.values(selectedDataMap);");
                sb.AppendLine("");
                sb.AppendLine("    if (selectedRows.length === 0) {");
                sb.AppendLine("        fnShowNotification(\"Please select at least one row.\",\"error\");");
                sb.AppendLine("        return;");
                sb.AppendLine("    }");
                sb.AppendLine("");
               
                sb.AppendLine($"    var {tableName}Ids = selectedRows.map(function(row) {{");
                sb.AppendLine("        return row.ID || row.id;");
                sb.AppendLine("    });");
                sb.AppendLine("");

                //sb.AppendLine("    $(this).prop(\"disabled\", true).text(\"Adding...\");");
                sb.AppendLine("     $(this).prop(\"disabled\", true).find(\"span\").text(\"Adding...\");");
                sb.AppendLine("");
              
                sb.AppendLine("    $.ajax({");
                sb.AppendLine($"        url: backendUrl + '/{tableName.ToLower()}/addtolist',");
                sb.AppendLine("        method: 'POST',");
                sb.AppendLine("        contentType: 'application/json',");
                sb.AppendLine("        data: JSON.stringify({");
                sb.AppendLine($"            {tableName}Ids: {tableName}Ids");
                sb.AppendLine("        }),");
                sb.AppendLine("        success: function(response) {");
                sb.AppendLine($"            console.log(\"{tableName}s added to database:\", response);");
                //sb.AppendLine($"            showNotification(\"success\", response.Message || \"{tableName}s added to list successfully\");");
                sb.AppendLine("             if (response.includes(\"already exist\")) {");
                sb.AppendLine("                fnShowNotification(response,\"success\");");
                sb.AppendLine("              } else {");
                sb.AppendLine("                fnShowNotification(response,\"success\");");
                sb.AppendLine("              }");
                sb.AppendLine("");
                sb.AppendLine("            selectedDataMap = {};");
                sb.AppendLine("            $(\".rowCheckbox\").prop(\"checked\", false);");
                sb.AppendLine("            $(\"#selectAll\").prop(\"checked\", false);");
                sb.AppendLine("");
              
                sb.AppendLine("            loadListFromDatabase();");
                sb.AppendLine("");
               
                sb.AppendLine("            var tabStrip = $(\"#tabstrip\").data(\"kendoTabStrip\");");
                sb.AppendLine("            tabStrip.enable(tabStrip.tabGroup.children().eq(1), true);");
                sb.AppendLine("            tabStrip.select(1);");
                sb.AppendLine("        },");
                sb.AppendLine("        error: function(xhr, status, error) {");
               // sb.AppendLine("            //console.error(\"Error adding to list:\", error);");
                sb.AppendLine($"            fnShowNotification(\"Failed to add {tableName}s to list: \" + (xhr.responseText || error),\"error\");");
                sb.AppendLine("        },");
                sb.AppendLine("        complete: function() {");
                // sb.AppendLine("            $(\"#addToListBtn\").prop(\"disabled\", false).text(\"Add to List\");");
                sb.AppendLine("            $(\"#addToListBtn\").prop(\"disabled\", false).find(\"span\").text(\"Add to List\");\r\n");
                sb.AppendLine("        }");
                sb.AppendLine("    });");
                sb.AppendLine("});");
                sb.AppendLine("");

                sb.AppendLine(" let selecteditems = [];");
                sb.AppendLine("// Function to load list data from database");
                sb.AppendLine("function loadListFromDatabase() {");
                sb.AppendLine("    $.ajax({");
                sb.AppendLine($"        url: backendUrl + '/{tableName.ToLower()}/selected{tableName.ToLower()}s',");
                sb.AppendLine("        method: 'GET',");
                sb.AppendLine("        success: function(data) {");
                sb.AppendLine("        selecteditems = data;");
                sb.AppendLine("            $(\"#List\").empty();");
                sb.AppendLine("");
                if (isBarcodePrinting)
                {
                  
                    sb.AppendLine("            var buttonHtml = `");
                    sb.AppendLine("                <div class=\"mb-2\">");
                    sb.AppendLine("                    <button type=\"button\" id=\"printBarcodeBtn\" class=\"btn btn-secondary me-2 text-white addtoListButton\">");
                    sb.AppendLine("                        <i class=\"k-icon k-font-icon k-i-print\"></i> Print Barcode");
                    sb.AppendLine("                    </button>");
                    sb.AppendLine("                </div>`;");
                    sb.AppendLine("            $(\"#List\").append(buttonHtml);");
                }

                sb.AppendLine("            var listGrid = $('<div id=\"ListGrid\"></div>');");
                sb.AppendLine("            $(\"#List\").append(listGrid);");
                sb.AppendLine("");

               
                if (isHierarchical)
                {
                    sb.AppendLine($"            var originalGrid = $('#{tableName}Grid').data('kendoTreeList');");
                    sb.AppendLine("            if (!originalGrid) return;");
                    sb.AppendLine("");
                    // Now uses a proper map function with barcode detection
                    sb.AppendLine("var clonedColumns = originalGrid.columns.slice(2).map(function(col) {");
                    sb.AppendLine("    var newCol = $.extend(true, {}, col);");  // ← Deep clone
                    sb.AppendLine("    // Check if column has barcode template");
                    sb.AppendLine("    var hasBarcode = false;");
                    sb.AppendLine("    try {");
                    sb.AppendLine("        var templateStr = col.template ? col.template.toString() : '';");
                    sb.AppendLine("        hasBarcode = /kendoBarcode|kendoQRCode/i.test(templateStr);");
                    sb.AppendLine("    } catch (e) { hasBarcode = false; }");
                    sb.AppendLine("    // Replace barcode with plain text");
                    sb.AppendLine("    if (hasBarcode && col.field) {");
                    sb.AppendLine("        delete newCol.template;");
                    sb.AppendLine("        newCol.template = function(dataItem) {");
                    sb.AppendLine("            var value = dataItem[col.field];");
                    sb.AppendLine("            return value ? kendo.htmlEncode(value) : '';");
                    sb.AppendLine("        };");
                    sb.AppendLine("    }");
                    sb.AppendLine("    return newCol;");
                    sb.AppendLine("});");
                    sb.AppendLine("            var fields = { id: { type: 'number' }, parentID: { type: 'number', nullable: true } };");
                    sb.AppendLine("            clonedColumns.forEach(col => { if (col.field && !fields[col.field]) fields[col.field] = { type: 'string' }; });");
                    sb.AppendLine("");
                    sb.AppendLine("            listGrid.kendoTreeList({");
                    sb.AppendLine("                columns: clonedColumns,");
                    sb.AppendLine("                sortable: originalGrid.options.sortable ?? true,");
                    sb.AppendLine("                filterable: originalGrid.options.filterable ?? true,");
                    sb.AppendLine("                pageable: originalGrid.options.pageable ?? true,");
                    sb.AppendLine("                toolbar: originalGrid.options.toolbar ?? [");
                    sb.AppendLine("                    { name: \"search\", text: \"Search\" },");
                    sb.AppendLine("                    { name: \"clear\", text: \"Clear Filters\" }");
                    sb.AppendLine("                ],");
                    sb.AppendLine("                height: originalGrid.options.height || 360,");
                    sb.AppendLine("                noRecords: { template: \"No records available.\" },");
                    sb.AppendLine("                dataSource: new kendo.data.TreeListDataSource({");
                    sb.AppendLine("                    data: data,");
                    sb.AppendLine("                    pageSize: 5,");
                    sb.AppendLine("                    serverPaging: false,");
                    sb.AppendLine("                    serverFiltering: false,");
                    sb.AppendLine("                    serverSorting: false,");
                    sb.AppendLine("                    schema: {");
                    sb.AppendLine("                        model: {");
                    sb.AppendLine("                            id: \"id\",");
                    sb.AppendLine("                            parentId: \"parentID\",");
                    sb.AppendLine("                            fields: fields,");
                    sb.AppendLine("                            expanded: true");
                    sb.AppendLine("                        }");
                    sb.AppendLine("                    }");
                    sb.AppendLine("                }),");
                    sb.AppendLine("                dataBound: function() {");
                    sb.AppendLine("                    fnClearSearch();");
                    sb.AppendLine("                }");
                    sb.AppendLine("            });");
                }
                else
                {
                    sb.AppendLine($"            var originalGrid = $('#{tableName}Grid').data('kendoGrid');");
                    sb.AppendLine("            if (!originalGrid) return;");
                    sb.AppendLine("            var clonedOptions = $.extend(true, {}, originalGrid.getOptions());");
                   sb.AppendLine("            // Clone options and remove first two columns (checkbox/action)");
sb.AppendLine("            clonedOptions.columns = clonedOptions.columns.filter((_, i) => i > 1);");

sb.AppendLine("            // For any column whose template contains 'kendoBarcode' or 'kendoQRCode', convert it to plain text template");
sb.AppendLine("            clonedOptions.columns = clonedOptions.columns.map(function(col) {");
sb.AppendLine("                var hasBarcode = false;");
sb.AppendLine("                try {");
sb.AppendLine("                    var t = col.template ? col.template.toString() : '';");  // convert to string
sb.AppendLine("                    hasBarcode = /kendoBarcode|kendoQRCode/i.test(t);");
sb.AppendLine("                } catch (e) { hasBarcode = false; }");
sb.AppendLine("                if (hasBarcode) {");
sb.AppendLine("                    return {");
sb.AppendLine("                        field: col.field,");
sb.AppendLine("                        title: col.title,");
sb.AppendLine("                        width: col.width || '160px',");
sb.AppendLine("                        template: function(dataItem) {");
sb.AppendLine("                            return dataItem[col.field] ? kendo.htmlEncode(dataItem[col.field]) : '';");  
sb.AppendLine("                        },");
sb.AppendLine("                        attributes: { style: 'text-align:center;' },");
sb.AppendLine("                        headerAttributes: { style: 'text-align:center;' }");
sb.AppendLine("                    };");
sb.AppendLine("                }");
sb.AppendLine("                return col;");
sb.AppendLine("            });");

sb.AppendLine("            // Create List Grid DataSource");
sb.AppendLine("            clonedOptions.dataSource = new kendo.data.DataSource({");
sb.AppendLine("                data: data,");
sb.AppendLine("                pageSize: 5,");
sb.AppendLine("                serverPaging: false,");
sb.AppendLine("                serverFiltering: false,");
sb.AppendLine("                serverSorting: false");
sb.AppendLine("            });");

sb.AppendLine("            // Initialize List Grid with modified columns");
sb.AppendLine("            listGrid.kendoGrid(Object.assign({}, clonedOptions, { height: 360 }));");

                }

                sb.AppendLine("        },");
                sb.AppendLine("        error: function(xhr, status, error) {");
               // sb.AppendLine("           // console.error(\"Error loading list:\", error);");
                sb.AppendLine($"            fnShowNotification(\"Failed to load selected {tableName}s list\",\"error\");");
                sb.AppendLine("        }");
                sb.AppendLine("    });");
                sb.AppendLine("  }");

                sb.AppendLine("");
                sb.AppendLine("    $(document).on(\"click\", \"#printBarcodeBtn\", function () {");
                sb.AppendLine("        if (!selecteditems?.length) {");
                sb.AppendLine("            return fnShowNotification('No items selected for barcode printing. Please add items first.','error');");
                sb.AppendLine("        }");
                sb.AppendLine("");
                sb.AppendLine("        $.ajax({");
                sb.AppendLine("        url: backendUrl + '/Report?flag=true',");
                sb.AppendLine("            method: 'GET',");
                sb.AppendLine("            success: function(reports) {");
                sb.AppendLine("                if (reports?.length) {");
                sb.AppendLine("                    openReportInNewBrowserWindow(reports[0].fileName, reports[0].id, true);");
                sb.AppendLine("                } else {");
                sb.AppendLine("                    fnShowNotification('No reports available.','error');");
                sb.AppendLine("                }");
                sb.AppendLine("            },");
                sb.AppendLine("            error: function(xhr, status, error) {");
                sb.AppendLine("                fnShowNotification('Failed to fetch reports.','error');");
                sb.AppendLine("            }");
                sb.AppendLine("        });");
                sb.AppendLine("    });");

            }
            //function applySearchFilter Start
            //sb.AppendLine("function applySearchFilter() {");
            //sb.AppendLine("    var formData = {};");
            //sb.AppendLine("    var filter = { logic: 'and', filters: [] };");

            
            sb.AppendLine("function applyGlobalSearch() {");
           
            sb.AppendLine("");
            sb.AppendLine("    var parentData = {};");
            sb.AppendLine("    var filter = { logic: 'and', filters: [] };");
            foreach (var field in fields)
            {
                var fieldName = (field.FieldName ?? "").Trim();
                var fieldNameLowerCase = fieldName.ToLower(); // always lowercase for HTML IDs

                if (string.Equals(field.FieldType, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"    var {fieldNameLowerCase}Multi = $(\"#{fieldNameLowerCase}\").data(\"kendoMultiSelect\");");

                    var relatedDetails = detailFields
                                            .Where(df => df.FieldId == field.FieldId)
                                            .ToList();

                    foreach (var details in relatedDetails)
                    {
                        string textFieldLowerCase =
                            !string.IsNullOrWhiteSpace(details.TextFieldName) && details.TextFieldName.Trim().Length > 1
                                ? char.ToLower(details.TextFieldName.Trim()[0]) + details.TextFieldName.Trim()[1..]
                                : string.Empty;

                        sb.AppendLine(
                            $"    parentData['{fieldName}'] = {fieldNameLowerCase}Multi.dataItems().map(x => x.{textFieldLowerCase}).sort((a, b) => a.localeCompare(b)).join(\",\");"
                        );
                    }
                }

                else if (string.Equals(field.FieldType, FieldTypeEnums.Slider.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($" if ($(\"#isfilter_{fieldNameLowerCase}\").is(\":checked\")) ");
                    sb.AppendLine($"parentData['{fieldName}'] = ($('#{fieldNameLowerCase}').val() == null) ? \"\" : $('#{fieldNameLowerCase}').val();                            ");
                }
                else if (string.Equals(field.FieldType, FieldTypeEnums.Switches.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($" if ($(\"#isfilter_{fieldNameLowerCase}\").is(\":checked\")) ");
                    sb.AppendLine($"parentData['{fieldName}'] = $(\"#{fieldNameLowerCase}\").data(\"kendoSwitch\")?.value() ? 1 : 0;");
                }
                else if (string.Equals(field.FieldType, FieldTypeEnums.Bit.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($" if ($(\"#isfilter_{fieldNameLowerCase}\").is(\":checked\")) ");
                    sb.AppendLine($" parentData['{fieldName}'] = $('#{fieldNameLowerCase}').is(\":checked\") ? 1 : 0;");
                }
                else if (string.Equals(field.FieldType, FieldTypeEnums.Date.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"const {fieldNameLowerCase} = $('#{fieldNameLowerCase}Criteria').data('kendoDropDownList')?.value();");
                    sb.AppendLine($"if ({fieldNameLowerCase} === 'Between') {{");
                    sb.AppendLine($"    handleBetween(filter, '{fieldNameLowerCase}', '#{fieldNameLowerCase}Picker', 'yyyy-MM-dd', 'DateRange');");
                    sb.AppendLine("} else {");
                    sb.AppendLine($"    handleSingle(parentData, '{fieldNameLowerCase}', 'kendoDatePicker', 'yyyy-MM-dd');");
                    sb.AppendLine("}");
                }
                else if (string.Equals(field.FieldType, FieldTypeEnums.Datetime.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"const {fieldNameLowerCase} = $('#{fieldNameLowerCase}Criteria').data('kendoDropDownList')?.value();");
                    sb.AppendLine($"if ({fieldNameLowerCase} === 'Between') {{");
                    sb.AppendLine($"    handleBetween(filter, '{fieldNameLowerCase}', null, 'yyyy-MM-dd HH:mm:ss', 'DateTime');");
                    sb.AppendLine("} else {");
                    sb.AppendLine($"    handleSingle(parentData, '{fieldNameLowerCase}', 'kendoDateTimePicker', 'yyyy-MM-dd HH:mm:ss');");
                    sb.AppendLine("}");
                }
                else if (string.Equals(field.FieldType, FieldTypeEnums.Timeduration.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"var {fieldNameLowerCase}Picker = $('#{fieldNameLowerCase}').data('kendoTimeDurationPicker');");
                    sb.AppendLine($"var value = {fieldNameLowerCase}Picker ? {fieldNameLowerCase}Picker.value() : null;");
                    sb.AppendLine("if (value) {");
                    sb.AppendLine("    var h = Math.floor(value / 3600000);");
                    sb.AppendLine("    var m = Math.floor((value % 3600000) / 60000);");
                    sb.AppendLine("    var s = Math.floor((value % 60000) / 1000);");
                    sb.AppendLine($"    parentData['{fieldNameLowerCase}'] = `${{h.toString().padStart(2, '0')}}:${{m.toString().padStart(2, '0')}}:${{s.toString().padStart(2, '0')}}`;");
                    sb.AppendLine("} else {");
                    sb.AppendLine($"    parentData['{fieldNameLowerCase}'] = null;");
                    sb.AppendLine("}");

                }
                else if ((string.Equals(field.FieldType, FieldTypeEnums.Colorpicker.ToString(), StringComparison.OrdinalIgnoreCase)))
                {
                    sb.AppendLine($"var {fieldNameLowerCase}Val = $('#{fieldNameLowerCase}').val();");
                    sb.AppendLine($"{fieldNameLowerCase}Val = {fieldNameLowerCase}Val ? {fieldNameLowerCase}Val.toLowerCase() : null;");
                    sb.AppendLine($"parentData['{fieldName}'] = ({fieldNameLowerCase}Val && {fieldNameLowerCase}Val.toLowerCase() !== '#000000') ? {fieldNameLowerCase}Val : null;");

                }

                else
                {
                    sb.AppendLine($"    parentData['{fieldName}'] = ($('#{fieldNameLowerCase}').val() ?? \"\");");
                }
            }
            sb.AppendLine("");
            sb.AppendLine("");
            sb.AppendLine("    // 🔹 Child filters");
            sb.AppendLine("    var childData = {};");
            foreach (var childSearch in (childSearchListByParentId ?? Enumerable.Empty<ClientSearchField>())
            .Where(x => x.FormId == x.FormId))
            {
                sb.AppendLine($"    childData['{childSearch.FieldName}'] = ($('#{childSearch?.FieldName?.ToLower()}').val() ?? \"\");");
            }
            sb.AppendLine("");
            sb.AppendLine("");
            //sb.AppendLine("    grid.dataSource.filter(req.filter);");

            sb.AppendLine("    for (var fieldName in parentData) {");
            // sb.AppendLine("        var fieldValue = formData[fieldName] ? formData[fieldName].trim() : '';");
            sb.AppendLine("         var fieldValue = (parentData[fieldName] !== null && parentData[fieldName] !== undefined)        ? parentData[fieldName].toString().trim()        : '';");  
            sb.AppendLine("        if (fieldValue) {");
            sb.AppendLine("            var criteriaElement = $('#' + fieldName.toLowerCase() + 'Criteria');");
            sb.AppendLine("            var criteria = 'equals';");
            sb.AppendLine("            if ($('#' + fieldName).data('kendoMultiSelect')) {");
            sb.AppendLine("                criteria = 'contains';");
            sb.AppendLine("            } else if (criteriaElement.length > 0) {");
            sb.AppendLine("                criteria = criteriaElement.val();");
            sb.AppendLine("            }");
            sb.AppendLine("            filter.filters.push({ field: fieldName, operator: criteria, value: fieldValue });");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
    
            if (isHierarchical)
            {
                sb.AppendLine($"        var treeList = $('#{tableName}Grid').data('kendoTreeList');");
                sb.AppendLine("        treeList.dataSource.filter(filter);");
                sb.AppendLine("        treeList.dataSource.read().then(function () {");
                sb.AppendLine("            treeList.dataSource.view().forEach(function (item) {");
                sb.AppendLine("                expandParents(item, treeList);");
                sb.AppendLine("            });");
                sb.AppendLine("        });");


            }
            else
            {
                sb.AppendLine($"        var treeList = $('#{tableName}Grid').data('kendoGrid');");
                sb.AppendLine("        treeList.dataSource.filter(filter);");
            }

            sb.AppendLine("    } ");
            //function applySearchFilter End


            //sb.AppendLine("$(document).ready(function () {");

            // Update Button Click
            HashSet<string> formNames = [];
            foreach (var field in detailFields)
            {
                formNames.Add(field.FormName ?? "");
            }
            var firstFormName = formNames.FirstOrDefault();


            if (isHierarchical)
            {

                //sb.AppendLine("loadTree(actionColumn);");
                // Load TreeList Function with Add, Delete, and Drag & Drop functionality
                sb.AppendLine("function loadTree(actionColumn) {");
                sb.AppendLine($"    $('#{tableName}Grid').empty();");
                sb.AppendLine($"    $('#{tableName}Grid').kendoTreeList({{");
                sb.AppendLine("        dataSource: {");
                sb.AppendLine("            transport: {");
                sb.AppendLine("                read: function (options) {");
                sb.AppendLine("                    var formData = {};");
                sb.AppendLine("                    var filter = { logic: 'and', filters: [] };");
                sb.AppendLine("                    for (const fieldName in formData) {");
                sb.AppendLine("                        const fieldValue = formData[fieldName].trim();");
                sb.AppendLine("                        var fieldNameLowerCase = fieldName.trim().charAt(0).toLowerCase() + fieldName.trim().slice(1);");
                sb.AppendLine("                        if (fieldValue) {");
                sb.AppendLine("                            const criteriaElement = $('#' + fieldNameLowerCase + 'Criteria');");
                sb.AppendLine("                            let criteria = 'equals';");
                sb.AppendLine("                            if (criteriaElement.length > 0) {");
                sb.AppendLine("                                criteria = criteriaElement.val();");
                sb.AppendLine("                            }");
                sb.AppendLine("                            filter.filters.push({ field: fieldName, operator: criteria, value: fieldValue });");
                sb.AppendLine("                        }");
                sb.AppendLine("                    }");
                sb.AppendLine("var requestData = { skip: options.data.skip || 0, take: options.data.take || 50, sort: options.data.sort || null, filter: options.data.filter || filter };");

                sb.AppendLine("    var parentMapping = {};");
                sb.AppendLine("                    $.ajax({");
                sb.AppendLine($"                        url: backendUrl + `/{tableName.ToLower()}s`,");
                sb.AppendLine("                        type: 'POST',");
                sb.AppendLine("                        dataType: 'json',");
                sb.AppendLine("                        contentType: 'application/json',");
                sb.AppendLine("                        data: JSON.stringify(requestData),");
                sb.AppendLine("                        timeout: 10000,");

                sb.AppendLine("                    beforeSend: function (xhr) {");
                sb.AppendLine("                        var token = localStorage.getItem(\"jwtToken\");");
                sb.AppendLine("                        if (token) {");
                sb.AppendLine("                            xhr.setRequestHeader(\"Authorization\", \"Bearer \" + token);");
                sb.AppendLine("                        } else {");
                sb.AppendLine("                            // Handle missing token");
                sb.AppendLine("                            console.error(\"Authentication token is missing.\");");
                sb.AppendLine("                        }");
                sb.AppendLine("                    },");

                sb.AppendLine("                        success: function (response) {");
                sb.AppendLine("                            console.log('TreeList data:', response);");
                sb.AppendLine("        const allData = response.data;");
                sb.AppendLine("        console.log('Data:', response.data);");
                sb.AppendLine("        const parentLookup = allData.reduce((acc, item) => {");
                sb.AppendLine("            if (item.parentID !== null) {");
                sb.AppendLine("                acc[item.parentID] = true;");
                sb.AppendLine("            }");
                sb.AppendLine("            return acc;");
                sb.AppendLine("        }, {});");

                sb.AppendLine("        const modifiedData = allData.map(item => ({");
                sb.AppendLine("            id: item.id,");
                sb.AppendLine("            parentId: item.parentID !== undefined ? item.parentID : null,");
                sb.AppendLine("            hasChildren: parentLookup[item.id] || false,");

                // Dynamically map fields
                foreach (var field in displayfields)
                {
                    var fieldName = (field.FieldName ?? "").Trim();
                    if (string.IsNullOrEmpty(fieldName))
                        continue;

                    
                    var lowerkey = fieldName.ToLowerInvariant();        // e.g. "BarcodeEX" -> "barcodeex"
                    var itemProp = fieldName.ToLowerInvariant();     // same -> use item.barcodeex

                    if (fieldName.Equals("Name", StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine("            name: item.name,");
                    }
                    else
                    {
                        sb.AppendLine($"            {lowerkey}: item.{itemProp},");
                    }
                }

                sb.AppendLine("        }));");




                sb.AppendLine("        console.log('Modified Data:', modifiedData);");
                sb.AppendLine("        if (Array.isArray(modifiedData)) {");
                sb.AppendLine("            options.success(modifiedData);");
                sb.AppendLine("        } else {");
                sb.AppendLine("            console.error(\"Invalid data format.\");");
                sb.AppendLine("        }");

                sb.AppendLine("                        },");
                sb.AppendLine("                        error: function (xhr, status, error) {");
                sb.AppendLine("                            console.error('TreeList error:', error, xhr.responseText);");
                sb.AppendLine("                            fnShowNotification('Error fetching data: ','error');");
                sb.AppendLine("                            options.error();");
                sb.AppendLine("                        }");
                sb.AppendLine("                    });");
                sb.AppendLine("                }");
                sb.AppendLine("            },");
                sb.AppendLine("            schema: {");
                //sb.AppendLine("                data: 'data',");
                sb.AppendLine("                model: {");
                sb.AppendLine("                    id: 'id',");
                sb.AppendLine("                    parentId: 'parentId',");
                sb.AppendLine("                    hasChildren: 'hasChildren',");
                //sb.AppendLine("                    expanded: 'Expanded',");
                sb.AppendLine("                    fields: {");
                sb.AppendLine("                        id: { type: 'string' },");
                sb.AppendLine("                        parentId: { type: 'string', nullable: true },");
                sb.AppendLine("                        hasChildren: { type: 'boolean' },");
                sb.AppendLine("                        Expanded: { type: 'boolean' }");
                //sb.AppendLine("                        Name: { type: 'string' }");

                foreach (var field in displayfields)
                {
                    var fieldName = (field.FieldName ?? "").Trim();
                    //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    if (Regex.IsMatch(fieldNameLowerCase, @"Id$", RegexOptions.IgnoreCase))
                    {
                        continue;
                    }
                    sb.AppendLine($"                        ,{fieldNameLowerCase}: {{ type: 'string' }}");
                    if (field.SourceTableId > 0)
                    {
                        var sourceTableName = (field.SourceTableName ?? "").Trim();
                        var sourceTableNameLowerCase = char.ToLower(sourceTableName[0]) + sourceTableName[1..];
                        sb.AppendLine($"                        ,{sourceTableNameLowerCase}Name: {{ type: 'string' }}");
                    }
                }

                sb.AppendLine("                    }");
                sb.AppendLine("                }");
                sb.AppendLine("            },");
                sb.AppendLine("},");

                sb.AppendLine("pageSize: 5,");
                sb.AppendLine("scrollable: true,");
                sb.AppendLine("resizable: true,");
                sb.AppendLine("sortable: true,");
                sb.AppendLine("toolbar: [\"search\"],");
                sb.AppendLine("search: { fields: [\"name\"] },");
                sb.AppendLine("pageable: {");
                sb.AppendLine("    refresh: true,");
                sb.AppendLine("    responsive: true,");
                sb.AppendLine("    pageSizes: [5, 10, 20, 30, 50],");
                sb.AppendLine("    pageSize: 5,");
                sb.AppendLine("    buttonCount: 5");
                sb.AppendLine("},");
                sb.AppendLine("noRecords: true,");
                sb.AppendLine("messages: { noRecords: \"No records available.\" },");
                sb.AppendLine("filterable: {");
                sb.AppendLine("    extra: false,");
                sb.AppendLine("    operators: {");
                sb.AppendLine("        string: { contains: \"Contains\", doesnotcontain: \"Does not contain\" }");
                sb.AppendLine("    }");
                sb.AppendLine("},");

                //////
                sb.AppendLine("        editable: {");
                sb.AppendLine("            move: {");
                sb.AppendLine("                reorderable: true");
                sb.AppendLine("            }");
                sb.AppendLine("        },");
                sb.AppendLine("        dragAndDrop: true,");
                sb.AppendLine("        draggable: true,");

                sb.AppendLine("dragstart: function (e) {");
                sb.AppendLine("    console.log('Drag started');");
                sb.AppendLine("    console.log('Source node:', e.source);  // Log the source node during the drag event");
                sb.AppendLine("},");

                sb.AppendLine("dataBound: function() {");
                sb.AppendLine("    initTooltips();");
                sb.AppendLine("      fnClearSearch();");

                if (isAddToList)
                {
                    sb.AppendLine("  var grid = this;");
                    sb.AppendLine("");
                    sb.AppendLine("  grid.dataSource.view().forEach(function (item) {");
                    sb.AppendLine("    if (selectedDataMap[item.id]) {");
                    sb.AppendLine("        // Restore previously selected rows");
                    sb.AppendLine("        $(\".rowCheckbox[data-id='\" + item.id + \"']\").prop(\"checked\", true);");
                    sb.AppendLine("    }");
                    sb.AppendLine("  });");
                    sb.AppendLine("  // Sync header checkbox - check if all visible rows are selected");
                    sb.AppendLine("  var visibleRows = grid.dataSource.view();");
                    sb.AppendLine("  var allVisibleSelected = visibleRows.length > 0 && visibleRows.every(function(item) {");
                    sb.AppendLine("    return selectedDataMap[item.id];");
                    sb.AppendLine("  });");
                    sb.AppendLine("  $(\"#selectAll\").prop(\"checked\", allVisibleSelected); ");
                }
                sb.AppendLine("},");

                sb.AppendLine("drop: function(e) {");
                sb.AppendLine("    console.log('Drop event triggered');");
                sb.AppendLine("    console.log('Source:', e.source);");
                sb.AppendLine("    console.log('Destination:', e.destination);");

                sb.AppendLine();

                sb.AppendLine("    var droppedDataItem = e.source;");
                sb.AppendLine("    var targetDataItem = e.destination;");

                sb.AppendLine();

                sb.AppendLine("    if (!droppedDataItem || !targetDataItem) {");
                sb.AppendLine("        console.error('Missing source or destination data item.');");
                sb.AppendLine("        return;");
                sb.AppendLine("    }");

                sb.AppendLine();

                sb.AppendLine("    // Validate required fields");
                sb.AppendLine("    if (!droppedDataItem.id) {");
                sb.AppendLine("        console.error('Dropped item is missing a valid ID.');");
                sb.AppendLine("        return;");
                sb.AppendLine("    }");

                sb.AppendLine("    if (!targetDataItem.id) {");
                sb.AppendLine("        console.error('Target item is missing a valid ID.');");
                sb.AppendLine("        return;");
                sb.AppendLine("    }");

                sb.AppendLine();

                sb.AppendLine("    if (droppedDataItem.id === targetDataItem.id) {");
                sb.AppendLine("        console.warn('Cannot drop an item onto itself.');");
                sb.AppendLine("        return;");
                sb.AppendLine("    }");

                sb.AppendLine();

                sb.AppendLine("    if (droppedDataItem.parentId === targetDataItem.id) {");
                sb.AppendLine("        console.warn('Item is already under the selected parent.');");
                sb.AppendLine("        return;");
                sb.AppendLine("    }");

                sb.AppendLine();

                sb.AppendLine("    function isDescendant(sourceNode, targetNode, allNodes) {");
                sb.AppendLine("        let current = targetNode;");
                sb.AppendLine("        while (current && current.parentId !== null && current.parentId !== undefined) {");
                sb.AppendLine("            if (current.parentId === sourceNode.id) {");
                sb.AppendLine("                return true;");
                sb.AppendLine("            }");
                sb.AppendLine("            current = allNodes.find(item => item.id === current.parentId);");
                sb.AppendLine("        }");
                sb.AppendLine("        return false;");
                sb.AppendLine("    }");
                sb.AppendLine();

                sb.AppendLine("    // Helper function to flatten the TreeList data");
                sb.AppendLine("    function getAllTreeListItems(treeList) {");
                sb.AppendLine("        const flatList = [];");
                sb.AppendLine();
                sb.AppendLine("        function flatten(data) {");
                sb.AppendLine("            data.forEach(item => {");
                sb.AppendLine("                flatList.push(item);");
                sb.AppendLine("                if (item.hasChildren && item.children) {");
                sb.AppendLine("                    flatten(item.children.view()); // Recursively flatten children");
                sb.AppendLine("                }");
                sb.AppendLine("            });");
                sb.AppendLine("        }");
                sb.AppendLine();
                sb.AppendLine("        const rootItems = treeList.dataSource.view(); // Get the top-level items (root rows)");
                sb.AppendLine("        flatten(rootItems); // Flatten the full tree");
                sb.AppendLine("        return flatList;");
                sb.AppendLine("    }");

                sb.AppendLine();

                sb.AppendLine("    // Get all TreeList items (flattened list)");
                sb.AppendLine($"    const treeList = $('#{tableName}Grid').data('kendoTreeList'); // TreeList reference");
                sb.AppendLine("    const allItems = getAllTreeListItems(treeList);");

                sb.AppendLine();

                sb.AppendLine("    // Check for circular hierarchy (prevents moving node into a descendant)");
                sb.AppendLine("    if (isDescendant(droppedDataItem, targetDataItem, allItems)) {");
                sb.AppendLine("        console.warn('Cannot move a node into one of its own descendants.');");
                sb.AppendLine("        e.setValid(false);");
                sb.AppendLine("        return;");
                sb.AppendLine("    }");
                sb.AppendLine();

                sb.AppendLine("    // ✅ Use Kendo's .set() to update parentId (maintains binding)");
                sb.AppendLine("    droppedDataItem.set('parentid', targetDataItem.id);");
                sb.AppendLine("    console.log('Updated parentId to:', targetDataItem.id);");

                sb.AppendLine();

                sb.AppendLine("    // ✅ Convert observable to plain object");
                sb.AppendLine("    const updatedItem = droppedDataItem.toJSON();");
                sb.AppendLine("    console.log('Sending updated item:', updatedItem);");

                sb.AppendLine();

                sb.AppendLine("    // Send the updated item to the backend");
                sb.AppendLine("    $.ajax({");
                //sb.AppendLine("        url: backendUrl + '{tableName}/Update/' + updatedItem.id,");
                sb.AppendLine($"        url: backendUrl + '/{tableName.ToLower()}/' + updatedItem.id,");
                sb.AppendLine("        type: 'PUT',  // Using PUT to update the object");
                sb.AppendLine("        contentType: 'application/json',");
                sb.AppendLine("        data: JSON.stringify(updatedItem),");
                sb.AppendLine("        success: function(response) {");
                sb.AppendLine("            console.log('Parent updated successfully');");
                sb.AppendLine("        },");
                sb.AppendLine("        error: function(xhr, status, error) {");
                sb.AppendLine("            console.error('Error updating parent:', error);");
                sb.AppendLine("            console.log('Server response:', xhr.responseText);");
                sb.AppendLine("        }");
                sb.AppendLine("    });");
                sb.AppendLine("},");
                sb.AppendLine("        columns: [");
                if (isAddToList)
                {
                    sb.AppendLine("        {");
                    sb.AppendLine("              headerTemplate: \"<input type='checkbox' id='selectAll' style='margin-left: 23px;' /> \",");
                    sb.AppendLine("              template: \"<input type='checkbox' class='rowCheckbox' data-id='#=id#' />\",");
                    sb.AppendLine("              width: 60,");
                    sb.AppendLine("              filterable: false,");
                    sb.AppendLine("              sortable: false");
                    sb.AppendLine("         },");
                }
                sb.AppendLine("            ");
                //sb.AppendLine("                width: \"300px\",");
                //sb.AppendLine("                expandable: true,");
                //sb.AppendLine("                template: `");
                //sb.AppendLine("                    <button class='btn btn-primary btn-sm k-button-icontext' style=\"min-width: 40px;\" data-id=\"#= id #\" onclick=\"return EditUser(this);\">");
                //sb.AppendLine("                        <i class='k-icon k-font-icon k-i-pencil'></i>");
                //sb.AppendLine("                    </button>");
                //sb.AppendLine("                    <button class='btn btn-danger btn-sm k-button-icontext' style=\"min-width: 40px;\" data-id=\"#= id #\" onclick=\"return DeleteUser(this);\">");
                //sb.AppendLine("                        <i class='k-icon k-font-icon k-i-trash'></i>");
                //sb.AppendLine("                    </button>");
                //sb.AppendLine("                    <button class='btn btn-secondary btn-sm k-button-icontext' style=\"min-width: 40px;\" data-id=\"#= id #\" onclick=\"return AddChild(this);\">");
                //sb.AppendLine("                        <i class=\"k-icon k-font-icon k-i-plus\"></i>");
                //sb.AppendLine("                    </button>");
                //sb.AppendLine("                `,");
                //sb.AppendLine("                attributes: { style: \"text-align: center;\" },");
                //sb.AppendLine("                headerAttributes: { style: \"text-align: center;\" }");
                sb.AppendLine("      actionColumn,");

                // Add ID field (usually hidden)
                sb.AppendLine("            { field: 'id', title: 'ID', hidden: true },");



                // Add dynamic fields
                foreach (var field in displayfields)
                {
                    var fieldName = (field.FieldName ?? "").Trim();
                    var fieldNameLower = fieldName.ToLower();

                    if (Regex.IsMatch(fieldName, @"Id$", RegexOptions.IgnoreCase)) continue;
                    if (!Enum.TryParse<FieldTypeEnums>(field.TypeId, true, out var fieldType))
                        fieldType = FieldTypeEnums.Unknown; // default if parsing fails

                    switch (fieldType)
                    {
                        // DateTime field template
                        case FieldTypeEnums.Datetime:

                            sb.AppendLine("            {");
                            sb.AppendLine($"                field: '{fieldNameLower}',");
                            sb.AppendLine($"                title: '{fieldName}',");
                            sb.AppendLine("                template: function (dataItem) {");
                            sb.AppendLine($"                    return dataItem.{fieldNameLower} ? formatUtcToLocal(dataItem.{fieldNameLower}, \"MM/dd/yyyy hh:mm tt\") : \"\";");
                            sb.AppendLine("                },");
                            sb.AppendLine("                width: '150px'");
                            sb.AppendLine("            },");
                            break;

                        // Date field template
                        case FieldTypeEnums.Date:

                            sb.AppendLine("            {");
                            sb.AppendLine($"                field: '{fieldNameLower}',");
                            sb.AppendLine($"                title: '{fieldName}',");
                            sb.AppendLine("                template: function (dataItem) {");
                            sb.AppendLine($"                    return dataItem.{fieldNameLower} ? formatUtcToLocal(dataItem.{fieldNameLower}, \"MM/dd/yyyy\") : \"\";");
                            sb.AppendLine("                },");
                            sb.AppendLine("                width: '120px'");
                            sb.AppendLine("            },");
                            break;

                        case FieldTypeEnums.Signature:

                            sb.AppendLine("            {");
                            sb.AppendLine($"                field: '{fieldNameLower}',");
                            sb.AppendLine($"                title: '{field.DisplayName}',");
                            sb.AppendLine("                template: function (dataItem) {");
                            sb.AppendLine($"                    if (dataItem.{fieldNameLower}) {{");
                            sb.AppendLine($"                        return `<img src='data:image/png;base64,${{dataItem.{fieldNameLower}}}' alt='Signature' style='height:60px;' />`; ");
                            sb.AppendLine("                    } else {");
                            sb.AppendLine("                        return 'No Signature';");
                            sb.AppendLine("                    }");
                            sb.AppendLine("                },");
                            sb.AppendLine("                width: '150px',");
                            sb.AppendLine("                filterable: false");
                            sb.AppendLine("            },");
                            break;

                        case FieldTypeEnums.Image:

                            sb.AppendLine("            {");
                            sb.AppendLine($"                field: '{fieldNameLower}',");
                            sb.AppendLine($"                title: '{field.DisplayName}',");
                            sb.AppendLine("                template: function (dataItem) {");
                            //sb.AppendLine($"                    if (dataItem.{fieldNameLower}) {{");
                            //sb.AppendLine($"                        return \"<img src='data:image/png;base64,\" + dataItem.{fieldNameLower} + \"' width='80' height='80' style='object-fit:cover;border-radius:6px;' />\";");
                            //sb.AppendLine("                    } else {");
                            //sb.AppendLine("                        return '<span style=\"color:#888;\">No Image</span>';");
                            //sb.AppendLine("                    }");
                            sb.AppendLine($"                    if (dataItem.{fieldNameLower}) {{");
                            sb.AppendLine($"                        const encodedImage = encodeURIComponent(dataItem.{fieldNameLower});");
                            sb.AppendLine("                        return `");
                            sb.AppendLine("                            <div style=\"display: flex; justify-content: center; align-items: center;\">");
                            sb.AppendLine($"                                <button class=\"btn btn-success preview-btn btn-sm {fieldNameLower}preview-btn\"");
                            sb.AppendLine("                                        data-image=\"${encodedImage}\"");
                            sb.AppendLine("                                        title=\"Preview Image\"");
                            sb.AppendLine("                                        style=\"min-width: 40px;\">");
                            sb.AppendLine("                                    <i class=\"k-icon k-font-icon k-i-eye\"></i>");
                            sb.AppendLine("                                </button>");
                            sb.AppendLine("                            </div>`;");
                            sb.AppendLine("                    } else {");
                            sb.AppendLine("return `<div style=\"display: flex; justify-content: center; align-items: center;\"></div>`;");
                            sb.AppendLine("}");
                            sb.AppendLine("                },");
                            sb.AppendLine("                width: '150px',");
                            sb.AppendLine("                filterable: false");
                            sb.AppendLine("            },");
                            break;
                        // Add this single case in your switch statement
                        // This will handle both Barcode and QR Code based on the DisplayName or a property
                        case FieldTypeEnums.Barcode:
                            {
                                // Detect if the field is a QR code by name or display label
                                bool isQRCode = field.DisplayName?.ToLower().Contains("qr") == true ||
                                                fieldNameLower.Contains("qr");

                                sb.AppendLine("            {");
                                sb.AppendLine($"                field: '{fieldNameLower}',");
                                sb.AppendLine($"                title: '{field.DisplayName}',");
                                sb.AppendLine(isQRCode ? "                width: '140px'," : "                width: '200px',");
                                sb.AppendLine("                filterable: true,");
                                sb.AppendLine("                sortable: false,");
                                sb.AppendLine("                template: function(dataItem) {");
                                sb.AppendLine($"                    var value = dataItem['{fieldNameLower}'];");
                                sb.AppendLine("                    if (!value || value.toString().trim() === '') return '';");

                                sb.AppendLine($"                    var uid = dataItem.id || kendo.guid();");
                                sb.AppendLine($"                    var elementId = 'bc_{fieldNameLower}_' + uid;");

                                // Barcode type map
                                sb.AppendLine("                    var typeMap = {");
                                sb.AppendLine("                        'CODE128': 'Code128',");
                                sb.AppendLine("                        'CODE39': 'Code39',");
                                sb.AppendLine("                        'CODE93': 'Code93',");
                                sb.AppendLine("                        'QRCODE': 'QRCode'");
                                sb.AppendLine("                    };");

                                // ✅ Correct QR detection logic
                                sb.AppendLine($"                    var fieldName = '{fieldNameLower}';");
                                sb.AppendLine($"                    var rawType = window[fieldName + '_barcodeType'] || (fieldName.toLowerCase().includes('qr') ? 'QRCODE' : 'CODE128');");
                                sb.AppendLine("                    rawType = rawType.toUpperCase();");
                                sb.AppendLine("                    var kendoType = typeMap[rawType] || 'Code128';");

                                // Render when DOM ready
                                sb.AppendLine("                    setTimeout(function() {");
                                sb.AppendLine("                        var el = $('#' + elementId);");
                                sb.AppendLine("                        if (!el.length) return;");

                                // 🧹 FIX: Clear previous rendering to prevent duplicate barcodes
                                sb.AppendLine("                        el.empty();");

                                sb.AppendLine("                        if (kendoType === 'QRCode') {");
                                sb.AppendLine("                            el.kendoQRCode({");
                                sb.AppendLine("                                value: String(value),");
                                sb.AppendLine("                                size: 80,");
                                sb.AppendLine("                                renderAs: 'svg',");
                                sb.AppendLine("                                errorCorrection: 'M'");
                                sb.AppendLine("                            });");
                                sb.AppendLine("                        } else {");
                                sb.AppendLine("                            el.kendoBarcode({");
                                sb.AppendLine("                                value: String(value),");
                                sb.AppendLine("                                type: kendoType,");
                                sb.AppendLine("                                width: 140,");
                                sb.AppendLine("                                height: 60,");
                                sb.AppendLine("                                renderAs: 'svg',");
                                sb.AppendLine("                                text: { visible: true, font: '10px Arial' }");
                                sb.AppendLine("                            });");
                                sb.AppendLine("                        }");
                                sb.AppendLine("                    }, 0);");

                                // ✅ Use CSS wrapper (no inline styles)
                                sb.AppendLine("                    return `<div class='barcode-input-wrapper'><div class='barcode-row' id='${elementId}'></div></div>`;");
                                sb.AppendLine("                },");
                                sb.AppendLine("                attributes: { class: 'text-center' },");
                                sb.AppendLine("                headerAttributes: { class: 'text-center' }");
                                sb.AppendLine("            },");
                                break;
                            }






                        default:
                            {
                                //for displayname in isheirarchie
                                sb.AppendLine($"            {{ field: '{fieldNameLower}', title: '{field.DisplayName}', width: '120px' }},");
                                break;
                            }
                    }
                }

                    //else if (field.TypeId?.ToLower() == "richtexteditor")
                    //{
                    //    sb.AppendLine("            {");
                    //    sb.AppendLine($"                field: '{fieldNameLower}',");
                    //    sb.AppendLine($"                title: '{field.DisplayName.Trim()}',");
                    //    sb.AppendLine("                width: '400px',");
                    //    sb.AppendLine("                template: function (dataItem) {");
                    //    sb.AppendLine("                    try {");
                    //    sb.AppendLine($"                        var html = dataItem['{fieldNameLower}'] || '';");
                    //    sb.AppendLine("                        var div = document.createElement('div');");
                    //    sb.AppendLine("                        div.innerHTML = html;");
                    //    sb.AppendLine("                        var plainText = div.innerText || div.textContent || '';");
                    //    sb.AppendLine("                        return plainText;");
                    //    sb.AppendLine("                    } catch (e) {");
                    //    sb.AppendLine("                        return ''; ");
                    //    sb.AppendLine("                    }");
                    //    sb.AppendLine("                },");
                    //    sb.AppendLine("                filterable: { cell: { operator: \"contains\" } }");
                    //    sb.AppendLine("            },");
                    //}



                    //sb.AppendLine("            { command: ['edit', 'destroy'], title: '&nbsp;', width: '250px' }"); // Command for Edit and Delete
                    sb.AppendLine("        ],");
                    //sb.AppendLine("        dataTextField: 'Name',");
                    //sb.AppendLine("        dataValueField: 'Id',");
                    sb.AppendLine("        loadOnDemand: false,");
                    //sb.AppendLine("        draggable: true,");  // Enable Drag and Drop
                    sb.AppendLine("        autoBind: false,");
                    //sb.AppendLine("        }");
                    sb.AppendLine("    });");
                    sb.AppendLine($"    $('#{tableName}Grid').data('kendoTreeList').dataSource.read();");
                    sb.AppendLine("}");


                foreach (var field in displayfields)
                {
                    if (!Enum.TryParse<FieldTypeEnums>(field.TypeId, true, out var fieldType))
                    {
                        // fallback (if unknown type) -> treat as default
                        fieldType = default;
                    }
                    var fieldName = (field.FieldName ?? "").Trim();
                    //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;


                    if (fieldType == FieldTypeEnums.Image && !string.IsNullOrWhiteSpace(fieldNameLowerCase))
                    {
                        ImagePreviewScript.AppendImagePreviewScript(sb, fieldNameLowerCase ?? "", field.DisplayName ?? "", tableName);
                    }
                }


                // Expand parent rows in Kendo TreeList
                sb.AppendLine("function expandParents(item, treeList) {");
                    sb.AppendLine("    var parentId = item.ParentID;");
                    sb.AppendLine("    if (parentId) {");
                    sb.AppendLine("        var parent = treeList.dataSource.get(parentId);");
                    sb.AppendLine("        if (parent) {");
                    sb.AppendLine("            treeList.expand(treeList.tbody.find('tr[data-uid=\"' + parent.uid + '\"]'));");
                    sb.AppendLine("            expandParents(parent, treeList);");
                    sb.AppendLine("        }");
                    sb.AppendLine("    }");
                    sb.AppendLine("}");

                    sb.AppendLine("function clearGlobalSearch() {");
                    sb.AppendLine("    $('input, select').each(function() {");
                    sb.AppendLine("        var fieldType = $(this).attr('type');");
                    sb.AppendLine("        if (fieldType === 'checkbox' || fieldType === 'radio') {");
                    sb.AppendLine("            $(this).prop('checked', false);");
                    sb.AppendLine("        } else {");
                    sb.AppendLine("            $(this).val('');");
                    sb.AppendLine("        }");
                    sb.AppendLine("    });");

                    sb.AppendLine("    var filter = { logic: 'and', filters: [] };");


                    sb.AppendLine($"        var treeList = $('#{tableName}Grid').data('kendoTreeList');");
                    sb.AppendLine("        treeList.dataSource.filter(filter);");
                    sb.AppendLine("        treeList.dataSource.read();");
                    sb.AppendLine("    }");
                    //sb.AppendLine("}"); // <-- Missing closing brace added
                }
            else
            {
                //sb.AppendLine("loadGrid(actionColumn);");

                // Load Grid Function
                sb.AppendLine("function loadGrid(actionColumn) {");
                sb.AppendLine("    $('#" + tableName + "Grid').kendoGrid({");
                sb.AppendLine("        dataSource: {");
                sb.AppendLine("            transport: {");
                sb.AppendLine("                read: function (options) {");
                sb.AppendLine("                    var parentData = {};");
                sb.AppendLine("    var filter = { logic: 'and', filters: [] };");
                foreach (var field in fields)
                {
                    var fieldName = (field.FieldName ?? "").Trim();
                    var fieldNameLowerCase = fieldName.ToLower();

                    if (!Enum.TryParse<FieldTypeEnums>(field.FieldType, true, out var fieldType))
                    {
                        continue;
                    }

                    //if ((string.Equals(field.FieldType, FieldTypeEnums.Slider.ToString(), StringComparison.OrdinalIgnoreCase)) || (string.Equals(field.FieldType, FieldTypeEnums.Switches.ToString(), StringComparison.OrdinalIgnoreCase)) || (string.Equals(field.FieldType, FieldTypeEnums.Bit.ToString(), StringComparison.OrdinalIgnoreCase)))
                    //{
                    //    sb.AppendLine($" if ($(\"#isfilter_{fieldNameLowerCase}\").is(\":checked\")) ");
                    //}
                    if (string.Equals(field.FieldType, FieldTypeEnums.Bit.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine($" if ($(\"#isfilter_{fieldNameLowerCase}\").is(\":checked\")) ");
                        sb.AppendLine($"  parentData['{fieldName}'] = $(\"#{fieldNameLowerCase}\").is(\":checked\") ? 1 : 0;");
                    }
                    else if (string.Equals(field.FieldType, FieldTypeEnums.Switches.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine($" if ($(\"#isfilter_{fieldNameLowerCase}\").is(\":checked\")) ");
                        sb.AppendLine($" parentData['{fieldName}'] = $(\"#{fieldNameLowerCase}\").data(\"kendoSwitch\")?.value() ? 1 : 0;");
                    }
                    else if (string.Equals(field.FieldType, FieldTypeEnums.Slider.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine($" if ($(\"#isfilter_{fieldNameLowerCase}\").is(\":checked\")) ");
                        //var fieldNameLowerCase = char.ToLower((field.FieldName ?? "").Trim()[0]) + (field.FieldName ?? "").Trim()[1..];
                        sb.AppendLine($"parentData['{fieldName}'] = ($('#{fieldNameLowerCase}').val() || \"\");");
                    }
                    else if (string.Equals(field.FieldType, FieldTypeEnums.Datetime.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine($"const {fieldNameLowerCase} = $('#{fieldNameLowerCase}Criteria').data('kendoDropDownList')?.value();");
                        sb.AppendLine($"if ({fieldNameLowerCase} === 'Between') {{");
                        sb.AppendLine($"    handleBetween(filter, '{fieldNameLowerCase}', null, 'yyyy-MM-dd HH:mm:ss', 'DateTime');");
                        sb.AppendLine("} else {");
                        sb.AppendLine($"    handleSingle(parentData, '{fieldNameLowerCase}', 'kendoDateTimePicker', 'yyyy-MM-dd HH:mm:ss');");
                        sb.AppendLine("}");
                    }
                    else if (string.Equals(field.FieldType, FieldTypeEnums.Timeduration.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine($"var {fieldNameLowerCase}Picker = $('#{fieldNameLowerCase}').data('kendoTimeDurationPicker');");
                        sb.AppendLine($"var value = {fieldNameLowerCase}Picker ? {fieldNameLowerCase}Picker.value() : null;");
                        sb.AppendLine("if (value) {");
                        sb.AppendLine("    var h = Math.floor(value / 3600000);");
                        sb.AppendLine("    var m = Math.floor((value % 3600000) / 60000);");
                        sb.AppendLine("    var s = Math.floor((value % 60000) / 1000);");
                        sb.AppendLine($"    parentData['{fieldNameLowerCase}'] = `${{h.toString().padStart(2, '0')}}:${{m.toString().padStart(2, '0')}}:${{s.toString().padStart(2, '0')}}`;");
                        sb.AppendLine("} else {");
                        sb.AppendLine($"    parentData['{fieldNameLowerCase}'] = null;");
                        sb.AppendLine("}");

                    }
                    else if (string.Equals(field.FieldType, FieldTypeEnums.Date.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine($"const {fieldNameLowerCase} = $('#{fieldNameLowerCase}Criteria').data('kendoDropDownList')?.value();");
                        sb.AppendLine($"if ({fieldNameLowerCase} === 'Between') {{");
                        sb.AppendLine($"    handleBetween(filter, '{fieldNameLowerCase}', '#{fieldNameLowerCase}Picker', 'yyyy-MM-dd', 'DateRange');");
                        sb.AppendLine("} else {");
                        sb.AppendLine($"    handleSingle(parentData, '{fieldNameLowerCase}', 'kendoDatePicker', 'yyyy-MM-dd');");
                        sb.AppendLine("}");
                    }
                    else if (string.Equals(field.FieldType, FieldTypeEnums.Colorpicker.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine($"           var {fieldNameLowerCase}Val = $('#{fieldNameLowerCase}').val();");
                        sb.AppendLine($"           {fieldNameLowerCase}Val = {fieldNameLowerCase}Val ? {fieldNameLowerCase}Val.toLowerCase() : null;");

                        sb.AppendLine($"           parentData['{fieldNameLowerCase}'] = ({fieldNameLowerCase}Val && {fieldNameLowerCase}Val.toLowerCase() !== '#000000') ? {fieldNameLowerCase}Val : null;");
                    }

                    else if ((string.Equals(field.FieldType, FieldTypeEnums.Colorpicker.ToString(), StringComparison.OrdinalIgnoreCase)))
                    {
                        sb.AppendLine($"var {fieldNameLowerCase}Val = $('#{fieldNameLowerCase}').val();");
                        sb.AppendLine($"{fieldNameLowerCase}Val = {fieldNameLowerCase}Val ? {fieldNameLowerCase}Val.toLowerCase() : null;");
                        sb.AppendLine($"parentData['{fieldName}'] = ({fieldNameLowerCase}Val && {fieldNameLowerCase}Val.toLowerCase() !== '#000000') ? {fieldNameLowerCase}Val : null;");

                    }
                    else
                    {
                       // var fieldNameLowerCase = char.ToLower((field.FieldName ?? "").Trim()[0]) + (field.FieldName ?? "").Trim()[1..];
                        sb.AppendLine($"                    parentData['{(field.FieldName ?? "").Trim()}'] = $('#{fieldNameLowerCase}').val() == undefined ? \"\" : $('#{fieldNameLowerCase}').val();");
                    }
                }
                //foreach (var field in fields)
                //{
                //    var fieldNameLowerCase = char.ToLower((field.FieldName ?? "").Trim()[0]) + (field.FieldName ?? "").Trim()[1..];
                //    sb.AppendLine($"                    formData['{(field.FieldName ?? "").Trim()}'] = $('#{fieldNameLowerCase}').val() == undefined ? \"\" : $('#{fieldNameLowerCase}').val();");
                //}

                sb.AppendLine("                    for (const fieldName in parentData) {");
               // sb.AppendLine("                         const fieldValue = formData[fieldName] ? formData[fieldName].trim() : '';");
               sb.AppendLine("                       var fieldValue = parentData[fieldName] ? parentData[fieldName].toString().trim() : '';");
                sb.AppendLine("                        var fieldNameLowerCase = fieldName.trim().charAt(0).toLowerCase() + fieldName.trim().slice(1);");
                sb.AppendLine("                        if (fieldValue) {");
                sb.AppendLine("                            const criteriaElement = $('#' + fieldNameLowerCase + 'Criteria');");
                sb.AppendLine("                            let criteria = 'equals';");
                sb.AppendLine("                            if (criteriaElement.length > 0) {");
                sb.AppendLine("                                criteria = criteriaElement.val();");
                sb.AppendLine("                            }");
                sb.AppendLine("                            filter.filters.push({ field: fieldName, operator: criteria, value: fieldValue });");
                sb.AppendLine("                        }");
                sb.AppendLine("                    }");
                sb.AppendLine("                    var requestData = { skip: options.data.skip || 0, take: options.data.take || 5, sort: options.data.sort || null, filter: options.data.filter || filter };");
                sb.AppendLine("                    $.ajax({");
                sb.AppendLine($"                        url: backendUrl + `/{tableName.ToLower()}s`,");
                sb.AppendLine("                        type: 'POST',");
                sb.AppendLine("                        dataType: 'json',");
                sb.AppendLine("                        contentType: 'application/json',");
                sb.AppendLine("                        data: JSON.stringify(requestData),");
                sb.AppendLine("                        timeout: 10000,");
                sb.AppendLine("                        success: function (response) {");
                sb.AppendLine("                            options.success({ data: response.data, total: response.total });");
                sb.AppendLine("                        },");
                sb.AppendLine("                        error: function (xhr, status, error) {");
                sb.AppendLine("                            if (status === 'timeout') {");
                sb.AppendLine("                                fnShowNotification('Request timed out.','error');");
                sb.AppendLine("                            } else {");
                sb.AppendLine("                                fnShowNotification('Error fetching data: ' ,'error');");
                sb.AppendLine("                            }");
                sb.AppendLine("                            options.error();");
                sb.AppendLine("                        }");
                sb.AppendLine("                    });");
                sb.AppendLine("                }");
                sb.AppendLine("            },");
                sb.AppendLine("schema: { id: 'Id', data: 'data', total: 'total' ,");
                sb.AppendLine("model: {");
                sb.AppendLine("    id: \"id\",");
                sb.AppendLine("    fields: {");

                int dropdownCounter = 1;//for dropdown  increment

                //foreach (var field in displayfields)
                //{
                //    var fieldName = (field.FieldName ?? "").Trim();

                //    var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];

                //    // Skip fields ending with "Id"
                //    if (Regex.IsMatch(fieldNameLowerCase, @"Id$", RegexOptions.IgnoreCase))
                //    {
                //        continue;
                //    }
                //    if (field.TypeId == "varchar" || field.TypeId == "nvarchar" || field.TypeId == "signature")
                //    {
                //        // Default type is string; you can add type inference here if needed
                //        sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"string\" }},");
                //    }
                //    if (field.TypeId == "int")
                //    {
                //        // Default type is string; you can add type inference here if needed
                //        sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"number\" }},");
                //    }
                //    if (field.TypeId == "date" || field.TypeId == "datetime")
                //    {
                //        // Default type is string; you can add type inference here if needed
                //        sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"date\" }},");
                //    }
                //    if (field.TypeId == "decimal" || field.TypeId == "float")
                //    {
                //        // Default type is string; you can add type inference here if needed
                //        sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"number\" }},");
                //    }
                //    if (field.TypeId == "rating")
                //    {
                //        sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"number\" }},");
                //    }

                //}

                foreach (var field in displayfields)
                {


                    var fieldName = (field.FieldName ?? "").Trim();
                    //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    // Skip fields ending with "Id"
                    if (Regex.IsMatch(fieldNameLowerCase, @"Id$", RegexOptions.IgnoreCase))
                    {
                        continue;
                    }

                    // ✅ Convert string -> enum
                    if (!Enum.TryParse<FieldTypeEnums>(field.TypeId, true, out var fieldType))
                    {
                        continue; // Skip unknown / unmapped types
                    }

                    // ✅ Switch on enum
                    switch (fieldType)
                    {
                        case FieldTypeEnums.Varchar:
                        case FieldTypeEnums.Nvarchar:
                        case FieldTypeEnums.Signature:
                            sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"string\" }},");
                            break;

                            ;
                        case FieldTypeEnums.Barcode: // ✅ Include Barcode here as string (data field)
                            sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"string\" }},");
                            break;

                        case FieldTypeEnums.Date:
                        case FieldTypeEnums.Datetime:
                            sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"date\" }},");
                            break;

                        case FieldTypeEnums.Int:
                        case FieldTypeEnums.Decimal:
                        case FieldTypeEnums.Tinyint:
                        case FieldTypeEnums.Bigint:
                        case FieldTypeEnums.Smallint:
                        case FieldTypeEnums.Float:
                        case FieldTypeEnums.Money:
                        case FieldTypeEnums.Rating:
                            sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"number\" }},");

                            break;

                        case FieldTypeEnums.Bit:
                            sb.AppendLine($"        {fieldNameLowerCase}: {{ type: \"boolean\" }},");
                            break;

                        default:
                            // optional: skip or handle other enums like CheckboxGroup, Dropdown etc.
                            break;
                    }
                }

                sb.AppendLine("    }");
                sb.AppendLine("}");
                sb.AppendLine("},");

                sb.AppendLine("            pageSize: 5,");
                sb.AppendLine("            serverPaging: true,");
                sb.AppendLine("            serverSorting: true,");
                sb.AppendLine("            serverFiltering: true");
                sb.AppendLine("        },");
                sb.AppendLine("        sortable: true,");
                sb.AppendLine("        noRecords: true,");
                sb.AppendLine("        messages: {");
                sb.AppendLine("            noRecords: \"No records available.\"");
                sb.AppendLine("        },");
                sb.AppendLine("        resizable: true,");
                sb.AppendLine("        pageable: { responsive: false, pageSizes: [5,10, 20, 30, 50], pageSize: 5,refresh: true, buttonCount: 5 },");
                sb.AppendLine("filterable: {");
                sb.AppendLine("    extra: false,");
                sb.AppendLine("    operators: {");
                sb.AppendLine("        string: {");
                sb.AppendLine("            contains: 'Contains',");
                sb.AppendLine("            doesnotcontain: 'Does not contain',");
                sb.AppendLine("            startswith: 'Starts with',");
                sb.AppendLine("            endswith: 'Ends with',");
                sb.AppendLine("            eq: 'Is equal to',");
                sb.AppendLine("            neq: 'Is not equal to',");
                sb.AppendLine("            isempty: 'Is empty',");
                sb.AppendLine("            isnotempty: 'Is not empty',");
                sb.AppendLine("            isnull: 'Is null',");
                sb.AppendLine("            isnotnull: 'Is not null',");
                sb.AppendLine("            hasvalue: 'Has value',");
                sb.AppendLine("            hasnovalue: 'Has no value'");
                sb.AppendLine("        }");
                sb.AppendLine("    }");
                sb.AppendLine("},");
                sb.AppendLine("        toolbar: [\"search\"],");
                sb.AppendLine("        search: {");
                sb.AppendLine("            fields: [");

                //foreach (var field in displayfields)
                //{
                //    var fieldName = (field.FieldName ?? "").Trim();                      // e.g., "DropDown"
                //    var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..]; // e.g., "dropDown"

                //    // Skip fields ending with "Id"
                //    if (Regex.IsMatch(fieldName, @"Id$", RegexOptions.IgnoreCase))
                //        continue;

                //    // Handle dropdown with display field from source table
                //    if (field.TypeId == "dropdown" && field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName))
                //    {
                //        var sourceTable = (field.SourceTableName ?? "").Trim(); // e.g., "Location"
                //        var displayField = $"{fieldNameLowerCase}_{sourceTable}{dropdownCounter}"; // Corrected: use lowercase field name

                //        sb.AppendLine($"            {{ name: '{displayField}', title: '{sourceTable}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                //        dropdownCounter++;
                //    }
                //    else if (field.TypeId == "checkboxgroup" && field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName))
                //    {
                //        var SourceTableName = field.SourceTableName.Trim();
                //        // var SourceTableNameLowerCase = char.ToLower(SourceTableName[0]) + SourceTableName[1..];

                //        sb.AppendLine($"            {{ name: '{fieldNameLowerCase}_{SourceTableName}', title: '{fieldName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                //    }

                //    else
                //    {
                //        // Regular field
                //        sb.AppendLine($"            {{ name: '{fieldNameLowerCase}', title: '{fieldName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                //    }
                //}
                foreach (var field in displayfields)
                {
                    var fieldName = (field.FieldName ?? "").Trim();                      // e.g., "DropDown"
                                                                                         //  var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..]; // e.g., "dropDown"
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    // Skip fields ending with "Id"
                    if (Regex.IsMatch(fieldName, @"Id$", RegexOptions.IgnoreCase))
                        continue;

                    if (!Enum.TryParse<FieldTypeEnums>(field.TypeId, true, out var fieldType))
                    {
                        fieldType = FieldTypeEnums.Unknown; // default/fallback enum
                    }

                    switch (fieldType)
                    {
                        case FieldTypeEnums.DropDown when field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName):
                            {
                                var sourceTable = (field.SourceTableName ?? "").Trim(); // e.g., "Location"

                                var displayField = $"{fieldNameLowerCase}_{sourceTable}"; // Corrected: use lowercase field name

                                sb.AppendLine($"            {{ name: '{displayField}', title: '{sourceTable}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");


                                break;
                            }

                        case FieldTypeEnums.Checkboxgroup when field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName):
                            {
                                var SourceTableName = field.SourceTableName.Trim();
                                // var SourceTableNameLowerCase = char.ToLower(SourceTableName[0]) + SourceTableName[1..];

                                sb.AppendLine($"            {{ name: '{fieldNameLowerCase}_{SourceTableName}', title: '{fieldName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                break;
                            }

                        case FieldTypeEnums.Multiselect when field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName):
                            {
                                var SourceTableName = field.SourceTableName.Trim();
                                // var SourceTableNameLowerCase = char.ToLower(SourceTableName[0]) + SourceTableName[1..];

                                sb.AppendLine($"            {{ name: '{fieldNameLowerCase}_{SourceTableName}', title: '{fieldName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                break;
                            }

                        case FieldTypeEnums.Radiogroup when field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName):
                            {
                                var SourceTableName = field.SourceTableName.Trim();
                                // var SourceTableNameLowerCase = char.ToLower(SourceTableName[0]) + SourceTableName[1..];
                                //var SourceTableName = char.ToUpper(field.SourceTableName.Trim()[0]) + field.SourceTableName.Trim().Substring(1);

                                sb.AppendLine($"            {{ name: '{fieldNameLowerCase}_{SourceTableName}', title: '{fieldName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                break;
                            }
                        case FieldTypeEnums.Int:
                        case FieldTypeEnums.Float:
                        case FieldTypeEnums.Decimal:
                        case FieldTypeEnums.Money:
                        case FieldTypeEnums.Bigint:
                        case FieldTypeEnums.Tinyint:
                        case FieldTypeEnums.Smallint:
                            sb.AppendLine($"            {{ name: '{fieldNameLowerCase}', title: '{fieldName}', width: '120px',  operator: \"eq\" }},");
                            break;

                        default:
                            {
                                sb.AppendLine($"            {{ name: '{fieldNameLowerCase}', title: '{fieldName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                break;
                            }
                    }
                }

                sb.AppendLine("        ],");
                sb.AppendLine("        },");
                sb.AppendLine(" dataBound: function() {");
                sb.AppendLine("         initTooltips();");
                //sb.AppendLine("  fixScrollableHeight(this);");
                sb.AppendLine(" fnClearSearch();");
                if (isAddToList)
                {
                    sb.AppendLine("  var grid = this;");
                    sb.AppendLine("");
                    sb.AppendLine("  grid.dataSource.view().forEach(function (item) {");
                    sb.AppendLine("    if (selectedDataMap[item.id]) {");
                    sb.AppendLine("        // Restore previously selected rows");
                    sb.AppendLine("        $(\".rowCheckbox[data-id='\" + item.id + \"']\").prop(\"checked\", true);");
                    sb.AppendLine("    }");
                    sb.AppendLine("  });");
                    sb.AppendLine("  // Sync header checkbox - check if all visible rows are selected");
                    sb.AppendLine("  var visibleRows = grid.dataSource.view();");
                    sb.AppendLine("  var allVisibleSelected = visibleRows.length > 0 && visibleRows.every(function(item) {");
                    sb.AppendLine("    return selectedDataMap[item.id];");
                    sb.AppendLine("  });");
                    sb.AppendLine("  $(\"#selectAll\").prop(\"checked\", allVisibleSelected); ");
                }
                sb.AppendLine("        },");

                sb.AppendLine("        columns: [");
                if (isAddToList)
                {
                    sb.AppendLine("        {");
                    sb.AppendLine("              title: \"<input type='checkbox' id='selectAll' /> \",");
                    sb.AppendLine("              template: \"<input type='checkbox' class='rowCheckbox' data-id='#=id#' />\",");
                    sb.AppendLine("              width: 60,");
                    sb.AppendLine("              filterable: false,");
                    sb.AppendLine("              sortable: false");
                    sb.AppendLine("         },");
                }
                sb.AppendLine("            actionColumn,");

                //dropdownCounter = 1;//for dropdown
                //foreach (var field in displayfields)
                //{
                //    var fieldName = (field.FieldName ?? "").Trim();
                //    var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];

                //    if (field.TypeId == "dropdown" && field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName))
                //    {
                //        var sourceTable = (field.SourceTableName ?? "").Trim(); // e.g., "Location"
                //        var displayField = $"{fieldNameLowerCase}_{sourceTable}"; // Corrected: use lowercase field name

                //        sb.AppendLine($"            {{ field: '{displayField}', title: '{fieldName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                //        dropdownCounter++;
                //    }

                //    else if (field.TypeId == "checkboxgroup" && field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName))
                //    {
                //        var SourceTableName = char.ToLower(field.SourceTableName[0]) + field.SourceTableName[1..];
                //        //var SourceTableNameLowerCase = char.ToLower(SourceTableName[0]) + SourceTableName[1..];

                //        sb.AppendLine($"            {{ field: '{fieldNameLowerCase}_{SourceTableName}', title: '{fieldName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                //    }

                //    else if (field.TypeId?.ToLower() == "richtexteditor")
                //    {

                //        sb.AppendLine("        {");
                //        sb.AppendLine($"            field: '{fieldNameLowerCase}',");
                //        sb.AppendLine($"            title: '{fieldName}',");
                //        sb.AppendLine("            width: '80px',");
                //        sb.AppendLine("            template: function(dataItem) {");
                //        sb.AppendLine($"                const rawHtml = dataItem.{fieldNameLowerCase} || '';");
                //        sb.AppendLine("    const hasContent = rawHtml.replace(/<[^>]*>/g, '').trim() !== '';");
                //        sb.AppendLine("    if (!hasContent) {");
                //        sb.AppendLine("        return '';");
                //        sb.AppendLine("    }");
                //        sb.AppendLine("                const encoded = encodeURIComponent(rawHtml);");
                //        sb.AppendLine("                return `");
                //        sb.AppendLine("                    <div style=\"display: flex; justify-content: center; align-items: center; height: 100%;\">");
                //        sb.AppendLine("                        <button class=\"btn btn-success btn-sm preview-btn\"");
                //        sb.AppendLine("                                title=\"Preview\"");
                //        sb.AppendLine("                                data-richtext=\"${encoded}\"");
                //        sb.AppendLine("                                style=\"min-width: 40px;\">");
                //        sb.AppendLine("                            <i class=\"k-icon k-font-icon k-i-eye\"></i>");
                //        sb.AppendLine("                        </button>");
                //        sb.AppendLine("                    </div>`;");
                //        sb.AppendLine("            },");
                //        sb.AppendLine("            filterable: { cell: { operator: \"contains\" } }");
                //        sb.AppendLine("        },");
                //    }


                //    //else if (fieldNameLowerCase.ToLower().Contains("datetime"))
                //    else if (field.TypeId?.ToLower() == "datetime")
                //    {
                //        // Add template for datetime
                //        sb.AppendLine("            {");
                //        sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                //        sb.AppendLine($"                title: '{fieldName}',");
                //        sb.AppendLine("                template: function(dataItem) {");
                //        sb.AppendLine($"                    return dataItem.{fieldNameLowerCase} ? formatUtcToLocal(dataItem.{fieldNameLowerCase}, 'dd-MM-yyyy HH:mm') : '';"); // null check
                //        sb.AppendLine("                },");
                //        sb.AppendLine("                width: '150px',");
                //        sb.AppendLine("                filterable: { cell: { operator: \"contains\" } }");
                //        sb.AppendLine("            },");
                //    }
                //    else if (field.TypeId?.ToLower() == "date")
                //    {
                //        // Add template for date
                //        sb.AppendLine("            {");
                //        sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                //        sb.AppendLine($"                title: '{fieldName}',");
                //        sb.AppendLine("                template: function(dataItem) {");
                //        sb.AppendLine($"                    return dataItem.{fieldNameLowerCase} ? formatUtcToLocal(dataItem.{fieldNameLowerCase}, 'dd-MM-yyyy') : '';"); // null check
                //        sb.AppendLine("                },");
                //        sb.AppendLine("                width: '120px',");
                //        sb.AppendLine("                filterable: { cell: { operator: \"contains\" } }");
                //        sb.AppendLine("            },");
                //    }

                //    else if (field.TypeId?.ToLower() == "rating")
                //    {
                //        sb.AppendLine("                {");
                //        sb.AppendLine($"                    field: '{fieldNameLowerCase}',");
                //        sb.AppendLine($"                    title: '{fieldName}',");
                //        sb.AppendLine("                    width: '120px',");
                //        sb.AppendLine("                    template: function (dataItem) {");
                //        sb.AppendLine($"                        const val = dataItem['{fieldNameLowerCase}'] || 0;");
                //        sb.AppendLine($"                        const id = `rating_{fieldNameLowerCase}_${{dataItem.id}}`;"); // note double $ to escape for C#
                //        sb.AppendLine("                        setTimeout(function () {");
                //        sb.AppendLine("                            $(\"#\" + id).kendoRating({");
                //        sb.AppendLine("                                min: 1,");
                //        sb.AppendLine("                                max: 5,");
                //        sb.AppendLine("                                label: false,");
                //        sb.AppendLine("                                value: val,");
                //        sb.AppendLine("                                readonly: true,");
                //        sb.AppendLine("                                enabled: false");
                //        sb.AppendLine("                            });");
                //        sb.AppendLine("                        }, 0);");
                //        sb.AppendLine("                        return `<div id=\"${id}\"></div>`;");
                //        sb.AppendLine("                    },");
                //        sb.AppendLine("                    attributes: { style: \"text-align: center;\" },");
                //        sb.AppendLine("                    headerAttributes: { style: \"text-align: center;\" },");
                //        sb.AppendLine("                    filterable: { cell: { operator: \"contains\" } }");
                //        sb.AppendLine("                },");

                //    }
                //    else if (field.TypeId?.ToLower() == "colorpicker")
                //    {
                //        sb.AppendLine("            {");
                //        sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                //        sb.AppendLine($"                title: '{fieldName}',");
                //        sb.AppendLine("                width: '160px',");
                //        sb.AppendLine("                template: function (dataItem) {");
                //        sb.AppendLine($"                    var hex = dataItem['{fieldNameLowerCase}'];");
                //        sb.AppendLine("                    if (!hex || hex.trim() === '' || hex.toLowerCase() === 'transparent') {");
                //        sb.AppendLine("                        return ``;");  // empty string if no color");
                //        sb.AppendLine("                    }");
                //        sb.AppendLine("                    var knownColors = {");
                //        sb.AppendLine("                        \"#000000\": \"Black\",");
                //        sb.AppendLine("                        \"#ffffff\": \"White\",");
                //        sb.AppendLine("                        \"#ff0000\": \"Red\",");
                //        sb.AppendLine("                        \"#00ff00\": \"Lime\",");
                //        sb.AppendLine("                        \"#0000ff\": \"Blue\",");
                //        sb.AppendLine("                        \"#ffff00\": \"Yellow\",");
                //        sb.AppendLine("                        \"#00ffff\": \"Cyan\",");
                //        sb.AppendLine("                        \"#ff00ff\": \"Magenta\",");
                //        sb.AppendLine("                        \"#800000\": \"Maroon\",");
                //        sb.AppendLine("                        \"#808000\": \"Olive\"");
                //        sb.AppendLine("                    };");
                //        sb.AppendLine("                    var hexLower = hex.toLowerCase();");
                //        sb.AppendLine("                    var name = knownColors[hexLower] || hex.toUpperCase();");
                //        sb.AppendLine("                    return `<div style='display: flex; align-items: center; gap: 6px;'>` +");
                //        sb.AppendLine("                           `<div style='width: 14px; height: 14px; background-color: ${hex}; border: 1px solid #ccc;'></div>` +");
                //        sb.AppendLine("                           `<span>${name}</span>` +");
                //        sb.AppendLine("                           `</div>`;");
                //        sb.AppendLine("                },");
                //        sb.AppendLine("                attributes: { style: 'text-align: center;' },");
                //        sb.AppendLine("                headerAttributes: { style: 'text-align: center;' },");
                //        sb.AppendLine("                filterable: { cell: { operator: 'contains' } }");
                //        sb.AppendLine("            },");
                //    }



                //    else if (field.TypeId?.ToLower() == "signature")
                //    {
                //        sb.AppendLine("            {");
                //        sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                //        sb.AppendLine($"                title: '{fieldName}',");
                //        sb.AppendLine("                template: function (dataItem) {");
                //        sb.AppendLine($"                    if (dataItem.{fieldNameLowerCase}Base64) {{");
                //        sb.AppendLine($"                        return `<img src='${{dataItem.{fieldNameLowerCase}Base64}}' alt='Signature' style='height:60px;' />`; ");
                //        sb.AppendLine("                    } else {");
                //        sb.AppendLine("                        return 'No Signature';");
                //        sb.AppendLine("                    }");
                //        sb.AppendLine("                },");
                //        sb.AppendLine("                width: '150px',");
                //        sb.AppendLine("                filterable: false");
                //        sb.AppendLine("            },");
                //    }

                //    else if (field.TypeId?.ToLower() == "image")
                //    {
                //        sb.AppendLine("            {");
                //        sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                //        sb.AppendLine($"                title: '{fieldName}',");
                //        sb.AppendLine("                template: function (dataItem) {");
                //        sb.AppendLine($"                    if (dataItem.{fieldNameLowerCase}) {{");
                //        sb.AppendLine($"                        return \"<img src='data:image/png;base64,\" + dataItem.{fieldNameLowerCase} + \"' width='80' height='80' style='object-fit:cover;border-radius:6px;' />\";");
                //        sb.AppendLine("                    } else {");
                //        sb.AppendLine("                        return '<span style=\"color:#888;\">No Image</span>';");
                //        sb.AppendLine("                    }");
                //        sb.AppendLine("                },");
                //        sb.AppendLine("                width: '150px',");
                //        sb.AppendLine("                filterable: false");
                //        sb.AppendLine("            },");
                //    }
                //    //else if (field.TypeId?.ToLower() == "dropdown")
                //    //{
                //    //    sb.AppendLine("            {");
                //    //    sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                //    //    sb.AppendLine($"                title: '{field}',");
                //    //    sb.AppendLine("                template: function(dataItem) {");
                //    //    sb.AppendLine($"                    return dataItem['{fieldNameLowerCase}Name'] || '';"); // Adjust 'Name' suffix as per your actual convention
                //    //    sb.AppendLine("                },");
                //    //    sb.AppendLine("                width: '150px',");
                //    //    sb.AppendLine("                filterable: { cell: { operator: \"contains\" } }");
                //    //    sb.AppendLine("            },");
                //    //}

                //    else if (field.TypeId == "timeduration")
                //    {

                //        sb.AppendLine("   {");
                //        sb.AppendLine($"    field: '{fieldNameLowerCase}',");
                //        sb.AppendLine($"    title: '{field.DisplayName}',");
                //        sb.AppendLine("    width: '120px',");
                //        sb.AppendLine("    template: function(dataItem) {");
                //        sb.AppendLine($"        if (!dataItem.{fieldNameLowerCase}) return '';");
                //        sb.AppendLine();
                //        sb.AppendLine($"        var parts = dataItem.{fieldNameLowerCase}.split(':');");
                //        sb.AppendLine();
                //        sb.AppendLine("        var hh = parts[0] ? parts[0].toString().padStart(2, '0') + \" Hours\" : \"00\";");
                //        sb.AppendLine("        var mm = parts[1] ? parts[1].toString().padStart(2, '0') + \" Minutes\" : \"00\";");
                //        sb.AppendLine("        var ss = parts[2] ? parts[2].toString().padStart(2, '0') + \" Seconds\" : \"00\";");
                //        sb.AppendLine();
                //        sb.AppendLine("        return hh + \" : \" + mm + \" : \" + ss;");
                //        sb.AppendLine("    },");
                //        sb.AppendLine("    filterable: { cell: { operator: \"contains\" } }");
                //        sb.AppendLine("},");


                //    }

                //    else
                //    {
                //        sb.AppendLine($"            {{ field: '{fieldNameLowerCase}', title: '{(field.DisplayName ?? "").Trim()}', width: '120px',   filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                //        //sb.AppendLine("                filterable: { cell: { operator: \"contains\" } }");
                //    }
                //    if (Regex.IsMatch(fieldNameLowerCase, @"Id$", RegexOptions.IgnoreCase))
                //    {
                //        continue;
                //    }

                //}
                foreach (var field in displayfields)
                {
                    //    var fieldName = (field.FieldName ?? "").Trim();
                    //    var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                    //    var fieldNameLowerCase = JsonSerializer.Serialize(
                    //  string.IsNullOrEmpty(fieldName) ? fieldName :
                    //  (fieldName.All(char.IsUpper) ? fieldName.ToLower() :
                    //  (fieldName.TakeWhile(char.IsUpper).Count() <= 1 ? char.ToLower(fieldName[0]) + fieldName.Substring(1) :
                    //  fieldName.Substring(0, fieldName.TakeWhile(char.IsUpper).Count() - 1).ToLower() + fieldName.Substring(fieldName.TakeWhile(char.IsUpper).Count() - 1)))
                    //);
                    //fieldNameLowerCase = fieldNameLowerCase.Substring(1, fieldNameLowerCase.Length - 2);
                    var fieldName = (field.FieldName ?? "").Trim();
                    //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
    

                    // Skip fields ending with "Id"
                    if (Regex.IsMatch(fieldNameLowerCase, @"Id$", RegexOptions.IgnoreCase))
                        continue;

                    // Parse TypeId into enum safely
                    if (!Enum.TryParse<FieldTypeEnums>(field.TypeId, true, out var fieldType))
                        fieldType = FieldTypeEnums.Unknown; // default if parsing fails

                    switch (fieldType)
                    {
                        case FieldTypeEnums.DropDown when field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName):
                            {
                                var sourceTable = (field.SourceTableName ?? "").Trim(); // e.g., "Location"
                                var displayField = $"{fieldNameLowerCase}_{sourceTable}"; // Corrected: use lowercase field name

                                sb.AppendLine($"            {{ field: '{displayField}', title: '{field.DisplayName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                dropdownCounter++;
                                break;
                            }
                        case FieldTypeEnums.Radiogroup when field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName):
                            {
                                var sourceTable = (field.SourceTableName ?? "").Trim(); // e.g., "Location"
                                var displayField = $"{fieldNameLowerCase}_{sourceTable}"; // Corrected: use lowercase field name

                                //sb.AppendLine($"            {{ field: '{displayField}', title: '{fieldName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                sb.AppendLine($"            {{ field: '{fieldNameLowerCase}_{sourceTable}', title: '{field.DisplayName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                dropdownCounter++;
                                break;
                            }

                        case FieldTypeEnums.Checkboxgroup when field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName):
                            {
                                var SourceTableName = char.ToLower(field.SourceTableName[0]) + field.SourceTableName[1..];
                                //var SourceTableNameLowerCase = char.ToLower(SourceTableName[0]) + SourceTableName[1..];

                                sb.AppendLine($"            {{ field: '{fieldNameLowerCase}_{SourceTableName}', title: '{field.DisplayName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                break;
                            }

                        case FieldTypeEnums.Multiselect when field.SourceTableId > 0 && !string.IsNullOrWhiteSpace(field.SourceTableName):
                            {
                                var SourceTableName = char.ToLower(field.SourceTableName[0]) + field.SourceTableName[1..];
                                //var SourceTableNameLowerCase = char.ToLower(SourceTableName[0]) + SourceTableName[1..];

                                sb.AppendLine($"            {{ field: '{fieldNameLowerCase}_{SourceTableName}', title: '{field.DisplayName}', width: '120px', filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                break;
                            }

                        case FieldTypeEnums.Richtexteditor:
                            {
                                sb.AppendLine("        {");
                                sb.AppendLine($"            field: '{fieldNameLowerCase}',");
                                sb.AppendLine($"            title: '{field.DisplayName}',");
                                sb.AppendLine("            width: '80px',");
                                sb.AppendLine("            template: function(dataItem) {");
                                sb.AppendLine($"                const rawHtml = dataItem.{fieldNameLowerCase} || '';");
                                sb.AppendLine("    const hasContent = rawHtml.replace(/<[^>]*>/g, '').trim() !== '';");
                                sb.AppendLine("    if (!hasContent) {");
                                sb.AppendLine("        return '';");
                                sb.AppendLine("    }");
                                sb.AppendLine("                const encoded = encodeURIComponent(rawHtml);");
                                sb.AppendLine("                return `");
                                sb.AppendLine("                    <div style=\"display: flex; justify-content: center; align-items: center; height: 100%;\">");
                                sb.AppendLine($"                        <button class=\"btn btn-success preview-button btn-sm {fieldNameLowerCase}preview-btn\"");
                                sb.AppendLine("                                title=\"Preview\"");
                                sb.AppendLine("                                data-richtext=\"${encoded}\"");
                                sb.AppendLine("                                style=\"min-width: 40px;\">");
                                sb.AppendLine("                            <i class=\"k-icon k-font-icon k-i-eye\"></i>");
                                sb.AppendLine("                        </button>");
                                sb.AppendLine("                    </div>`;");
                                sb.AppendLine("            },");
                                sb.AppendLine("            filterable: { cell: { operator: \"contains\" } }");
                                sb.AppendLine("        },");
                                break;
                            }

                        case FieldTypeEnums.Datetime:
                            {
                                sb.AppendLine("            {");
                                sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                                sb.AppendLine($"                title: '{field.DisplayName}',");
                                sb.AppendLine("                template: function(dataItem) {");
                                sb.AppendLine($"                    return dataItem.{fieldNameLowerCase} ? formatUtcToLocal(dataItem.{fieldNameLowerCase}, 'MM/dd/yyyy hh:mm tt') : '';"); // null check
                                sb.AppendLine("                },");
                                sb.AppendLine("                width: '150px',");
                                sb.AppendLine("                filterable: { cell: { operator: \"contains\" } }");
                                sb.AppendLine("            },");
                                break;
                            }

                        case FieldTypeEnums.Date:
                            {
                                sb.AppendLine("            {");
                                sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                                sb.AppendLine($"                title: '{field.DisplayName}',");
                                sb.AppendLine("                template: function(dataItem) {");
                                sb.AppendLine($"                    return dataItem.{fieldNameLowerCase} ? formatUtcToLocal(dataItem.{fieldNameLowerCase}, 'MM/dd/yyyy') : '';"); // null check
                                sb.AppendLine("                },");
                                sb.AppendLine("                width: '120px',");
                                sb.AppendLine("                filterable: { cell: { operator: \"contains\" } }");
                                sb.AppendLine("            },");
                                break;
                            }

                        case FieldTypeEnums.Rating:
                            {
                                sb.AppendLine("                {");
                                sb.AppendLine($"                    field: '{fieldNameLowerCase}',");
                                sb.AppendLine($"                    title: '{fieldName}',");
                                sb.AppendLine("                    width: '120px',");
                                sb.AppendLine("                    template: function (dataItem) {");
                                //sb.AppendLine($"                        const val = dataItem['{fieldNameLowerCase}'] || 0;");
                                //sb.AppendLine($"                        const id = `rating_{fieldNameLowerCase}_${{dataItem.id}}`;");
                                sb.AppendLine($"                        const val = dataItem['{fieldNameLowerCase}'];");
                                sb.AppendLine($"                        const id = `rating_{fieldNameLowerCase}_${{dataItem.id}}`;");
                                sb.AppendLine("");
                                sb.AppendLine("                        if (val == null|| val === 0) {");
                                sb.AppendLine("                            return `<span></span>`;");
                                sb.AppendLine("                        }");
                                sb.AppendLine("");
                                sb.AppendLine("                        setTimeout(function () {");
                                sb.AppendLine("                            $(\"#\" + id).kendoRating({");
                                sb.AppendLine("                                min: 1,");
                                sb.AppendLine("                                max: 5,");
                                sb.AppendLine("                                label: false,");
                                sb.AppendLine("                                value: val,");
                                sb.AppendLine("                                readonly: true,");
                                sb.AppendLine("                                enabled: false");
                                sb.AppendLine("                            });");
                                sb.AppendLine("                        }, 0);");
                                sb.AppendLine("");
                                sb.AppendLine("                        return `<div id=\"${id}\"></div>`;");
                                sb.AppendLine("                    },");
                                sb.AppendLine("                    attributes: { style: \"text-align: center;\" },");
                                sb.AppendLine("                    headerAttributes: { style: \"text-align: center;\" },");
                                sb.AppendLine("                    filterable: { cell: { operator: \"contains\" } }");
                                sb.AppendLine("                },");
                                break;
                            }
                        case FieldTypeEnums.Barcode:
                            {
                                sb.AppendLine("            {");
                                sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                                sb.AppendLine($"                title: '{field.DisplayName}',");
                                sb.AppendLine("                width: '160px',");
                                sb.AppendLine("                template: function(dataItem) {");
                                sb.AppendLine($"                    var value = dataItem['{fieldNameLowerCase}'];");
                                sb.AppendLine("                    if (!value || value.toString().trim() === '') return '';");

                                sb.AppendLine($"                    var uid = dataItem.id || kendo.guid();");
                                sb.AppendLine($"                    var elementId = 'bc_{fieldNameLowerCase}_' + uid;");

                                // Barcode type mapping
                                sb.AppendLine("                    var typeMap = {");
                                sb.AppendLine("                        'CODE128': 'Code128',");
                                sb.AppendLine("                        'CODE39': 'Code39',");
                                sb.AppendLine("                        'CODE93': 'Code93',");
                                sb.AppendLine("                        'QRCODE': 'QRCode',");
                                sb.AppendLine("                        'QR': 'QRCode'");
                                sb.AppendLine("                    };");

                                // Auto detect QR from field name or use configured type
                                sb.AppendLine($"                    var rawType = window['{fieldNameLowerCase}_barcodeType'] || (/qr/i.test('{fieldNameLowerCase}') ? 'QRCODE' : null) || 'CODE128';");
                                sb.AppendLine("                    rawType = rawType.toUpperCase();");
                                sb.AppendLine("                    var kendoType = typeMap[rawType] || 'Code128';");

                                // Render after Kendo row DOM exists
                                sb.AppendLine("                    setTimeout(function(){");
                                sb.AppendLine("                        var el = $('#' + elementId);");
                                sb.AppendLine("                        if (!el.length) return;");

                                // QR rendering
                                sb.AppendLine("                        if (kendoType === 'QRCode') {");
                                sb.AppendLine("                            el.kendoQRCode({");
                                sb.AppendLine("                                value: String(value),");
                                sb.AppendLine("                                size: 80,");
                                sb.AppendLine("                                renderAs: 'svg',");
                                sb.AppendLine("                                errorCorrection: 'M'");
                                sb.AppendLine("                            });");
                                sb.AppendLine("                        } else {");
                                sb.AppendLine("                            el.kendoBarcode({");
                                sb.AppendLine("                                value: String(value),");
                                sb.AppendLine("                                type: kendoType,");
                                sb.AppendLine("                                width: 140,");
                                sb.AppendLine("                                height: 60,");
                                sb.AppendLine("                                renderAs: 'svg',");
                                sb.AppendLine("                                text: { visible: true, font: '10px Arial' }");
                                sb.AppendLine("                            });");
                                sb.AppendLine("                        }");
                                sb.AppendLine("                    }, 0);");

                                sb.AppendLine("                    return `<div id='${elementId}' style='text-align:center;'></div>`;");
                                sb.AppendLine("                },");
                                sb.AppendLine("                attributes: { style: 'text-align:center;' },");
                                sb.AppendLine("                headerAttributes: { style: 'text-align:center;' }");
                                sb.AppendLine("            },");
                                break;
                            }






                        case FieldTypeEnums.Colorpicker:
                            {
                                sb.AppendLine("            {");
                                sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                                sb.AppendLine($"                title: '{field.DisplayName}',");
                                sb.AppendLine("                width: '160px',");
                                sb.AppendLine("                template: function (dataItem) {");
                                sb.AppendLine($"                    var hex = dataItem['{fieldNameLowerCase}'];");
                                sb.AppendLine("                    if (!hex || hex.trim() === '' || hex.toLowerCase() === 'transparent') {");
                                sb.AppendLine("                        return ``;");  // empty string if no color");
                                sb.AppendLine("                    }");
                                sb.AppendLine("                    var knownColors = {");
                                sb.AppendLine("                        \"#000000\": \"Black\",");
                                sb.AppendLine("                        \"#ffffff\": \"White\",");
                                sb.AppendLine("                        \"#ff0000\": \"Red\",");
                                sb.AppendLine("                        \"#00ff00\": \"Lime\",");
                                sb.AppendLine("                        \"#0000ff\": \"Blue\",");
                                sb.AppendLine("                        \"#ffff00\": \"Yellow\",");
                                sb.AppendLine("                        \"#00ffff\": \"Cyan\",");
                                sb.AppendLine("                        \"#ff00ff\": \"Magenta\",");
                                sb.AppendLine("                        \"#800000\": \"Maroon\",");
                                sb.AppendLine("                        \"#808000\": \"Olive\"");
                                sb.AppendLine("                    };");
                                sb.AppendLine("                    var hexLower = hex.toLowerCase();");
                                sb.AppendLine("                    var name = knownColors[hexLower] || hex.toUpperCase();");
                                sb.AppendLine("                    return `<div style='display: flex; align-items: center; gap: 6px;'>` +");
                                sb.AppendLine("                           `<div style='width: 14px; height: 14px; background-color: ${hex}; border: 1px solid #ccc;'></div>` +");
                                sb.AppendLine("                           `<span>${name}</span>` +");
                                sb.AppendLine("                           `</div>`;");
                                sb.AppendLine("                },");
                                sb.AppendLine("                attributes: { style: 'text-align: center;' },");
                                sb.AppendLine("                headerAttributes: { style: 'text-align: center;' },");
                                sb.AppendLine("                filterable: { cell: { operator: 'contains' } }");
                                sb.AppendLine("            },");
                                break;
                            }

                        case FieldTypeEnums.Signature:
                            {
                                sb.AppendLine("            {");
                                sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                                sb.AppendLine($"                title: '{field.DisplayName}',");
                                sb.AppendLine("                template: function (dataItem) {");
                                sb.AppendLine($"                    if (dataItem.{fieldNameLowerCase}Base64) {{");
                                sb.AppendLine($"                        return `<img src='${{dataItem.{fieldNameLowerCase}Base64}}' alt='Signature' style='height:60px;' />`; ");
                                sb.AppendLine("                    } else {");
                                sb.AppendLine("                        return 'No Signature';");
                                sb.AppendLine("                    }");
                                sb.AppendLine("                },");
                                sb.AppendLine("                width: '150px',");
                                sb.AppendLine("                filterable: false");
                                sb.AppendLine("            },");
                                break;
                            }

                        case FieldTypeEnums.Image:
                            {
                                sb.AppendLine("            {");
                                sb.AppendLine($"                field: '{fieldNameLowerCase}',");
                                sb.AppendLine($"                title: '{field.DisplayName}',");
                                sb.AppendLine("                template: function (dataItem) {");
                                //sb.AppendLine($"                    if (dataItem.{fieldNameLowerCase}) {{");
                                //sb.AppendLine($"                        return \"<img src='data:image/png;base64,\" + dataItem.{fieldNameLowerCase} + \"' width='80' height='80' style='object-fit:cover;border-radius:6px;' />\";");
                                //sb.AppendLine("                    } else {");
                                //sb.AppendLine("                        return '<span style=\"color:#888;\">No Image</span>';");
                                //sb.AppendLine("                    }");
                                sb.AppendLine($"                    if (dataItem.{fieldNameLowerCase}) {{");
                                sb.AppendLine($"                        const encodedImage = encodeURIComponent(dataItem.{fieldNameLowerCase});");
                                sb.AppendLine("                        return `");
                                sb.AppendLine("                            <div style=\"display: flex; justify-content: center; align-items: center;\">");
                                sb.AppendLine($"                                <button class=\"btn btn-success preview-btn btn-sm {fieldNameLowerCase}preview-btn\"");
                                sb.AppendLine("                                        data-image=\"${encodedImage}\"");
                                sb.AppendLine("                                        title=\"Preview Image\"");
                                sb.AppendLine("                                        style=\"min-width: 40px;\">");
                                sb.AppendLine("                                    <i class=\"k-icon k-font-icon k-i-eye\"></i>");
                                sb.AppendLine("                                </button>");
                                sb.AppendLine("                            </div>`;");
                                sb.AppendLine("                    } else {");
                                sb.AppendLine("return `<div style=\"display: flex; justify-content: center; align-items: center;\"></div>`;");
                                sb.AppendLine("}");
                                sb.AppendLine("                },");
                                sb.AppendLine("                width: '150px',");
                                sb.AppendLine("                filterable: false");
                                sb.AppendLine("            },");
                                break;
                            }

                        case FieldTypeEnums.Timeduration:
                            {
                                sb.AppendLine("   {");
                                sb.AppendLine($"    field: '{fieldNameLowerCase}',");
                                sb.AppendLine($"    title: '{field.DisplayName}',");
                                sb.AppendLine("    width: '120px',");
                                sb.AppendLine("    template: function(dataItem) {");
                                sb.AppendLine($"        if (!dataItem.{fieldNameLowerCase}) return '';");
                                sb.AppendLine();
                                sb.AppendLine($"        var parts = dataItem.{fieldNameLowerCase}.split(':');");
                                sb.AppendLine();
                                sb.AppendLine("        var hh = parts[0] ? parts[0].toString().padStart(2, '0') + \" Hours\" : \"00\";");
                                sb.AppendLine("        var mm = parts[1] ? parts[1].toString().padStart(2, '0') + \" Minutes\" : \"00\";");
                                sb.AppendLine("        var ss = parts[2] ? parts[2].toString().padStart(2, '0') + \" Seconds\" : \"00\";");
                                sb.AppendLine();
                                sb.AppendLine("        return hh + \" : \" + mm + \" : \" + ss;");
                                sb.AppendLine("    },");
                                sb.AppendLine("    filterable: { cell: { operator: \"contains\" } }");
                                sb.AppendLine("},");
                                break;
                            }

                        default:
                            {
                                sb.AppendLine($"            {{ field: '{fieldNameLowerCase}', title: '{(field.DisplayName ?? "").Trim()}', width: '120px',   filterable: {{ cell: {{ operator: \"contains\" }} }} }},");
                                break;
                            }
                    }
                }

                sb.AppendLine("        ]");
                sb.AppendLine("    });");
                sb.AppendLine("}");

                foreach (var field in displayfields)
                {
                    if (!Enum.TryParse<FieldTypeEnums>(field.TypeId, true, out var fieldType))
                    {
                        // fallback (if unknown type) -> treat as default
                        fieldType = default;
                    }
                    var fieldName = (field.FieldName ?? "").Trim();
                    //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    if (fieldType == FieldTypeEnums.Richtexteditor)
                    {
                        sb.AppendLine($"  var {fieldNameLowerCase}richTextWindow;");
                        sb.AppendLine($"    $('#{tableName}Grid').on('click', '.{fieldNameLowerCase}preview-btn', function (e) {{");
                        sb.AppendLine("      e.preventDefault();");
                        sb.AppendLine($"      const item = $('#{tableName}Grid').data('kendoGrid').dataItem($(this).closest('tr'));");
                        sb.AppendLine($"      {fieldNameLowerCase}showRichTextPreviewCard(decodeHtml(item.{fieldNameLowerCase} || 'No content available'));");
                        sb.AppendLine("    });");
                        sb.AppendLine();
                        sb.AppendLine($"    function {fieldNameLowerCase}showRichTextPreviewCard(content) {{");
                        sb.AppendLine($"      if (!{fieldNameLowerCase}richTextWindow) {{");
                        sb.AppendLine($"        {fieldNameLowerCase}richTextWindow = $(\"#{fieldNameLowerCase}richTextPreviewWindow\").kendoWindow({{");
                        sb.AppendLine("          width: \"800px\", height: \"auto\", modal: true, visible: false,");
                        sb.AppendLine("          actions: [\"Maximize\", \"Close\"], resizable: true,");
                        sb.AppendLine($"          title: \"{field.DisplayName}\",");
                        sb.AppendLine($"          activate: {fieldNameLowerCase}adjustRichTextWindow, maximize: {fieldNameLowerCase}adjustRichTextWindow, resize: {fieldNameLowerCase}adjustRichTextWindow");
                        sb.AppendLine("        }).data(\"kendoWindow\");");
                        sb.AppendLine("      }");
                        sb.AppendLine($"      $(\"#{fieldNameLowerCase}richTextPreviewContent\").html(content);");
                        sb.AppendLine($"      {fieldNameLowerCase}richTextWindow.center().open();");
                        sb.AppendLine($"      {fieldNameLowerCase}adjustRichTextWindow();");
                        sb.AppendLine("    }");
                        sb.AppendLine();
                        sb.AppendLine($"    function {fieldNameLowerCase}adjustRichTextWindow() {{");
                        sb.AppendLine($"      const $win = $(\"#{fieldNameLowerCase}richTextPreviewWindow\").closest(\".k-window\"),");
                        sb.AppendLine($"            $content = $(\"#{fieldNameLowerCase}richTextPreviewContent\"),");
                        sb.AppendLine("            isMax = $win.hasClass(\"k-window-maximized\");");
                        sb.AppendLine("            $win.css(\"overflow\", \"hidden\");");
                        sb.AppendLine("            $windowContent.css(\"overflow\", \"hidden\");");
                        sb.AppendLine("      if (isMax) {");
                        sb.AppendLine("        const h = $(window).height();");
                        sb.AppendLine("        $content.css({");
                        sb.AppendLine("          maxHeight: (h - 90) + \"px\",");
                        sb.AppendLine("          overflowY: \"auto\", overflowX: \"hidden\"");
                        sb.AppendLine("        });");
                        sb.AppendLine("      } else {");
                        sb.AppendLine("        $content.css({");
                        sb.AppendLine("          maxHeight: \"auto\", overflow: \"visible\"");
                        sb.AppendLine("        });");
                        sb.AppendLine("      }");
                        sb.AppendLine("    }");
                        sb.AppendLine();
                        sb.AppendLine("    function decodeHtml(html) {");
                        sb.AppendLine("      const txt = document.createElement(\"textarea\");");
                        sb.AppendLine("      txt.innerHTML = html;");
                        sb.AppendLine("      return txt.value;");
                        sb.AppendLine("    }");
                    }




                    else if (fieldType == FieldTypeEnums.Image && !string.IsNullOrWhiteSpace(fieldNameLowerCase))
                    {
                        ImagePreviewScript.AppendImagePreviewScript(sb, fieldNameLowerCase ?? "", field.DisplayName ?? "", tableName);
                    }

                }



                sb.AppendLine($"$('#{tableName}Grid').on('click', '.update-btn', function () {{");
                sb.AppendLine("    var selectedRow = null;");
                //sb.AppendLine("    if (isHierarchical) {");
                //sb.AppendLine($"        var treeList = $('#{tableName}Grid').data('kendoTreeList');");
                //sb.AppendLine("        var tr = $(this).closest('tr');");
                //sb.AppendLine("        selectedRow = treeList.dataItem(tr);");
                //sb.AppendLine("        if (!selectedRow) {");
                //sb.AppendLine("            showNotification('error', 'Selected row not found.');");
                //sb.AppendLine("            return;");
                //sb.AppendLine("        }");
                //sb.AppendLine("    } else {");
                sb.AppendLine($"        var grid = $('#{tableName}Grid').data('kendoGrid');");
                sb.AppendLine("        selectedRow = grid.dataItem($(this).closest('tr'));");
                sb.AppendLine("        if (!selectedRow) {");
                sb.AppendLine("            fnShowNotification('Selected row not found.','error');");
                sb.AppendLine("            return;");
                sb.AppendLine("        }");
                //sb.AppendLine("    }");
                sb.AppendLine($"    var strURL = '/{tableName}/{firstFormName}Details?id=' + selectedRow.id;"); // <<-- FIXED HERE
                sb.AppendLine("    window.location.href = strURL;");
                sb.AppendLine("});");



                sb.AppendLine($"$('#{tableName}Grid').on('click', '.delete-btn', function () {{");
                sb.AppendLine("    var selectedRow = null;");
                //sb.AppendLine("    if (isHierarchical) {");
                //sb.AppendLine($"        var treeList = $('#{tableName}Grid').data('kendoTreeList');");
                //sb.AppendLine("        selectedRow = treeList.dataItem($(this).closest('tr'));");
                //sb.AppendLine("        if (!selectedRow) {");
                //sb.AppendLine("            showNotification('error', 'Selected node not found.');");
                //sb.AppendLine("            return;");
                //sb.AppendLine("        }");
                //sb.AppendLine("    } else {");
                sb.AppendLine($"       var grid = $('#{tableName}Grid').data('kendoGrid');");
                sb.AppendLine("        selectedRow = grid.dataItem($(this).closest('tr'));");
                sb.AppendLine("        if (!selectedRow) {");
                sb.AppendLine("            fnShowNotification('Selected row not found.','error');");
                sb.AppendLine("            return;");
                sb.AppendLine("        }");
                //sb.AppendLine("    }");
                sb.AppendLine("    if (selectedRow) {");
                sb.AppendLine("        deleteRecord(selectedRow.id);"); // ✅ FIXED  
                sb.AppendLine("    }");
                sb.AppendLine("});");
                //var tableName = "TestField"; // your dynamic table name

                //var sb = new StringBuilder();
                sb.AppendLine("function deleteRecord(id) {");
                sb.AppendLine("    if (!id) {");
                sb.AppendLine("        console.error('ID is missing or invalid.');");
                sb.AppendLine("        return false;");
                sb.AppendLine("    }");
                sb.AppendLine("");
                sb.AppendLine($"    var tableName = '{tableName}';");
                sb.AppendLine("    var grid = $('#' + tableName + 'Grid').data('kendoGrid');");
                sb.AppendLine("");
                sb.AppendLine("    // Save delete context");
                sb.AppendLine("    $('#confirmDeleteBtn').data('context', tableName).data('id', id);");
                sb.AppendLine("");
                sb.AppendLine("    $.ajax({");
                sb.AppendLine($"        url: backendUrl + '/{tableName}/references/' + id,");
                sb.AppendLine("        type: 'GET',");
                sb.AppendLine("        beforeSend: function (xhr) {");
                sb.AppendLine("            const token = localStorage.getItem('jwtToken');");
                sb.AppendLine("            if (token) xhr.setRequestHeader('Authorization', 'Bearer ' + token);");
                sb.AppendLine("        },");
                sb.AppendLine("        success: function (response) {");
                sb.AppendLine("            const hasReferences = response?.references && response.references.length > 0;");
                sb.AppendLine("            const hasChildReferences = hasReferences && response.references.some(r => r.hasChildReferences);");
                sb.AppendLine("");
                sb.AppendLine("            if (hasChildReferences) {");
                sb.AppendLine("                $('#confirmDeleteBtn').hide();");
                sb.AppendLine("                  let warningHtml = `<p class=\"notdeleteitem\">Cannot Delete Item :<br/></p>`;");
                sb.AppendLine("                  warningHtml += `<p class=\"followindrecord\">This item is linked to the following records.</p><ul>`;");            
                sb.AppendLine("                response.references.forEach(ref => {");
                sb.AppendLine("                    ref.childTableNames?.forEach(childTable => {");
                sb.AppendLine("                        warningHtml += `<li><b>${childTable}</b>`;");
                sb.AppendLine("                        let innerList = '';");
                sb.AppendLine("                        const names = ref.namesByTable?.[childTable];");
                sb.AppendLine("                        if (names?.length > 0) { innerList += '<ul>'; names.forEach(name => innerList += `<li>${name}</li>`); innerList += '</ul>'; }");
                sb.AppendLine("                        const docNames = ref.documentName;");
                sb.AppendLine("                        if (docNames?.length > 0) { innerList += '<ul>'; docNames.forEach(doc => innerList += `<li>${doc}</li>`); innerList += '</ul>'; }");
                sb.AppendLine("                        warningHtml += innerList + '</li>';");
                sb.AppendLine("                    });");
                sb.AppendLine("                });");
                sb.AppendLine("                warningHtml += `<span class=\"removeref\">Please remove these references before deleting this record.</span>`;");
                sb.AppendLine("                $('#relatedRecordsWarning').html(warningHtml);");
                sb.AppendLine("                $('#ConfirmMessage').hide();");
                sb.AppendLine("                deleteWindow.center().open();");
                sb.AppendLine("            } else {");
                sb.AppendLine("                $('#confirmDeleteBtn').show();");
                sb.AppendLine("                $('#relatedRecordsWarning').html(\"<p class='text-success'>No related references found.</p>\");");
                sb.AppendLine("                $('#ConfirmMessage').show();");
                sb.AppendLine("                deleteWindow.center().open();");
                sb.AppendLine("");
                sb.AppendLine("                $('#confirmDeleteBtn').off('click').on('click', function () {");
                sb.AppendLine("                    $.ajax({");
                sb.AppendLine("                        url: backendUrl + '/' + tableName.toLowerCase() + '/' + id,");
                sb.AppendLine("                        type: 'DELETE',");
                sb.AppendLine("                        beforeSend: function (xhr) {");
                sb.AppendLine("                            const token = localStorage.getItem('jwtToken');");
                sb.AppendLine("                            if (token) xhr.setRequestHeader('Authorization', 'Bearer ' + token);");
                sb.AppendLine("                        },");
                sb.AppendLine("                        success: function () {");
                sb.AppendLine("                            fnShowNotification('Record deleted successfully.','success');");
                sb.AppendLine("                            deleteWindow.close();");
                sb.AppendLine("                            setTimeout(() => location.reload(), 200);");
                sb.AppendLine("                        },");
                sb.AppendLine("                        error: function () {");
                sb.AppendLine("                            fnShowNotification('Error deleting record.', 'error');");
                sb.AppendLine("                        }");
                sb.AppendLine("                    });");
                sb.AppendLine("                });");
                sb.AppendLine("            }");
                sb.AppendLine("        },");
                sb.AppendLine("        error: function () {");
                sb.AppendLine("            fnShowNotification('Error verifying references.', 'error');");
                sb.AppendLine("        }");
                sb.AppendLine("    });");
                sb.AppendLine("    return false;");
                sb.AppendLine("}");

                //sb.AppendLine("function deleteRecord(id) {");
                //sb.AppendLine("    if (!id) {");
                //sb.AppendLine("        console.error('ID is missing or invalid.');");
                //sb.AppendLine("        return false;");
                //sb.AppendLine("    }");
                //sb.AppendLine($"    var tableName = '{tableName}';");
                //sb.AppendLine($"    var grid = $('#' + tableName + 'Grid').data('kendoGrid');");
                //sb.AppendLine();
                //sb.AppendLine("    $.ajax({");
                //sb.AppendLine($"        url: backendUrl + '/' + tableName.toLowerCase() + '/references/' + id,");
                //sb.AppendLine("        type: 'GET',");
                //sb.AppendLine("        beforeSend: function (xhr) {");
                //sb.AppendLine("            const token = localStorage.getItem('jwtToken');");
                //sb.AppendLine("            if (token) { xhr.setRequestHeader('Authorization', 'Bearer ' + token); }");
                //sb.AppendLine("        },");
                //sb.AppendLine("        success: function (response) {");
                //sb.AppendLine("            if (response && response.references && response.references.length > 0) {");
                //sb.AppendLine("                const hasChildReferences = response.references.some(r => r.hasChildReferences);");
                //sb.AppendLine();
                //sb.AppendLine("                if (hasChildReferences) {");
                //sb.AppendLine("                    $('#confirmDeleteBtn').hide();");
                //sb.AppendLine("                    let warningHtml = `<p><b>${response.message || 'Cannot delete this record.'}</b></p>`;");
                //sb.AppendLine("                    warningHtml += `<p>This item is linked to the following records and cannot be deleted:</p><ul>`;");
                //sb.AppendLine("                    response.references.forEach(ref => {");
                //sb.AppendLine("                        ref.childTableNames?.forEach(childTable => {");
                //sb.AppendLine("                            warningHtml += `<li><b>${childTable}</b>`;");
                //sb.AppendLine("                            let innerList = '';");
                //sb.AppendLine("                            const names = ref.namesByTable?.[childTable];");
                //sb.AppendLine("                            if (names?.length > 0) { innerList += '<ul>'; names.forEach(name => innerList += `<li>${name}</li>`); innerList += '</ul>'; }");
                ////sb.AppendLine("                            if (childTable === 'TestFieldMasterFormDocument') {");
                //sb.AppendLine("                                const docNames = ref.documentName;");
                //sb.AppendLine("                                if (docNames?.length > 0) { innerList += '<ul>'; docNames.forEach(doc => innerList += `<li>${doc}</li>`); innerList += '</ul>'; }");
                ////sb.AppendLine("                            }");
                //sb.AppendLine("                            warningHtml += innerList + '</li>';");
                //sb.AppendLine("                        });");
                //sb.AppendLine("                    });");
                //sb.AppendLine("                    warningHtml += `</ul><p>Please remove these references before deleting this record.</p>`;");
                //sb.AppendLine("                    $('#relatedRecordsWarning').html(warningHtml);");
                //sb.AppendLine("                    $('#ConfirmMessage').hide();");
                //sb.AppendLine("                    deleteWindow.center().open();");
                //sb.AppendLine("                } else {");
                //sb.AppendLine("                    $('#confirmDeleteBtn').show();");
                //sb.AppendLine("                    $('#relatedRecordsWarning').html(\"<p class='text-success'>No related references found. You can safely delete this record.</p>\");");
                //sb.AppendLine("                    $('#ConfirmMessage').show();");
                //sb.AppendLine("                    deleteWindow.center().open();");
                //sb.AppendLine("                    $('#confirmDeleteBtn').off('click').on('click', function () {");
                //sb.AppendLine("                        $.ajax({");
                //sb.AppendLine($"                            url: backendUrl + '/' + tableName.toLowerCase() + '/' + id,");
                //sb.AppendLine("                            type: 'DELETE',");
                //sb.AppendLine("                            beforeSend: function (xhr) {");
                //sb.AppendLine("                                const token = localStorage.getItem('jwtToken');");
                //sb.AppendLine("                                if (token) { xhr.setRequestHeader('Authorization', 'Bearer ' + token); }");
                //sb.AppendLine("                            },");
                //sb.AppendLine("                            success: function () {");
                //sb.AppendLine("                                showNotification('Record deleted successfully.', 'success');");
                //sb.AppendLine("                                deleteWindow.close();");
                //sb.AppendLine("                                grid.dataSource.read();");
                //sb.AppendLine("                                setTimeout(() => location.reload(), 200);");
                //sb.AppendLine("                            },");
                //sb.AppendLine("                            error: function () { showNotification('Error deleting record.', 'error'); }");
                //sb.AppendLine("                        });");
                //sb.AppendLine("                    });");
                //sb.AppendLine("                }");
                //sb.AppendLine("            } else {");
                //sb.AppendLine("                $('#confirmDeleteBtn').show();");
                //sb.AppendLine("                $('#relatedRecordsWarning').html(\"<p class='text-success'>No related references found. You can safely delete this record.</p>\");");
                //sb.AppendLine("                $('#ConfirmMessage').show();");
                //sb.AppendLine("                deleteWindow.center().open();");
                //sb.AppendLine("            }");
                //sb.AppendLine("        },");
                //sb.AppendLine("        error: function () { showNotification('Error verifying references.', 'error'); }");
                //sb.AppendLine("    });");
                //sb.AppendLine("    return false;");
                //sb.AppendLine("}");

                //sb.AppendLine($"function deleteRecord(id) {{");
                //sb.AppendLine("    if (!id) {");
                //sb.AppendLine("        console.error('ID is missing or invalid.');");
                //sb.AppendLine("        return false;");
                //sb.AppendLine("    }");
                //sb.AppendLine("");
                //sb.AppendLine($"    var tableName = '{tableName}';");
                //sb.AppendLine("    var grid = $('#' + tableName + 'Grid').data('kendoGrid');");
                //sb.AppendLine("");
                //sb.AppendLine("    $.ajax({");
                //sb.AppendLine("        url: backendUrl + '/' + tableName.toLowerCase() + '/references/' + id,");
                //sb.AppendLine("        type: 'GET',");
                //sb.AppendLine("        beforeSend: function (xhr) {");
                //sb.AppendLine("            const token = localStorage.getItem('jwtToken');");
                //sb.AppendLine("            if (token) { xhr.setRequestHeader('Authorization', 'Bearer ' + token); }");
                //sb.AppendLine("        },");
                //sb.AppendLine("        success: function (response) {");
                //sb.AppendLine("            let warningHtml = '';");
                //sb.AppendLine("if (response && response.reference && response.reference.hasChildReferences) {");

                //sb.AppendLine("    $('#confirmDeleteBtn').hide();");
                //sb.AppendLine("    warningHtml = `<p><b>${response.message || 'Cannot delete this record.'}</b></p>`;");
                //sb.AppendLine("    warningHtml += `<p>This item is linked to the following records and cannot be deleted:</p><ul>`;");

                //sb.AppendLine("    if (response.reference.childTableNames && response.reference.childTableNames.length > 0) {");
                //sb.AppendLine("        response.reference.childTableNames.forEach(childTable => {");
                //sb.AppendLine("            warningHtml += `<li><b>${childTable}</b></li><ul>`;");

                //sb.AppendLine("            // 🔹 Render record names from namesByTable");
                //sb.AppendLine("            const names = response.reference.namesByTable && response.reference.namesByTable[childTable];");
                //sb.AppendLine("            if (names && names.length > 0) {");
                //sb.AppendLine("                names.forEach(name => {");
                //sb.AppendLine("                    warningHtml += `<li>${name}</li>`;");
                //sb.AppendLine("                });");
                //sb.AppendLine("            }");

                //sb.AppendLine("            // Optional: document name if exists");
                //sb.AppendLine("            const docNames = response.reference.documentName;");
                //sb.AppendLine("                if (docNames) {");
                //sb.AppendLine("                     if (Array.isArray(docNames)) {");
                //sb.AppendLine("                         docNames.forEach(doc => {");
                //sb.AppendLine("                             warningHtml += `<li>${doc}</li>`;");
                //sb.AppendLine("                         });");
                //sb.AppendLine("                      } else {");
                //sb.AppendLine("                         warningHtml += `<li>${docNames}</li>`;");
                //sb.AppendLine("                        }");
                //sb.AppendLine("            }");

                //sb.AppendLine("            warningHtml += `</ul>`;");
                //sb.AppendLine("        });");
                //sb.AppendLine("    }");

                //sb.AppendLine("    warningHtml += `</ul><p>Please remove these references before deleting this record.</p>`;");
                //sb.AppendLine("    $('#relatedRecordsWarning').html(warningHtml);");
                //sb.AppendLine("    $('#ConfirmMessage').hide();");
                //sb.AppendLine("    deleteWindow.center().open();");
                //sb.AppendLine("            } else {");
                //sb.AppendLine("                $('#confirmDeleteBtn').show();");
                //sb.AppendLine("                warningHtml = `<p class='text-success'>No related references found. You can safely delete this record.</p>`;");
                //sb.AppendLine("                $('#relatedRecordsWarning').html(warningHtml);");
                //sb.AppendLine("                $('#ConfirmMessage').show();");
                //sb.AppendLine("                deleteWindow.center().open();");
                //sb.AppendLine("");
                //sb.AppendLine("                $('#confirmDeleteBtn').off('click').on('click', function () {");
                //sb.AppendLine("                    $.ajax({");
                //sb.AppendLine("                        url: backendUrl + '/' + tableName.toLowerCase() + '/' + id,");
                //sb.AppendLine("                        type: 'DELETE',");
                //sb.AppendLine("                        beforeSend: function (xhr) {");
                //sb.AppendLine("                            const token = localStorage.getItem('jwtToken');");
                //sb.AppendLine("                            if (token) { xhr.setRequestHeader('Authorization', 'Bearer ' + token); }");
                //sb.AppendLine("                        },");
                //sb.AppendLine("                        success: function () {");
                //sb.AppendLine("                            showNotification('Record deleted successfully.', 'success');");
                //sb.AppendLine("                            deleteWindow.close();");
                //sb.AppendLine("                            grid.dataSource.read();");
                //sb.AppendLine("                              setTimeout(function() {");
                //sb.AppendLine("                                  location.reload();");
                //sb.AppendLine("                                }, 200);");
                //sb.AppendLine("                        },");
                //sb.AppendLine("                        error: function () {");
                //sb.AppendLine("                            showNotification('Error deleting record.', 'error');");
                //sb.AppendLine("                        }");
                //sb.AppendLine("                    });");
                //sb.AppendLine("                });");
                //sb.AppendLine("            }");
                //sb.AppendLine("        },");
                //sb.AppendLine("        error: function () {");
                //sb.AppendLine("            showNotification('Error verifying references.', 'error');");
                //sb.AppendLine("        }");
                //sb.AppendLine("    });");
                //sb.AppendLine("");
                //sb.AppendLine("    return false;");
                //sb.AppendLine("}");

                //sb.AppendLine($"function deleteRecord(id) {{");
                //sb.AppendLine("    if (!id) {");
                //sb.AppendLine("        console.error('ID is missing or invalid.');");
                //sb.AppendLine("        return false;");
                //sb.AppendLine("    }");
                //sb.AppendLine("");
                //sb.AppendLine($"    var tableName = '{tableName}';");
                //sb.AppendLine("    var grid = $('#' + tableName + 'Grid').data('kendoGrid');");
                //sb.AppendLine("");
                //sb.AppendLine("    $.ajax({");
                //sb.AppendLine("        url: backendUrl + '/' + tableName.toLowerCase() + '/references/' + id,");
                //sb.AppendLine("        type: 'GET',");
                //sb.AppendLine("        beforeSend: function (xhr) {");
                //sb.AppendLine("            const token = localStorage.getItem('jwtToken');");
                //sb.AppendLine("            if (token) { xhr.setRequestHeader('Authorization', 'Bearer ' + token); }");
                //sb.AppendLine("        },");
                //sb.AppendLine("        success: function (response) {");
                //sb.AppendLine("            let warningHtml = '';");

                //sb.AppendLine("            if (response && response.reference && response.reference.hasChildReferences) {");
                //sb.AppendLine("                $('#confirmDeleteBtn').hide();");
                //sb.AppendLine("                warningHtml = `<p><b>${response.message || 'Cannot delete this record.'}</b></p>`;");
                //sb.AppendLine("                warningHtml += `<p>This item is linked to the following records and cannot be deleted:</p><ul>`;");
                //sb.AppendLine("                if (response.reference.childTableNames && response.reference.childTableNames.length > 0) {");
                //sb.AppendLine("                    response.reference.childTableNames.forEach(childTable => {");
                //sb.AppendLine("                        warningHtml += `<li><b>${childTable}</b></li><ul>`;");
                //sb.AppendLine("                        if (response.reference.documentName) {");
                //sb.AppendLine("                            warningHtml += `<li>${response.reference.documentName}</li>`;");
                //sb.AppendLine("                        }");
                //sb.AppendLine("                        warningHtml += `</ul>`;");
                //sb.AppendLine("                    });");
                //sb.AppendLine("                }");
                //sb.AppendLine("                warningHtml += `</ul><p>Please remove these references before deleting this record.</p>`;");
                //sb.AppendLine("                $('#relatedRecordsWarning').html(warningHtml);");
                //sb.AppendLine("                $('#ConfirmMessage').hide();");
                //sb.AppendLine("                deleteWindow.center().open();");
                //sb.AppendLine("            } else {");
                //sb.AppendLine("                $('#confirmDeleteBtn').show();");
                //sb.AppendLine("                warningHtml = `<p class='text-success'>No related references found. You can safely delete this record.</p>`;");
                //sb.AppendLine("                $('#relatedRecordsWarning').html(warningHtml);");
                //sb.AppendLine("                $('#ConfirmMessage').show();");
                //sb.AppendLine("                deleteWindow.center().open();");
                //sb.AppendLine("");
                //sb.AppendLine("                $('#confirmDeleteBtn').off('click').on('click', function () {");
                //sb.AppendLine("                    $.ajax({");
                //sb.AppendLine("                        url: backendUrl + '/' + tableName.toLowerCase() + '/' + id,");
                //sb.AppendLine("                        type: 'DELETE',");
                //sb.AppendLine("                        beforeSend: function (xhr) {");
                //sb.AppendLine("                            const token = localStorage.getItem('jwtToken');");
                //sb.AppendLine("                            if (token) { xhr.setRequestHeader('Authorization', 'Bearer ' + token); }");
                //sb.AppendLine("                        },");
                //sb.AppendLine("                        success: function () {");
                //sb.AppendLine("                            showNotification('Record deleted successfully.', 'success');");
                //sb.AppendLine("                            deleteWindow.close();");
                //sb.AppendLine("                            grid.dataSource.read();");
                //sb.AppendLine("                        },");
                //sb.AppendLine("                        error: function () {");
                //sb.AppendLine("                            showNotification('Error deleting record.', 'error');");
                //sb.AppendLine("                        }");
                //sb.AppendLine("                    });");
                //sb.AppendLine("                });");
                //sb.AppendLine("            }");
                //sb.AppendLine("        },");
                //sb.AppendLine("        error: function () {");
                //sb.AppendLine("            showNotification('Error verifying references.', 'error');");
                //sb.AppendLine("        }");
                //sb.AppendLine("    });");
                //sb.AppendLine("");
                //sb.AppendLine("    return false;");
                //sb.AppendLine("}");


                //sb.AppendLine("function deleteRecord(Id) {");
                //sb.AppendLine("    if (confirm('Are you sure you want to delete this record?')) {");
                //sb.AppendLine($"        var url = backendUrl + /{tableName.ToLower()}/ + Id;");
                //sb.AppendLine("        $.ajax({");
                //sb.AppendLine("            url: url,");
                //sb.AppendLine("            type: 'DELETE',");
                //sb.AppendLine("            success: function () {");
                //sb.AppendLine("                if (isHierarchical) {");
                //sb.AppendLine($"                    const treeList = $('#{tableName}Grid').data('kendoTreeList');");
                //sb.AppendLine("                    if (treeList) {");
                //sb.AppendLine("                        treeList.dataSource.read();");
                //sb.AppendLine("                        showNotification('success', 'Record deleted successfully.');");
                //sb.AppendLine("                    }");
                //sb.AppendLine("                } else {");
                //sb.AppendLine($"                    const grid = $('#{tableName}Grid').data('kendoGrid');");
                //sb.AppendLine("                    if (grid) {");
                //sb.AppendLine("                        grid.dataSource.read();");
                //sb.AppendLine("                        showNotification('success', 'Record deleted successfully.');");
                //sb.AppendLine("                    }");
                //sb.AppendLine("                }");
                //sb.AppendLine("            },");
                //sb.AppendLine("            error: function () {");
                //sb.AppendLine("                showNotification('error', 'Error deleting record.');");
                //sb.AppendLine("            }");
                //sb.AppendLine("        });");
                //sb.AppendLine("    }");
                //sb.AppendLine("}");


                //TODO: Commenting Here Because Already Moved In Common Before If-Else
                //sb.AppendLine("function applySearchFilter() {");
                //sb.AppendLine("    var formData = {};");

                //foreach (var field in fields)
                //{
                //    var fieldNameLowerCase = char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim().Substring(1);
                //    sb.AppendLine($"    formData['{field.FieldName.Trim()}'] = ($('#{fieldNameLowerCase}').val() == null) ? \"\" : $('#{fieldNameLowerCase}').val();");
                //}

                //sb.AppendLine("    var filter = { logic: 'and', filters: [] };");
                //sb.AppendLine("    for (var fieldName in formData) {");
                //sb.AppendLine("        var fieldValue = formData[fieldName] ? formData[fieldName].trim() : '';");
                //sb.AppendLine("        if (fieldValue) {");
                //sb.AppendLine("            var criteriaElement = $('#' + fieldName.toLowerCase() + 'Criteria');");
                //sb.AppendLine("            var criteria = 'equals';");
                //sb.AppendLine("            if (criteriaElement.length > 0) {");
                //sb.AppendLine("                criteria = criteriaElement.val();");
                //sb.AppendLine("            }");
                //sb.AppendLine("            filter.filters.push({ field: fieldName, operator: criteria, value: fieldValue });");
                //sb.AppendLine("        }");
                //sb.AppendLine("    }");

                //sb.AppendLine($"        var grid = $('#{tableName}Grid').data('kendoGrid');");
                //sb.AppendLine("        grid.dataSource.filter(filter);");
                //sb.AppendLine("        grid.dataSource.read();");

                //sb.AppendLine("}"); // Close applySearchFilter()

                // <-- Missing closing brace added
            }

            //sb.AppendLine("}"); end function
            sb.AppendLine("$(document).ready(function () {");
            /*  Slider search functionality start */

            // foreach (var detailsFields in detailFields)
            foreach (var field in fields)
            {
                var fieldName = (field.FieldName ?? "").Trim();
                    if (string.IsNullOrEmpty(fieldName))
                        continue;

                    //  var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    string staticCriteriaJson = "";

                    // Try parse enum from string
                    if (!Enum.TryParse<FieldTypeEnums>(field.FieldType, true, out var fieldType))
                        continue;

                var defaultValue = !string.IsNullOrWhiteSpace(field.DefaultValue) ? (field.DefaultValue) : string.Empty;
                var finalValue = !string.IsNullOrWhiteSpace(field.DefaultValue)? field.DefaultValue: "#000000";


                //{
                //if (!Enum.TryParse<FieldTypeEnums>(detailsFields.TypeId, true, out var fieldType))
                //    fieldType = FieldTypeEnums.Unknown;

                //var fieldNameLowerCase = !string.IsNullOrWhiteSpace(detailsFields.FieldName) &&
                //                         detailsFields.FieldName.Trim().Length > 0
                //                         ? detailsFields.FieldName.Trim().ToLower()
                //                         : string.Empty;

                switch (fieldType)
                {
                  //  var defaultValue = !string.IsNullOrWhiteSpace(field.DefaultValue) ? (field.DefaultValue) : string.Empty;

                    case FieldTypeEnums.Slider:
                        sb.AppendLine($"var slider = $(\"#{fieldNameLowerCase}\").kendoSlider({{");
                       // sb.AppendLine($"    min: {detailsFields.MinValue},");
                       // sb.AppendLine($"    max: {detailsFields.MaxValue},");
                        sb.AppendLine("    tooltip: { enabled: true, template: \"#= value #\" },");
                        sb.AppendLine("    showButtons: true,");
                        sb.AppendLine("    tickPlacement: \"none\"");
                        sb.AppendLine("}).data(\"kendoSlider\");");
                        sb.AppendLine("");
                        sb.AppendLine($"let payload{fieldNameLowerCase} = {{ name: $(\"#nameInput\").val() }};");
                        sb.AppendLine("if ($(\"#isfilter\").is(\":checked\")) {");
                        sb.AppendLine($"    payload{fieldNameLowerCase}.{fieldNameLowerCase} = slider.value();");
                        sb.AppendLine("}");
                        break;

                    case FieldTypeEnums.Date:
                        sb.AppendLine($"var db{fieldNameLowerCase}=\"{defaultValue}\";");
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoDatePicker({{");
                        sb.AppendLine($" value: fromDbDateString(db{fieldNameLowerCase}),");
                        sb.AppendLine("    dateInput: true");
                        sb.AppendLine("});");
                        break;

                    case FieldTypeEnums.Datetime:
                        sb.AppendLine($"var db{fieldNameLowerCase}=\"{defaultValue}\";");
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoDateTimePicker({{");
                        sb.AppendLine($"  value: fromDbDateTimeString(db{fieldNameLowerCase}),");
                        sb.AppendLine("    dateInput: true");
                        sb.AppendLine("});");
                        break;

                    case FieldTypeEnums.Timeduration:
                        sb.AppendLine($"  var  db{fieldNameLowerCase} = \"{defaultValue}\"; ");
                        sb.AppendLine($"$('#{fieldNameLowerCase}').kendoTimeDurationPicker({{");
                        sb.AppendLine("    columns: [");
                        sb.AppendLine("        { name: 'hours', format: '## Hours ', min: 0, max: 23 },");
                        sb.AppendLine("        { name: 'minutes', format: ' ## Minutes ', min: 0, max: 59, step: 1 },");
                        sb.AppendLine("        { name: 'seconds', format: ' ## Seconds', min: 0, max: 59, step: 1 }");
                        sb.AppendLine("    ],");
                        sb.AppendLine("    separator: ':',");
                        sb.AppendLine($"     value: hmsStringToMs(db{fieldNameLowerCase})");
                        sb.AppendLine("});");
                        break;


                    case FieldTypeEnums.Colorpicker:
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoColorPicker({{");
                        sb.AppendLine($"        value: \"{finalValue}\",");
                        sb.AppendLine("    buttons: true,");
                        sb.AppendLine("    preview: true,");
                        sb.AppendLine("    input: true");
                        sb.AppendLine("});");
                        break;

                    case FieldTypeEnums.Rating:
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoRating({{");
                        sb.AppendLine("    label: false");
                        sb.AppendLine("});");
                        break;

                    case FieldTypeEnums.Switches:
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoSwitch();");
                        break;

                    case FieldTypeEnums.Bit:
                    case FieldTypeEnums.DropDown:
                    case FieldTypeEnums.Radiogroup:
                        break;
            


                    default:
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoTextBox();");
                        break;
                }
            }

            var detailField = fields.Where(x => x.ParentId > 0).ToList();
            foreach (var detailsFields in detailField)
            {
                if (!Enum.TryParse<FieldTypeEnums>(detailsFields.FieldType, true, out var fieldType))
                    fieldType = FieldTypeEnums.Unknown;

                var fieldNameLowerCase = !string.IsNullOrWhiteSpace(detailsFields.FieldName) &&
                                         detailsFields.FieldName.Trim().Length > 1
                                         ? detailsFields.FieldName.Trim().ToLower()
                                         : string.Empty;

                var defaultValue = !string.IsNullOrWhiteSpace(detailsFields.DefaultValue) ? (detailsFields.DefaultValue) : string.Empty;

                var finalValue = !string.IsNullOrWhiteSpace(detailsFields.DefaultValue)? detailsFields.DefaultValue: "#000000";

                switch (fieldType)
                {
                    case FieldTypeEnums.Slider:
                        sb.AppendLine($"var slider = $(\"#{fieldNameLowerCase}\").kendoSlider({{");
                        sb.AppendLine($"    min: {detailsFields.MinValue},");
                        sb.AppendLine($"    max: {detailsFields.MaxValue},");
                        sb.AppendLine("    tooltip: { enabled: true, template: \"#= value #\" },");
                        sb.AppendLine("    showButtons: true,");
                        sb.AppendLine("    tickPlacement: \"none\"");
                        sb.AppendLine("}).data(\"kendoSlider\");");
                        sb.AppendLine("");
                        sb.AppendLine($"let payload{fieldNameLowerCase} = {{ name: $(\"#nameInput\").val() }};");
                        sb.AppendLine("if ($(\"#isfilter\").is(\":checked\")) {");
                        sb.AppendLine($"    payload{fieldNameLowerCase}.{fieldNameLowerCase} = slider.value();");
                        sb.AppendLine("}");
                        break;

                    case FieldTypeEnums.Date:
                        sb.AppendLine($" var db{fieldNameLowerCase}=\"{defaultValue}\"");
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoDatePicker({{");
                        sb.AppendLine($" value: fromDbDateString(db{fieldNameLowerCase}),");
                        sb.AppendLine("    dateInput: true");
                        sb.AppendLine("});");
                        break;

                    case FieldTypeEnums.Datetime:
                        sb.AppendLine($" var db{fieldNameLowerCase}=\"{defaultValue}\"");
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoDateTimePicker({{");
                        sb.AppendLine($"  value: fromDbDateTimeString(db{fieldNameLowerCase}),");
                        sb.AppendLine("    dateInput: true");
                        sb.AppendLine("});");
                        break;

                    case FieldTypeEnums.Colorpicker:
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoColorPicker({{");
                        sb.AppendLine($"        value: \"{finalValue}\",");
                        //sb.AppendLine("    value: \"#000000\",");
                        sb.AppendLine("    buttons: true,");
                        sb.AppendLine("    preview: true,");
                        sb.AppendLine("    input: true");
                        sb.AppendLine("});");
                        break;

                    case FieldTypeEnums.Rating:
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoRating({{");
                        sb.AppendLine("    label: false");
                        sb.AppendLine("});");
                        break;

                    case FieldTypeEnums.Switches:
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoSwitch();");
                        break;

                    case FieldTypeEnums.Bit:
                    case FieldTypeEnums.DropDown:
                    case FieldTypeEnums.Radiogroup:
                        break;
            


                    default:
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoTextBox();");
                        break;
                }
            }

            //sb.AppendLine("    const urlPath = window.location.pathname;");
            //sb.AppendLine("    const pathSegments = urlPath.split('/').filter(Boolean);");
            //sb.AppendLine("    const formName = pathSegments[pathSegments.length - 2];");
            sb.AppendLine("    var actionColumn = '';");
            sb.AppendLine("");
            sb.AppendLine("    fetchFormPermissions().then(function (permissionsArray) {");
            sb.AppendLine($"   var permissions = permissionsArray.find(p => p.formName === \"{firstFormName}\");");

            sb.AppendLine("");
            sb.AppendLine("    var $newButton = $(\"#textButton\");");
            sb.AppendLine("    $newButton.hide();");

            foreach (var field in displayfields)
            {
                var fieldName = (field.FieldName ?? "").Trim();
                if (string.IsNullOrEmpty(fieldName))
                    continue;

                var fieldNameLowerCase = fieldName.ToLower();
                var tooltipContent = field.ToolTip?.Trim();

                // Escape single quotes in tooltip content to prevent JS errors
                tooltipContent = tooltipContent.Replace("'", "\\'");

                // Try parse enum
                if (!Enum.TryParse<FieldTypeEnums>(field.TypeId, true, out var fieldType))
                    continue;

                sb.AppendLine($"// Tooltip for {fieldNameLowerCase}");
                sb.AppendLine("(function() {");
                sb.AppendLine($"    var el = $('#{fieldNameLowerCase}');");
                sb.AppendLine("    if (!el.length) return;");

                switch (fieldType)
                {
                    case FieldTypeEnums.Varchar:
                    case FieldTypeEnums.Nvarchar:
                    case FieldTypeEnums.Richtexteditor:
                    case FieldTypeEnums.Captcha:
                    case FieldTypeEnums.Colorpicker:
                    case FieldTypeEnums.Hyperlink:
                    case FieldTypeEnums.Signature:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {

                            sb.AppendLine($"    var wrapper = el.closest('.k-textbox, .k-textarea');");
                            sb.AppendLine($"    if (wrapper.length) wrapper.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    else el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                        }
                        break;

                    case FieldTypeEnums.Int:
                    case FieldTypeEnums.Bigint:
                    case FieldTypeEnums.Float:
                    case FieldTypeEnums.Decimal:
                    case FieldTypeEnums.Money:
                    case FieldTypeEnums.Smallint:
                    case FieldTypeEnums.Tinyint:
                    case FieldTypeEnums.Slider:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {

                            sb.AppendLine($"    var numWrapper = el.closest('.k-numerictextbox');");
                            sb.AppendLine($"    if (numWrapper.length) {{");
                            sb.AppendLine($"        numWrapper.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }} else {{");
                            sb.AppendLine($"        el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }}");
                        }
                        break;

                    case FieldTypeEnums.Date:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    var datePicker = el.data('kendoDatePicker');");
                            sb.AppendLine($"    if (datePicker && datePicker.wrapper && datePicker.wrapper.length) {{");
                            sb.AppendLine($"        datePicker.wrapper.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }} else {{");
                            sb.AppendLine($"        el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }}");
                        }
                        break;

                    case FieldTypeEnums.Multiselect:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    var multiSelect = el.data('kendoMultiSelect');");
                            sb.AppendLine($"    if (multiSelect && multiSelect.wrapper && multiSelect.wrapper.length) {{");
                            sb.AppendLine($"        multiSelect.wrapper.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }} else {{");
                            sb.AppendLine($"        el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }}");
                        }
                        break;

                    case FieldTypeEnums.Datetime:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    var dateTimePicker = el.data('kendoDateTimePicker');");
                            sb.AppendLine($"    if (dateTimePicker && dateTimePicker.wrapper && dateTimePicker.wrapper.length) {{");
                            sb.AppendLine($"        dateTimePicker.wrapper.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }} else {{");
                            sb.AppendLine($"        el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }}");
                        }
                        break;

                    case FieldTypeEnums.DropDown:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    var dropDown = el.data('kendoDropDownList');");
                            sb.AppendLine($"    if (dropDown && dropDown.wrapper && dropDown.wrapper.length) {{");
                            sb.AppendLine($"        dropDown.wrapper.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }} else {{");
                            sb.AppendLine($"        el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }}");
                        }
                        break;


                    case FieldTypeEnums.Rating:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    var rating = el.data('kendoRating');");
                            sb.AppendLine($"    if (rating && rating.wrapper && rating.wrapper.length) {{");
                            sb.AppendLine($"        rating.wrapper.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }} else {{");
                            sb.AppendLine($"        el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                            sb.AppendLine($"    }}");
                        }
                        break;

                 
                    case FieldTypeEnums.Switches:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    (function () {{");
                            sb.AppendLine($"        var ddl = $('#{fieldNameLowerCase}').data('kendoDropDownList');");
                            sb.AppendLine($"        if (ddl && ddl.wrapper) {{");
                            sb.AppendLine($"            ddl.wrapper.kendoTooltip({{");
                            sb.AppendLine($"                content: '{tooltipContent.Replace("'", "\\'")}',");
                            sb.AppendLine($"                position: 'top',");
                            sb.AppendLine($"                showOn: 'mouseenter'");
                            sb.AppendLine($"            }});");
                            sb.AppendLine($"        }}");
                            sb.AppendLine($"    }})();");

                        }
                        break;


                    case FieldTypeEnums.Bit:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    var checkboxWrapper = el.closest('.k-checkbox');");
                        sb.AppendLine($"    if (checkboxWrapper.length) {{");
                        sb.AppendLine($"        checkboxWrapper.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                        sb.AppendLine($"    }} else {{");
                        sb.AppendLine($"        el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                        sb.AppendLine($"    }}");
                        }
                        break;

                    case FieldTypeEnums.Radiogroup:
                    case FieldTypeEnums.Checkboxgroup:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    var formGroup = el.closest('.form-group');");
                        sb.AppendLine($"    if (formGroup.length) {{");
                        sb.AppendLine($"        formGroup.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                        sb.AppendLine($"    }} else {{");
                        sb.AppendLine($"        el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                        sb.AppendLine($"    }}");
                        }
                        break;

                    case FieldTypeEnums.Timeduration:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    var timePicker = el.data('kendoTimePicker');");
                        sb.AppendLine($"    if (timePicker && timePicker.wrapper && timePicker.wrapper.length) {{");
                        sb.AppendLine($"        timePicker.wrapper.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                        sb.AppendLine($"    }} else {{");
                        sb.AppendLine($"        el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                        sb.AppendLine($"    }}");
                        }
                        break;

                    default:
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    el.kendoTooltip({{ content: '{tooltipContent}', position: 'top', showOn: 'mouseenter' }});");
                        }
                        break;
                }

                sb.AppendLine("})();");
                sb.AppendLine();
            }



            if (isHierarchical)
            {
                sb.AppendLine($"var $treeList = $(\"#{tableName}Grid\");");
                // Check if user has no view, edit, or delete permissions
                sb.AppendLine("if (!permissions || (!permissions.isView && !permissions.isEdit && !permissions.isDelete)) {");
                sb.AppendLine("window.location.replace('/Home/Error');");
                sb.AppendLine("}");
                sb.AppendLine();
                sb.AppendLine("if ($treeList.length) {");
                sb.AppendLine("    actionColumn = {");
                // sb.AppendLine("        title: \"Actions\",");
                sb.AppendLine("        width: \"200px\",");
                sb.AppendLine("           filterable : false,");
                sb.AppendLine("        template: function(dataItem) {");
                sb.AppendLine("           return (permissions.isEdit || permissions.isDelete) ? `");
                sb.AppendLine("               ${permissions.isEdit ? `<button class='btn btn-sm btn-primary edit-button update-btn' data-id='${dataItem.id}' data-parentid='${dataItem.parentId}' onclick=\"return EditUser(this);\"><i class='k-icon k-font-icon k-i-pencil'></i></button>` : ''}");
                sb.AppendLine("                ${permissions.isDelete ? `<button class='btn btn-sm btn-danger remove-button delete-btn' data-id='${dataItem.id}' onclick=\"return DeleteUser(this);\"><i class='k-icon k-font-icon k-i-trash'></i></button>` : ''}");
                sb.AppendLine("                ${permissions.isEdit ? `<button class='btn btn-secondary btn-sm child-button addchild-btn' data-id='${dataItem.id}' onclick=\"return AddChild(this);\"><i class='k-icon k-font-icon k-i-plus'></i></button>` : ''}");
                sb.AppendLine("            ` : '';");
                sb.AppendLine("        }");
                sb.AppendLine("    };");
                sb.AppendLine();
                sb.AppendLine("            if (permissions.isEdit && $newButton.length) {");
                sb.AppendLine("                $newButton.show();");
                sb.AppendLine("            } else { ");
                sb.AppendLine("    $newButton.remove();");
                sb.AppendLine("}");
                sb.AppendLine();
                sb.AppendLine("    // Initialize the TreeList using its ID");
                sb.AppendLine("    loadTree(actionColumn);");
                sb.AppendLine("}");
            }
            else
            {
                    sb.AppendLine($"var $grid = $(\"#{tableName}Grid\");");
                    // Check if user has no view, edit, or delete permissions
                    sb.AppendLine("if (!permissions || (!permissions.isView && !permissions.isEdit && !permissions.isDelete)) {");
                    ////sb.AppendLine("    $newButton.hide();");
                    //sb.AppendLine("    $grid.hide();");
                    sb.AppendLine("window.location.replace('/Home/Error');");
                    sb.AppendLine("}");
                    sb.AppendLine("");
                    sb.AppendLine("        if ($grid.length) {");
                    sb.AppendLine("            actionColumn = {");
                    //sb.AppendLine("                title: \"Actions\",");
                    sb.AppendLine("                width: \"120px\",");
                    sb.AppendLine("                template: function (dataItem) {");
                    sb.AppendLine("                    return (permissions.isEdit || permissions.isDelete) ? `");
                    sb.AppendLine("                        ${permissions.isEdit ? `<button class='btn btn-sm btn-primary edit-button update-btn' data-id='${dataItem.id}'><i class='k-icon k-font-icon k-i-pencil'></i></button>` : ''}");
                    sb.AppendLine("                        ${permissions.isDelete ? `<button class='btn btn-sm btn-danger  remove-button delete-btn' data-id='${dataItem.id}'><i class='k-icon k-font-icon k-i-trash'></i></button>` : ''}");
                    sb.AppendLine("                    ` : '';");
                    sb.AppendLine("                }");
                    sb.AppendLine("            };");
                    sb.AppendLine("");
                    sb.AppendLine("            if (permissions.isEdit && $newButton.length) {");
                    sb.AppendLine("                $newButton.show();");
                    sb.AppendLine("            } else { ");
                    sb.AppendLine("    $newButton.remove();");
                    sb.AppendLine("}");
                    sb.AppendLine();
                    sb.AppendLine("            // Initialize the grid using its ID");
                    sb.AppendLine("            loadGrid(actionColumn);");
                    sb.AppendLine("        } ");
                }
                sb.AppendLine("    });");
                sb.AppendLine("});");

            var rootFields = fields
            .Where(f => f.ParentId == null || f.ParentId == 0)
            .ToList();
            var script = await SearchCriteriaHelper.GenerateFieldScriptsAsync(rootFields, configConnectionString,alignmentType);
            sb.AppendLine(script);
            //foreach (var field in fields)
            //{
            //    //if ((field.FieldType?.ToLower() ?? "") != "dropdown")
            //    //{
            //    //    var fieldName = (field.FieldName ?? "").Trim();
            //    //    var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
            //    //    string staticCriteriaJson = "";

            //    //    if (field.FieldType == "varchar" || field.FieldType == "nvarchar" || field.FieldType == "richtexteditor" || field.FieldType == "captcha" || field.FieldType == "colorpicker" || field.FieldType == "hyperlink" || field.FieldType == "rangeslider" || field.FieldType == "richtexteditor" || field.FieldType == "signature" || field.FieldType == "radiogroup" || field.FieldType == "checkboxgroup")
            //    //    {
            //    //        staticCriteriaJson = "[{ id: 1, name: \"Equals\" }, { id: 2, name: \"Contains\" }, { id: 3, name: \"StartsWith\" }, { id: 4, name: \"EndsWith\" }]";
            //    //    }
            //    //    else if (field.FieldType == "int" || field.FieldType == "bigint" || field.FieldType == "float" || field.FieldType == "decimal" || field.FieldType == "numeric" || field.FieldType == "money" || field.FieldType == "smallint" || field.FieldType == "slider" || field.FieldType == "bit" || field.FieldType == "rating"  )
            //    //    {
            //    //        staticCriteriaJson = "[{ id: 1, name: \"=\" }, { id: 2, name: \">\" }, { id: 3, name: \"<\" }]";
            //    //    }
            //    //    else if (field.FieldType == "datetime" || field.FieldType == "date" || field.FieldType == "timeduration")
            //    //    {
            //    //        staticCriteriaJson = "[{ id: 1, name: \"=\" }, { id: 2, name: \">\" }, { id: 3, name: \"<\" }]";
            //    //    }

            //    //if (field.FieldType == "switches")
            //    //    {
            //    //        sb.AppendLine($"    $('#{fieldNameLowerCase}').kendoDropDownList({{");
            //    //        sb.AppendLine("        optionLabel: '-- Select Value --',");
            //    //        sb.AppendLine("        dataTextField: 'name',");
            //    //        sb.AppendLine("        dataValueField: 'name',");
            //    //        sb.AppendLine("        filter: 'contains',");
            //    //        sb.AppendLine("        dataSource: [");
            //    //        sb.AppendLine("            { id: 1, name: 'True' },");
            //    //        sb.AppendLine("            { id: 2, name: 'False' }");
            //    //        sb.AppendLine("        ]");
            //    //        sb.AppendLine("    });");
            //    //    }


            //    //    if (field.FieldType != "dropdown" && field.FieldType != "switches")
            //    //    {
            //    //        sb.AppendLine($"    $('#{fieldNameLowerCase}Criteria').kendoDropDownList({{");
            //    //        sb.AppendLine("        optionLabel: '-- Select --',");
            //    //        sb.AppendLine("        dataTextField: 'name',");
            //    //        sb.AppendLine("        dataValueField: 'name',");
            //    //        sb.AppendLine($"        filter: 'contains',");

            //    //        sb.AppendLine($"        dataSource: {staticCriteriaJson}");
            //    //        sb.AppendLine("    });");
            //    //    }

            //    //    if (field.FieldType == "datetime")
            //    //    {
            //    //        sb.AppendLine($"    $('#{fieldNameLowerCase}Criteria').data('kendoDropDownList').bind('change', function () {{");
            //    //        sb.AppendLine("        var selectedText = this.text();");
            //    //        sb.AppendLine("        if (selectedText === 'Between') {");
            //    //        sb.AppendLine($"            showDateRangeInputs('{fieldNameLowerCase}Criteria');");
            //    //        sb.AppendLine("        } else {");
            //    //        sb.AppendLine($"            hideDateRangeInputs('{fieldNameLowerCase}Criteria');");
            //    //        sb.AppendLine("        }");
            //    //        sb.AppendLine("    });");
            //    //    }
            //    //    if (field.FieldType == "date")
            //    //    {
            //    //        sb.AppendLine($"    $('#{fieldNameLowerCase}Criteria').data('kendoDropDownList').bind('change', function () {{");
            //    //        sb.AppendLine("        var selectedText = this.text();");
            //    //        sb.AppendLine("        if (selectedText === 'Between') {");
            //    //        sb.AppendLine($"            showDateRangeInputs('{fieldNameLowerCase}Criteria');");
            //    //        sb.AppendLine("        } else {");
            //    //        sb.AppendLine($"            hideDateRangeInputs('{fieldNameLowerCase}Criteria');");
            //    //        sb.AppendLine("        }");
            //    //        sb.AppendLine("    });");
            //    //    }
            //    //}


            //    if (!string.Equals(field.FieldType, FieldTypeEnums.DropDown.ToString(), StringComparison.OrdinalIgnoreCase))
            //    {
            //        var fieldName = (field.FieldName ?? "").Trim();
            //        if (string.IsNullOrEmpty(fieldName))
            //            continue;

            //        //  var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
            //        var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
            //        string staticCriteriaJson = "";

            //        // Try parse enum from string
            //        if (!Enum.TryParse<FieldTypeEnums>(field.FieldType, true, out var fieldType))
            //            continue;

            //        switch (fieldType)
            //        {


            //            case FieldTypeEnums.Varchar:
            //            case FieldTypeEnums.Nvarchar:
            //            case FieldTypeEnums.Richtexteditor:
            //            case FieldTypeEnums.Captcha:
            //            case FieldTypeEnums.Hyperlink:
            //            case FieldTypeEnums.Rangeslider:
            //            case FieldTypeEnums.Signature:
            //                staticCriteriaJson =
            //                    "[{ id: 1, name: \"Equals\" }, { id: 2, name: \"Contains\" }, { id: 3, name: \"StartsWith\" }, { id: 4, name: \"EndsWith\" }]";
            //                break;

            //            case FieldTypeEnums.Barcode:
            //                staticCriteriaJson =
            //                    "[{ id: 1, name: \"Equals\" }, { id: 2, name: \"Contains\" }, { id: 3, name: \"StartsWith\" }, { id: 4, name: \"EndsWith\" }]";
            //                break;

            //            case FieldTypeEnums.Int:
            //            case FieldTypeEnums.Bigint:
            //            case FieldTypeEnums.Float:
            //            case FieldTypeEnums.Decimal:
            //            case FieldTypeEnums.Numeric:
            //            case FieldTypeEnums.Money:
            //            case FieldTypeEnums.Smallint:
            //            case FieldTypeEnums.Tinyint:
            //            case FieldTypeEnums.Rating:
            //            case FieldTypeEnums.Timeduration:
            //                staticCriteriaJson =
            //                    "[{ id: 1, name: \"=\" }, { id: 2, name: \">\" }, { id: 3, name: \"<\" }]";
            //                break;


            //            case FieldTypeEnums.Date:
            //            case FieldTypeEnums.Datetime:
            //                staticCriteriaJson =
            //                    "[{ id: 1, name: \"=\" }, { id: 2, name: \">\" }, { id: 3, name: \"<\" }, { id: 4, name: \"Between\" }]";
            //                break;

            //                //case FieldTypeEnums.Switches:
            //                //    sb.AppendLine($"    $('#{fieldNameLowerCase}').kendoDropDownList({{");
            //                //    sb.AppendLine("        optionLabel: '-- Select Value --',");
            //                //    sb.AppendLine("        dataTextField: 'name',");
            //                //    sb.AppendLine("        dataValueField: 'name',");
            //                //    sb.AppendLine("        filter: 'contains',");
            //                //    sb.AppendLine("        dataSource: [");
            //                //    sb.AppendLine("            { id: 1, name: 'True' },");
            //                //    sb.AppendLine("            { id: 2, name: 'False' }");
            //                //    sb.AppendLine("        ]");
            //                //    sb.AppendLine("    });");
            //                //    break;
            //        }

            //        // Render criteria dropdown if NOT dropdown or switches
            //        if (fieldType != FieldTypeEnums.DropDown && fieldType != FieldTypeEnums.Switches && fieldType != FieldTypeEnums.Radiogroup && fieldType != FieldTypeEnums.Checkboxgroup && fieldType != FieldTypeEnums.Multiselect && fieldType != FieldTypeEnums.Slider && fieldType != FieldTypeEnums.Colorpicker && fieldType != FieldTypeEnums.Bit)
            //        {
            //            sb.AppendLine($"    $('#{fieldNameLowerCase}Criteria').kendoDropDownList({{");
            //            sb.AppendLine("        optionLabel: '-- Select --',");
            //            sb.AppendLine("        dataTextField: 'name',");
            //            sb.AppendLine("        dataValueField: 'name',");
            //            sb.AppendLine("        filter: 'contains',");
            //            sb.AppendLine($"        dataSource: {staticCriteriaJson}");
            //            sb.AppendLine("    });");
            //        }
            //        if (string.Equals(field.FieldType, FieldTypeEnums.Date.ToString(), StringComparison.OrdinalIgnoreCase))
            //        {
            //            sb.AppendLine($"$('#{fieldNameLowerCase}Criteria').data('kendoDropDownList').bind('change', function () {{");
            //            sb.AppendLine("    const selectedText = this.text();");
            //            sb.AppendLine($"    const $labelDiv = $(\"label[for='{fieldNameLowerCase}']\").closest('.col-md-4');");
            //            sb.AppendLine($"    const $input{fieldNameLowerCase} = $('.{fieldNameLowerCase}');");
            //            sb.AppendLine("");
            //            sb.AppendLine($"    const existingRange = $('#{fieldNameLowerCase}Picker').data('kendoDateRangePicker');");
            //            sb.AppendLine("    if (existingRange) {");
            //            sb.AppendLine("        existingRange.destroy();");
            //            sb.AppendLine($"        $('#{fieldNameLowerCase}Picker').empty();");
            //            sb.AppendLine("    }");
            //            sb.AppendLine("");
            //            sb.AppendLine("    if (selectedText === 'Between') {");
            //            sb.AppendLine($"        $('#{fieldNameLowerCase}Picker').kendoDateRangePicker({{");
            //            sb.AppendLine("            messages: { startLabel: '', endLabel: '' }");
            //            sb.AppendLine("        });");
            //            sb.AppendLine($"        $('#{fieldNameLowerCase}Picker').css('height', '42px');");
            //            sb.AppendLine("    } else {");
            //            sb.AppendLine($"        $('#{fieldNameLowerCase}Picker').css('height', '');");
            //            sb.AppendLine("    }");
            //            sb.AppendLine("");
            //            sb.AppendLine($"    $labelDiv.toggle(selectedText !== 'Between');");
            //            sb.AppendLine($"    $input{fieldNameLowerCase}.toggle(selectedText !== 'Between');");
            //            sb.AppendLine($"    $('#{fieldNameLowerCase}Picker').toggle(selectedText === 'Between');");
            //            sb.AppendLine("");
            //            sb.AppendLine("    $('.k-floating-label-container .k-input, .k-floating-label-container .k-input-solid')");
            //            sb.AppendLine("        .css('height', '42px');");
            //            sb.AppendLine("});");
            //        }

            //        else if (string.Equals(field.FieldType, FieldTypeEnums.Datetime.ToString(), StringComparison.OrdinalIgnoreCase))
            //        {
            //            sb.AppendLine($"$('#{fieldNameLowerCase}Criteria').data('kendoDropDownList').bind('change', function () {{");
            //            sb.AppendLine("    const selectedText = this.text();");
            //            sb.AppendLine($"    const container = $('.{fieldNameLowerCase}');");
            //            sb.AppendLine();
            //            sb.AppendLine($"    $('#{fieldNameLowerCase}').data('kendoDateTimePicker')?.destroy();");
            //            sb.AppendLine($"    $('#start_{fieldNameLowerCase}').data('kendoDateTimePicker')?.destroy();");
            //            sb.AppendLine($"    $('#end_{fieldNameLowerCase}').data('kendoDateTimePicker')?.destroy();");
            //            sb.AppendLine("    container.empty();");
            //            sb.AppendLine();
            //            sb.AppendLine("    if (selectedText === 'Between') {");
            //            sb.AppendLine("        container.html(`");
            //            sb.AppendLine("<div class='d-flex justify-content-between' style='gap:10px;'>");
            //            sb.AppendLine($"    <input type='text' class='inputcontrol' id='start_{fieldNameLowerCase}' name='start_{fieldNameLowerCase}' />");
            //            sb.AppendLine("    <div class='mt-2 form-label-text'>To:</div>");
            //            sb.AppendLine($"    <input type='text' class='inputcontrol' id='end_{fieldNameLowerCase}' name='end_{fieldNameLowerCase}' />");
            //            sb.AppendLine("</div>");
            //            sb.AppendLine("        `);");
            //            sb.AppendLine();
            //            if(alignmentType == 2)
            //            {
            //                sb.AppendLine("        container.css('bottom', '');");
            //            }
            //            sb.AppendLine($"        $('#start_{fieldNameLowerCase}').kendoDateTimePicker({{");
            //            sb.AppendLine("            dateInput: true,");
            //            sb.AppendLine("        });");
            //            sb.AppendLine($"        $('#end_{fieldNameLowerCase}').kendoDateTimePicker({{");
            //            sb.AppendLine("            dateInput: true,");
            //            sb.AppendLine("        });");
            //            sb.AppendLine("    } else {");
            //            sb.AppendLine("        container.html(`");
            //            sb.AppendLine("                 <div class=\"col-md-4\">");
            //            sb.AppendLine($"            <label for=\"{fieldNameLowerCase}\" class=\"form-label-text\">{field.DisplayName}</label>");
            //            sb.AppendLine("                 </div>");
            //            if(alignmentType == 2)
            //            {
            //                sb.AppendLine("                 <div class=\"col-md-8\" style=\"width:100%\">");
            //            }
            //            sb.AppendLine($"            <input type=\"text\" class=\"inputcontrol datetimepicker\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" />");
            //            sb.AppendLine("                 </div>");
            //            sb.AppendLine("        `);");
            //            sb.AppendLine();
            //            if (alignmentType == 2)
            //            {
            //                sb.AppendLine("        container.css('bottom', '29px');");
            //            }
            //            sb.AppendLine($"        $('#{fieldNameLowerCase}').kendoDateTimePicker({{");
            //            sb.AppendLine("            dateInput: true,");
            //            sb.AppendLine("        });");
            //            sb.AppendLine("    }");
            //            sb.AppendLine();
            //          //  sb.AppendLine("    $('.k-floating-label-container').css('width', '100%');");
            //            sb.AppendLine("    $('.k-floating-label-container .k-input, .k-floating-label-container .k-input-solid')");
            //          //  sb.AppendLine("        .css('width', '100%')");
            //            sb.AppendLine("        .css('height', '43px');");
            //            sb.AppendLine("});");

                    //}
                    //else if (fieldType == FieldTypeEnums.Timeduration)
                    //{
                    //    var defaultValue = !string.IsNullOrWhiteSpace(field.DefaultValue) ? (field.DefaultValue) : string.Empty;
                    //    sb.AppendLine($"  var  db{fieldNameLowerCase} = \"{defaultValue}\"; ");
                    //    sb.AppendLine($"$('#{fieldNameLowerCase}').kendoTimeDurationPicker({{");
                    //    sb.AppendLine("    columns: [");
                    //    sb.AppendLine("        { name: 'hours', format: '## Hours ', min: 0, max: 23 },");
                    //    sb.AppendLine("        { name: 'minutes', format: ' ## Minutes ', min: 0, max: 59, step: 1 },");
                    //    sb.AppendLine("        { name: 'seconds', format: ' ## Seconds', min: 0, max: 59, step: 1 }");
                    //    sb.AppendLine("    ],");
                    //    sb.AppendLine("    separator: ':',");
                    //    sb.AppendLine($"     value: hmsStringToMs(db{fieldNameLowerCase})");
                    //    sb.AppendLine("});");
                    //}
                
            //    }
            //}
            //foreach (var detailsFields in detailFields)
            //    {


            //        // **Set dropdown values dynamically**
            //        //foreach (var field in fields)
            //        //{
            //        //   if (Detailsfields?.san == "startswith" || Detailsfields?.san == "contains")
            //        if (string.Equals(detailsFields.TypeId, FieldTypeEnums.DropDown.ToString(), StringComparison.OrdinalIgnoreCase) || 
            //            string.Equals(detailsFields.TypeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) ||
            //            string.Equals(detailsFields.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase) ||
            //            string.Equals(detailsFields.TypeId, FieldTypeEnums.Radiogroup.ToString(), StringComparison.OrdinalIgnoreCase))
            //        {
            //            //var fieldNameLowerCase = char.ToLower(Detailsfields.FieldName.Trim()[0]) + Detailsfields.FieldName.Trim()[1..];
            //            //string fieldNameLowerCase = !string.IsNullOrWhiteSpace(Detailsfields.FieldName) && Detailsfields.FieldName.Trim().Length > 1
            //            //                            ? char.ToLower(Detailsfields.FieldName.Trim()[0]) + Detailsfields.FieldName.Trim()[1..]
            //            //                            : string.Empty;
            //            var fieldNameLowerCase = !string.IsNullOrWhiteSpace(detailsFields.FieldName) && detailsFields.FieldName.Trim().Length > 1
            //                                      ? detailsFields.FieldName?.Trim().ToLower() : string.Empty;

            //            //var textFieldLowerCase = char.ToLower(Detailsfields.TextFieldName.Trim()[0]) + Detailsfields.TextFieldName.Trim()[1..];
            //            //string textFieldLowerCase = !string.IsNullOrWhiteSpace(Detailsfields.TextFieldName) && Detailsfields.TextFieldName.Trim().Length > 1
            //            //                            ? char.ToLower(Detailsfields.TextFieldName.Trim()[0]) + Detailsfields.TextFieldName.Trim()[1..]
            //            //                            : string.Empty;
            //            var textFieldLowerCase = !string.IsNullOrWhiteSpace(detailsFields.TextFieldName) && detailsFields.TextFieldName.Trim().Length > 1
            //                                     ? detailsFields.TextFieldName?.Trim().ToLower() : string.Empty;
            //            bool isCascading = await IsCascadingFieldAsync(detailsFields.FieldId, detailsFields.FormId, configConnectionString);
            //            TableModel? sourcetable = await GetTableData(detailsFields.SourceTableId, configConnectionString);
            //            if (sourcetable != null && !isCascading && sourcetable.IsHierarchical && string.IsNullOrEmpty(detailsFields.ParentFieldName))
            //            {
            //                sb.AppendLine($"$('#{fieldNameLowerCase}').kendoDropDownTree({{");
            //                sb.AppendLine("    placeholder: 'Select Parent',");
            //                sb.AppendLine("    height: 'auto',");
            //                sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
            //                sb.AppendLine("    dataValueField: 'id',");


            //            if (detailsFields?.FilterOption?.ToLower() == "startswith" || detailsFields?.FilterOption?.ToLower() == "contains")
            //            {
            //                sb.AppendLine($"filter: '{detailsFields.FilterOption.ToLower()}',");
            //            }

            //            //else
            //            //{
            //            //    sb.AppendLine("filter: NULL,");  // for null or other values
            //            //}
            //            sb.AppendLine("    dataSource: new kendo.data.HierarchicalDataSource({");
            //                sb.AppendLine($"   sort: {{ field: \"{textFieldLowerCase}\", dir: 'asc' }},");
            //                sb.AppendLine("        transport: {");
            //                sb.AppendLine("            read: function (options) {");
            //                sb.AppendLine("                $.ajax({");
            //                sb.AppendLine($"                    url: backendUrl + '/{detailsFields.SourceTableName?.ToLower() ?? ""}/hierarchy',");
            //                sb.AppendLine("                    type: 'GET',");
            //                sb.AppendLine("                    dataType: 'json',");
            //                sb.AppendLine("                    success: function (response) {");
            //                sb.AppendLine("                        options.success(response);");
            //                sb.AppendLine("                    },");
            //                sb.AppendLine("                    error: function (xhr, status, error) {");
            //                sb.AppendLine("                        console.error('Error fetching hierarchy:', error);");
            //                sb.AppendLine("                        options.error(xhr);");
            //                sb.AppendLine("                    }");
            //                sb.AppendLine("                });");
            //                sb.AppendLine("            }");
            //                sb.AppendLine("        },");
            //                sb.AppendLine("        schema: {");
            //                sb.AppendLine("            model: { id: 'id', children: 'items' }");
            //                sb.AppendLine("        }");
            //                sb.AppendLine("    })");
            //                sb.AppendLine("});");
            //        }

            //        if (detailsFields?.IsMultiColumn == true && string.IsNullOrEmpty(detailsFields.ParentFieldName))
            //        {
            //            sb.AppendLine($"$('#{fieldNameLowerCase}').kendoMultiColumnComboBox({{");
            //            sb.AppendLine("    placeholder: '--Select--',");
            //            sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
            //            sb.AppendLine("    dataValueField: 'id',");
            //            sb.AppendLine($"    filter: '{detailsFields.FilterOption?.ToLowerInvariant()}',");

            //            // Build filterFields dynamically
            //            if (detailsFields.MultiColumnFieldNames != null && detailsFields.MultiColumnFieldNames.Count > 0)
            //            {
            //                var fieldList = string.Join(", ", detailsFields.MultiColumnFieldNames
            //                    .Select(f => $"'{f.SourceFieldName?.Trim().ToLower()}'"));
            //                sb.AppendLine($"    filterFields: [{fieldList}],");
            //            }

            //            sb.AppendLine("    minLength: 1,");
            //            sb.AppendLine("    autoBind: true,");
            //            sb.AppendLine("    suggest: true,");
            //            sb.AppendLine("    columns: [");

            //            if (detailsFields.MultiColumnFieldNames != null && detailsFields.MultiColumnFieldNames.Count > 0)
            //            {
            //                for (int i = 0; i < detailsFields.MultiColumnFieldNames.Count; i++)
            //                {
            //                    var column = detailsFields.MultiColumnFieldNames[i];
            //                    var comma = i < detailsFields.MultiColumnFieldNames.Count - 1 ? "," : "";

            //                    // field name in lowercase
            //                    var fieldNameCamelCase = column.SourceFieldName?.Trim().ToLower() ?? string.Empty;

            //                    // formatted title: add spaces between capitals
            //                    var formattedTitle = System.Text.RegularExpressions.Regex
            //                        .Replace(column.SourceFieldName ?? string.Empty, "(\\B[A-Z])", " $1").Trim();

            //                    // remove trailing " Data" (case-insensitive)
            //                    if (formattedTitle.EndsWith(" Data", StringComparison.OrdinalIgnoreCase))
            //                        formattedTitle = formattedTitle.Substring(0, formattedTitle.Length - 5).Trim();

            //                    sb.AppendLine($"        {{ field: '{fieldNameCamelCase}', title: '{formattedTitle}' }}{comma}");
            //                }
            //            }
            //            else
            //            {
            //                sb.AppendLine("        { field: 'id', title: 'ID' },");
            //                sb.AppendLine("        { field: 'name', title: 'Name' }");
            //            }

            //            sb.AppendLine("    ],");
            //            sb.AppendLine("    dataSource: {");
            //            sb.AppendLine("        sort: { field: 'datafield', dir: 'asc' },");
            //            sb.AppendLine("        transport: {");
            //            sb.AppendLine("            read: function (options) {");
            //            sb.AppendLine("                $.ajax({");
            //            sb.AppendLine($"                    url: backendUrl + '/{(detailsFields.SourceTableName ?? "").ToLower()}',");
            //            sb.AppendLine("                    type: 'GET',");
            //            sb.AppendLine("                    dataType: 'json',");
            //            sb.AppendLine("                    success: function (response) {");
            //            sb.AppendLine("                        options.success(response);");
            //            sb.AppendLine($"                        $('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').value('{detailsFields.DefaultValue}');");
            //            sb.AppendLine("                    },");
            //            sb.AppendLine("                    error: function (xhr, status, error) {");
            //            sb.AppendLine("                        console.error('Error fetching data:', error);");
            //            sb.AppendLine("                        options.error(xhr);");
            //            sb.AppendLine("                    }");
            //            sb.AppendLine("                });");
            //            sb.AppendLine("            }");
            //            sb.AppendLine("        }");
            //            sb.AppendLine("    },");
            //            sb.AppendLine("    noDataTemplate: 'No matching records found'");
            //            sb.AppendLine("});");
            //            sb.AppendLine($"$('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').input.attr('readonly', false);");
            //        }

            //        // Parent Dropdown(StudentID)

            //        //if (field != null && sourcetable != null)
            //        //{
            //        if (isCascading && string.IsNullOrEmpty(detailsFields?.ParentFieldName) && detailsFields?.IsMultiColumn == false || !isCascading && string.IsNullOrEmpty(detailsFields?.ParentFieldName) && detailsFields?.IsMultiColumn == false && !sourcetable.IsHierarchical)
            //            {
            //                if (string.Equals(detailsFields.TypeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) ||
            //                   string.Equals(detailsFields.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
            //                {
            //                    sb.AppendLine($"$('#{fieldNameLowerCase}').kendoMultiSelect({{");
            //                    sb.AppendLine("    placeholder: '-- Select --',");
            //                }
            //                else
            //                {
            //                    sb.AppendLine($"$('#{fieldNameLowerCase}').kendoDropDownList({{");
            //                    sb.AppendLine("    optionLabel: '-- Select --',");
            //                }
            //                sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
            //            sb.AppendLine("    dataValueField: 'id',");

            //            if (string.Equals(detailsFields.TypeId, FieldTypeEnums.DropDown.ToString(), StringComparison.OrdinalIgnoreCase))
            //            {
            //                var filterOperator = string.IsNullOrEmpty(detailsFields.FilterOption)
            //                ? "contains"
            //                : detailsFields.FilterOption.ToLower();


            //                if (detailsFields.IsLazyLoaded)
            //                {
            //                    sb.AppendLine($"filter: \"{filterOperator}\",");
            //                    sb.AppendLine();
            //                    sb.AppendLine("virtual: {");
            //                    sb.AppendLine("  itemHeight: 26,");
            //                    sb.AppendLine("  valueMapper: function(options) {");
            //                    sb.AppendLine("    $.ajax({");
            //                    sb.AppendLine("      url: backendUrl + \"/ValueMapper\",");
            //                    sb.AppendLine("      type: \"POST\",");
            //                    sb.AppendLine("      contentType: \"application/json\",");
            //                    sb.AppendLine("      dataType: \"json\",");
            //                    sb.AppendLine("      data: JSON.stringify({");
            //                    sb.AppendLine("        selectedIds: $.isArray(options.value) ? options.value : [options.value],");
            //                    sb.AppendLine($"        sourceTableName: \"{detailsFields.TableName}\"");
            //                    sb.AppendLine("      }),");
            //                    sb.AppendLine("      success: function(data) {");
            //                    sb.AppendLine("        const mappedIds = Object.keys(data).map(k => data[k]);");
            //                    sb.AppendLine("        options.success(mappedIds);");
            //                    sb.AppendLine("      },");
            //                    sb.AppendLine("      error: function(xhr) {");
            //                    sb.AppendLine("        options.success([]);");
            //                    sb.AppendLine("      }");
            //                    sb.AppendLine("    });");
            //                    sb.AppendLine("  }");
            //                    sb.AppendLine("},");
            //                    sb.AppendLine("height: 300,");
            //                }
            //                else
            //                {
            //                    sb.AppendLine($"filter: '{(string.IsNullOrEmpty(detailsFields.FilterOption) ? "contains" : detailsFields.FilterOption.ToLower())}',");
            //                }
            //            }
            //            else
            //            {
            //                sb.AppendLine($"filter: 'contains',");
            //            }
            //            if (detailsFields.IsLazyLoaded)
            //            {
            //                sb.AppendLine("dataSource: {");                       
            //                sb.AppendLine("  transport: {");
            //                sb.AppendLine("    read: function(options) {");
            //                sb.AppendLine("      const filterValue = options.data.filter?.filters?.[0]?.value || '';");

            //                sb.AppendLine("      const requestPayload = {");
            //                sb.AppendLine("        skip: options.data.skip || 0,");
            //                sb.AppendLine("        take: options.data.take || 20,");
            //                sb.AppendLine("        filter: {");
            //                sb.AppendLine("          logic: 'and',");
            //                sb.AppendLine("          filters: [");
            //                sb.AppendLine("            {");
            //                sb.AppendLine("              field: 'datafield',");
            //                sb.AppendLine("              operator: 'contains',");
            //                sb.AppendLine("              value: filterValue");
            //                sb.AppendLine("            }");
            //                sb.AppendLine("          ]");
            //                sb.AppendLine("        }");
            //                sb.AppendLine("      };");

            //                sb.AppendLine("      $.ajax({");
            //                sb.AppendLine("        url: backendUrl + '/DataSources',");
            //                sb.AppendLine("        type: 'POST',");
            //                sb.AppendLine("        contentType: 'application/json',");
            //                sb.AppendLine("        dataType: 'json',");
            //                sb.AppendLine("        data: JSON.stringify(requestPayload),");
            //                sb.AppendLine("        success: function(response) {");
            //                sb.AppendLine("          options.success({");
            //                sb.AppendLine("            data: response.data,");
            //                sb.AppendLine("            total: response.total");
            //                sb.AppendLine("          });");
            //                //sb.AppendLine($"          $('#{fieldNameLowerCase}').data('kendoDropDownList').value('{detailsFields.DefaultValue}');");
            //                sb.AppendLine("        },");
            //                sb.AppendLine("        error: function(xhr) {");
            //                sb.AppendLine("          console.error('Data Read Error:', xhr);");
            //                sb.AppendLine("          options.error(xhr);");
            //                sb.AppendLine("        }");
            //                sb.AppendLine("      });");
            //                sb.AppendLine("    }");
            //                sb.AppendLine("  },");
            //                sb.AppendLine("  schema: {");
            //                sb.AppendLine("    data: response => response.data || [],");
            //                sb.AppendLine("    total: response => response.total || 0");
            //                sb.AppendLine("  },");
            //                sb.AppendLine("  serverPaging: true,");
            //                sb.AppendLine("  serverFiltering: true,");
            //                sb.AppendLine("  serverSorting: true");
            //                sb.AppendLine("}");

            //            }
            //            else
            //            {
            //                sb.AppendLine("    dataSource: {");
            //                sb.AppendLine($"   sort: {{ field: \"{textFieldLowerCase}\", dir: 'asc' }},");
            //                sb.AppendLine("        transport: {");
            //                sb.AppendLine("            read: function (options) {");
            //                sb.AppendLine($"                $.ajax({{");
            //                sb.AppendLine($"                    url: backendUrl + '/{(detailsFields.SourceTableName ?? "").ToLower()}',"); // Adjust URL to get Student IDs
            //                sb.AppendLine("                    type: 'GET',");
            //                sb.AppendLine("                    dataType: 'json',");
            //                sb.AppendLine("                    success: function (response) {");
            //                sb.AppendLine("                        options.success(response);");
            //                if (string.Equals(detailsFields.TypeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) ||
            //                   string.Equals(detailsFields.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
            //                {
            //                    sb.AppendLine($" $('#{fieldNameLowerCase}').data('kendoMultiSelect').value('{detailsFields.DefaultValue}'); ");
            //                }
            //                else
            //                {
            //                    sb.AppendLine($" $('#{fieldNameLowerCase}').data('kendoDropDownList').value('{detailsFields.DefaultValue}'); ");
            //                }
            //                sb.AppendLine("                    },");
            //                sb.AppendLine("                    error: function (xhr, status, error) {");
            //                sb.AppendLine("                        console.error('Error fetching data:', error);");
            //                sb.AppendLine("                        options.error(xhr);");
            //                sb.AppendLine("                    }");
            //                sb.AppendLine("                });");
            //                sb.AppendLine("            }");
            //                sb.AppendLine("        }");
            //                sb.AppendLine("    },");
            //            }
                       

            //            if (string.Equals(detailsFields.TypeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) || string.Equals(detailsFields.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
            //                {
            //                    sb.AppendLine("dataBound: function () {");
            //                    sb.AppendLine("    fnSyncCheckboxes(this);");
            //                    sb.AppendLine("    updateSelectAllState(this); // keep select all synced initially");
            //                    sb.AppendLine("},");
            //                    sb.AppendLine("change: function () {");
            //                    sb.AppendLine("    fnSyncCheckboxes(this);");
            //                    sb.AppendLine("    updateSelectAllState(this); // sync after every change");
            //                    sb.AppendLine("},");
            //                    sb.AppendLine("headerTemplate:");
            //                    sb.AppendLine("    \"<div class='select-all-wrapper'>\" +");
            //                    sb.AppendLine("    \"  <label><input type='checkbox' id='selectAllCheckbox' /> Select All</label>\" +");
            //                    sb.AppendLine("    \"</div>\",");
            //                    sb.AppendLine("");
            //                    sb.AppendLine($"itemTemplate: \"<label class='custom-checkbox-wrapper'> <input type='checkbox' class='custom-checkbox' value='#: id #' /> #: {textFieldLowerCase} # </label>\"");
            //                    sb.AppendLine("});");
            //                    sb.AppendLine("");
            //                    sb.AppendLine("$(document).on(\"change\", \"#selectAllCheckbox\", function () {");
            //                    sb.AppendLine($"    var multiSelect = $(\"#{fieldNameLowerCase}\").data(\"kendoMultiSelect\");");
            //                    sb.AppendLine("");
            //                    sb.AppendLine("    if (this.checked) {");
            //                    sb.AppendLine("        var allValues = multiSelect.dataSource.view().map(function (item) {");
            //                    sb.AppendLine("            return item.id;");
            //                    sb.AppendLine("        });");
            //                    sb.AppendLine("        multiSelect.value(allValues);");
            //                    sb.AppendLine("    } else {");
            //                    sb.AppendLine("        multiSelect.value([]);");
            //                    sb.AppendLine("    }");
            //                    sb.AppendLine("");
            //                    sb.AppendLine("    fnSyncCheckboxes(multiSelect);");
            //                    sb.AppendLine("    updateSelectAllState(multiSelect); // sync checkbox state");

            //                }
            //                else if (string.Equals(detailsFields.TypeId, FieldTypeEnums.Radiogroup.ToString(), StringComparison.OrdinalIgnoreCase))
            //                {
            //                    sb.AppendLine("template:");
            //                    sb.AppendLine("    \"<label class='custom-radio-wrapper'>\" +");
            //                    sb.AppendLine($"    \" <input type='radio' name='ccRadio' value='#: id #' /> #: {textFieldLowerCase} #\" +");
            //                    sb.AppendLine("    \"</label>\",");
            //                    sb.AppendLine("dataBound: function () {");
            //                    sb.AppendLine("    updateRadios(this);");
            //                    sb.AppendLine("},");
            //                    sb.AppendLine("change: function () {");
            //                    sb.AppendLine("    updateRadios(this);");
            //                    sb.AppendLine("}");
            //                }
            //                sb.AppendLine("});");
            //            }



            //            // Child Dropdown (LastName) - Cascading based on selected StudentID
            //            if (!string.IsNullOrEmpty(detailsFields?.ParentFieldName))
            //            {
            //                // var fieldNameLowerCase1 = char.ToLower(Detailsfields.FieldName.Trim()[0]) + Detailsfields.FieldName.Trim()[1..];
            //                string fieldNameLower = !string.IsNullOrWhiteSpace(detailsFields.FieldName) && detailsFields.FieldName.Trim().Length > 1 ? char.ToLower(detailsFields.FieldName.Trim()[0]) + detailsFields.FieldName.Trim()[1..] : string.Empty;

            //                var parentFieldNameLowerCase = char.ToLower(detailsFields.ParentFieldName.Trim()[0]) + detailsFields.ParentFieldName.Trim()[1..];

            //                //var textFieldLowerCase1 = char.ToLower(Detailsfields.TextFieldName.Trim()[0]) + Detailsfields.TextFieldName.Trim()[1..];
            //                string textFieldLowerCase1 = !string.IsNullOrWhiteSpace(detailsFields.TextFieldName) && detailsFields.TextFieldName.Trim().Length > 1 ? char.ToLower(detailsFields.TextFieldName.Trim()[0]) + detailsFields.TextFieldName.Trim()[1..] : string.Empty;

            //                if (detailsFields.IsMultiColumn == true)
            //                {
            //                    sb.AppendLine($"$('#{fieldNameLowerCase}').kendoMultiColumnComboBox({{");
            //                }
            //                else
            //                {
            //                    sb.AppendLine($"$('#{fieldNameLowerCase}').kendoDropDownList({{");
            //                }
            //                sb.AppendLine("    optionLabel: '-- Select --',");
            //                sb.AppendLine($"    dataTextField: '{textFieldLowerCase1}',");
            //                sb.AppendLine("    dataValueField: 'id',");
            //                sb.AppendLine($"        filter: '{detailsFields.FilterOption}',");
            //                sb.AppendLine("    autoBind: false,");
            //                sb.AppendLine("    enable: true,");
            //                if (detailsFields.IsMultiColumn == true)
            //                {
            //                    sb.AppendLine("    columns: [");
            //                    if (detailsFields.MultiColumnFieldNames != null && detailsFields.MultiColumnFieldNames.Count != 0)
            //                    {
            //                        for (int i = 0; i < detailsFields.MultiColumnFieldNames.Count; i++)
            //                        {
            //                            var column = detailsFields.MultiColumnFieldNames[i];
            //                            var comma = i < detailsFields.MultiColumnFieldNames.Count - 1 ? "," : "";
            //                            //var trimmedFieldName = (column.SourceFieldName ?? "").TrimEnd();
            //                            //var fieldNameCamelCase = char.ToLower(trimmedFieldName[0]) + trimmedFieldName[1..];
            //                            var fieldNameCamelCase = !string.IsNullOrWhiteSpace(column.SourceFieldName) && column.SourceFieldName.Length > 1 ? column.SourceFieldName?.Trim().ToLower() : string.Empty;
            //                            sb.AppendLine($"        {{ field: '{fieldNameCamelCase}', title: '{column.SourceFieldName}' }}{comma}");
            //                        }
            //                    }
            //                    sb.AppendLine("    ],");
            //                }

            //                sb.AppendLine("    dataSource: {");
            //                sb.AppendLine($"   sort: {{ field: \"{textFieldLowerCase1}\", dir: 'asc' }},");
            //                sb.AppendLine("        transport: {");
            //                sb.AppendLine("            read: function (options) {");
            //                sb.AppendLine("                var parentId = options.data.parentId;");
            //                sb.AppendLine("                if (parentId) {");
            //                sb.AppendLine("                    $.ajax({");
            //                if (detailsFields.SourceHeaderTableName != null)
            //                {
            //                    sb.AppendLine($"                        url: backendUrl + '/{(detailsFields.SourceTableName ?? "").ToLower()}/' + parentId,");
            //                }
            //                if (!string.IsNullOrEmpty(detailsFields.ParentFieldName) && detailsFields.ParentSourceTblName == detailsFields.SourceHeaderTableName)
            //                {
            //                    sb.AppendLine($"                        url: backendUrl + '/{tableName.ToLower()}/' + parentId,");
            //                }
            //                sb.AppendLine("                        type: 'GET',");
            //                sb.AppendLine("                        dataType: 'json',");
            //                sb.AppendLine("                        success: function (response) {");
            //                sb.AppendLine("                            if (!Array.isArray(response)) {");
            //                sb.AppendLine("                                response = [response];");
            //                sb.AppendLine("                            }");
            //                sb.AppendLine("                            options.success(response);");
            //                sb.AppendLine("                        },");
            //                sb.AppendLine("                        error: function (jqXHR, textStatus, errorThrown) {");
            //                sb.AppendLine("                            console.error('Error fetching data: ' + textStatus + ' ' + errorThrown);");
            //                sb.AppendLine("                        }");
            //                sb.AppendLine("                    });");
            //                sb.AppendLine("                } else {");
            //                sb.AppendLine("                    // No parent selected: clear dropdown");
            //                sb.AppendLine("                    options.success([]);");
            //                sb.AppendLine("                }");
            //                sb.AppendLine("            }");
            //                sb.AppendLine("        }");
            //                sb.AppendLine("    }");
            //                sb.AppendLine("});");

            //                // Add change event on the Parent dropdown (StudentID)
            //                sb.AppendLine($"$('#{parentFieldNameLowerCase}').bind('change', function(e) {{");
            //                sb.AppendLine($"        var selectedValue = $('#{parentFieldNameLowerCase}').val();");
            //                if (detailsFields.IsMultiColumn == true)
            //                {
            //                    sb.AppendLine($"        var childDropDown = $('#{fieldNameLower}').data('kendoMultiColumnComboBox');");
            //                }
            //                else
            //                {
            //                    sb.AppendLine($"        var childDropDown = $('#{fieldNameLower}').data('kendoDropDownList');");
            //                }
            //                sb.AppendLine("        if (selectedValue) {");
            //                sb.AppendLine("            if (childDropDown) {");
            //                //  sb.AppendLine("                childDropDown.enable(true);");       commented code due to enable  dd  so that it not desabled but  show no data
            //                sb.AppendLine("                childDropDown.dataSource.read({ parentId: selectedValue });");
            //                sb.AppendLine("            }");
            //                sb.AppendLine("        } else {");
            //                sb.AppendLine("            if (childDropDown) {");
            //                // sb.AppendLine("                childDropDown.enable(false);");  commented code due to enable  dd  so that it not desabled but  show no data
            //                sb.AppendLine("                childDropDown.value('');");
            //                sb.AppendLine("                childDropDown.dataSource.data([]);");  // Clear the data
            //                sb.AppendLine("                childDropDown.text('');");  // Clear the text
            //                sb.AppendLine($"            $('#{fieldNameLower}').trigger('change');");
            //                sb.AppendLine("            }");
            //                sb.AppendLine("        }");
            //                sb.AppendLine("});");
            //            }
            //        }
            //    }



            sb.AppendLine("function handleBetween(filter, field, pickerSelector, format, pickerType = 'DateRange') {");
            sb.AppendLine("    if (pickerType === 'DateRange') {");
            sb.AppendLine("        const picker = $(pickerSelector).data('kendoDateRangePicker');");
            sb.AppendLine("        if (picker) {");
            sb.AppendLine("            const range = picker.range();");
            sb.AppendLine("            if (range?.start && range?.end) {");
            sb.AppendLine("                filter.filters.push({ field, operator: 'gte', value: kendo.toString(range.start, format) });");
            sb.AppendLine("                filter.filters.push({ field, operator: 'lte', value: kendo.toString(range.end, format) });");
            sb.AppendLine("            }");
            sb.AppendLine("        }");
            sb.AppendLine("    } else if (pickerType === 'DateTime') {");
            sb.AppendLine("        const startPicker = $(`#start_${field}`).data('kendoDateTimePicker');");
            sb.AppendLine("        const endPicker = $(`#end_${field}`).data('kendoDateTimePicker');");
            sb.AppendLine("        if (startPicker && endPicker) {");
            sb.AppendLine("            const startVal = startPicker.value();");
            sb.AppendLine("            const endVal = endPicker.value();");
            sb.AppendLine("            if (startVal && endVal) {");
            sb.AppendLine("                filter.filters.push({ field, operator: 'gte', value: kendo.toString(startVal, format) });");
            sb.AppendLine("                filter.filters.push({ field, operator: 'lte', value: kendo.toString(endVal, format) });");
            sb.AppendLine("            }");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            sb.AppendLine();

            sb.AppendLine("function handleSingle(parentData, field, pickerType, format) {");
            sb.AppendLine("    const picker = $(`#${field}`).data(pickerType);");
            sb.AppendLine("    const val = picker?.value();");
            sb.AppendLine("    if (val) parentData[field] = kendo.toString(val, format);");
            sb.AppendLine("}");




            //sb.AppendLine("     var notification = $('#notification').kendoNotification({");
            //    sb.AppendLine("        animation: { open: { effects: \"slideIn:left\" }, close: { effects: \"slideIn:left\", reverse: true } },");
            //    sb.AppendLine("        position: { top: 91, right: 80 },");
            //    sb.AppendLine("        stacking: 'down',");
            //    sb.AppendLine("        autoHideAfter: 5000,");
            //    sb.AppendLine("        hideOnClick: true,");
            //    sb.AppendLine("        button: true");
            //    sb.AppendLine("     }).data('kendoNotification');");

            //    sb.AppendLine("     function showNotification(type, message) {");
            //    sb.AppendLine("        notification.show(message, type);");
            //    sb.AppendLine("     }");

                //sb.AppendLine("}");

                sb.AppendLine("function formatUtcToLocal(dbDateString, format = 'dd-MM-yyyy HH:mm') {");
                sb.AppendLine("    if (!dbDateString) return '';"); // null or empty check
                sb.AppendLine("    const localDate = new Date(dbDateString + 'Z');"); // Append Z to mark it as UTC
                sb.AppendLine("    if (isNaN(localDate.getTime())) return '';"); // invalid date check
                sb.AppendLine("    return kendo.toString(localDate, format);");
                sb.AppendLine("}");


                //sb.AppendLine("function clearSearch() {");
                //sb.AppendLine("    $('input, select').each(function () {");
                //sb.AppendLine("        var $el = $(this);");
                //sb.AppendLine("        var fieldType = $el.attr('type');");
                //sb.AppendLine("");
                //sb.AppendLine("        if (fieldType === 'checkbox' || fieldType === 'radio') {");
                //sb.AppendLine("            $el.prop('checked', false);");
                //sb.AppendLine("        } else {");
                //sb.AppendLine("            // Handle Kendo DropDownList");
                //sb.AppendLine("            var ddl = $el.data('kendoDropDownList');");
                //sb.AppendLine("            if (ddl) {");
                //sb.AppendLine("                ddl.value('');   // clears selection (goes back to optionLabel)");
                //sb.AppendLine("                return;");
                //sb.AppendLine("            }");
                //sb.AppendLine("");
                //sb.AppendLine("            // Handle Kendo MultiSelect");
                //sb.AppendLine("            var ms = $el.data('kendoMultiSelect');");
                //sb.AppendLine("            if (ms) {");
                //sb.AppendLine("                ms.value([]);   // clears all selections");
                //sb.AppendLine("                return;");
                //sb.AppendLine("            }");
                //sb.AppendLine("");
                //sb.AppendLine("            // Default for normal inputs/selects");
                //sb.AppendLine("            $el.val('');");
                //sb.AppendLine("        }");
                //sb.AppendLine("    });");
                //sb.AppendLine("");

                //sb.AppendLine("    var filter = { logic: 'and', filters: [] };");


                //sb.AppendLine($"        var grid = $('#{tableName}Grid').data('kendoGrid');");
                //sb.AppendLine("        grid.dataSource.filter(filter);");
                //sb.AppendLine("        grid.dataSource.read();");

                //sb.AppendLine("}");
                foreach (var field in fields)
                {
                    //if (!Enum.TryParse<FieldTypeEnums>(field.FieldType, true, out var fieldType))
                    //    continue;

                    if (string.Equals(field.FieldType, FieldTypeEnums.Radiogroup.ToString(), StringComparison.OrdinalIgnoreCase))
                    {

                        sb.AppendLine("function updateRadios(dd) {");
                        sb.AppendLine("    var value = dd.value();");
                        sb.AppendLine("    dd.list.find(\"input[type=radio]\").each(function () {");
                        sb.AppendLine("        $(this).prop(\"checked\", $(this).val() === value);");
                        sb.AppendLine("    });");
                        sb.AppendLine("}");

                    }
                    else if(string.Equals(field.FieldType , FieldTypeEnums.Datetime.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                    sb.AppendLine("function fromDbDateTimeString(dbDateTimeStr) {");
                    sb.AppendLine("    if (!dbDateTimeStr) return null;");
                    sb.AppendLine("");
                    sb.AppendLine("    const match = dbDateTimeStr.match(/^(\\" + "d{4})-(\\" + "d{2})-(\\" + "d{2}) (\\" + "d{1,2}):(\\" + "d{2}):(\\" + "d{2}) (AM|PM)$/i);");
                    sb.AppendLine("");
                    sb.AppendLine("    if (match) {");
                    sb.AppendLine("        let [_, year, month, day, hour, minute, second, meridian] = match;");
                    sb.AppendLine("        year = Number(year);");
                    sb.AppendLine("        month = Number(month) - 1;");
                    sb.AppendLine("        day = Number(day);");
                    sb.AppendLine("        hour = Number(hour);");
                    sb.AppendLine("        minute = Number(minute);");
                    sb.AppendLine("        second = Number(second);");
                    sb.AppendLine("");
                    sb.AppendLine("        if (meridian.toUpperCase() === 'PM' && hour < 12) hour += 12;");
                    sb.AppendLine("        if (meridian.toUpperCase() === 'AM' && hour === 12) hour = 0;");
                    sb.AppendLine("");
                    sb.AppendLine("        return new Date(year, month, day, hour, minute, second);");
                    sb.AppendLine("    }");
                    sb.AppendLine("");
                    sb.AppendLine("    const normalized = dbDateTimeStr.replace(' ', 'T');");
                    sb.AppendLine("    const date = new Date(normalized);");
                    sb.AppendLine("    return isNaN(date.getTime()) ? null : date;");
                    sb.AppendLine("}");

                }
                else if (string.Equals(field.FieldType, FieldTypeEnums.Date.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine("function fromDbDateString(dbDateStr) {");
                    sb.AppendLine("    if (!dbDateStr) return null;");
                    sb.AppendLine("    const [year, month, day] = dbDateStr.split('-').map(Number);");
                    sb.AppendLine("    return new Date(year, month - 1, day);");
                    sb.AppendLine("}");

                }

                else if (string.Equals(field.FieldType, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) || string.Equals(field.FieldType, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine("function fnSyncCheckboxes(ms) {");
                        sb.AppendLine("    const sel = ms.value().map(String);");
                        sb.AppendLine("");
                        sb.AppendLine("    ms.ul.find(\"li\").each(function () {");
                        sb.AppendLine("        const $li = $(this);");
                        sb.AppendLine("        const item = ms.dataItem($li.index());");
                        sb.AppendLine("        const id = String(item.id);");
                        sb.AppendLine("        const $cb = $li.find(\".custom-checkbox\");");
                        sb.AppendLine("");
                        sb.AppendLine("        // sync checkbox state");
                        sb.AppendLine("        $cb.prop(\"checked\", sel.includes(id));");
                        sb.AppendLine("");
                        sb.AppendLine("        // ensure only one handler");
                        sb.AppendLine("        $cb.off(\"click\").on(\"click\", function (e) {");
                        sb.AppendLine("            e.stopPropagation(); // stop Kendo from hijacking the click");
                        sb.AppendLine("");
                        sb.AppendLine("            let values = ms.value().map(String);");
                        sb.AppendLine("            if (this.checked && !values.includes(id)) {");
                        sb.AppendLine("                values.push(id);");
                        sb.AppendLine("            } else if (!this.checked && values.includes(id)) {");
                        sb.AppendLine("                values = values.filter(v => v !== id);");
                        sb.AppendLine("            }");
                        sb.AppendLine("");
                        sb.AppendLine("            ms.value(values);");
                        sb.AppendLine("            ms.trigger(\"change\");");
                        sb.AppendLine("        });");
                        sb.AppendLine("");
                        sb.AppendLine("        // make label text clickable too");
                        sb.AppendLine("        $li.find(\"label\").off(\"click\").on(\"click\", function (e) {");
                        sb.AppendLine("            e.preventDefault(); // stop Kendo's default li-select");
                        sb.AppendLine("            $cb.trigger(\"click\"); // simulate checkbox click");
                        sb.AppendLine("        });");
                        sb.AppendLine("    });");
                        sb.AppendLine("}");
                        sb.AppendLine("");
                        sb.AppendLine("function updateSelectAllState(ms) {");
                        sb.AppendLine("    var total = ms.dataSource.view().length;");
                        sb.AppendLine("    var selected = ms.value().length;");
                        sb.AppendLine();
                        sb.AppendLine("    if (selected === 0) {");
                        sb.AppendLine("        $(\"#selectAllCheckbox\").prop(\"checked\", false).prop(\"indeterminate\", false);");
                        sb.AppendLine("    } else if (selected === total) {");
                        sb.AppendLine("        $(\"#selectAllCheckbox\").prop(\"checked\", true).prop(\"indeterminate\", false);");
                        sb.AppendLine("    } else {");
                        sb.AppendLine("        $(\"#selectAllCheckbox\").prop(\"checked\", false).prop(\"indeterminate\", true);");
                        sb.AppendLine("    }");
                        sb.AppendLine("}");
                    }
                    else if (string.Equals(field.FieldType, FieldTypeEnums.Timeduration.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine("function hmsStringToMs(hms) {");
                    sb.AppendLine("    if (!hms) return 0;");
                    sb.AppendLine("    const [h, m, s] = hms.split(':').map(Number);");
                    sb.AppendLine("    return ((h * 3600) + (m * 60) + s) * 1000;");
                    sb.AppendLine("}");

                }
            }


                if (isHierarchical)
                {
                    sb.AppendLine("    function AddChild(e) {");
                    sb.AppendLine("        let parentId = $(e).data('id');");
                    sb.AppendLine("        if (!parentId) {");
                    sb.AppendLine("            fnShowNotification('Parent ID is missing or invalid.','error');");
                    sb.AppendLine("            return false;");
                    sb.AppendLine("        }"); // Closing bracket for the if statement

                    // Use string concatenation instead of string interpolation
                    sb.AppendLine("        var strURL = '/" + tableName + "/" + firstFormName + "Details?parentId=' + parentId;");

                    sb.AppendLine("        window.location.href = strURL;");
                    sb.AppendLine("        return false;");
                    sb.AppendLine("    }");
                    sb.AppendLine("");

                }
                sb.AppendLine("    function EditUser(e) {");
                sb.AppendLine("        var FormID = $(e).data('id');");
                sb.AppendLine("    var parentId = $(e).data('parentid');");
                sb.AppendLine("        if (!FormID) {");
                sb.AppendLine("            fnShowNotification('Form ID is missing or invalid.','error');");
                sb.AppendLine("            return false;");
                sb.AppendLine("        }"); // Ensure FormID is valid

                // Use string concatenation instead of string interpolation in JavaScript
                //sb.AppendLine("        var strURL = '/" + tableName + "/" + firstFormName + "Details?id=' + FormID;");
                sb.AppendLine("        var strURL = '/" + tableName + "/" + firstFormName + "Details?id=' + FormID + (parentId ? '&parentId=' + parentId : '');");
                sb.AppendLine("        window.location.href = strURL;");
                sb.AppendLine("        return false;");
                sb.AppendLine("    }");
                sb.AppendLine("");


                sb.AppendLine("    function DeleteUser(e) {");
                sb.AppendLine("        var FormID = $(e).data('id');");

                sb.AppendLine("        // Check if FormID exists");
                sb.AppendLine("        if (!FormID) {");
                sb.AppendLine("            console.error('FormID is missing or invalid.');");
                sb.AppendLine("            return false;");
                sb.AppendLine("        }");

                sb.AppendLine("        // Confirm deletion");
                sb.AppendLine("        if (confirm('Are you sure you want to delete this record?')) {");
                sb.AppendLine("            // Make AJAX request to delete");
                //sb.AppendLine("            var url = backendUrl + '/Delete/' + FormID;");
                sb.AppendLine($"               var url= backendUrl + `/{tableName.ToLower()}/`+ FormID;");

                sb.AppendLine("            console.log('Calling DELETE URL: ', url);");
                sb.AppendLine("            $.ajax({");

                sb.AppendLine("                url: url,");
                sb.AppendLine("                type: 'DELETE',");
                sb.AppendLine("                beforeSend: function (xhr) {");
                sb.AppendLine("                    var token = localStorage.getItem('jwtToken');");
                sb.AppendLine("                    if (token) {");
                sb.AppendLine("                        xhr.setRequestHeader('Authorization', 'Bearer ' + token);");
                sb.AppendLine("                    }");
                sb.AppendLine("                },");
                sb.AppendLine("                success: function (response) {");
                sb.AppendLine("                    // Show success notification");
                sb.AppendLine("                    fnShowNotification('Delete successfully', 'success');");
                sb.AppendLine("                    // Refresh data after deletion");
                sb.AppendLine($"                    $('#{tableName}Grid').data('kendoTreeList').dataSource.fetch();");
                sb.AppendLine("                    // Reload the page");
                sb.AppendLine("                    location.reload();");
                sb.AppendLine("                },");
                sb.AppendLine("                error: function (xhr, status, error) {");
                sb.AppendLine("                    // Log and show error notification");
                sb.AppendLine("                    console.error('Error deleting menu:', error);");
                sb.AppendLine("                    fnShowNotification('Error deleting data', 'error');");
                sb.AppendLine("                }");
                sb.AppendLine("            });");
                sb.AppendLine("        }");

                sb.AppendLine("        return false;");
                sb.AppendLine("    }");
                sb.AppendLine("</script>");

                // Create folder and file
                string projectFolderName = $@"{clientName}\{projectName}";

                string directoryPath = $@"C:\ClientProject\{projectFolderName}\Presentation\ClientProjectBuilder.MvcUI\Views\{tableName}";

                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                string filePath = "";
                foreach (var field in displayfields)
                {
                    if (tableName == field.TableName)
                    {
                        filePath = Path.Combine(directoryPath, $"{field.FormName}List.cshtml");
                        try
                        {
                            File.WriteAllText(filePath, sb.ToString());
                            Console.WriteLine($"File created: {filePath}");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error writing file: {ex.Message}");
                        }
                    }
                }
            }
        }
    }