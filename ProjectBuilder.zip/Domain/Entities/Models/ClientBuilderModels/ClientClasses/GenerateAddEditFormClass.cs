﻿using Dapper;
using DapperDB;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using Entities.Models.Table;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Text;
using Entities.Enums;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateAddEditFormClass(DapperDbContext.DbContext context, IConfiguration configuration)
    {
        private readonly DapperDbContext.DbContext _context = context;

        private readonly IConfiguration _configuration = configuration;

        public async Task<TableModel?> GetTableData(int? id, string configConnectionString)
        {
            try
            {
                //string? originalConnectionString = _configuration.GetConnectionString("DefaultConnection");

                using var connection = new SqlConnection(configConnectionString); // Use directly here
                await connection.OpenAsync();

                var result = await connection.QuerySingleOrDefaultAsync<TableModel>(
                    $"SELECT * FROM [{DatabaseSchema.Config.ToSchemaName()}].TableDefination WHERE ID=@id", new { id });

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public async Task<bool> IsCascadingFieldAsync(int fieldId, int formId, string configConnectionString)
        {
            string query = $@"
        SELECT COUNT(*)
        FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination AS f
        WHERE f.ParentFieldId = @FieldId
          AND f.TableId = (
              SELECT TOP 1 TableId FROM [{DatabaseSchema.Config.ToSchemaName()}].Form WHERE Id = @FormId
          )";

            //string? originalConnectionString = _configuration.GetConnectionString("DefaultConnection");

            using SqlConnection connection = new(configConnectionString);
            SqlCommand command = new(query, connection);
            command.Parameters.AddWithValue("@FieldId", fieldId);
            command.Parameters.AddWithValue("@FormId", formId);

            await connection.OpenAsync();
            //int count = (int)await command.ExecuteScalarAsync();

            object? result = await command.ExecuteScalarAsync();
            int count = Convert.ToInt32(result);
            return count > 0;
        }

        public static string GetLabelClass(int AlignmentType)
        {
            switch (AlignmentType)
            {
                case 1: return "label-left";
                case 2: return "label-top";
                // case 3: return "floating-label";
                default: return "";
            }
        }

        private string GetDbTypeAttribute(FieldTypeEnums fieldType) => fieldType switch
        {
            FieldTypeEnums.Decimal => "decimal",
            FieldTypeEnums.Int => "int",
            FieldTypeEnums.Float => "float",
            FieldTypeEnums.Smallint => "smallint",
            FieldTypeEnums.Money => "money",
            FieldTypeEnums.Tinyint => "tinyint",
            FieldTypeEnums.Bigint => "bigint",
            _ => string.Empty
        };
        //private double GetMinValue(FieldTypeEnums fieldType) => fieldType switch
        //{
        //    FieldTypeEnums.Int => int.MinValue,
        //    FieldTypeEnums.Bigint => long.MinValue,
        //    FieldTypeEnums.Smallint => short.MinValue,
        //    FieldTypeEnums.Tinyint => 0,
        //    FieldTypeEnums.Money => -922337203685477.5808,
        //    FieldTypeEnums.Float => -3.4E+38,
        //    FieldTypeEnums.Decimal => -999999999999999999,
        //    _ => 0
        //};

        //private double GetMaxValue(FieldTypeEnums fieldType) => fieldType switch
        //{
        //    FieldTypeEnums.Int => int.MaxValue,
        //    FieldTypeEnums.Bigint => long.MaxValue,
        //    FieldTypeEnums.Smallint => short.MaxValue,
        //    FieldTypeEnums.Tinyint => 255,
        //    FieldTypeEnums.Money => 922337203685477.5807,
        //    FieldTypeEnums.Float => 3.4E+38,
        //    FieldTypeEnums.Decimal => 999999999999999999,
        //    _ => 0
        //};

        public (double Min, double Max) GetValueRange(FieldTypeEnums fieldType)
        {
            return fieldType switch
            {
                FieldTypeEnums.Int => (int.MinValue, int.MaxValue),
                FieldTypeEnums.Bigint => (long.MinValue, long.MaxValue),
                FieldTypeEnums.Smallint => (short.MinValue, short.MaxValue),
                FieldTypeEnums.Tinyint => (0, 255),
                FieldTypeEnums.Money => (-922337203685477.5808, 922337203685477.5807),
                FieldTypeEnums.Float => (-3.4E+38, 3.4E+38),
                FieldTypeEnums.Decimal => (-999999999999999999, 999999999999999999),
                _ => (0, 0)
            };
        }

        public async Task<string> GenerateAddEditForm(string projectName, string clientName, ClientTable table, List<ClientCardViewFields> fields, List<ClientDisplayField> displayfields, List<ClientActionDetail> formActionQuery, bool isDetailsForm, IEnumerable<ClientForm> forms, List<ClientDisplayField>? displayfieldByParentId, int AlignmentType, string configConnectionString)
        {
            //ArgumentNullException.ThrowIfNull(displayfieldByParentId);
            //ArgumentNullException.ThrowIfNull(displayfields);

            string cssClass = GetLabelClass(AlignmentType);
            List<string> uploadControlIds = [];
            List<(string FieldName, string UploadId)> imageUploadFields = [];

            HashSet<int> formId = [];
            foreach (var field in fields)
            {
                formId.Add(field.FormId);
            }
            var parentFormId = formId.FirstOrDefault();
            var parentForm = forms.FirstOrDefault(f => f.ID == parentFormId);
            //string parentFormName = null; 
            //if (parentForm != null)
            //{
            //    parentFormName = parentForm.DisplayName;
            //}
            string parentFormName = parentForm != null ? parentForm.DisplayName!.Trim() : string.Empty;
            var childForms = forms.Where(f => f.ParentId == parentFormId).ToList();
            StringBuilder sb = new();

            var groupedSections = fields
                .Where(f => f != null)
                .GroupBy(f => new
                {
                    SectionName = string.IsNullOrWhiteSpace(f.SectionName) ? "Default Section" : f.SectionName.Trim(),
                    f.SectionOrder
                })
               .OrderBy(g => g.Key.SectionOrder)
               .ToList();

            //sb.AppendLine("<div class=\"mt-4 main-section w-100 mb-4\">");
            //Detalis Tabing

            var CardViewLableName = fields.Select(f => f.CardViewLabel ?? "").Distinct().FirstOrDefault();

            sb.AppendLine("<div class=\"listsection\">");
            sb.AppendLine($"    <h4 style='font-weight:bold; font-size:28px;align-content:center;margin-bottom:20px;'>{CardViewLableName}</h4>");
            //sb.AppendLine($" <h3 id=\"pageTitle\" class=\"text-start text-primary mb-4\"> Create {parentForm.Name} </h3>");

            sb.AppendLine("    <div id=\"example\">");
            sb.AppendLine("        <div class=\"demo-section\">");
            sb.AppendLine("            <div id=\"tabstrip\">");
            sb.AppendLine("                <ul>");
            sb.AppendLine($"                    <li class=\"k-active\">{parentFormName}</li>");

            //Add Document Tab If Selected
            bool DocumentEnabled = parentForm?.IsDocumentEnabled ?? false;
            if (DocumentEnabled)
            {
                sb.AppendLine("      <li>Document</li>  ");
            }

            //sb.AppendLine("                    <li>Location</li>");
            //sb.AppendLine("                    <li>People</li>");
            foreach (var form in childForms)
            {
                var displayName = string.IsNullOrWhiteSpace(form.DisplayName) ? form.Name : form.DisplayName?.Trim() ?? "";
                sb.AppendLine($"                    <li>{displayName}</li>");
                //var childDisplayName = form.DisplayName.Trim(); 
                //sb.AppendLine($"       <li>{childDisplayName}</li>");
            }
            sb.AppendLine("                </ul>");
            sb.AppendLine("                <div class=\"mt-4 main-section\">");
            sb.AppendLine("                    <!-- Summary Tab -->");
            sb.AppendLine("<div id=\"errorMessageContainer\" style=\"display: none; margin-top: 15px; margin-bottom: 15px;\"></div>");

            // Start the form tag
            sb.AppendLine("<form id=\"Form\" method=\"post\">");

            // Outer Summary Tab Button

            // Outer Tab Content with Summary pane including inner section tabs
            sb.AppendLine("<div id=\"FormExtended\" class='tab-content mt-3'>");
            sb.AppendLine("    <div class='tab-pane fade show active' id='summary-tab' role='tabpanel' aria-labelledby='summary-tab'>");

            // Inner Section Tabs inside Summary tab
            sb.AppendLine("        <ul class='nav nav-tabs' role='tablist' id='sectionTabs'>");
            for (int i = 0; i < groupedSections.Count; i++)
            {
                var section = groupedSections[i];
                var activeClass = i == 0 ? "active" : "";
                var sectionId = "tab_" + section.Key.SectionName.Replace(" ", "_");

                sb.AppendLine("            <li class='nav-item' role='presentation'>");
                sb.AppendLine($"  <button class='nav-link {activeClass}' id='{sectionId}-tab' data-bs-toggle='tab' data-bs-target='#{sectionId}' type='button' role='tab' aria-controls='{sectionId}' aria-selected='{(i == 0).ToString().ToLower()}'>{section.Key.SectionName}</button>");
                sb.AppendLine("</li>");
            }
            sb.AppendLine("</ul>");

            // Inner Section Tab Content inside Summary
            sb.AppendLine("<div class='tab-content mt-3' id='sectionTabContent'>");
            for (int i = 0; i < groupedSections.Count; i++)
            {
                var section = groupedSections[i];
                var activeClass = i == 0 ? "show active" : "";
                var sectionId = "tab_" + section.Key.SectionName.Replace(" ", "_");

                sb.AppendLine($"<div class='tab-pane fade {activeClass}' id='{sectionId}' role='tabpanel' aria-labelledby='{sectionId}-tab'>");
                sb.AppendLine("<div class='row'>");

                // Generate fields inside this section
                //foreach (var field in section)
                //{
                //    //var fieldName = field.FieldName.Trim();
                //    var fieldName = field.FieldName?.Trim() ?? string.Empty;
                //    var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                //    var displayName = string.IsNullOrWhiteSpace(field.DisplayName) ? fieldName : (field.DisplayName?.Trim() ?? "");
                //    var readonlyAttribute = field.IsReadOnly ? "readonly" : "";
                //    var defaultValue = field.DefaultValue?.ToString()?.Trim() ?? "";
                //    var requiredAttributes = field.Mandatory ? $"required data-required-msg=\"{displayName} is required\"" : string.Empty;
                //    var requiredValidation = field.Mandatory ? $"<span class=\"login-danger required\">*</span>" : string.Empty;

                //    sb.AppendLine("    <div class=\"col-md-6\">");
                //    //sb.AppendLine($"        <div class=\"form-group {cssClass}\">");

                //    // Use different wrapper for RangeSlider
                //    if (field.TypeId == "rangeslider")
                //    {
                //        //sb.AppendLine($"        <div class=\"k-form-group {cssClass}\">");
                //        sb.AppendLine($"        <div class=\"k-form-group force-label-positioned force-{cssClass}\">");
                //    }
                //    else if (field.TypeId == "timeduration")
                //    {
                //        sb.AppendLine($"        <div class=\"form-group {cssClass} force-{cssClass}\">");
                //    }
                //    else if (field.TypeId == "richtexteditor")
                //    {
                //        sb.AppendLine($"       <div class=\"form-group force-label-positioned force-{cssClass}\">");
                //    }

                //    else if (field.TypeId != "slider")
                //    {
                //        sb.AppendLine($"        <div class=\"form-group {cssClass}\">");
                //    }


                //    if (field.TypeId == "int" || field.TypeId == "decimal" || field.TypeId == "float")
                //    {
                //        sb.AppendLine($" <input type=\"number\" class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {requiredAttributes} value=\"{defaultValue}\" {(field.TypeId == "decimal" || field.TypeId == "float" ? "step=\"0.01\"" : "")} {readonlyAttribute} />");
                //    }
                //    else if (field.TypeId == "varchar" || field.TypeId == "nvarchar")
                //    {
                //        if (field.Max)
                //        {
                //            sb.AppendLine($"  <textarea class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {requiredAttributes} {readonlyAttribute}>{defaultValue}</textarea>");
                //        }
                //        else
                //        {
                //            sb.AppendLine($"  <input type=\"text\" class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {requiredAttributes} value=\"{defaultValue}\" {readonlyAttribute} />");
                //        }

                //    }
                //    else if (field.TypeId == "switches")
                //    {
                //        sb.AppendLine($"  <input id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" class=\"form-control1 k-switch\" />");
                //    }
                //    //For Time-Duration
                //    else if (field.TypeId == "timeduration")
                //    {
                //        sb.AppendLine("<div class=\"kendo-timer-wrapper\">");

                //        sb.AppendLine($"        <input type=\"text\" class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}\"  name=\"{fieldNameLowerCase}\" {requiredAttributes} value=\"{defaultValue}\" {readonlyAttribute} title=\"{fieldName}\" />");
                //        sb.AppendLine("</div>");

                //    }
                //    else if (field.TypeId?.ToLower() == "varbinary" || field.TypeId?.ToLower() == "imageupload")
                //    {
                //        var uploadId = $"upload_{Guid.NewGuid():N}";
                //        //imageUploadFields.Add((field.FieldName.Trim(), uploadId));
                //        imageUploadFields.Add((field.FieldName?.Trim() ?? string.Empty, uploadId));

                //        uploadControlIds.Add(uploadId);

                //        sb.AppendLine($@"
                //        <div class=""mb-3"">
                //            <input id=""{uploadId}"" name=""{field.FieldName?.Trim() ?? string.Empty}"" type=""file"" />
                //        </div>");
                //    }
                //    //For RangeSlider
                //    //else if (field.TypeId.ToLower() == "rangeslider")
                //    else if ((field.TypeId?.ToLower() ?? "") == "rangeslider")
                //    {
                //        var minValue = field.MinValue ?? 0;
                //        var maxValue = field.MaxValue ?? 100;
                //        var smallStep = field.SmallStep ?? 1;
                //        var largeStep = field.LargeStep ?? 10;
                //        var symbol = string.IsNullOrEmpty(field.Symbol) ? "" : field.Symbol;

                //        // Parse default value
                //        var start = defaultValue?.Split(',')[0];
                //        var end = defaultValue?.Split(',').Length > 1 ? defaultValue.Split(',')[1] : null;

                //        var defaultStart = int.TryParse(start, out var sVal) ? sVal : minValue;
                //        var defaultEnd = int.TryParse(end, out var eVal) ? eVal : maxValue;

                //        sb.AppendLine("<div class=\"container mt-4\">");
                //        sb.AppendLine("  <div class=\"d-flex align-items-center mb-2\">");
                //        //sb.AppendLine($"    <label for=\"{fieldNameLowerCase}\" class=\"form-label1 me-3 mb-0\" style=\"white-space: nowrap;\">💰 {displayName}</label>");
                //        sb.AppendLine($"    <input type=\"hidden\" id=\"{fieldNameLowerCase}Value\" name=\"{fieldNameLowerCase}\" value=\"{defaultStart},{defaultEnd}\" />");
                //        sb.AppendLine($"    <div id=\"{fieldNameLowerCase}\" style=\"width: 100%;\">");
                //        sb.AppendLine("      <input />");
                //        sb.AppendLine("      <input />");
                //        sb.AppendLine("    </div>");
                //        sb.AppendLine("  </div>");
                //        sb.AppendLine("  <br/>");
                //        //sb.AppendLine($"  <div class=\"text-muted\" id=\"rangeValues_{fieldNameLowerCase}\"></div>");
                //        sb.AppendLine($"  <div class=\"text-muted\" id=\"rangeValues_{fieldNameLowerCase}\" style=\"font-size:15px;\"></div>");

                //        sb.AppendLine("</div>");
                //    }
                //    else if (field.TypeId == "date")
                //    {
                //        var formattedDate = DateTime.TryParse(defaultValue, out var dt) ? dt.ToString("yyyy-MM-dd") : defaultValue;
                //        sb.AppendLine($"  <input type=\"date\" class=\"form-control1 datepicker required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {requiredAttributes} value=\"{formattedDate}\" {readonlyAttribute} />");
                //    }
                //    else if (field.TypeId == "datetime")
                //    {


                //        DateTime dtUtc;
                //        string formattedDateTime = "";

                //        if (DateTime.TryParse(defaultValue, out var dtParsed))
                //        {
                //            dtUtc = DateTime.SpecifyKind(dtParsed, DateTimeKind.Utc);
                //            DateTime localTime = dtUtc.ToLocalTime();
                //            formattedDateTime = localTime.ToString("yyyy-MM-ddTHH:mm");
                //        }
                //        else
                //        {
                //            formattedDateTime = defaultValue;
                //        }

                //        // var formattedDateTime = DateTime.TryParse(defaultValue, out var dt2) ? dt2.ToString("yyyy-MM-ddTHH:mm") : defaultValue;
                //        sb.AppendLine($"  <input type=\"datetime-local\" class=\"form-control1 datetimepicker required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" value=\"{formattedDateTime}\"  {requiredAttributes} {readonlyAttribute} />");
                //    }
                //    else if (field.TypeId == "bit" || field.TypeId == "boolean")
                //    {
                //        var isChecked = defaultValue == "true" || defaultValue == "1" ? "checked" : "";
                //        sb.AppendLine($"  <input type=\"checkbox\" class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {isChecked} {requiredAttributes} {readonlyAttribute} />");
                //    }
                //    else if (field.TypeId == "dropdown")
                //    {
                //        sb.AppendLine($"  <input class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" value=\"{defaultValue}\" {requiredAttributes} {readonlyAttribute} />");
                //    }
                //    //else if (field.TypeId.ToLower() == "radiogroup")
                //    else if ((field.TypeId?.ToLower() ?? "") == "radiogroup")
                //    {
                //        //var radioFieldNameLower = char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim()[1..];
                //        //
                //        var radioFieldNameLower = !string.IsNullOrWhiteSpace(field.FieldName) && field.FieldName.Trim().Length > 1
                //                                  ? char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim()[1..]
                //                                  : string.Empty;

                //        var groupElementId = $"radiogroup_{radioFieldNameLower}";
                //        var containerId = $"{radioFieldNameLower}_container";
                //        var blockId = $"{radioFieldNameLower}_block";

                //        // Removed <div class="form-group label-left">
                //        sb.AppendLine($"<div id=\"{blockId}\" class=\"form-control1 p-3\">");

                //        // Search input
                //        sb.AppendLine($"    <input id=\"search_{radioFieldNameLower}\" class=\"form-control\" />");

                //        // Container for radio buttons
                //        sb.AppendLine($"    <div id=\"{containerId}\" class=\"radiobutton-group\" data-field-name=\"{radioFieldNameLower}\" data-default-value=\"{defaultValue}\" {readonlyAttribute} {requiredAttributes}>");
                //        sb.AppendLine($"        <ul id=\"{groupElementId}\" class=\"list-unstyled\"></ul>");
                //        sb.AppendLine("    </div>");
                //        sb.AppendLine("</div>"); // End of block div

                //        // JavaScript initialization
                //        sb.AppendLine("<script>");
                //        sb.AppendLine("$(document).ready(function () {");

                //        sb.AppendLine($"    $('#search_{radioFieldNameLower}').kendoTextBox({{");
                //        sb.AppendLine($"        placeholder: 'Search {field.FieldName}..',");
                //        sb.AppendLine("        clearButton: true");
                //        sb.AppendLine("    });");

                //        sb.AppendLine($"    $('#search_{radioFieldNameLower}').on('input', function () {{");
                //        sb.AppendLine("        var filter = $(this).val().toLowerCase();");
                //        sb.AppendLine($"        $('#{groupElementId} li').each(function () {{");
                //        sb.AppendLine("            var label = $(this).text().toLowerCase();");
                //        sb.AppendLine("            $(this).toggle(label.includes(filter));");
                //        sb.AppendLine("        });");
                //        sb.AppendLine("    });");

                //        sb.AppendLine("});");
                //        sb.AppendLine("</script>");
                //    }


                //    else if ((field.TypeId?.ToLower() ?? "") == "checkboxgroup")
                //    {
                //        var selectAllId = $"selectAll_{fieldNameLowerCase}";
                //        var groupElementId = $"checkboxgroup_{fieldNameLowerCase}";
                //        var containerId = $"{fieldNameLowerCase}_container";
                //        var blockId = $"{fieldNameLowerCase}_block";


                //        sb.AppendLine($"            <div id=\"{blockId}\" class=\"form-control1 p-3\">");

                //        sb.AppendLine($"            <input id=\"search_{fieldNameLowerCase}\"/>");
                //        sb.AppendLine($"                <div id=\"{fieldNameLowerCase}_options\" class=\"fw-bold mt-2\">Available {field.FieldName?.ToLower() ?? string.Empty} Options:</div>");
                //        sb.AppendLine($"                <input type=\"checkbox\" id=\"{selectAllId}\" class=\"k-checkbox k-checkbox-md k-rounded-md\">");
                //        sb.AppendLine($"                <label class=\"k-checkbox-label\" for=\"{selectAllId}\">Select all</label>");

                //        sb.AppendLine("                <hr class=\"my-2\">");

                //        sb.AppendLine($"                <div id=\"{containerId}\" class=\"checkbox-group\" data-field-name=\"{fieldNameLowerCase}\" data-default-value=\"{defaultValue}\" {readonlyAttribute} {requiredAttributes}>");
                //        sb.AppendLine($"                    <ul id=\"{groupElementId}\"></ul>");
                //        sb.AppendLine("                </div>");

                //        sb.AppendLine("            </div>");


                //        sb.AppendLine($"            <label for=\"{blockId}\" class=\"form-label1\">{field.FieldName}</label>");
                //    }


                //    else if (field.TypeId == "hyperlink")
                //    {
                //        var link = field.Link?.Trim() ?? "#";
                //        var displayText = string.IsNullOrWhiteSpace(field.DisplayName) ? link : field.DisplayName;

                //        sb.AppendLine($"  <a href=\"{link}\" id=\"{fieldNameLowerCase}\" target=\"_blank\">{displayText}</a>");
                //    }

                //    else if (field.TypeId == "captcha")
                //    {
                //        sb.AppendLine(" <input id=\"captcha\" /> ");
                //        sb.AppendLine(" <input type=\"hidden\" id=\"captchaId\" name=\"CaptchaID\" />");
                //    }
                //    else if (field.TypeId?.ToLower() == "colorpicker")
                //    {
                //        sb.AppendLine("  <div class=\"col-md-6\">");
                //        sb.AppendLine("    <div class=\"form-group label-left d-flex align-items-center\" style=\"gap: 10px;\">");
                //        sb.AppendLine($"      <label for=\"{fieldNameLowerCase}\" class=\"form-label1\">{displayName}</label>");
                //        sb.AppendLine($"      <input type=\"color\" class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" value=\"{defaultValue}\" {requiredAttributes} {readonlyAttribute} style=\"width: 100px; border-radius: 2px; padding: 6px;\" />");
                //        sb.AppendLine($"      <input type=\"text\" id=\"{fieldNameLowerCase}Name\" name=\"{fieldNameLowerCase}Name\" class=\"form-control1\" readonly style=\"width: 100px; border-radius: 2px; padding: 6px;\" />");
                //        sb.AppendLine("    </div>");
                //        sb.AppendLine("  </div>");
                //    }

                //    else if (field.TypeId == "slider")
                //    {
                //        if (field.Orientation == 2)
                //        {
                //            sb.AppendLine("    <div class=\"d-flex justify-content-center\">");
                //            sb.AppendLine("        <div class=\"col-md-2\">");
                //        }
                //        sb.AppendLine($"            <div class=\"form-group {cssClass}\">");
                //        sb.AppendLine($"               <input type=\"range\" class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}\" {readonlyAttribute}  {requiredAttributes} />");
                //        sb.AppendLine($"               <label for=\"{field.FieldName?.Trim() ?? string.Empty}\" class=\"form-label1\">{displayName}</label>");
                //        if (field.Orientation == 2)
                //        {
                //            sb.AppendLine("            </div>");
                //            sb.AppendLine("        </div>");
                //        }
                //    }
                //    else if (field.TypeId == "rating")
                //    {
                //        sb.AppendLine($"  <div id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\"  {requiredAttributes} class=\"form-control1 required_field\"></div>");
                //    }
                //    else if (field.TypeId == "richtexteditor")
                //    {

                //        sb.AppendLine($"    <textarea id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" class=\"form-control1 required_field\" style=\"padding: 5px; font-size: 14px; border: 1px solid #ccc; border-radius:10px; resize: vertical;\"></textarea>");
                //        sb.AppendLine($"    <label for=\"{fieldNameLowerCase}\" class=\"form-label1\">{displayName}</label>");


                //    }
                //    else if ((field.TypeId?.ToLower() ?? "") == "signature")
                //    {
                //        sb.AppendLine($"  <div class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}_container\" {requiredAttributes}>");
                //        sb.AppendLine($"     <canvas id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" class=\"signature-canvas\"></canvas>");
                //        sb.AppendLine("      <button type=\"button\" class=\"clear-signature-btn\">Clear</button>");
                //        sb.AppendLine("  </div>");
                //    }
                //    else if (string.Equals(field?.TypeId, "image", StringComparison.CurrentCultureIgnoreCase))
                //    {
                //        sb.AppendLine("    <div class=\"d-flex align-items-start gap-3\">");
                //        sb.AppendLine("      <div class=\"form-submit text-end mb-4\">");
                //        sb.AppendLine("        <button type=\"button\" id=\"editImageBtn\" class=\"btn cancel-form\">Add Image</button>");
                //        sb.AppendLine("      </div>");
                //        sb.AppendLine("      <img id=\"imagePreview\" src=\"\" alt=\"Image Preview\"");
                //        sb.AppendLine("           style=\"max-width: 100%; max-height: 300px; border: 1px solid #ccc; padding: 5px; border-radius: 8px;\" />");
                //        sb.AppendLine("    </div>");
                //        sb.AppendLine("  <input type=\"hidden\" id=\"ImageBase64\" name=\"ImageBase64\" />");
                //    }
                //    else
                //    {
                //        sb.AppendLine($"  <input type=\"text\" class=\"form-control1 required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" value=\"{defaultValue}\" {readonlyAttribute} {requiredAttributes} />");
                //    }
                //    // Append label only if not hyperlink

                //    //sb.AppendLine("</div>");
                //    //sb.AppendLine("</div>");
                //    if (field.TypeId?.ToLower() != "captcha" && field.TypeId?.ToLower() != "colorpicker" && field.TypeId?.ToLower() != "hyperlink" && field.TypeId?.ToLower() != "slider" && field.TypeId?.ToLower() != "richtexteditor" && field.TypeId != "Image" && field.TypeId?.ToLower() != "checkboxgroup")
                //    {
                //        sb.AppendLine($" <label for=\"{field.FieldName?.Trim() ?? string.Empty}\" class=\"form-label1\">{displayName}{requiredValidation}</label>");
                //    }

                //    sb.AppendLine("        </div>");



                //    sb.AppendLine("    </div>");
                //}
                foreach (var field in section)
                {
                    var fieldName = field.FieldName?.Trim() ?? string.Empty;
                    // var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    var displayName = string.IsNullOrWhiteSpace(field.DisplayName) ? fieldName : field.DisplayName?.Trim() ?? "";
                    var readonlyAttribute = field.IsReadOnly ? "readonly" : "";
                    var defaultValue = field.DefaultValue?.ToString()?.Trim() ?? "";
                    var requiredAttributes = field.Mandatory ? $"required data-required-msg=\"{displayName} is required\"" : string.Empty;
                    var requiredValidation = field.Mandatory ? $"<span class=\"login-danger required\">*</span>" : string.Empty;
                    var requiredClass = field.Mandatory ? $"class=\"required_field\" " : string.Empty;
                    string maxLengthAttr = field.Length > 0 ? $"data-maxlength=\"{field.Length}\"" : "";

                    //to get default
                    var defaultValues = !string.IsNullOrWhiteSpace(field.DefaultValue)
                  ? $" value='{System.Net.WebUtility.HtmlEncode(field.DefaultValue)}'"
                  : string.Empty;

                    //to get default checked unchecked
                    var isChecked = string.Equals(field.DefaultValue?.Trim(), "1", StringComparison.OrdinalIgnoreCase)
                    || string.Equals(field.DefaultValue?.Trim(), "true", StringComparison.OrdinalIgnoreCase);

                    var checkedAttr = isChecked ? " checked" : string.Empty;

                    var alignmentClass = GetLabelClass(AlignmentType);

                    // Left alignment ke liye wrap divs
                    var rowlabel = $"<div class=\"col-md-2\">";
                    var rowcontrol = $"<div class=\"col-md-10\">";
                    var rowend = $"</div>";

                    sb.AppendLine(" <div class=\"col-md-6\">");

                    FieldTypeEnums fieldType;
                    if (!Enum.TryParse(field.TypeId, true, out fieldType))
                    {
                        fieldType = FieldTypeEnums.Unknown;
                    }

                    // form-group div
                    var formGroupDiv = $"        <div class=\"form-group {cssClass} " +
                        $"{(fieldType == FieldTypeEnums.Date || fieldType == FieldTypeEnums.Datetime ? "date-field" : "")}\">";

                    var labeldiv = $" <label for=\"{fieldNameLowerCase?.Trim() ?? string.Empty}\" class=\"form-label-text\">{displayName}{requiredValidation}</label>";

                    var excludedTypes = new[]
                    {
                        FieldTypeEnums.Captcha,
                        FieldTypeEnums.Hyperlink,
                        //FieldTypeEnums.Richtexteditor,
                        //FieldTypeEnums.Image,
                       // FieldTypeEnums.Checkboxgroup,
                       
                        FieldTypeEnums.Bit
                    };

                    if (alignmentClass == "label-left")
                    {
                        // Add extra class only for Colorpicker
                        var extraClass = fieldType == FieldTypeEnums.Colorpicker ? " colorpicker-label-left" : "";

                        // Append form-group div with that class
                        sb.AppendLine(formGroupDiv.Replace("form-group", $"form-group{extraClass}"));

                        if (!excludedTypes.Contains(fieldType))
                        {
                            sb.AppendLine(rowlabel);
                            sb.AppendLine(labeldiv);
                            sb.AppendLine(rowend);
                        }
                        else if (fieldType == FieldTypeEnums.Captcha)
                        {
                            // Captcha: don't append labeldiv, but keep rowlabel & rowend
                            sb.AppendLine(rowlabel);
                            sb.AppendLine(rowend);
                        }
                        sb.AppendLine(rowcontrol);
                    }
                    else
                    {
                        if (fieldType != FieldTypeEnums.Bit)
                            // Top alignment
                            sb.AppendLine(formGroupDiv);
                        if (!excludedTypes.Contains(fieldType))
                        {
                            sb.AppendLine(labeldiv);
                        }
                    }


                    switch (fieldType)
                    {
                        case FieldTypeEnums.Rangeslider:
                            {
                                // Range Slider
                                var minValue = field.MinValue ?? 0;
                                var maxValue = field.MaxValue ?? 100;
                                var smallStep = field.SmallStep ?? 1;
                                var largeStep = field.LargeStep ?? 10;
                                var symbol = string.IsNullOrEmpty(field.Symbol) ? "" : field.Symbol;

                                // Parse default value
                                var start = defaultValue?.Split(',')[0];
                                var end = defaultValue?.Split(',').Length > 1 ? defaultValue.Split(',')[1] : null;

                                var defaultStart = int.TryParse(start, out var sVal) ? sVal : minValue;
                                var defaultEnd = int.TryParse(end, out var eVal) ? eVal : maxValue;

                                sb.AppendLine($"<div class=\"k-form-group force-label-positioned force-{cssClass}\">");
                                sb.AppendLine("<div class=\"container\">");
                                sb.AppendLine("  <div class=\"d-flex align-items-center mb-2\">");
                                sb.AppendLine($"    <input type=\"hidden\" id=\"{fieldNameLowerCase}Value\" name=\"{fieldNameLowerCase}\" value=\"{defaultStart},{defaultEnd}\" {requiredAttributes} />");
                                sb.AppendLine($"    <div id=\"{fieldNameLowerCase}\" style=\"width: 100%;\">");
                                sb.AppendLine("      <input />");
                                sb.AppendLine("      <input />");
                                sb.AppendLine("    </div>");
                                sb.AppendLine("  </div>");
                                sb.AppendLine("  <br/>");
                                sb.AppendLine($"  <div class=\"text-muted\" id=\"rangeValues_{fieldNameLowerCase}\" style=\"font-size:15px;\"></div>");
                                sb.AppendLine("</div>");
                                sb.AppendLine("</div>");
                                break;
                            }

                        case FieldTypeEnums.Slider:
                            {
                                sb.AppendLine($"<div class=\"k-form-group force-label-positioned force-{cssClass}\">");
                                sb.AppendLine($"    <input type=\"range\" class=\"required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {readonlyAttribute} {requiredAttributes}  {defaultValues}/>");
                                sb.AppendLine("</div>");
                                break;
                            }

                        case FieldTypeEnums.Decimal:
                        case FieldTypeEnums.Int:
                        case FieldTypeEnums.Float:
                        case FieldTypeEnums.Smallint:
                        case FieldTypeEnums.Money:
                        case FieldTypeEnums.Tinyint:
                        case FieldTypeEnums.Bigint:
                            {
                                var dbTypeAttribute = GetDbTypeAttribute(fieldType);
                                if (!string.IsNullOrEmpty(dbTypeAttribute))
                                {
                                    sb.AppendLine($" <input type=\"number\" class=\"required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" data-dbtype=\"{dbTypeAttribute}\" {requiredAttributes} {defaultValues} {readonlyAttribute} />");
                                }
                                break;
                            }

                        case FieldTypeEnums.Nvarchar:
                            sb.AppendLine($"  <textarea class=\"required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {requiredAttributes} {readonlyAttribute} {maxLengthAttr}>{defaultValues}</textarea>");
                            break;

                        case FieldTypeEnums.Varchar:
                            sb.AppendLine($"<input type=\"text\" class=\"required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {requiredAttributes} {defaultValues} {maxLengthAttr} {readonlyAttribute} />");
                            break;

                        case FieldTypeEnums.Richtexteditor:
                            sb.AppendLine($"    <button type=\"button\" id=\"{fieldNameLowerCase}editTextBtn\" class=\"btn cancel-form d-flex justify-content-center align-items-center\" style=\"height:35px; width:35px; background-color:lightgray; padding:0;\">");
                            sb.AppendLine("        <img src=\"~/Icon/document-editor.png\" height=\"27px\" />");
                            sb.AppendLine("    </button>");
                            sb.AppendLine($"    <input type=\"hidden\" id=\"{fieldNameLowerCase}RichTextContent\" name=\"{fieldNameLowerCase}\" class=\"texteditor-field\" {requiredAttributes} />");
                            sb.AppendLine($"    <div id=\"{fieldNameLowerCase}textEditorWindow\" style=\"display:none;\">");
                            sb.AppendLine($"        <div id=\"{fieldNameLowerCase}textEditorContainer\" style=\"margin:13px 13px 13px 13px\">");
                            sb.AppendLine($"            <textarea id=\"{fieldNameLowerCase}\"></textarea>");
                            sb.AppendLine("        </div>");
                            sb.AppendLine("        <div class=\"k-window-footer\" style=\"text-align:right; margin-top:10px;\">");
                            sb.AppendLine($"            <button id=\"{fieldNameLowerCase}btnAddText\" class=\"k-button k-primary\">Add</button>");
                            sb.AppendLine("        </div>");
                            sb.AppendLine("    </div>");
                            break;

                        case FieldTypeEnums.Varbinary:
                        case FieldTypeEnums.ImageUpload:
                            var uploadId = $"upload_{Guid.NewGuid():N}";
                            imageUploadFields.Add((field.FieldName?.Trim() ?? string.Empty, uploadId));
                            uploadControlIds.Add(uploadId);
                            sb.AppendLine($@"<div class=""mb-3""><input id=""{uploadId}"" name=""{field.FieldName?.Trim() ?? string.Empty}"" type=""file"" /> </div>");
                            break;

                        case FieldTypeEnums.Date:
                            var formattedDate = DateTime.TryParse(defaultValue, out var dt) ? dt.ToString("yyyy-MM-dd") : defaultValue;
                            sb.AppendLine($"  <input type=\"date\" class=\"datepicker required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {requiredAttributes} value=\"{formattedDate}\" {readonlyAttribute} placeholder=\"mm-dd-yyyy\"/>");
                            break;

                        case FieldTypeEnums.Datetime:
                            var formattedDateTime = DateTime.TryParse(defaultValue, out var dtParsed)
                                ? DateTime.SpecifyKind(dtParsed, DateTimeKind.Utc).ToLocalTime().ToString("yyyy-MM-ddTHH:mm")
                                : defaultValue;
                            sb.AppendLine($"  <input type=\"datetime-local\" class=\"datetimepicker required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" value=\"{formattedDateTime}\"  {requiredAttributes} {readonlyAttribute} placeholder=\"mm-dd-yyyy hh:mm AM/PM\" />");
                            break;

                        case FieldTypeEnums.Timeduration:
                            sb.AppendLine($"<input type=\"text\" class=\"required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {requiredAttributes} {defaultValues} {readonlyAttribute} title=\"{fieldName}\" />");
                            break;

                        case FieldTypeEnums.Bit:
                            sb.AppendLine("    <div class=\"form-group label-top\">");
                            sb.AppendLine($"        <input type=\"checkbox\" {checkedAttr}");
                            sb.AppendLine($"               id=\"{fieldNameLowerCase}\" ");
                            sb.AppendLine("               class=\"form-check-input required_field checkbox-field\" ");
                            sb.AppendLine($"               name=\"{fieldNameLowerCase}\" ");
                            sb.AppendLine($"               {requiredAttributes} ");
                            sb.AppendLine($"               title=\"{fieldName}\" />");
                            sb.AppendLine($"        <label for=\"{fieldNameLowerCase}\" class=\"custom-checkbox-lebel\">{displayName}{requiredValidation}</label>");
                            sb.AppendLine("    </div>");
                            break;

                        case FieldTypeEnums.Switches:
                            sb.AppendLine($"  <input type=\"checkbox\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" class=\"inputcontrol k-switch\" {requiredAttributes} {checkedAttr}/>");
                            break;

                        case FieldTypeEnums.DropDown:
                            sb.AppendLine($"  <input class=\"required_field dropdown-field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {requiredAttributes} {readonlyAttribute} />");
                            break;

                        case FieldTypeEnums.Multiselect:
                            sb.AppendLine($"  <input {requiredClass} id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\"  {requiredAttributes} {readonlyAttribute} />");
                            break;

                        case FieldTypeEnums.Radiogroup:
                            var radioFieldNameLower = !string.IsNullOrWhiteSpace(field.FieldName) && field.FieldName.Trim().Length > 1
                                                 ? char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim()[1..]
                                                 : string.Empty;

                            var groupElementId = $"radiogroup_{radioFieldNameLower}";
                            var containerId = $"{radioFieldNameLower}_container";
                            var blockId = $"{radioFieldNameLower}_block";

                            sb.AppendLine($"<div id=\"{blockId}\" class=\"inputcontrol p-3\">");
                            sb.AppendLine($"    <div id=\"{containerId}\" class=\"radiobutton-group\" data-field-name=\"{radioFieldNameLower}\" data-default-value=\"{defaultValue}\" {readonlyAttribute}>");
                            sb.AppendLine($"        <ul id=\"{groupElementId}\" class=\"list-unstyled\"></ul>");
                            sb.AppendLine("    </div>");
                            sb.AppendLine("</div>");
                            sb.AppendLine($"<input type=\"hidden\" class=\"radio-group-field\" id=\"{radioFieldNameLower}Value\" name=\"{radioFieldNameLower}Value\" {requiredAttributes} />");
                            break;

                        case FieldTypeEnums.Checkboxgroup:
                            var selectAllId = $"selectAll_{fieldNameLowerCase}";
                            var groupElementId1 = $"checkboxgroup_{fieldNameLowerCase}";
                            var containerId1 = $"{fieldNameLowerCase}_container";
                            var blockId1 = $"{fieldNameLowerCase}_block";

                            sb.AppendLine($"<div id=\"{blockId1}\" class=\"inputcontrol p-3\">");
                            sb.AppendLine($"    <input type=\"checkbox\" id=\"{selectAllId}\" class=\"k-checkbox k-checkbox-md k-rounded-md\">");
                            sb.AppendLine($"    <label class=\"k-checkbox-label\" for=\"{selectAllId}\">Select all</label>");
                            sb.AppendLine("    <hr class=\"my-2\">");
                            sb.AppendLine($"    <div id=\"{containerId1}\" class=\"checkbox-group\" data-field-name=\"{fieldNameLowerCase}\" data-default-value=\"{defaultValue}\" {readonlyAttribute}>");
                            sb.AppendLine($"        <ul id=\"{groupElementId1}\"></ul>");
                            sb.AppendLine("    </div>");
                            sb.AppendLine("</div>");
                            sb.AppendLine($"<input type=\"hidden\" id=\"{fieldNameLowerCase}Value\" name=\"{fieldNameLowerCase}\" class=\"checkbox-group-field\" {requiredAttributes} />");
                            break;

                        case FieldTypeEnums.Hyperlink:
                            var link = field.Link?.Trim() ?? "#";
                            var displayText = string.IsNullOrWhiteSpace(field.DisplayName) ? link : field.DisplayName;
                            sb.AppendLine($"  <a href=\"{link}\" id=\"{fieldNameLowerCase}\" target=\"_blank\">{displayText}</a>");
                            break;

                        case FieldTypeEnums.Captcha:
                            sb.AppendLine(" <input id=\"captcha\" class=\"required_field\" required data-required-msg=\"Captcha is required\"/> ");
                            break;

                        case FieldTypeEnums.Colorpicker:
                            sb.AppendLine("  <div class=\"col-md-6\">");
                            sb.AppendLine("    <div class=\"form-group label-left d-flex align-items-center\" style=\"gap: 10px;\">");
                            sb.AppendLine($"      <input type=\"color\" class=\"inputcontrol required_field colorpicker-field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {defaultValues} {requiredAttributes} {readonlyAttribute} style=\"width: 100px; border-radius: 2px; padding: 6px;\" />");
                            sb.AppendLine($"      <input type=\"text\" id=\"{fieldNameLowerCase}Name\" name=\"{fieldNameLowerCase}Name\" class=\"inputcontrol\" readonly style=\"width: 100px; border-radius: 2px; padding: 6px;\" />");
                            sb.AppendLine("    </div>");
                            sb.AppendLine("  </div>");
                            break;

                        //case FieldTypeEnums.Barcode:
                        //    sb.AppendLine("<div class=\"row mb-3\">");
                        //    sb.AppendLine("  <div class=\"col-md-6\">");
                        //    sb.AppendLine("    <div class=\"d-flex align-items-center gap-2\">");
                        //    sb.AppendLine($"      <input type=\"text\" class=\"inputcontrol required_field form-control\" id=\"{field.FieldName?.Trim().ToLower()}\" name=\"{field.FieldName?.Trim().ToLower()}\" placeholder=\"{(string.IsNullOrWhiteSpace(field.ToolTip) ? "Enter barcode value" : field.ToolTip.Trim())}\" value=\"{defaultValue}\" {requiredAttributes} {readonlyAttribute} style=\"border-radius:4px; padding:6px; min-width:0; flex-grow:1;\" />");
                        //    sb.AppendLine($"      <button type=\"button\" id=\"{field.FieldName?.Trim().ToLower()}_previewBtn\" class=\"k-button k-primary barcode-preview-btn\" style=\"border-radius:4px; padding:6px 12px; white-space:nowrap;\"><i class=\"k-icon k-font-icon k-i-eye\"></i></button>");
                        //    sb.AppendLine("    </div>");
                        //    sb.AppendLine("  </div>");
                        //    sb.AppendLine("</div>");
                        //    break;



                        case FieldTypeEnums.Barcode:
                            var fieldNameLower = field.FieldName?.Trim().ToLower();
                            sb.AppendLine("    <div class=\"d-flex align-items-start gap-2 barcode-row\">");
                            sb.AppendLine("        <div class=\"barcode-input-wrapper\">");
                            sb.AppendLine("            <div class=\"d-flex align-items-start gap-2\">");
                            sb.AppendLine("                <div class=\"flex-grow-1\">");
                            sb.AppendLine(
                                $"                    <input type=\"text\" " +
                                $"id=\"{fieldNameLower}\" " +
                                $"name=\"{fieldNameLower}\" " +
                                $"placeholder=\"Enter barcode value\" " +
                                $"value=\"{defaultValue}\" " +
                                $"class=\"barcode_input required_field\" " +
                                $"{requiredAttributes} {readonlyAttribute} />"
                            );
                            sb.AppendLine(
                                $"                    <span class=\"k-invalid-msg text-danger\" data-for=\"{fieldNameLower}\"></span>"
                            );
                            sb.AppendLine("                </div>");
                            sb.AppendLine(
                                $"                <button type=\"button\" id=\"{fieldNameLower}_previewBtn\" " +
                                $"class=\"k-button k-primary barcode-preview-btn barcode-eye-btn\">" +
                                $"<i class=\"k-icon k-font-icon k-i-eye\"></i></button>"
                            );
                            sb.AppendLine("            </div>");
                            sb.AppendLine("        </div>");
                            sb.AppendLine("    </div>");
                            break;
                        case FieldTypeEnums.Rating:
                            sb.AppendLine($"  <div id=\"{fieldNameLowerCase}\" class=\"required_field\"></div>");
                            sb.AppendLine($"  <input type=\"hidden\" id=\"{fieldNameLowerCase}Value\" name=\"{fieldNameLowerCase}\" class=\"rating-field\" {requiredAttributes} {defaultValues}/>");
                            break;

                        case FieldTypeEnums.Signature:
                            sb.AppendLine($"  <div class=\"inputcontrol required_field\" id=\"{fieldNameLowerCase}_container\">");
                            sb.AppendLine($"     <canvas id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" class=\"signature-canvas\"></canvas>");
                            sb.AppendLine("      <button type=\"button\" class=\"clear-signature-btn\">Clear</button>");
                            sb.AppendLine("  </div>");
                            sb.AppendLine($"  <input type=\"hidden\" id=\"{fieldNameLowerCase}Value\" name=\"{fieldNameLowerCase}\" class=\"signature-field\" {requiredAttributes} />");
                            break;

                        case FieldTypeEnums.Image:
                            var imageText = field.DisplayName;



                            sb.AppendLine("           <div class='image-container'>");
                            sb.AppendLine("              <div class='row'>");
                            sb.AppendLine("                   <div class='col-md-12'>");
                            sb.AppendLine($"                        <img id='{fieldNameLowerCase}imagePreview'class='image' src='~/Icon/default_image.png' alt='Image Preview' />");
                            sb.AppendLine("                    </div>");
                            sb.AppendLine("                    <div class='row image-btn'>");
                            sb.AppendLine($"                        <button id='{fieldNameLowerCase}editImageBtn' class='imageeditorbtn'>");
                            sb.AppendLine("                            <img src='~/Icon/plus.png' height='20px' />");
                            sb.AppendLine("                        </button>");
                            sb.AppendLine($"                        <button id='{fieldNameLowerCase}closeImagePreview' class='imageeditorbtn'>");
                            sb.AppendLine("                            <img src='~/Icon/minus.png' height='20px' />");
                            sb.AppendLine("                        </button>");
                            sb.AppendLine("                    </div>");
                            sb.AppendLine($"  <input type=\"hidden\" id=\"{fieldNameLowerCase}ImageBase64\" name=\"{fieldNameLowerCase}ImageBase64\" class=\"image-field\" {requiredAttributes} />");
                            sb.AppendLine("            </div>");
                            sb.AppendLine("        </div>");
                            break;

                        default:
                            sb.AppendLine($"  <input type=\"text\" class=\"required_field\" id=\"{fieldNameLowerCase}\" name=\"{fieldNameLowerCase}\" {defaultValues} {readonlyAttribute} {requiredAttributes} />");
                            break;
                    }

                    if (alignmentClass == "label-left")
                    {
                        sb.AppendLine(rowend); // Close col-md-10
                        sb.AppendLine(" </div>"); // Close form-group
                    }
                    else
                    {
                        if (fieldType != FieldTypeEnums.Bit)
                            sb.AppendLine(" </div>"); // Close form-group
                    }

                    sb.AppendLine(" </div>"); // Close col-md-6
                }

                sb.AppendLine("</div>"); // close tab-pane
                sb.AppendLine("</div>"); // close div row class
            }
            sb.AppendLine("</div>"); // close inner tab-content

            sb.AppendLine("  </div>"); // close summary tab-pane
            sb.AppendLine("</div>"); // close outer tab-content

            // Buttons row (Save and Cancel)
            sb.AppendLine("<div class=\"row\">");
            sb.AppendLine("    <div class=\"form-submit text-end mb-4\">");
            sb.AppendLine("        <button type=\"button\" id=\"btnSave\" class=\"btn btn-primary me-2 text-white\">Save</button>");
            bool showSaveContinue = parentForm?.SaveContinue ?? false;
            bool showSaveReuse = parentForm?.SaveReuse ?? false;


            if (showSaveContinue)
            {
                sb.AppendLine("        <button type=\"button\" id=\"btnSaveContinue\" class=\"btn btn-primary me-2 text-white\">Save & Continue</button>");
            }

            if (showSaveReuse)
            {
                sb.AppendLine("        <button type=\"button\" id=\"btnSaveReuse\" class=\"btn btn-primary me-2 text-white\"><i class=\"fas fa-redo\"></i>Save & Reuse</button>");
                //sb.AppendLine("            <button type=\"button\" id=\"btnClearReuse\" class=\"btn btn-primary me-2 text-white2\">Clear Reuse </button>");
            }

            sb.AppendLine("        <button type=\"button\" id=\"btnCancel\" onclick=\"redirectToPage()\" class=\"btn cancel-form\">Cancel</button>");
            sb.AppendLine("    </div>");
            sb.AppendLine("    </div>");
            // Close outer divs
            sb.AppendLine("</form>");
            foreach (var field in fields)
            {
                if (string.Equals(field.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;

                    sb.AppendLine($"<div id=\"imageEditorPopup_{fieldNameLowerCase}\" style=\"display:none;\">");
                    sb.AppendLine($"  <div id=\"imageEditorContainer_{fieldNameLowerCase}\" style=\"width: 100%; height: 600px;\"></div>");
                    sb.AppendLine("  <div class=\"form-submit text-end mb-4\">");
                    sb.AppendLine("    <div class=\"k-window-footer\" style=\"text-align:right; margin-top:10px;\">");
                    sb.AppendLine($"      <button id=\"saveEditedImage_{fieldNameLowerCase}\" class=\"k-button k-primary me-2 text-white\" style=\"background-color: #2e37a4 !important;\">Add</button>");
                    sb.AppendLine("    </div>");
                    sb.AppendLine("  </div>");
                    sb.AppendLine("</div>");
                }
            }
            sb.AppendLine("</div>");
            sb.AppendLine("<!-- Tab (Fields) -->");
            //sb.AppendLine("    <div id=\"Location\" class=\"mt-5\"></div>");
            //sb.AppendLine("    <div id=\"People\" class=\"mt-5\"></div>");
            if (DocumentEnabled)
            {
                sb.AppendLine($"    <div id=\"Document\" class=\"mt-5\"></div>");
            }
            foreach (var form in childForms)
            {
                //sb.AppendLine($"                    <li>{form.TableName}</li>");
                sb.AppendLine($"    <div id=\"{form.TableName}\" class=\"mt-5\"></div>");
            }
            sb.AppendLine("        </div>"); // Closing .main-section
            sb.AppendLine("    </div>");     // Closing #tabstrip
            sb.AppendLine("        <span id=\"fnShowNotification\"></span>");
            sb.AppendLine("    </div>");     // Closing .demo-section
            sb.AppendLine("</div>");

            //foreach (var form in childForms)   
            //{
            //    sb.AppendLine("<div class=\"listsection mb-2\">");
            //    sb.AppendLine("<div>");
            //    sb.AppendLine($" <h2 class=\"text-start text-primary\">{form.Name}List</h2>");
            //    sb.AppendLine("<div class=\"mb-2\">");
            //    sb.AppendLine($"    <button class=\"btn btn-primary me-2 text-white\" style=\"background-color: #2e37a4; border-color: #0000;\" id=\"{form.TableName}Btn\" disabled>");
            //    sb.AppendLine("        <i class=\"k-icon k-font-icon k-i-plus\"></i> New");
            //    sb.AppendLine("    </button>");
            //    sb.AppendLine("</div>");
            //    sb.AppendLine("</div>");
            //    sb.AppendLine($"<div id='{form.Name}Grid' class='class=\"card p-4 rounded\"'></div>");
            //    sb.AppendLine("</div>");
            //}
            //if (table.DetailTableId > 0)
            //{

            //    sb.AppendLine("<div class=\"listsection\">");
            //    sb.AppendLine("<div>");
            //    sb.AppendLine($" <h2 class=\"text-start text-primary\">{table.DetailTableName}List</h2>");
            //    sb.AppendLine("<div class=\"mb-2\">");
            //    sb.AppendLine("    <button class=\"btn mb-4\" id=\"newBtn\" disabled>");
            //    sb.AppendLine("        <i class=\"k-icon k-font-icon k-i-plus\"></i> New");
            //    sb.AppendLine("    </button>");
            //    sb.AppendLine("</div>");
            //    sb.AppendLine("</div>");
            //    sb.AppendLine($"<div id='{table.DetailTableName}Grid' class='class=\"card p-4 rounded\"'></div>");
            //}


            // Loader
            sb.AppendLine("<!-- Loader -->");
            sb.AppendLine("<div id=\"editLoader\" class=\"custom-loader text-center\" style=\"display:none;\">");
            sb.AppendLine("    <div class=\"bouncing-dots\">");
            sb.AppendLine("        <span></span><span></span><span></span>");
            sb.AppendLine("    </div>");
            sb.AppendLine("</div>");
            //sb.AppendLine("</div>");

            sb.AppendLine("<script>");

            sb.AppendLine("   var backendUrl = '@ViewData[\"BackendUrl\"]';");
            sb.AppendLine("      var FkId; ");
            foreach (var field in fields)
            {


                if (string.Equals(field.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine("var imageEditor;");
                    sb.AppendLine("function reinitializeImageEditor(imageUrl, containerId) {");
                    sb.AppendLine("    var container = $(`#${containerId}`);");
                    sb.AppendLine("    var existingEditor = container.data(\"kendoImageEditor\");");
                    sb.AppendLine("    if (existingEditor) {");
                    sb.AppendLine("        existingEditor.destroy();");
                    sb.AppendLine("        container.empty();");
                    sb.AppendLine("    }");
                    sb.AppendLine("    imageEditor = container.kendoImageEditor({");
                    sb.AppendLine("        width: \"100%\",");
                    sb.AppendLine("        height: 600,");
                    sb.AppendLine("        imageUrl: imageUrl");
                    sb.AppendLine("    }).data(\"kendoImageEditor\");");
                    sb.AppendLine("    return imageEditor;;");
                    sb.AppendLine("}");

                    sb.AppendLine("    function rebindZoomDropDownItems(retryCount = 5) {");
                    sb.AppendLine("        const zoomDropDown = $(\".k-imageeditor-toolbar .k-dropdownlist[data-command='ZoomDropDownImageEditorCommand']\").data(\"kendoDropDownList\");");
                    sb.AppendLine("        if (zoomDropDown) {");
                    sb.AppendLine("            const zoomItems = [{ text: \"Show actual size\", value: 1 }, { text: \"Fit to screen\", value: \"fitToScreen\" }];");
                    sb.AppendLine("            zoomDropDown.setDataSource(zoomItems);");
                    sb.AppendLine("            zoomDropDown.value(\"fitToScreen\");");
                    sb.AppendLine("            zoomDropDown.trigger(\"change\");");
                    sb.AppendLine("        } else if (retryCount > 0) {");
                    sb.AppendLine("            setTimeout(() => rebindZoomDropDownItems(retryCount - 1), 200);");
                    sb.AppendLine("        } else { console.warn(\"Zoom dropdown could not be initialized after retries.\"); }");
                    sb.AppendLine("    }");

                    sb.AppendLine("  function forceEnableAllImageEditorControls() {");
                    sb.AppendLine("    if (!imageEditor) return;");
                    sb.AppendLine("");
                    sb.AppendLine("    const canvas = $(\"#imageEditorContainer\").find(\"canvas\")[0];");
                    sb.AppendLine("    const hasImage = canvas && canvas.width > 0 && canvas.height > 0;");
                    sb.AppendLine("");
                    sb.AppendLine("    $('.k-imageeditor-toolbar .k-button, .k-imageeditor-toolbar .k-dropdownlist').each(function () {");
                    sb.AppendLine("      const $el = $(this);");
                    sb.AppendLine("      const command = $el.attr(\"data-command\");");
                    sb.AppendLine("      const isUploadButton = command === \"UploadImageEditorCommand\";");
                    sb.AppendLine("");
                    sb.AppendLine("      // Always enable upload button");
                    sb.AppendLine("      if (isUploadButton) {");
                    sb.AppendLine("        $el.removeClass('k-disabled k-state-disabled')");
                    sb.AppendLine("           .removeAttr('disabled aria-disabled')");
                    sb.AppendLine("           .attr('tabindex', '0');");
                    sb.AppendLine("        return;");
                    sb.AppendLine("      }");
                    sb.AppendLine("");
                    sb.AppendLine("      if (!hasImage) return; // Keep all disabled if no image");
                    sb.AppendLine("");
                    sb.AppendLine("      const undoAvailable = imageEditor && imageEditor.undoStack && imageEditor.undoStack.length > 0;");
                    sb.AppendLine("      const redoAvailable = imageEditor && imageEditor.redoStack && imageEditor.redoStack.length > 0;");
                    sb.AppendLine("");
                    sb.AppendLine("      if (");
                    sb.AppendLine("        (command === 'UndoImageEditorCommand' && undoAvailable) ||");
                    sb.AppendLine("        (command === 'RedoImageEditorCommand' && redoAvailable) ||");
                    sb.AppendLine("        (command !== 'UndoImageEditorCommand' && command !== 'RedoImageEditorCommand')");
                    sb.AppendLine("      ) {");
                    sb.AppendLine("        $el.removeClass('k-disabled k-state-disabled')");
                    sb.AppendLine("           .removeAttr('disabled aria-disabled')");
                    sb.AppendLine("           .attr('tabindex', '0');");
                    sb.AppendLine("      } else {");
                    sb.AppendLine("        $el.addClass('k-disabled k-state-disabled')");
                    sb.AppendLine("           .attr('disabled', 'disabled')");
                    sb.AppendLine("           .attr('aria-disabled', 'true')");
                    sb.AppendLine("           .attr('tabindex', '-1');");
                    sb.AppendLine("      }");
                    sb.AppendLine("    });");
                    sb.AppendLine("  }");
                    sb.AppendLine("");
                    sb.AppendLine("  function monitorEditorState() {");
                    sb.AppendLine("    if (!imageEditor) return;");
                    sb.AppendLine("");
                    sb.AppendLine("    const commandsToTrack = [\"UndoImageEditorCommand\", \"RedoImageEditorCommand\"];");
                    sb.AppendLine("");
                    sb.AppendLine("    const originalExecuteCommand = imageEditor.executeCommand;");
                    sb.AppendLine("    imageEditor.executeCommand = function (command) {");
                    sb.AppendLine("      const result = originalExecuteCommand.call(this, command);");
                    sb.AppendLine("");
                    sb.AppendLine("      if (commandsToTrack.includes(command.command) || command.command.startsWith(\"Apply\")) {");
                    sb.AppendLine("        // Delay to allow state to update");
                    sb.AppendLine("        setTimeout(() => forceEnableAllImageEditorControls(), 100);");
                    sb.AppendLine("      }");
                    sb.AppendLine("");
                    sb.AppendLine("      return result;");
                    sb.AppendLine("    };");
                    sb.AppendLine("  }");

                    sb.AppendLine("    function overrideImageEditorMethods() {");
                    sb.AppendLine("        if (!imageEditor) return;");
                    sb.AppendLine("        const originalZoom = imageEditor.zoom;");
                    sb.AppendLine("        imageEditor.zoom = function (ratio) { return originalZoom.call(this, ratio); };");
                    sb.AppendLine("        const originalExecuteCommand = imageEditor.executeCommand;");
                    sb.AppendLine("        imageEditor.executeCommand = function (command) {");
                    sb.AppendLine("            const toolbar = this.toolbar;");
                    sb.AppendLine("            if (toolbar && toolbar.tools) {");
                    sb.AppendLine("                toolbar.tools.forEach(tool => {");
                    sb.AppendLine("                    if (tool.options && tool.options.canExecute) { tool.options.canExecute = function () { return true; }; }");
                    sb.AppendLine("                });");
                    sb.AppendLine("            }");
                    sb.AppendLine("            if (command.command === 'CropImageEditorCommand' || (command.command === 'OpenPaneImageEditorCommand' && command.options === 'crop')) {");
                    sb.AppendLine("                try { return originalExecuteCommand.call(this, command); }");
                    sb.AppendLine("                catch (e) {");
                    sb.AppendLine("                    if (e.message.includes('cross-origin') || e.message.includes('tainted')) {");
                    sb.AppendLine("                        console.warn('CORS issue detected, attempting alternative crop method');");
                    sb.AppendLine("                        if (command.command === 'OpenPaneImageEditorCommand') return originalExecuteCommand.call(this, command);");
                    sb.AppendLine("                    }");
                    sb.AppendLine("                    throw e;");
                    sb.AppendLine("                }");
                    sb.AppendLine("            }");
                    sb.AppendLine("            return originalExecuteCommand.call(this, command);");
                    sb.AppendLine("        };");
                    sb.AppendLine("    }");

                    sb.AppendLine("    function loadImageWithCORS(imageUrl) {");
                    sb.AppendLine("        return new Promise((resolve, reject) => {");
                    sb.AppendLine("            if (!imageUrl) { resolve(null); return; }");
                    sb.AppendLine("            const img = new Image(); img.crossOrigin = 'anonymous';");
                    sb.AppendLine("            img.onload = function () {");
                    sb.AppendLine("                const canvas = document.createElement('canvas');");
                    sb.AppendLine("                const ctx = canvas.getContext('2d');");
                    sb.AppendLine("                canvas.width = img.width; canvas.height = img.height;");
                    sb.AppendLine("                ctx.drawImage(img, 0, 0);");
                    sb.AppendLine("                canvas.toBlob(function (blob) {");
                    sb.AppendLine("                    const url = URL.createObjectURL(blob); resolve(url);");
                    sb.AppendLine("                }, 'image/png');");
                    sb.AppendLine("            };");
                    sb.AppendLine("            img.onerror = function () {");
                    sb.AppendLine("                const fallbackImg = new Image();");
                    sb.AppendLine("                fallbackImg.onload = function () { resolve(imageUrl); };");
                    sb.AppendLine("                fallbackImg.onerror = function () { reject(new Error('Failed to load image')); };");
                    sb.AppendLine("                fallbackImg.src = imageUrl;");
                    sb.AppendLine("            };");
                    sb.AppendLine("            img.src = imageUrl;");
                    sb.AppendLine("        });");
                    sb.AppendLine("    }");

                    sb.AppendLine("    function initializeImageEditor(imageUrl, FormId = false) {");
                    sb.AppendLine("        const existingEditor = $(\"#imageEditorContainer\").data(\"kendoImageEditor\");");
                    sb.AppendLine("        if (existingEditor) { existingEditor.destroy(); }");
                    sb.AppendLine("        const editorConfig = {");
                    sb.AppendLine("            width: \"100%\", height: 600,");
                    sb.AppendLine("            imageRendered: function (e) {");
                    sb.AppendLine("                imageEditor = $(\"#imageEditorContainer\").data(\"kendoImageEditor\");");
                    sb.AppendLine("                if (imageEditor) {");
                    sb.AppendLine("                    setTimeout(() => {");
                    sb.AppendLine("                        overrideImageEditorMethods();");
                    sb.AppendLine("                        forceEnableAllImageEditorControls();");
                    sb.AppendLine("                        monitorEditorState();");
                    sb.AppendLine("                        rebindZoomDropDownItems();");
                    sb.AppendLine("                        setTimeout(() => {");
                    sb.AppendLine("                            try { imageEditor.zoom(1); $(\".k-imageeditor-canvas\")[0]?.scrollTo(0, 0); }");
                    sb.AppendLine("                            catch (err) { console.warn(\"Zoom or scroll reset failed:\", err); }");
                    sb.AppendLine("                        }, 200);");
                    sb.AppendLine("                    }, 100);");
                    sb.AppendLine("                }");
                    sb.AppendLine("            }");
                    sb.AppendLine("        };");
                    sb.AppendLine("        if (imageUrl) {");
                    sb.AppendLine("            loadImageWithCORS(imageUrl).then(corsImageUrl => {");
                    sb.AppendLine("                if (corsImageUrl) { editorConfig.imageUrl = corsImageUrl; }");
                    sb.AppendLine("                imageEditor = $(\"#imageEditorContainer\").kendoImageEditor(editorConfig).data(\"kendoImageEditor\");");
                    sb.AppendLine("                setTimeout(() => {");
                    sb.AppendLine("                    overrideImageEditorMethods();");
                    sb.AppendLine("                    forceEnableAllImageEditorControls();");
                    sb.AppendLine("                    rebindZoomDropDownItems();");
                    sb.AppendLine("                }, 300);");
                    sb.AppendLine("            }).catch(error => {");
                    sb.AppendLine("                console.error('Error loading image:', error);");
                    sb.AppendLine("                imageEditor = $(\"#imageEditorContainer\").kendoImageEditor(editorConfig).data(\"kendoImageEditor\");");
                    sb.AppendLine("                setTimeout(() => {");
                    sb.AppendLine("                    overrideImageEditorMethods();");
                    sb.AppendLine("                    forceEnableAllImageEditorControls();");
                    sb.AppendLine("                    rebindZoomDropDownItems();");
                    sb.AppendLine("                }, 300);");
                    sb.AppendLine("            });");
                    sb.AppendLine("        } else {");
                    sb.AppendLine("            imageEditor = $(\"#imageEditorContainer\").kendoImageEditor(editorConfig).data(\"kendoImageEditor\");");
                    sb.AppendLine("            setTimeout(() => {");
                    sb.AppendLine("                overrideImageEditorMethods();");
                    sb.AppendLine("                forceEnableAllImageEditorControls();");
                    sb.AppendLine("                rebindZoomDropDownItems();");
                    sb.AppendLine("            }, 300);");
                    sb.AppendLine("        }");
                    sb.AppendLine("    }");

                    sb.AppendLine("    function initializePopupImageEditor(imageUrl, containerId) {");
                    sb.AppendLine("    const container = $(`#${containerId}`);");
                    sb.AppendLine("        const existingEditor = container.data(\"kendoImageEditor\");");
                    sb.AppendLine("");
                    sb.AppendLine("        if (existingEditor) {");
                    sb.AppendLine("            existingEditor.destroy();");
                    sb.AppendLine("            container.empty();");
                    sb.AppendLine("        }");
                    sb.AppendLine("");
                    sb.AppendLine("        imageEditor = container.kendoImageEditor({");
                    sb.AppendLine("            width: \"100%\",");
                    sb.AppendLine("            height: 600,");
                    sb.AppendLine("            imageUrl: imageUrl || null,");
                    sb.AppendLine("            imageRendered: function () {");
                    sb.AppendLine("                setTimeout(() => {");
                    sb.AppendLine("                    overrideImageEditorMethods();");
                    sb.AppendLine("                    forceEnableAllImageEditorControls();");
                    sb.AppendLine("                    rebindZoomDropDownItems();");
                    sb.AppendLine("                }, 100);");
                    sb.AppendLine("            }");
                    sb.AppendLine("        }).data(\"kendoImageEditor\");");
                    sb.AppendLine("   if (!imageUrl) {\r\n   ");
                    sb.AppendLine("  // Ensure canvas is cleared for blank editor\r\n  ");
                    sb.AppendLine("  const canvas = container.find(\"canvas\")[0];\r\n   ");
                    sb.AppendLine("     if (canvas) {\r\n  ");
                    sb.AppendLine("  const ctx = canvas.getContext(\"2d\");\r\n   ");
                    sb.AppendLine("   ctx.clearRect(0, 0, canvas.width, canvas.height);\r\n  ");
                    sb.AppendLine("   canvas.width = 1;\r\n  ");
                    sb.AppendLine("  canvas.height = 1;  ");
                    sb.AppendLine("  } ");
                    sb.AppendLine(" } ");
                    sb.AppendLine("}");

                    //sb.AppendLine("    function initializePopupImageEditor(imageUrl) {");
                    //sb.AppendLine("        const container = $(\"#imageEditorContainer\");");
                    //sb.AppendLine("        const existingEditor = container.data(\"kendoImageEditor\");");
                    //sb.AppendLine("");
                    //sb.AppendLine("        if (existingEditor) {");
                    //sb.AppendLine("            existingEditor.destroy();");
                    //sb.AppendLine("            container.empty();");
                    //sb.AppendLine("        }");
                    //sb.AppendLine("");
                    //sb.AppendLine("        imageEditor = container.kendoImageEditor({");
                    //sb.AppendLine("            width: \"100%\",");
                    //sb.AppendLine("            height: 600,");
                    //sb.AppendLine("            imageUrl: imageUrl,");
                    //sb.AppendLine("            imageRendered: function () {");
                    //sb.AppendLine("                setTimeout(() => {");
                    //sb.AppendLine("                    overrideImageEditorMethods();");
                    //sb.AppendLine("                    forceEnableAllImageEditorControls();");
                    //sb.AppendLine("                    rebindZoomDropDownItems();");
                    //sb.AppendLine("                }, 100);");
                    //sb.AppendLine("            }");
                    //sb.AppendLine("        }).data(\"kendoImageEditor\");");
                    //sb.AppendLine("    }");


                    sb.AppendLine("    // Add direct event handlers to bypass Kendo's internal logic");
                    sb.AppendLine("    $(document).on('click', '.k-imageeditor-toolbar [data-command=\"ZoomImageEditorCommand\"][data-options=\"zoomIn\"]', function(e) {");
                    sb.AppendLine("        e.preventDefault(); e.stopPropagation();");
                    sb.AppendLine("        if (imageEditor) { imageEditor.executeCommand({ command: \"ZoomImageEditorCommand\", options: \"zoomIn\" }); }");
                    sb.AppendLine("    });");

                    sb.AppendLine("    $(document).on('click', '.k-imageeditor-toolbar [data-command=\"ZoomImageEditorCommand\"][data-options=\"zoomOut\"]', function(e) {");
                    sb.AppendLine("        e.preventDefault(); e.stopPropagation();");
                    sb.AppendLine("        if (imageEditor) { imageEditor.executeCommand({ command: \"ZoomImageEditorCommand\", options: \"zoomOut\" }); }");
                    sb.AppendLine("    });");

                    sb.AppendLine("    $(document).on('change', \".k-imageeditor-toolbar .k-dropdownlist[data-command='ZoomDropDownImageEditorCommand']\", function () {");
                    sb.AppendLine("        const ddl = $(this).data(\"kendoDropDownList\");");
                    sb.AppendLine("        const selectedValue = ddl.value();");
                    sb.AppendLine("        if (imageEditor) { imageEditor.zoom(selectedValue); }");
                    sb.AppendLine("    });");

                    sb.AppendLine("    $(document).on('click', '.k-imageeditor-toolbar [data-command=\"OpenPaneImageEditorCommand\"][data-options=\"crop\"]', function(e) {");
                    sb.AppendLine("        e.preventDefault(); e.stopPropagation();");
                    sb.AppendLine("        if (imageEditor) { imageEditor.executeCommand({ command: 'OpenPaneImageEditorCommand', options: 'crop' }); }");
                    sb.AppendLine("    });");

                    sb.AppendLine("    $(document).on('click', '.k-imageeditor-toolbar [data-command=\"OpenPaneImageEditorCommand\"][data-options=\"resize\"]', function(e) {");
                    sb.AppendLine("        e.preventDefault(); e.stopPropagation();");
                    sb.AppendLine("        if (imageEditor) { imageEditor.executeCommand({ command: 'OpenPaneImageEditorCommand', options: 'resize' }); }");
                    sb.AppendLine("    });");

                    sb.AppendLine("    $(document).on('click', '.k-imageeditor-toolbar [data-command=\"UndoImageEditorCommand\"]', function(e) {");
                    sb.AppendLine("        e.preventDefault(); e.stopPropagation();");
                    sb.AppendLine("        if (imageEditor) { imageEditor.executeCommand({ command: \"UndoImageEditorCommand\" }); }");
                    sb.AppendLine("    });");

                    sb.AppendLine("    $(document).on('click', '.k-imageeditor-toolbar [data-command=\"RedoImageEditorCommand\"]', function(e) {");
                    sb.AppendLine("        e.preventDefault(); e.stopPropagation();");
                    sb.AppendLine("        if (imageEditor) { imageEditor.executeCommand({ command: \"RedoImageEditorCommand\" }); }");
                    sb.AppendLine("    });");

                    sb.AppendLine("    // Force enable controls periodically as fallback");
                    sb.AppendLine("    setInterval(() => {");
                    sb.AppendLine("        if (imageEditor) { forceEnableAllImageEditorControls(); }");
                    sb.AppendLine("    }, 1000);");
                }
            }
            sb.AppendLine("   $(document).ready(function () {");
            sb.AppendLine("$(\"#btnSave\").kendoButton({");
            sb.AppendLine("    icon: \"save\"");
            sb.AppendLine("});");
            sb.AppendLine("$(\"#btnCancel\").kendoButton({");
            sb.AppendLine("    icon: \"cancel\"");
            sb.AppendLine("});");
            if (showSaveContinue)
            {
                sb.AppendLine("$(\"#btnSaveContinue\").kendoButton({");
                sb.AppendLine("    icon: \"arrow-right\"");
                sb.AppendLine("});");
            }
            if (showSaveReuse)
            {
                sb.AppendLine("$(\"#btnSaveReuse\").kendoButton();");
            }

            //{
            //    sb.AppendLine($"      {form.Name}Grid();");
            //}
            if (uploadControlIds.Count != 0)
            {
                sb.AppendLine("    initUploadControl();");
                //sb.AppendLine("    initUploadControl();");
                sb.AppendLine(@"
    function initUploadControl() {");

                foreach (var id in uploadControlIds)
                {
                    sb.AppendLine($@"
        $('#{id}').kendoUpload({{
            async: false,
            multiple: false,
            showFileList: true
        }});");
                }

                sb.AppendLine("}"); // Close initUploadControl
            }
            foreach (var field in fields)
            {
                var fieldName = field.FieldName?.Trim() ?? string.Empty;
                //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                var tooltipContent = field.ToolTip?.Trim();
                var defaultValue = !string.IsNullOrWhiteSpace(field.DefaultValue) ? (field.DefaultValue) : string.Empty;

                if (string.Equals(field.TypeId, FieldTypeEnums.Timeduration.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"         var db{fieldNameLowerCase}=\"{defaultValue}\";");
                    sb.AppendLine($"        var {fieldNameLowerCase}Duration = $('#{fieldNameLowerCase}').kendoTimeDurationPicker({{");
                    sb.AppendLine("            columns: [");
                    sb.AppendLine("                { name: \"hours\", format: \"## Hours \", min: 0, max: 23 },");
                    sb.AppendLine("                { name: \"minutes\", format: \" ## Minutes \", min: 0, max: 59, step: 1 },");
                    sb.AppendLine("                { name: \"seconds\", format: \" ## Seconds\", min: 0, max: 59, step: 1 }");
                    sb.AppendLine("            ],");
                    sb.AppendLine("            separator: \":\",");
                    sb.AppendLine($"              value: hmsStringToMs(db{fieldNameLowerCase}),");
                    sb.AppendLine("");
                    sb.AppendLine("            // Common function to clear validation errors");
                    sb.AppendLine("            change: function () {");
                    sb.AppendLine("                clearTimeDurationError(this);");
                    sb.AppendLine("            },");
                    sb.AppendLine("            close: function () {");
                    sb.AppendLine("                clearTimeDurationError(this);");
                    sb.AppendLine("            }");
                    sb.AppendLine($"        }}).data('kendoTimeDurationPicker');");

                    if (!string.IsNullOrEmpty(tooltipContent))
                    {
                        // Tooltip binding on the wrapper
                        sb.AppendLine($"        {fieldNameLowerCase}Duration.wrapper.kendoTooltip({{");
                        sb.AppendLine($"            content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\"");
                        sb.AppendLine("        });");
                    }
                }

                if (string.Equals(field.TypeId, FieldTypeEnums.Captcha.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine(" $(function() {");
                    sb.AppendLine("     var captchaWidget = $(\"#captcha\").kendoCaptcha({");
                    sb.AppendLine("         handler: backendUrl + \"/Captcha/Handler\",");
                   // sb.AppendLine("         validationHandler: backendUrl + \"/Captcha/Validate\",");
                    sb.AppendLine("         audioHandler: backendUrl + \"/Captcha/Audio\"");
                    sb.AppendLine("     }).data(\"kendoCaptcha\");");

                    if (!string.IsNullOrEmpty(tooltipContent))
                    {
                        sb.AppendLine("     var $captchaWrapper = captchaWidget.wrapper;");
                        sb.AppendLine($"     $captchaWrapper.kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\", width: 200 }});");

                    }
                    sb.AppendLine(" });");
                }
            }

            //foreach (var field in fields)
            //{
            //    var fieldName = field.FieldName?.Trim() ?? "";
            //    if (string.IsNullOrEmpty(fieldName)) continue;

            //    var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
            //    var type = field.TypeId?.ToLower() ?? "";

            //    if (type == "varchar" || type == "nvarchar")
            //    {
            //        if(field.Max)
            //        {
            //            sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").kendoTextArea();");
            //        }
            //        else
            //        {
            //            sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").kendoTextBox();");
            //        }
            //    }
            //    else if (type == "int" || type == "decimal" || type == "float" || type == "money"
            //          || type == "bigint" || type == "smallint" || type == "tinyint")
            //    {
            //        sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").kendoNumericTextBox();");
            //    }
            //    else if (type == "date")
            //    {
            //        sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").kendoDatePicker();");
            //    }
            //    else if (type == "datetime")
            //    {
            //        sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").kendoDateTimePicker();");
            //    }
            //    else if (type == "rating")
            //    {
            //        sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").kendoRating();");
            //    }
            //}
            foreach (var field in fields)
            {
                var fieldName = field.FieldName?.Trim() ?? "";
                if (string.IsNullOrEmpty(fieldName)) continue;

                //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                var tooltipContent = field.ToolTip?.Trim();
                var defaultValue = !string.IsNullOrWhiteSpace(field.DefaultValue) ? (field.DefaultValue) : string.Empty;

                if (!Enum.TryParse<FieldTypeEnums>(field.TypeId, true, out var fieldType))
                    continue;

                switch (fieldType)
                {
                    case FieldTypeEnums.Nvarchar:

                        sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").kendoTextArea({{autoSize: true, resize: \"vertical\", rows: 5    }});");
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").closest('.k-textarea').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                        }
                        break;
                    case FieldTypeEnums.Varchar:
                        sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").kendoTextBox();");

                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").closest('.k-textbox').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                        }
                        break;

                    case FieldTypeEnums.Int:
                        {
                            var (minValue, maxValue) = GetValueRange(fieldType);
                            if (field.IsAllowPositive)
                                minValue = 0;
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").attr('data-allow-positive', '{field.IsAllowPositive.ToString().ToLower()}');");
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoNumericTextBox({{ format: \"n0\", decimals: 0, step: 1}});");
                            if (!string.IsNullOrEmpty(tooltipContent))
                            {
                                sb.AppendLine($"$(\"#{fieldNameLowerCase}\").closest('.k-numerictextbox').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                            }
                            break;
                        }
                    case FieldTypeEnums.Decimal:
                        {
                            var (minValue, maxValue) = GetValueRange(fieldType);
                            if (field.IsAllowPositive)
                                minValue = 0;
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").attr('data-allow-positive', '{field.IsAllowPositive.ToString().ToLower()}');");
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoNumericTextBox({{ format: \"n{field.Scale}\", decimals: {field.Scale}, step:0.01}});");
                            if (!string.IsNullOrEmpty(tooltipContent))
                            {
                                sb.AppendLine($"$(\"#{fieldNameLowerCase}\").closest('.k-numerictextbox').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                            }
                            break;
                        }
                    case FieldTypeEnums.Float:
                        {
                            var (minValue, maxValue) = GetValueRange(fieldType);
                            if (field.IsAllowPositive)
                                minValue = 0;
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").attr('data-allow-positive', '{field.IsAllowPositive.ToString().ToLower()}');");
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoNumericTextBox({{ format: \"n2\", decimals: 2, step: 0.01}});");
                            if (!string.IsNullOrEmpty(tooltipContent))
                            {
                                sb.AppendLine($"$(\"#{fieldNameLowerCase}\").closest('.k-numerictextbox').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                            }
                            break;
                        }
                    //case FieldTypeEnums.Float:
                    //    {
                    //        var minValue = field.IsAllowPositive ? 0 : -1.79E+308;
                    //        var maxValue = 1.79E+308;
                    //        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").attr('data-allow-positive', '{field.IsAllowPositive.ToString().ToLower()}');");
                    //        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").attr('data-dbtype', 'float');");
                    //        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoNumericTextBox({{ format: \"n2\", decimals: 2, step: 0.01, min: {minValue}, max: {maxValue} }});");
                    //        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").closest('.k-numerictextbox').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                    //        break;
                    //    }
                    case FieldTypeEnums.Money:
                        {
                            var (minValue, maxValue) = GetValueRange(fieldType);
                            if (field.IsAllowPositive)
                                minValue = 0;
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").attr('data-allow-positive', '{field.IsAllowPositive.ToString().ToLower()}');");
                            sb.AppendLine("kendo.culture('en-US');");
                            sb.AppendLine("kendo.cultures['en-US'].numberFormat.currency.pattern = ['-$n','$n'];");
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoNumericTextBox({{ format: \"c4\",culture: \"en-US\", decimals: 4, step: 0.0001 }});");
                            if (!string.IsNullOrEmpty(tooltipContent))
                            {
                                sb.AppendLine($"$(\"#{fieldNameLowerCase}\").closest('.k-numerictextbox').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                            }
                            break;
                        }
                    case FieldTypeEnums.Bigint:
                        {
                            var (minValue, maxValue) = GetValueRange(fieldType);
                            if (field.IsAllowPositive)
                                minValue = 0;
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").attr('data-allow-positive', '{field.IsAllowPositive.ToString().ToLower()}');");
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoNumericTextBox({{ format: \"n0\", decimals: 0, step: 1}});");
                            if (!string.IsNullOrEmpty(tooltipContent))
                            {
                                sb.AppendLine($"$(\"#{fieldNameLowerCase}\").closest('.k-numerictextbox').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                            }
                            break;
                        }
                    case FieldTypeEnums.Smallint:
                        {
                            var (minValue, maxValue) = GetValueRange(fieldType);
                            if (field.IsAllowPositive)
                                minValue = 0;
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").attr('data-allow-positive', '{field.IsAllowPositive.ToString().ToLower()}');");
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoNumericTextBox({{ format: \"n0\", decimals: 0, step: 1}});");
                            if (!string.IsNullOrEmpty(tooltipContent))
                            {
                                sb.AppendLine($"$(\"#{fieldNameLowerCase}\").closest('.k-numerictextbox').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                            }
                            break;
                        }
                    case FieldTypeEnums.Tinyint:
                        {
                            // allways unsigned
                            //var minValue = field.IsAllowPositive ? 0 : GetMinValue(fieldType);
                            //var maxValue = GetMaxValue(fieldType);
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").attr('data-allow-positive', '{field.IsAllowPositive.ToString().ToLower()}');");
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoNumericTextBox({{ format: \"n0\", decimals: 0, step: 1}});");
                            if (!string.IsNullOrEmpty(tooltipContent))
                            {
                                sb.AppendLine($"$(\"#{fieldNameLowerCase}\").closest('.k-numerictextbox').kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                            }
                            break;
                        }



                    case FieldTypeEnums.Date:
                        sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").kendoDatePicker({{");
                        sb.AppendLine("     format: \"MM/dd/yyyy\"");
                        // sb.AppendLine(" dateInput:true");
                        sb.AppendLine("     });");
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {

                            // Attach tooltip to the existing DatePicker
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").data(\"kendoDatePicker\").wrapper.kendoTooltip({{");
                            sb.AppendLine($"    content: \"{tooltipContent}\",");
                            sb.AppendLine("    position: \"top\",");
                            sb.AppendLine("    showOn: \"mouseenter\"");
                            sb.AppendLine("});");
                        }

                        break;

                    case FieldTypeEnums.Datetime:
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}\").kendoDateTimePicker({{");
                        // sb.AppendLine(" dateInput:true,");
                        sb.AppendLine($"   value: new Date(\"{defaultValue}\"),");
                        sb.AppendLine("    format: \"MM/dd/yyyy hh:mm tt\"");
                        sb.AppendLine("});");
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {

                            // Attach tooltip to the existing DateTimePicker
                            sb.AppendLine($"$(\"#{fieldNameLowerCase}\").data(\"kendoDateTimePicker\").wrapper.kendoTooltip({{");
                            sb.AppendLine($"    content: \"{tooltipContent}\",");
                            sb.AppendLine("    position: \"top\",");
                            sb.AppendLine("    showOn: \"mouseenter\"");
                            sb.AppendLine("});");
                        }


                        break;

                    case FieldTypeEnums.Rating:

                        //sb.AppendLine($"   var {fieldNameLowerCase}Rating = $(\"#{fieldNameLowerCase}\").kendoRating().data(\"kendoRating\");");
                        sb.AppendLine($"   var {fieldNameLowerCase}Rating = $(\"#{fieldNameLowerCase}\").kendoRating({{");
                        sb.AppendLine("       change: function(e) {");
                        sb.AppendLine($"           // Update hidden field whenever rating changes");
                        sb.AppendLine($"           $(\"#{fieldNameLowerCase}Value\").val(e.newValue || \"\");");
                        sb.AppendLine();
                        sb.AppendLine("           // Revalidate this input when user changes rating");
                        sb.AppendLine($"           validator.validateInput($(\"#{fieldNameLowerCase}Value\"));");
                        sb.AppendLine("       }");
                        sb.AppendLine($"   }}).data(\"kendoRating\");");
                        sb.AppendLine($"     {fieldNameLowerCase}Rating.value({defaultValue});");
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"   {fieldNameLowerCase}Rating.wrapper.kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                        }

                        break;
                    case FieldTypeEnums.Bit:
                        // ✅ Checkbox only (no IsSwitch logic anymore)
                        sb.AppendLine($"$('#{fieldNameLowerCase}').kendoCheckBox({{");
                        sb.AppendLine("    label: false");
                        sb.AppendLine("});");
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"   $(\"#{fieldNameLowerCase}\").closest(\".k-checkbox\").kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                        }
                        break;


                    case FieldTypeEnums.Switches:
                        // ✅ Dedicated Switch control
                        var label1 = string.IsNullOrWhiteSpace(field.SwitchLabel1) ? "YES" : field.SwitchLabel1?.Trim() ?? "";
                        var label2 = string.IsNullOrWhiteSpace(field.SwitchLabel2) ? "NO" : field.SwitchLabel2?.Trim() ?? "";

                        // ✅ Only create tooltip if user provided text
                        var hasTooltip = !string.IsNullOrWhiteSpace(tooltipContent);
                        var safeTooltip = hasTooltip ? tooltipContent.Replace("\"", "\\\"") : "";

                        // Initialize switch
                        sb.AppendLine($"    $('#{fieldNameLowerCase}').kendoSwitch({{");
                        sb.AppendLine("        messages: {");
                        sb.AppendLine($"            checked: \"{label1}\",");
                        sb.AppendLine($"            unchecked: \"{label2}\"");
                        sb.AppendLine("        },");
                        sb.AppendLine("        change: function(e) {");
                        sb.AppendLine("            var $input = $(this.element);");
                        sb.AppendLine("            $input.data('touched', true)");
                        sb.AppendLine("                  .removeClass('k-invalid is-invalid')");
                        sb.AppendLine("                  .closest('.form-group')");
                        sb.AppendLine("                  .find('.k-invalid-msg')");
                        sb.AppendLine("                  .remove();");
                        sb.AppendLine("        }");
                        sb.AppendLine("    });");

                        sb.AppendLine($"   var {fieldNameLowerCase}Switch = $(\"#{fieldNameLowerCase}\").data('kendoSwitch');");

                        // ✅ Add tooltip only when provided
                        sb.AppendLine($"   if ({fieldNameLowerCase}Switch && \"{safeTooltip}\" !== \"\") {{");
                        sb.AppendLine($"       {fieldNameLowerCase}Switch.wrapper.kendoTooltip({{");
                        sb.AppendLine($"           content: \"{safeTooltip}\",");
                        sb.AppendLine($"           position: \"top\",");
                        sb.AppendLine($"           showOn: \"mouseenter\"");
                        sb.AppendLine("       });");
                        sb.AppendLine("   }");
                        break;

                    default:
                        // Optionally handle unknown types
                        break;
                }
            }

            ////validation for signed unsigned
            //sb.AppendLine("    $(\"#Form\").kendoValidator({");
            //sb.AppendLine("        messages: {");
            //sb.AppendLine("            required: \"This field is required\",");
            //sb.AppendLine("            min: \"Value must be greater than or equal to {0}\",");
            //sb.AppendLine("            max: \"Value must be less than or equal to {0}\"");
            //sb.AppendLine("        }");
            //sb.AppendLine("    });");


            sb.AppendLine("        var validator = initializeKendoValidator(\"#Form\");");
            sb.AppendLine("");

            sb.AppendLine("    $(\"#Form\").on(\"input change\", \".required_field\", function () {");
            sb.AppendLine("        var input = $(this);");
            sb.AppendLine("");
            //sb.AppendLine("        validator.validateInput(input);");
            sb.AppendLine("");
            sb.AppendLine("        input.removeClass(\"k-invalid is-invalid\");");
            sb.AppendLine("        input.nextAll(\".k-invalid-msg\").remove();");
            sb.AppendLine("    });");
            sb.AppendLine("");

            foreach (var field in fields)
            {
                var typeId = field.TypeId?.Trim();
                var fieldName = field.FieldName?.Trim() ?? string.Empty;
                var fieldNameLowerCase = string.IsNullOrEmpty(fieldName)
                    ? string.Empty
                    : char.ToLowerInvariant(fieldName[0]) + fieldName.Substring(1);

                // --- Captcha handling ---
                if (string.Equals(typeId, FieldTypeEnums.Captcha.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine("    $('#captcha').on('input', function () {");
                    sb.AppendLine("        var input = $(this);");
                    sb.AppendLine("");
                    sb.AppendLine("        if ($.trim(input.val()) !== '') {");
                    sb.AppendLine("            input.removeClass('k-invalid is-invalid');");
                    sb.AppendLine("            input.closest('.form-group').find('.k-invalid-msg').remove();");
                    sb.AppendLine("        }");
                    sb.AppendLine("    });");
                    sb.AppendLine("");
                }

                // --- Time Duration handling ---
                else if (string.Equals(typeId, FieldTypeEnums.Timeduration.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine("    function clearTimeDurationError(widget) {");
                    sb.AppendLine("        var $input = $(widget.element);");
                    sb.AppendLine("        var value = widget.value();");
                    sb.AppendLine("");
                    sb.AppendLine("        if (value !== null && value !== undefined) {");
                    sb.AppendLine("            $input.removeClass('k-invalid is-invalid');");
                    sb.AppendLine("            $input.closest('.form-group').find('.k-invalid-msg').remove();");
                    sb.AppendLine($"            $('span[data-for=\"{fieldNameLowerCase}\"]').remove();");
                    sb.AppendLine("        }");
                    sb.AppendLine("    }");
                }

                // --- Switch handling ---
                else if (string.Equals(typeId, FieldTypeEnums.Switches.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"    $('#{fieldNameLowerCase}').on('change', function() {{");
                    sb.AppendLine("        $(this).data('touched', true);");
                    sb.AppendLine("        $(this).removeClass('k-invalid is-invalid');");
                    sb.AppendLine("        $(this).closest('.form-group').find('.k-invalid-msg').remove();");
                    sb.AppendLine("        if (typeof validator !== 'undefined') {");
                    sb.AppendLine("            validator.validateInput($(this));");
                    sb.AppendLine("        }");
                    sb.AppendLine("    });");
                }

                // --- Signature handling ---
                else if (string.Equals(typeId, FieldTypeEnums.Signature.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine("// --- Signature pad handling ---");
                    sb.AppendLine($"const canvas = document.getElementById(\"{fieldNameLowerCase}\");");
                    sb.AppendLine("if (canvas) {");
                    sb.AppendLine("    const ctx = canvas.getContext(\"2d\");");
                    sb.AppendLine("    let drawing = false;");
                    sb.AppendLine("    canvas.width = 400;");
                    sb.AppendLine("    canvas.height = 150;");

                    sb.AppendLine("    $(canvas).on(\"mousedown touchstart\", function() {");
                    sb.AppendLine("        drawing = true;");
                    sb.AppendLine("        ctx.beginPath();");
                    sb.AppendLine("    });");

                    sb.AppendLine("    $(canvas).on(\"mouseup touchend\", function() {");
                    sb.AppendLine("        drawing = false;");
                    sb.AppendLine("        ctx.beginPath();");
                    sb.AppendLine("        updateSignatureValue();");
                    sb.AppendLine("    });");

                    sb.AppendLine("    $(canvas).on(\"mousemove touchmove\", function(e) {");
                    sb.AppendLine("        if (!drawing) return;");
                    sb.AppendLine("        const rect = canvas.getBoundingClientRect();");
                    sb.AppendLine("        const x = e.offsetX || e.originalEvent.touches[0].clientX - rect.left;");
                    sb.AppendLine("        const y = e.offsetY || e.originalEvent.touches[0].clientY - rect.top;");
                    sb.AppendLine("        ctx.lineWidth = 2;");
                    sb.AppendLine("        ctx.lineCap = \"round\";");
                    sb.AppendLine("        ctx.strokeStyle = \"#000\";");
                    sb.AppendLine("        ctx.lineTo(x, y);");
                    sb.AppendLine("        ctx.stroke();");
                    sb.AppendLine("        ctx.beginPath();");
                    sb.AppendLine("        ctx.moveTo(x, y);");
                    sb.AppendLine("    });");

                    sb.AppendLine("    $(\".clear-signature-btn\").click(function() {");
                    sb.AppendLine("        ctx.clearRect(0, 0, canvas.width, canvas.height);");
                    sb.AppendLine($"        $(\"#{fieldNameLowerCase}Value\").val(\"\");");
                    sb.AppendLine($"        if (typeof validator !== 'undefined') validator.validateInput($(\"#{fieldNameLowerCase}Value\"));");
                    sb.AppendLine("    });");

                    sb.AppendLine("    function isCanvasEmpty(canvas) {");
                    sb.AppendLine("        const ctx = canvas.getContext(\"2d\");");
                    sb.AppendLine("        const pixelBuffer = new Uint32Array(ctx.getImageData(0, 0, canvas.width, canvas.height).data.buffer);");
                    sb.AppendLine("        return !pixelBuffer.some(color => color !== 0);");
                    sb.AppendLine("    }");

                    sb.AppendLine("    function updateSignatureValue() {");
                    sb.AppendLine("        if (!isCanvasEmpty(canvas)) {");
                    sb.AppendLine($"            $(\"#{fieldNameLowerCase}Value\").val(canvas.toDataURL());");
                    sb.AppendLine("        } else {");
                    sb.AppendLine($"            $(\"#{fieldNameLowerCase}Value\").val(\"\");");
                    sb.AppendLine("        }");
                    sb.AppendLine($"        if (typeof validator !== 'undefined') validator.validateInput($(\"#{fieldNameLowerCase}Value\"));");
                    sb.AppendLine("    }");

                    sb.AppendLine("}");
                }

                // --- Radio group ---
                else if (string.Equals(typeId, FieldTypeEnums.Radiogroup.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"$(\"#radiogroup_{fieldNameLowerCase}\").kendoRadioGroup({{");
                    sb.AppendLine($"    layout: {(field.Orientation == 2 ? "'vertical'" : "'horizontal'")},");
                    sb.AppendLine("    change: function(e) {");
                    sb.AppendLine($"        $(\"#{fieldNameLowerCase}Value\").val(e.newValue || \"\");");
                    sb.AppendLine($"        validator.validateInput($(\"#{fieldNameLowerCase}Value\"));");
                    sb.AppendLine("    }");
                    sb.AppendLine("});");

                    sb.AppendLine();
                    sb.AppendLine($"if (!$(\"#{fieldNameLowerCase}Value\").length) {{");
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").after('<input type=\"hidden\" id=\"{fieldNameLowerCase}Value\" name=\"{fieldNameLowerCase}Value\" required data-required-msg=\"{fieldNameLowerCase} is required\" />');");
                    sb.AppendLine("}");
                }

                // --- Checkbox group ---
                else if (string.Equals(typeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"// --- Checkbox group handling ({fieldNameLowerCase}) ---");
                    sb.AppendLine($"$(\"#checkboxgroup_{fieldNameLowerCase}\").html(`");
                    sb.AppendLine("    <li><input type='checkbox' value='1' /> A</li>");
                    sb.AppendLine("    <li><input type='checkbox' value='2' /> B</li>");
                    sb.AppendLine("`);");

                    sb.AppendLine();
                    sb.AppendLine($"if (!$(\"#{fieldNameLowerCase}Value\").length) {{");
                    sb.AppendLine($"    $(\"#checkboxgroup_{fieldNameLowerCase}\").after(`");
                    sb.AppendLine($"        <input type=\"hidden\" id=\"{fieldNameLowerCase}Value\"");
                    sb.AppendLine($"               name=\"{fieldNameLowerCase}\"");
                    sb.AppendLine("               class=\"checkbox-group-field\"");
                    sb.AppendLine("               required");
                    sb.AppendLine($"               data-required-msg=\"{fieldNameLowerCase} is required\" />");
                    sb.AppendLine("    `);");
                    sb.AppendLine("}");

                    sb.AppendLine();
                    sb.AppendLine($"$(\"#checkboxgroup_{fieldNameLowerCase}\").on(\"change\", \"input[type='checkbox']\", function() {{");
                    sb.AppendLine($"    const selected = $(\"#checkboxgroup_{fieldNameLowerCase} input:checked\")");
                    sb.AppendLine("        .map(function() { return this.value; })");
                    sb.AppendLine("        .get()")
                        .AppendLine("        .join(\",\");");

                    sb.AppendLine();
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}Value\").val(selected);");
                    sb.AppendLine($"    validator.validateInput($(\"#{fieldNameLowerCase}Value\"));");
                    sb.AppendLine("});");
                }

                // --- Normal Checkbox (Bit) ---
                else if (string.Equals(typeId, FieldTypeEnums.Bit.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine();
                    sb.AppendLine($"// --- Add validation behavior ({fieldNameLowerCase}) ---");
                    sb.AppendLine($"$(\"#{fieldNameLowerCase}\").on(\"change\", function () {{");
                    sb.AppendLine("    validator.validateInput($(this));");
                    sb.AppendLine("});");
                }

                // --- Color Picker ---
                else if (string.Equals(typeId, FieldTypeEnums.Colorpicker.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"// --- Color picker ({fieldNameLowerCase}) ---");
                    sb.AppendLine($"$(\"#{fieldNameLowerCase}\").on(\"input change\", function() {{");
                    sb.AppendLine("    validator.validateInput(this);");
                    sb.AppendLine("    const $input = $(this);");
                    sb.AppendLine("    const val = $input.val();");
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}Name\").val(val);");
                    sb.AppendLine("    if (val && val.trim() !== \"\") {");
                    sb.AppendLine("        $input.removeClass(\"is-invalid k-invalid\");");
                    sb.AppendLine("        $input.closest(\".form-group\").find(\".k-invalid-msg\").remove();");
                    sb.AppendLine("    } else {");
                    sb.AppendLine("        validator.validateInput($input);");
                    sb.AppendLine("    }");
                    sb.AppendLine("});");
                }

                // --- Rich Text Editor ---
                else if (string.Equals(typeId, FieldTypeEnums.Richtexteditor.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine("$(\"#testdesbtnAddText\").on(\"click\", function() {");
                    sb.AppendLine("    const textVal = $(\"#testdes\").val();");
                    sb.AppendLine("    $(\"#testdesRichTextContent\").val(textVal);");
                    sb.AppendLine("    validator.validateInput($(\"#testdesRichTextContent\"));");
                    sb.AppendLine("    $(\"#testdestextEditorWindow\").hide();");
                    sb.AppendLine("});");
                }
            }


            // --- Dropdown ---
            //sb.AppendLine("// $(\"#dropppdown\").kendoDropDownList({");
            //sb.AppendLine("   // optionLabel: \"-- Select --\",");
            //sb.AppendLine("   // dataSource: [");
            //sb.AppendLine("       // { text: \"Option 1\", value: \"1\" },");
            //sb.AppendLine("       // { text: \"Option 2\", value: \"2\" }");
            //sb.AppendLine("   // ],");
            //sb.AppendLine("   // dataTextField: \"text\",");
            //sb.AppendLine("   // dataValueField: \"value\",");
            //sb.AppendLine("   // change: function() {");
            //sb.AppendLine("       // formValidator.validateInput($(\"#dropppdown\"));");
            //sb.AppendLine("   // }");
            //sb.AppendLine("// });");

            // --- static image ---
            //sb.AppendLine("  $(\"#editImageBtn\").on(\"click\", function () {");
            //sb.AppendLine("      const staticImageUrl = \"@Url.Content(\"~/Icon/default_image.png\")\";");
            //sb.AppendLine("      $(\"#imagePreview\").attr(\"src\", staticImageUrl).show();");
            //sb.AppendLine("      $(\"#ImageBase64\").val(\"\");");
            //sb.AppendLine("      $(\"#closeImagePreview\").show();");
            //sb.AppendLine("      $(\"#Form\").data(\"kendoValidator\").validateInput($(\"#ImageBase64\"));");
            //sb.AppendLine("  });");

            //var imageFields = fields
            //.Where(f => string.Equals(f.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
            //.ToList();

            //foreach (var imageField in imageFields)
            //{
            //    var fieldName = imageField.FieldName?.Trim() ?? string.Empty;
            //    var fieldNameLowerCase = string.IsNullOrEmpty(fieldName)
            //        ? string.Empty
            //        : char.ToLowerInvariant(fieldName[0]) + fieldName.Substring(1);

            //    sb.AppendLine("// --- Close Image Preview Logic ---");
            //    sb.AppendLine("  $(\"#closeImagePreview\").on(\"click\", function () {");
            //    sb.AppendLine($"      $(\"#{fieldNameLowerCase}\").val(\"\");");
            //    sb.AppendLine($"      $(\"#imagePreview\").attr(\"src\", \"\").hide();");
            //    sb.AppendLine("      $(this).hide();");
            //    sb.AppendLine($"      $(\"#Form\").data(\"kendoValidator\").validateInput($(\"#{fieldNameLowerCase}\"));");
            //    sb.AppendLine("  });");
            //    sb.AppendLine("");
            //}

            //var matchingFields = fields
            //.Where(f => (string.Equals(f.TypeId, FieldTypeEnums.Varchar.ToString(), StringComparison.OrdinalIgnoreCase)
            //        || string.Equals(f.TypeId, FieldTypeEnums.Nvarchar.ToString(), StringComparison.OrdinalIgnoreCase))
            //         && f.Length > 0).ToList();

            //if (matchingFields.Count != 0)
            //{
            //    sb.AppendLine("        var validator = $(\"#Form\").kendoValidator({");
            //    sb.AppendLine("        errorTemplate: \"<span class='k-invalid-msg'>#=message#</span>\",");
            //    sb.AppendLine("        rules: {");
            //    sb.AppendLine("            maxLength: function (input) {");
            //    sb.AppendLine("                const max = input.data('maxlength');");
            //    sb.AppendLine("                if (max && input.val()) {");
            //    sb.AppendLine("                    return input.val().length <= max;");
            //    sb.AppendLine("            }");
            //    sb.AppendLine("            return true;");
            //    sb.AppendLine("        }");
            //    sb.AppendLine("        },");
            //    sb.AppendLine("        messages: {");
            //    sb.AppendLine("        maxLength: function (input) {");
            //    sb.AppendLine("            const max = input.data('maxlength');");
            //    sb.AppendLine("                const labelText = $(`label[for='${input.attr(\"id\")}']`).text().trim() || \"This field\";");
            //    sb.AppendLine("                return `${labelText} must not exceed ${max} characters.`;");
            //    sb.AppendLine("        }");
            //    sb.AppendLine("    }");
            //    sb.AppendLine("}).data('kendoValidator');");
            //    sb.AppendLine();
            //    sb.AppendLine("// Re-validate on input for fields with maxlength");
            //    sb.AppendLine("    $('[data-maxlength]').on('input', function () {");
            //    sb.AppendLine("        setTimeout(() => {");
            //    sb.AppendLine("            validator.validateInput($(this));");
            //    sb.AppendLine("        }, 0);");
            //    sb.AppendLine("    });");

            //}

            //var multiselectmandatory = fields.Where(f =>
            //string.Equals(f.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase)
            //&& f.Mandatory);

            //if (multiselectmandatory.Any())
            //{
            //    sb.AppendLine("var validator = $(\"#Form\").kendoValidator({");
            //    sb.AppendLine(" rules: {");
            //    sb.AppendLine(" requiredMultiSelect: function (input) {");
            //    sb.AppendLine(" if (input.data(\"role\") === \"multiselect\" && input.hasClass(\"required_field\")) {");
            //    sb.AppendLine(" var multiselect = input.data(\"kendoMultiSelect\");");
            //    sb.AppendLine(" return multiselect && multiselect.value().length > 0;");
            //    sb.AppendLine(" }");
            //    sb.AppendLine(" return true;");
            //    sb.AppendLine(" }");
            //    sb.AppendLine(" },");
            //    sb.AppendLine(" messages: {");
            //    sb.AppendLine(" requiredMultiSelect: function (input) {");
            //    sb.AppendLine(" if (input.data(\"role\") === \"multiselect\" && input.hasClass(\"required_field\")) {");
            //    sb.AppendLine(" var label = $.trim($(\"label[for='\" + input.attr(\"id\") + \"']\").text().replace('*', '').trim());");
            //    sb.AppendLine(" return (label || \"This field\") + \" is required\";"); 
            //    sb.AppendLine(" }");
            //    sb.AppendLine(" return \"\";");
            //    sb.AppendLine(" }");
            //    sb.AppendLine(" }");
            //    sb.AppendLine("}).data(\"kendoValidator\");"); 
            //}

            bool hasMaxLength = fields.Any(f =>
            (string.Equals(f.TypeId, FieldTypeEnums.Varchar.ToString(), StringComparison.OrdinalIgnoreCase)
            || string.Equals(f.TypeId, FieldTypeEnums.Nvarchar.ToString(), StringComparison.OrdinalIgnoreCase))
             && f.Length > 0);

            bool hasRequiredMultiSelect = fields.Any(f =>
                string.Equals(f.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase)
                && f.Mandatory);

            if (hasMaxLength || hasRequiredMultiSelect)
            {
                sb.AppendLine("var validator = $(\"#Form\").kendoValidator({");
                sb.AppendLine("        errorTemplate: \"<span class='k-invalid-msg'>#=message#</span>\",");
                sb.AppendLine("        rules: {");

                if (hasMaxLength)
                {
                    sb.AppendLine("            maxLength: function (input) {");
                    sb.AppendLine("                const max = input.data('maxlength');");
                    sb.AppendLine("                if (max && input.val()) {");
                    sb.AppendLine("                    return input.val().length <= max;");
                    sb.AppendLine("            }");
                    sb.AppendLine("            return true;");
                    sb.AppendLine("        },");
                }

                if (hasRequiredMultiSelect)
                {
                    sb.AppendLine("        requiredMultiSelect: function (input) {");
                    sb.AppendLine("            if (input.data(\"role\") === \"multiselect\" && input.hasClass(\"required_field\")) {");
                    sb.AppendLine("                var multiselect = input.data(\"kendoMultiSelect\");");
                    sb.AppendLine("                return multiselect && multiselect.value().length > 0;");
                    sb.AppendLine("            }");
                    sb.AppendLine("            return true;");
                    sb.AppendLine("        }");
                }

                sb.AppendLine("    },");
                sb.AppendLine("    messages: {");

                if (hasMaxLength)
                {
                    sb.AppendLine("        maxLength: function (input) {");
                    sb.AppendLine("            const max = input.data('maxlength');");
                    sb.AppendLine("            var labelText = $.trim($(\"label[for='\" + input.attr(\"id\") + \"']\").text().replace('*', '').trim());");
                    sb.AppendLine("            labelText = labelText || \"This field\";");
                    sb.AppendLine("            return labelText + \" must not exceed \" + max + \" characters.\";");
                    sb.AppendLine("        },");
                }



                if (hasRequiredMultiSelect)
                {
                    sb.AppendLine("        requiredMultiSelect: function (input) {");
                    sb.AppendLine("            if (input.data(\"role\") === \"multiselect\" && input.hasClass(\"required_field\")) {");
                    sb.AppendLine("                var label = $.trim($(\"label[for='\" + input.attr(\"id\") + \"']\").text().replace('*', '').trim());");
                    sb.AppendLine("                return (label || \"This field\") + \" is required\";");
                    sb.AppendLine("            }");
                    sb.AppendLine("            return \"\";");
                    sb.AppendLine("        }");
                }
                sb.AppendLine("    }");
                sb.AppendLine("}).data('kendoValidator');");
                if (hasMaxLength)
                {
                    sb.AppendLine();
                    sb.AppendLine("// Re-validate on input for fields with maxlength");
                    sb.AppendLine("    $('[data-maxlength]').on('input', function () {");
                    sb.AppendLine("        setTimeout(() => {");
                    sb.AppendLine("            validator.validateInput($(this));");
                    sb.AppendLine("        }, 0);");
                    sb.AppendLine("    });");
                }
            }


            sb.AppendLine("      var urlParams = new URLSearchParams(window.location.search);");
            sb.AppendLine("      var FormId = urlParams.get('id');");
            sb.AppendLine("       console.log('Form:', FormId);");
            ////////
            sb.AppendLine("      var ParentId = urlParams.has('parentId') ? urlParams.get('parentId') : null;");
            //  sb.AppendLine("      var lastFormId = urlParams.has('lastFormId') ? urlParams.get('lastFormId') : null;");
            sb.AppendLine("       FkId = urlParams.has('FkId') ? urlParams.get('FkId') : null;");
            sb.AppendLine("      if (ParentId) {");
            sb.AppendLine("          console.log('Parent:', ParentId);");
            sb.AppendLine("      } else {");
            sb.AppendLine("          console.log('ParentId not found');");
            sb.AppendLine("      }");

            //Image Editor
            foreach (var field in fields)
            {
                if (string.Equals(field.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    var tooltipContent = field.ToolTip?.Trim();
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;

                    sb.AppendLine($"  var imageEditorWindow_{fieldNameLowerCase} = $(\"#imageEditorPopup_{fieldNameLowerCase}\").kendoWindow({{");
                    sb.AppendLine("    title: \"Edit Image\",");
                    sb.AppendLine("    modal: true,");
                    sb.AppendLine("    visible: false,");
                    sb.AppendLine("    resizable: false,");
                    sb.AppendLine("    draggable: true,");
                    sb.AppendLine("    actions: [\"Maximize\", \"Close\"],");
                    sb.AppendLine("    width: \"80%\",");
                    sb.AppendLine("    open: function () {");
                    sb.AppendLine($"         const imageUrl = $(\"#{fieldNameLowerCase}imagePreview\").attr(\"src\") && $(\"#{fieldNameLowerCase}imagePreview\").attr(\"src\").startsWith('data:image/')");
                    sb.AppendLine($"            ? $(\"#{fieldNameLowerCase}imagePreview\").attr(\"src\")");
                    sb.AppendLine($"            : null;");
                    sb.AppendLine($"         initializePopupImageEditor(imageUrl, \"imageEditorContainer_{fieldNameLowerCase}\");");
                    sb.AppendLine("         rebindZoomDropDownItems();");
                    sb.AppendLine("    },");
                    sb.AppendLine("    maximize: function () {");
                    sb.AppendLine($"       $(\"#imageEditorContainer_{fieldNameLowerCase}\").css({{ width: '100%', height: '80%' }});");
                    sb.AppendLine("    }");
                    sb.AppendLine("  }).data(\"kendoWindow\");");
                    sb.AppendLine();
            
                    sb.AppendLine($"  $(\"#saveEditedImage_{fieldNameLowerCase}\").kendoButton({{");
                    sb.AppendLine("        icon: \"plus\",");
                    sb.AppendLine("        themeColor: \"primary\"");
                    sb.AppendLine("  });");
                    sb.AppendLine();
                    sb.AppendLine($"  $(\"#{fieldNameLowerCase}editImageBtn\").kendoButton({{ themeColor: \"base\" }});");
                    if (!string.IsNullOrEmpty(tooltipContent))
                    {
                        sb.AppendLine($"  $(\"#{fieldNameLowerCase}editImageBtn\").kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                    }
                    sb.AppendLine();

                    // Remove Image (Reset)
                    sb.AppendLine($"  $(\"#{fieldNameLowerCase}closeImagePreview\").click(function () {{");
                    sb.AppendLine($"      $(\"#{fieldNameLowerCase}imagePreview\").attr(\"src\", '@Url.Content(\"~/Icon/default_image.png\")').show();");
                    sb.AppendLine($"      $(\"#{fieldNameLowerCase}editImageBtn\").show();");
                    sb.AppendLine($"      $(\"#{fieldNameLowerCase}closeImagePreview\").show();");
                    sb.AppendLine($"      $(\"#{fieldNameLowerCase}ImageBase64\").val(\"\");");
                    sb.AppendLine($"      initializePopupImageEditor(null, \"imageEditorContainer_{fieldNameLowerCase}\");");
                    sb.AppendLine("        if (typeof notification !== 'undefined') { fnShowNotification(\"Image removed.\", \"success\"); }");
                    sb.AppendLine("  });");
                    sb.AppendLine();

                    // Make Remove Button Kendo
                    sb.AppendLine($"  $(\"#{fieldNameLowerCase}closeImagePreview\").kendoButton({{ themeColor: \"base\", content: \"Remove\" }});");
                    sb.AppendLine();
                    var imageField = fields.FirstOrDefault(f => string.Equals(f.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase));

                    // --- Image Editor Save Logic ---
                    sb.AppendLine($"  $(\"#saveEditedImage_{fieldNameLowerCase}\").click(function () {{");
                    sb.AppendLine("    try {");
                    sb.AppendLine($"        var canvas = $(\"#imageEditorContainer_{fieldNameLowerCase}\").find(\"canvas\")[0];");
                    sb.AppendLine("        if (canvas && typeof canvas.toDataURL === \"function\") {");
                    sb.AppendLine("            var base64Image = canvas.toDataURL(\"image/jpeg\", 0.9);");
                    sb.AppendLine($"            $(\"#{fieldNameLowerCase}imagePreview\").attr(\"src\", base64Image).show();");
                    sb.AppendLine($"            $(\"#{fieldNameLowerCase}ImageBase64\").val(base64Image);");
                    sb.AppendLine("            $(\".image-preview-container\").css(\"display\", \"flex\");");
                    sb.AppendLine($"            $(\"#{fieldNameLowerCase}closeImagePreview\").show();");
                    sb.AppendLine();
                    sb.AppendLine($"             const input = $(\"#{fieldNameLowerCase}ImageBase64\");");
                    sb.AppendLine("             input.val(base64Image);");
                    sb.AppendLine("             input.removeClass(\"k-invalid is-invalid\").attr(\"aria-invalid\", \"false\");");
                    sb.AppendLine("             input.closest(\".form-group\").find(\".k-invalid-msg\").remove();");
                    sb.AppendLine();
                    sb.AppendLine($"            imageEditorWindow_{fieldNameLowerCase}.close();");
                    //sb.AppendLine("            fnShowNotification(\"Image saved successfully.\", \"success\");");
                    sb.AppendLine("        } else { fnShowNotification(\"Unable to save image.\", \"error\"); }");
                    sb.AppendLine("    } catch (error) {");
                    sb.AppendLine("        console.error(\"Error saving image:\", error);");
                    sb.AppendLine("        fnShowNotification(\"Error saving image.\", \"error\");");
                    sb.AppendLine("    }");
                    sb.AppendLine("  });");  


                    // Cancel button (Close Window Only)
                    sb.AppendLine($"  $(\"#cancelEditedImage_{fieldNameLowerCase}\").click(function () {{");
                    sb.AppendLine($"       if (imageEditorWindow_{fieldNameLowerCase}) {{ imageEditorWindow_{fieldNameLowerCase}.close(); }}");
                    sb.AppendLine("  });");
                    sb.AppendLine();

                    // Open Editor
                    sb.AppendLine($"  $(\"#{fieldNameLowerCase}editImageBtn\").click(function () {{");
                    sb.AppendLine($"       var imageUrl = $(\"#{fieldNameLowerCase}imagePreview\").attr(\"src\") && $(\"#{fieldNameLowerCase}imagePreview\").attr(\"src\").startsWith('data:image/')");
                    sb.AppendLine($"           ? $(\"#{fieldNameLowerCase}imagePreview\").attr(\"src\")");
                    sb.AppendLine($"           : null;");
                    sb.AppendLine($"       imageEditorWindow_{fieldNameLowerCase}.center().open();");
                    sb.AppendLine($"       initializePopupImageEditor(imageUrl, \"imageEditorContainer_{fieldNameLowerCase}\");");
                    sb.AppendLine("  });");
                }
            }


            // Initialize signature pads
            foreach (var field in fields.Where(f =>
     string.Equals(f.TypeId, FieldTypeEnums.Signature.ToString(), StringComparison.OrdinalIgnoreCase)))
            {
                var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                var tooltipContent = field.ToolTip?.Trim();
                sb.AppendLine($"      // Initialize signature pad for {fieldNameLowerCase}");
                sb.AppendLine($"      const canvas_{fieldNameLowerCase} = $('#{fieldNameLowerCase}')[0];");
                sb.AppendLine($"      const ctx_{fieldNameLowerCase} = canvas_{fieldNameLowerCase}.getContext('2d');");
                sb.AppendLine($"      ctx_{fieldNameLowerCase}.strokeStyle = '#000';");
                sb.AppendLine($"      ctx_{fieldNameLowerCase}.lineWidth = 2;");
                sb.AppendLine($"      let drawing_{fieldNameLowerCase} = false;");
                sb.AppendLine($"      function resizeCanvas_{fieldNameLowerCase}() {{");
                sb.AppendLine($"          canvas_{fieldNameLowerCase}.width = canvas_{fieldNameLowerCase}.offsetWidth;");
                sb.AppendLine($"          canvas_{fieldNameLowerCase}.height = canvas_{fieldNameLowerCase}.offsetHeight;");
                sb.AppendLine("      }");
                sb.AppendLine($"      resizeCanvas_{fieldNameLowerCase}();");
                sb.AppendLine($"      window.addEventListener('resize', resizeCanvas_{fieldNameLowerCase});");
                sb.AppendLine($"      $('#{fieldNameLowerCase}_container').on('mousedown touchstart', function(e) {{");
                sb.AppendLine($"          drawing_{fieldNameLowerCase} = true;");
                sb.AppendLine($"          const pos = getPos(e, canvas_{fieldNameLowerCase});");
                sb.AppendLine($"          ctx_{fieldNameLowerCase}.beginPath();");
                sb.AppendLine($"          ctx_{fieldNameLowerCase}.moveTo(pos.x, pos.y);");
                sb.AppendLine("      });");
                sb.AppendLine($"      $('#{fieldNameLowerCase}_container').on('mousemove touchmove', function(e) {{");
                sb.AppendLine($"          if (drawing_{fieldNameLowerCase}) {{");
                sb.AppendLine("              e.preventDefault();");
                sb.AppendLine($"              const pos = getPos(e, canvas_{fieldNameLowerCase});");
                sb.AppendLine($"              ctx_{fieldNameLowerCase}.lineTo(pos.x, pos.y);");
                sb.AppendLine($"              ctx_{fieldNameLowerCase}.stroke();");
                sb.AppendLine("          }");
                sb.AppendLine("      });");
                sb.AppendLine($"      $('#{fieldNameLowerCase}_container').on('mouseup mouseleave touchend touchcancel', function() {{");
                sb.AppendLine($"          drawing_{fieldNameLowerCase} = false;");
                sb.AppendLine("      });");
                sb.AppendLine("      function getPos(e, canvas) {");
                sb.AppendLine("          const rect = canvas.getBoundingClientRect();");
                sb.AppendLine("          const evt = e.touches ? e.touches[0] : e;");
                sb.AppendLine("          const scaleX = canvas.width / rect.width;");
                sb.AppendLine("          const scaleY = canvas.height / rect.height;");
                sb.AppendLine("          return {");
                sb.AppendLine("              x: (evt.clientX - rect.left) * scaleX,");
                sb.AppendLine("              y: (evt.clientY - rect.top) * scaleY");
                sb.AppendLine("          };");
                sb.AppendLine("      }");
                if (!string.IsNullOrEmpty(tooltipContent))
                {
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}_container\").kendoTooltip({{");
                    sb.AppendLine("        filter: \".signature-canvas\",   // attach only to the canvas");
                    sb.AppendLine("        position: \"top\",");
                    sb.AppendLine("        showOn: \"mouseenter\",          // trigger only when hovering");
                    sb.AppendLine($"        content: \"{tooltipContent}\"");
                    sb.AppendLine("    });");
                }

                sb.AppendLine($"      $('#{fieldNameLowerCase}_container .clear-signature-btn').click(function() {{");
                sb.AppendLine($"          ctx_{fieldNameLowerCase}.clearRect(0, 0, canvas_{fieldNameLowerCase}.width, canvas_{fieldNameLowerCase}.height);");
                // sb.AppendLine($"   var {fieldNameLowerCase}Signature = $(\"#{fieldNameLowerCase}\").kendoSignature().data(\"kendoSignature\");");
                //sb.AppendLine($"   {fieldNameLowerCase}Signature.wrapper.kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                sb.AppendLine("      });");
            }

            ////Kendo Notification
            //sb.AppendLine("     var notification = $('#notification').kendoNotification({");
            //sb.AppendLine("        animation: { open: { effects: \"slideIn:left\" }, close: { effects: \"slideIn:left\", reverse: true } },");
            //sb.AppendLine("        position: { top: 91, right: 80 },");
            //sb.AppendLine("        stacking: 'down',");
            //sb.AppendLine("        autoHideAfter: 5000,");
            //sb.AppendLine("        hideOnClick: true,");
            //sb.AppendLine("        button: true");
            //sb.AppendLine("     }).data('kendoNotification');");

            //sb.AppendLine("     function showNotification(type, message) {");
            //sb.AppendLine("        notification.show(message, type);");
            //sb.AppendLine("     }");

            //slider initilizing 
            // Check if at least one slider exists before generating JS
            if (fields.Any(f => string.Equals(f.TypeId, FieldTypeEnums.Slider.ToString(), StringComparison.OrdinalIgnoreCase)))

            {
                sb.AppendLine("      var responseData = null;");
                sb.AppendLine("      let initializedTabs = {};");

                //  Generate initializeSliders function
                sb.AppendLine("function initializeSliders(tabId) {");
                sb.AppendLine("    if (initializedTabs[tabId]) return;");
                sb.AppendLine("    switch (tabId) {");

                for (int i = 0; i < groupedSections.Count; i++)
                {
                    var section = groupedSections[i];
                    var sectionId = "tab_" + section.Key.SectionName.Replace(" ", "_");

                    sb.AppendLine($"        case '#{sectionId}':");

                    foreach (var sectionField in section)
                    {
                        if (!string.Equals(sectionField.TypeId, FieldTypeEnums.Slider.ToString(), StringComparison.OrdinalIgnoreCase))
                            continue;

                        var fieldName = sectionField.FieldName?.Trim() ?? string.Empty;
                        var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                        var tooltipContent = sectionField.ToolTip?.Trim();

                        sb.AppendLine($"            $('#{fieldNameLowerCase}').kendoSlider({{");

                        if (sectionField.Orientation == 2)
                        {
                            sb.AppendLine("                orientation: \"vertical\",");
                        }

                        sb.AppendLine("                increaseButtonTitle: \"Right\",");
                        sb.AppendLine("                decreaseButtonTitle: \"Left\",");
                        sb.AppendLine($"                min: {sectionField.MinValue},");
                        sb.AppendLine($"                max: {sectionField.MaxValue},");
                        sb.AppendLine($"                smallStep: {sectionField.SmallStep},");
                        sb.AppendLine($"                largeStep: {sectionField.LargeStep},");
                        sb.AppendLine($"                showButtons: {sectionField.ShowButton.ToString().ToLower()}");
                        sb.AppendLine("            });");
                        sb.AppendLine($"   var {fieldNameLowerCase}Slider = $(\"#{fieldNameLowerCase}\").data(\"kendoSlider\");");
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"   {fieldNameLowerCase}Slider.wrapper.kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                        }
                    }

                    sb.AppendLine("            break;");
                }

                sb.AppendLine("    }");
                sb.AppendLine("    initializedTabs[tabId] = true;");
                sb.AppendLine("    if (responseData) {");
                sb.AppendLine("        populateSliderData(tabId);");
                sb.AppendLine("    }");
                sb.AppendLine("}");

                //  Generate populateSliderData function
                sb.AppendLine("function populateSliderData(tabId) {");
                sb.AppendLine("    var sliderIds = [];");

                sb.AppendLine("    switch (tabId) {");

                foreach (var section in groupedSections)
                {
                    var sectionId = "#tab_" + section.Key.SectionName.Replace(" ", "_");

                    //var sliderFieldNames = section
                    //    .Where(f => (f.TypeId?.ToLower() ?? "") == "slider")
                    //    .Select(f => "'" + (char.ToLower(f.FieldName[0]) + f.FieldName[1..]).Replace(" ", "_") + "'")
                    //    .ToList();

                    var sliderFieldNames = section
                    .Where(f => string.Equals(f.TypeId, FieldTypeEnums.Slider.ToString(), StringComparison.OrdinalIgnoreCase)
         && !string.IsNullOrWhiteSpace(f.FieldName)
         && f.FieldName.Trim().Length > 1)
                        .Select(f => "'" + (char.ToLower(f.FieldName!.Trim()[0]) + f.FieldName.Trim()[1..]).Replace(" ", "_") + "'")
                        .ToList();


                    if (sliderFieldNames.Count != 0)
                    {
                        var joinedNames = string.Join(", ", sliderFieldNames);
                        sb.AppendLine($"        case '{sectionId}':");
                        sb.AppendLine($"            sliderIds = [{joinedNames}];");
                        sb.AppendLine("            break;");
                    }
                }

                sb.AppendLine("    }");

                sb.AppendLine("    sliderIds.forEach(function(sliderId) {");
                sb.AppendLine("        var slider = $('#' + sliderId).data(\"kendoSlider\");");
                sb.AppendLine("        if (slider && responseData) {");
                sb.AppendLine("            for (const key in responseData) {");
                sb.AppendLine("                if (key.toLowerCase() === sliderId.toLowerCase()) {");
                sb.AppendLine("                    var val = responseData[key];");
                sb.AppendLine("                    if (val !== undefined && val !== null) {");
                sb.AppendLine("                        slider.value(val);");
                sb.AppendLine("                        slider.trigger(\"change\");");
                sb.AppendLine("                    }");
                sb.AppendLine("                }");
                sb.AppendLine("            }");
                sb.AppendLine("        }");
                sb.AppendLine("    });");
                sb.AppendLine("}");

                //  Tab event handler
                sb.AppendLine("$(\"button[data-bs-toggle='tab']\").on('shown.bs.tab', function(e) {");
                sb.AppendLine("    const target = $(e.target).attr('data-bs-target');");
                sb.AppendLine("    initializeSliders(target);");
                sb.AppendLine("});");
                foreach (var section in groupedSections)
                {
                    var sectionId = "#tab_" + section.Key.SectionName.Replace(" ", "_");
                    sb.AppendLine($"initializeSliders(`{sectionId}`);");
                    break;
                }
            }

            foreach (var form in childForms)
            {
                sb.AppendLine("     // Button to create a new form (button 1)");
                sb.AppendLine($"     $('#{form.TableName}Btn').click(function() {{");
                sb.AppendLine("        var lastFormId = localStorage.getItem('recentFormId');");
                sb.AppendLine("        if (FormId) {");
                sb.AppendLine($"       window.location.href = '/{table.Name}/{form.TableName}Details1?FkId=' + FormId;");
                sb.AppendLine("        } else if (lastFormId) {");
                sb.AppendLine($"        window.location.href = '/{table.Name}/{form.TableName}Details1?FkId=' + lastFormId;");
                sb.AppendLine("        } else {");
                sb.AppendLine("        fnShowNotification('No recent form or table found!','error');");
                sb.AppendLine("        }");
                sb.AppendLine("     });");
            }

            foreach (var field in fields)
            {
                if (string.Equals(field.TypeId, FieldTypeEnums.Rangeslider.ToString(), StringComparison.OrdinalIgnoreCase))
                {

                    var fieldName = field.FieldName?.Trim() ?? string.Empty;
                    //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    var tooltipContent = field.ToolTip?.Trim();
                    var sectionId = "tab_" + (field.SectionName?.Replace(" ", "_") ?? "");

                    var minValue = field.MinValue ?? 0;
                    var maxValue = field.MaxValue ?? 100;
                    var smallStep = field.SmallStep ?? 1;
                    var largeStep = field.LargeStep ?? 10;
                    var symbol = string.IsNullOrEmpty(field.Symbol) ? "" : field.Symbol;
                    var symbolPosition = field.SymbolPosition ?? 0;

                    // Set a default JS variable to reference later (this will be populated after AJAX)
                    sb.AppendLine($@"var response_{fieldNameLowerCase} = null;");

                    if (groupedSections.First().Key.SectionName == field.SectionName)
                    {
                        sb.AppendLine($@"
                        if (!$('#{fieldNameLowerCase}').data('kendoRangeSlider')) {{
                            $('#{fieldNameLowerCase}').kendoRangeSlider({{
                            min: {minValue},
                            max: {maxValue},
                            smallStep: {smallStep},
                            largeStep: {largeStep},
                           //tooltip: {{ enabled: true, format: '{symbol}{{0}}' }},   
                           tooltip: {{ enabled: true, format: '{(symbolPosition != 0 && symbolPosition == 1 ? symbol + " {0}" : "{0} " + symbol)}' }},
                            change: function (e) {{
                            var values = e.values;
                            $('#rangeValues_{fieldNameLowerCase}').text('Selected Range: ' + values[0] + ' {symbol} - ' + values[1] + ' {symbol}');
                            $('#{fieldNameLowerCase}Value').val(values[0] + ',' + values[1]);
                        }}
                    }});
                    var values = response_{fieldNameLowerCase} ? response_{fieldNameLowerCase}.split(',').map(Number) : [{minValue}, {maxValue}];
                    $('#{fieldNameLowerCase}').data('kendoRangeSlider').values(values);
                    $('#{fieldNameLowerCase}Value').val(values[0] + ',' + values[1]);
                     $('#rangeValues_{fieldNameLowerCase}').text('Selected Range: ' + {(symbolPosition != 0 && symbolPosition == 1 ? "'" + symbol + " ' + values[0] + ' - " + symbol + " ' + values[1]" : "values[0] + ' " + symbol + " - ' + values[1] + ' " + symbol + "'")});
                    }}
                    ");
                    }
                    else
                    {
                        sb.AppendLine($@"
                    var initialized_{fieldNameLowerCase} = false;
                    $('button[data-bs-target=""#{sectionId}""]').one('shown.bs.tab', function () {{
                    if (!initialized_{fieldNameLowerCase}) {{
                    $('#{fieldNameLowerCase}').kendoRangeSlider({{
                    min: {minValue},
                    max: {maxValue},
                    smallStep: {smallStep},
                    largeStep: {largeStep},
                    tooltip: {{ enabled: true, format: '{(symbolPosition != 0 && symbolPosition == 1 ? "{0} " + symbol : symbol + " {0}")}' }},
                    //tooltip: {{ enabled: true, format: '{{0}} {symbol}' }},
                    change: function (e) {{
                        var values = e.values;
                        $('#rangeValues_{fieldNameLowerCase}').text('Selected Range: ' + values[0] + ' {symbol} - ' + values[1] + ' {symbol}');
                        $('#{fieldNameLowerCase}Value').val(values[0] + ',' + values[1]);
                    }}
                }});

                initialized_{fieldNameLowerCase} = true;

                var values = response_{fieldNameLowerCase} ? response_{fieldNameLowerCase}.split(',').map(Number) : [{minValue}, {maxValue}];
                $('#{fieldNameLowerCase}').data('kendoRangeSlider').values(values);
                $('#{fieldNameLowerCase}Value').val(values[0] + ',' + values[1]);
                //$('#rangeValues_{fieldNameLowerCase}').text('Selected Range: {symbol}' + values[0] + ' - {symbol}' + values[1]);
                 $('#rangeValues_{fieldNameLowerCase}').text('Selected Range: ' + {(symbolPosition != 0 && symbolPosition == 1 ? "'" + symbol + " ' + values[0] + ' - " + symbol + " ' + values[1]" : "values[0] + ' " + symbol + " - ' + values[1] + ' " + symbol + "'")});

                  }}
                }});
            ");
                    }
                    //sb.AppendLine($"   {fieldNameLowerCase}Slider.wrapper.kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");

                    if (!string.IsNullOrWhiteSpace(field.ToolTip))
                    {
                        sb.AppendLine($"  var slider = $('#{fieldNameLowerCase}').data('kendoRangeSlider');");
                        sb.AppendLine($"  var tooltipMessage = \"{field.ToolTip.Replace("\"", "\\\"")}\";");
                        sb.AppendLine($"  if (tooltipMessage.trim() !== \"\") {{");
                        sb.AppendLine($"      slider.wrapper.kendoTooltip({{");
                        sb.AppendLine($"          filter: \".k-draghandle, .k-slider-track\",");
                        sb.AppendLine($"          content: tooltipMessage,");
                        sb.AppendLine($"          position: \"top\",");
                        sb.AppendLine($"          showOn: \"mouseenter\"");
                        sb.AppendLine($"      }});");
                        sb.AppendLine($"  }}");
                    }

                }
                //if (string.Equals(field.TypeId, FieldTypeEnums.Switches.ToString(), StringComparison.OrdinalIgnoreCase))
                //{
                //    var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];

                //    var label1 = string.IsNullOrWhiteSpace(field.SwitchLabel1) ? "YES" : (field.SwitchLabel1?.Trim() ?? "");
                //    var label2 = string.IsNullOrWhiteSpace(field.SwitchLabel2) ? "NO" : (field.SwitchLabel2?.Trim() ?? "");

                //    sb.AppendLine($"$('#{fieldNameLowerCase}').kendoSwitch({{");
                //    sb.AppendLine("    messages: {");
                //    sb.AppendLine($"        checked: \"{label1}\",");
                //    sb.AppendLine($"        unchecked: \"{label2}\"");
                //    sb.AppendLine("    },");
                //    sb.AppendLine("    size: 'large',");
                //    sb.AppendLine("    thumbRounded: 'large',");
                //    sb.AppendLine("    trackRounded: 'large',");
                //    sb.AppendLine("    showLabels: true");
                //    sb.AppendLine("});");
                //}
            }
            foreach (var field in fields)
            {
                var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];

                var sourceTableNameLower = field.SourceTableName?.ToLower() ?? string.Empty;

                if (string.Equals(field.TypeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($" let preSelected_{fieldNameLowerCase} = [];");
                    sb.AppendLine($" let {sourceTableNameLower}_{fieldNameLowerCase}DataLoaded = false;");
                    sb.AppendLine($" let original_{fieldNameLowerCase}_data = [];");
                    sb.AppendLine($" let selected_{fieldNameLowerCase}_values = [];");
                }

                if (string.Equals(field.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($" let preSelected_{fieldNameLowerCase} = [];");
                }
            }

            //Edit Mode
            // **Fetch and Populate Data for Edit**
            sb.AppendLine("     if (FormId) {");
            if (showSaveReuse)
            {
                sb.AppendLine("      $('#btnSaveReuse').hide();");
            }
            sb.AppendLine("        $.ajax({");
            sb.AppendLine($"            url: backendUrl + `/{table.Name.ToLower()}/`+ FormId,");
            sb.AppendLine("            type: 'GET',");
            sb.AppendLine("            dataType: 'json',");
            sb.AppendLine("            success: function (response) {");
            sb.AppendLine("                console.log('Editing Student Data:', response);");
            sb.AppendLine("                responseData = response;    ");
            foreach (var field in fields)
            {
                //var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                var tooltipContent = field.ToolTip?.Trim();
                if (string.Equals(field.TypeId, FieldTypeEnums.Timeduration.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    //var fieldNameLowerCase = char.ToLower(field.FieldName[0]) + field.FieldName.Substring(1);
                    sb.AppendLine($"                if (response.{fieldNameLowerCase}) {{");
                    sb.AppendLine($"                    var timeParts = response.{fieldNameLowerCase}.split(':');");
                    sb.AppendLine($"                    if (timeParts.length === 3) {{");
                    sb.AppendLine($"                        var hours = parseInt(timeParts[0], 10);");
                    sb.AppendLine($"                        var minutes = parseInt(timeParts[1], 10);");
                    sb.AppendLine($"                        var seconds = parseInt(timeParts[2], 10);");
                    sb.AppendLine($"                        var totalMilliseconds = ((hours * 3600) + (minutes * 60) + seconds) * 1000;");
                    sb.AppendLine($"                        var durationPicker = $('#{fieldNameLowerCase}').data('kendoTimeDurationPicker');");
                    sb.AppendLine($"                        if (durationPicker) {{");
                    sb.AppendLine($"                            durationPicker.value(totalMilliseconds);");
                    sb.AppendLine($"                        }}");
                    sb.AppendLine($"                    }}");
                    sb.AppendLine($"                }}");


                }

                if (string.Equals(field.TypeId, FieldTypeEnums.Richtexteditor.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    {
                        sb.AppendLine($"               if (responseData.{fieldNameLowerCase} !== undefined) {{");
                        sb.AppendLine($"    $(\"#{fieldNameLowerCase}RichTextContent\").val(responseData.{fieldNameLowerCase}); // keep HTML safe");
                        sb.AppendLine("}");
                    }
                }

                if (string.Equals(field.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"if(response.{fieldNameLowerCase}_{field.SourceTableName}Ids) {{");
                    sb.AppendLine($"    // Set Kendo multiselect values for {fieldNameLowerCase}");
                    sb.AppendLine($"    preSelected_{fieldNameLowerCase} = response.{fieldNameLowerCase}_{field.SourceTableName}Ids.split(',').map(id => id.toString().trim());");
                    sb.AppendLine($"    console.log('Pre-selected IDs:', preSelected_{fieldNameLowerCase});");
                    sb.AppendLine($"    var multiselect = $(\"#{fieldNameLowerCase}\").data(\"kendoMultiSelect\");");
                    sb.AppendLine("    if (multiselect) {");
                    sb.AppendLine($"        multiselect.value(preSelected_{fieldNameLowerCase});");
                    sb.AppendLine("        multiselect.trigger(\"change\"); // optional, in case you rely on change event");
                    sb.AppendLine("    }");
                    sb.AppendLine("}");
                }


                if (string.Equals(field.TypeId, FieldTypeEnums.Nvarchar.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"  $(\"#{fieldNameLowerCase}\").val(responseData.{fieldNameLowerCase}); ");
                }
                bool isCascading = await IsCascadingFieldAsync(field.FieldId, field.FormId, configConnectionString);

                TableModel? sourcetable = await GetTableData(field.SourceTableId, configConnectionString);
                if (sourcetable == null && string.Equals(field.TypeId, FieldTypeEnums.DropDown.ToString(), StringComparison.OrdinalIgnoreCase)
             && field.IsMultiColumn == false)
                {
                    //var fieldNameLowerCase = char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim().Substring(1);
                    var textFieldLowerCase = char.ToLower((field.TextFieldName?.Trim() ?? "")[0]) + (field.TextFieldName?.Trim() ?? "")[1..];
                    sb.AppendLine($"                  var selected{fieldNameLowerCase} = response.{fieldNameLowerCase};");
                    sb.AppendLine($"                 var {fieldNameLowerCase}Dropdown = $(\"#{fieldNameLowerCase}\").data(\"kendoDropDownList\");");
                    sb.AppendLine($"               {fieldNameLowerCase}Dropdown.value(selected{fieldNameLowerCase});");

                }

                else if (sourcetable != null && !isCascading && sourcetable.IsHierarchical && string.IsNullOrEmpty(field.ParentFieldName) && string.Equals(field.TypeId, FieldTypeEnums.DropDown.ToString(), StringComparison.OrdinalIgnoreCase))
                {

                    //var fieldNameLowerCase = char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim().Substring(1);
                    var textFieldLowerCase = char.ToLower((field.TextFieldName?.Trim() ?? "")[0]) + (field.TextFieldName?.Trim() ?? "")[1..];
                    sb.AppendLine($"                  var selected{fieldNameLowerCase} = response.{fieldNameLowerCase};");
                    sb.AppendLine($"                 var {fieldNameLowerCase}Dropdown = $(\"#{fieldNameLowerCase}\").data(\"kendoDropDownTree\");");
                    sb.AppendLine($"               {fieldNameLowerCase}Dropdown.value(selected{fieldNameLowerCase});");

                }

                //if (field.TypeId.ToLower() == "imageupload")
                if (string.Equals(field.TypeId, FieldTypeEnums.ImageUpload.ToString(), StringComparison.OrdinalIgnoreCase)
     || string.Equals(field.TypeId, FieldTypeEnums.Varbinary.ToString(), StringComparison.OrdinalIgnoreCase))

                {
                    var uploadField = imageUploadFields.FirstOrDefault(u => u.FieldName == field.FieldName);
                    if (!uploadField.Equals(default((string FieldName, string UploadId))))
                    {
                        var fieldNameTrimmed = field.FieldName?.Trim() ?? "";
                        var uploadId = uploadField.UploadId;

                        //                        sb.AppendLine($@"
                        //if (response.{fieldNameTrimmed}) {{
                        //    const fileName = response.{fieldNameTrimmed}Name || 'UploadedFile.png';
                        //    const fileSize = (response.{fieldNameTrimmed}.length * 3) / 4;
                        //    const uploadWidget = $('#{uploadId}').data('kendoUpload');

                        //    if (uploadWidget) {{
                        //        uploadWidget.options.showFileList = true;
                        //        uploadWidget.wrapper.find('.k-file').remove();

                        //        uploadWidget._renderInitialFiles([{{
                        //            name: fileName,
                        //            size: fileSize,
                        //            extension: fileName.split('.').pop(),
                        //            url: `data:image/png;base64,${{response.{fieldNameTrimmed}}}`
                        //        }}]);
                        //    }} else {{
                        //        console.warn('Upload widget not found for #{uploadId}.');
                        //    }}
                        //}}");


                        var fileNameField = fieldNameTrimmed + "Name"; // This defines it!

                        sb.AppendLine($@"
                            if (response.{fieldNameTrimmed}) {{
                                const fileNameFromApi = response.{fileNameField} || response.{fileNameField.ToLower()};
                                const fileName = fileNameFromApi ? fileNameFromApi.trim() : 'UploadedFile.png';
                                const fileSize = Math.floor((response.{fieldNameTrimmed}.length * 3) / 4);
                                const uploadWidget = $('#{uploadId}').data('kendoUpload');

                                if (uploadWidget) {{
                                    uploadWidget.options.showFileList = true;
                                    uploadWidget.wrapper.find('.k-file').remove();

                                    uploadWidget._renderInitialFiles([{{
                                        name: fileName,
                                        size: fileSize,
                                        extension: '.' + fileName.split('.').pop().toLowerCase(),
                                        uid: kendo.guid(),
                                        state: 'uploaded',
                                        url: `data:image/png;base64,${{response.{fieldNameTrimmed}}}`
                                    }}]);
                                }} else {{
                                    console.warn('Upload widget not found for #{uploadId}.');
                                }}
                            }}
                            ");
                    }
                }
                if (string.Equals(field.TypeId, FieldTypeEnums.Switches.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    //var fieldNameLowerCase = char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim().Substring(1);

                    sb.AppendLine($"                if ($(\"#{fieldNameLowerCase}\").data(\"kendoSwitch\") && response.{fieldNameLowerCase} !== undefined) {{");
                    sb.AppendLine($"                    var toggleVal = response.{fieldNameLowerCase};");
                    sb.AppendLine($"                    var isChecked = toggleVal === true || toggleVal === \"true\" || toggleVal === 1 || toggleVal === \"1\" || toggleVal === \"on\";");
                    sb.AppendLine($"                    $(\"#{fieldNameLowerCase}\").data(\"kendoSwitch\").check(isChecked);");
                    sb.AppendLine($"                }}");
                }

                if (string.Equals(field.TypeId, FieldTypeEnums.Rangeslider.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    //if (field.Rangeslider == true)
                    //{
                    var symbol = string.IsNullOrEmpty(field.Symbol) ? "" : field.Symbol;
                    //var fieldName = field.FieldName.Trim();
                    sb.AppendLine($"                 response_{fieldNameLowerCase} = response.{fieldNameLowerCase};");
                    //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName.Substring(1);
                    sb.AppendLine($"                if (response.{fieldNameLowerCase}) {{");
                    sb.AppendLine($"                    var rangeValues = response.{fieldNameLowerCase}.split(',').map(Number);");
                    sb.AppendLine($"                    var slider = $('#{fieldNameLowerCase}').data('kendoRangeSlider');");
                    sb.AppendLine($"                    if (slider && rangeValues.length === 2) {{");
                    sb.AppendLine($"                        slider.values(rangeValues);");
                    sb.AppendLine($"                        $('#{fieldNameLowerCase}Value').val(response.{fieldNameLowerCase});");
                    sb.AppendLine($"                       $('#rangeValues_{fieldNameLowerCase}').text('Selected Range: ' + rangeValues[0] + ' {symbol} - ' + rangeValues[1] + ' {symbol}');");
                    sb.AppendLine($"                    }}");
                    sb.AppendLine($"                }}");
                    sb.AppendLine($"   var {fieldNameLowerCase}Slider = $(\"#{fieldNameLowerCase}\").data(\"kendoRangeSlider\");");
                    //sb.AppendLine($"   {fieldNameLowerCase}Slider.wrapper.kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                    //}
                }
            }
            foreach (var field in fields)
            {
                if (string.Equals(field.TypeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    var fieldNameLowerCasecheck = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                    var sourceTableNameLower = field.SourceTableName?.ToLower() ?? string.Empty;

                    sb.AppendLine($" if(response.{fieldNameLowerCasecheck}_{sourceTableNameLower}Ids) {{ ");
                    sb.AppendLine($"    // Set Kendo CheckBoxGroup values for {fieldNameLowerCase}");
                    sb.AppendLine($"    preSelected_{fieldNameLowerCase} =  response.{fieldNameLowerCasecheck}_{sourceTableNameLower}Ids.split(',').map(id => id.toString().trim().toLowerCase()); ");
                    sb.AppendLine($"        console.log('Pre-selected IDs:', preSelected_{fieldNameLowerCase});");
                    sb.AppendLine("    }");
                    sb.AppendLine($"if ({sourceTableNameLower}_{fieldNameLowerCase}DataLoaded) {{");
                    sb.AppendLine($"render_{fieldNameLowerCase}_checkboxes(original_{fieldNameLowerCase}_data, preSelected_{fieldNameLowerCase});");
                    sb.AppendLine("}");
                }
            }
            if (fields.Any(f => f.TypeId == "slider"))
            {
                var firstSection = groupedSections.FirstOrDefault();
                var sectionName = firstSection?.Key?.SectionName;

                //if (firstSection.Key != null)
                if (!string.IsNullOrWhiteSpace(sectionName))
                {
                    //var sectionId = "#tab_" + firstSection.Key.SectionName.Replace(" ", "_");
                    var sectionId = "#tab_" + sectionName.Replace(" ", "_");
                    sb.AppendLine($"populateSliderData(`{sectionId}`);");
                }
            }

            foreach (var field in fields)
            {
                if (field.TypeId == "radiogroup")
                {
                    var radioFieldNameLower = !string.IsNullOrWhiteSpace(field.FieldName) && field.FieldName.Trim().Length > 1
                        ? char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim()[1..]
                        : string.Empty;

                    var radioFieldsNameLower = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    var groupElementId = $"radiogroup_{radioFieldNameLower}";

                    sb.AppendLine("setTimeout(function() {");
                    sb.AppendLine($"    var radiogroup = $(\"#{groupElementId}\").data(\"kendoRadioGroup\");");
                    sb.AppendLine($"    if (radiogroup) {{");


                    sb.AppendLine($"        radiogroup.setOptions({{ layout: {(field.Orientation == 2 ? "'vertical'" : "'horizontal'")} }});");

                    sb.AppendLine($"        if (response.{radioFieldsNameLower}) {{");
                    sb.AppendLine($"            radiogroup.value(response.{radioFieldsNameLower});");
                    sb.AppendLine($"            $(\"#{radioFieldNameLower}Value\").val(response.{radioFieldsNameLower});");

                    sb.AppendLine($"            var block = $(\"#{radioFieldNameLower}_block\");");
                    sb.AppendLine($"            block.removeClass('k-invalid');");
                    sb.AppendLine($"            block.find('.k-invalid-msg').hide();");

                    sb.AppendLine($"            var validator = $(\"#formId\").data('kendoValidator');");
                    sb.AppendLine($"            if (validator) validator.validateInput(block.find('input'));");
                    sb.AppendLine("        }");

                    sb.AppendLine("    }");
                    sb.AppendLine("}, 200);");
                }
            }

            sb.AppendLine("                $('input, select').each(function () {");
            sb.AppendLine("                    var fieldId = $(this).attr('id');");
            sb.AppendLine("                    fieldId = fieldId == undefined ? \"\" : fieldId;");
            sb.AppendLine("              if (!fieldId) return;");

            //sb.AppendLine("                    if (fieldId && response[fieldId] !== undefined) {");
            //sb.AppendLine("                        $(this).val(response[fieldId]).trigger('change');");
            //sb.AppendLine("                    }");
            //sb.AppendLine("                });");

            sb.AppendLine("            if ($(this).data(\"kendoNumericTextBox\")) {");
            sb.AppendLine("               var fieldId = $(this).attr(\"id\");");
            sb.AppendLine("               if (response[fieldId] !== undefined) {");
            sb.AppendLine("                     var numericWidget = $(\"#\" + fieldId).data(\"kendoNumericTextBox\");");
            sb.AppendLine("                     if (numericWidget) {");
            sb.AppendLine("                     numericWidget.value(response[fieldId]);");
            sb.AppendLine("                     numericWidget.trigger(\"change\");");
            sb.AppendLine("                }");
            sb.AppendLine("             }");
            sb.AppendLine("         }");
            sb.AppendLine("                 for (const key in response) {");
            sb.AppendLine("                if (key && key.toLowerCase() === fieldId.toLowerCase()) {");
            sb.AppendLine("                  var val = response[key];");
            sb.AppendLine("                 $(this).val(val).trigger('change');");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("});");


            // Form level check
            var formWithDelimiter = fields.FirstOrDefault(f => f.Delimiter != null && f.CardViewControlFields != null && f.CardViewControlFields.Any());
            if (formWithDelimiter != null)
            {
                sb.AppendLine($"var delimiterChar = '{formWithDelimiter.Delimiter}';");
                var fieldsArray = string.Join(",", formWithDelimiter.CardViewControlFields!.Select(f => $"'{f}'"));
                sb.AppendLine($"var fields = [{fieldsArray}];");

                sb.AppendLine("let titleElement = $(\".listsection\").find(\"h1,h2,h3,h4,.form-title,.list-title\").first();");
                sb.AppendLine("if (titleElement.length) {");

                // Get selected text labels from the CardView Control fields
                sb.AppendLine("    let fieldSummaryValue = fields.map(function(fieldId) {");
                sb.AppendLine("        let $field = $(\"#\" + fieldId);");
                sb.AppendLine("        if ($field.length) {");
                sb.AppendLine("            // Check if it's a multi-select or single select");
                sb.AppendLine("            if ($field.is('select')) {");
                sb.AppendLine("                return $field.find('option:selected').map(function() {");
                sb.AppendLine("                    return $(this).text().trim();");
                sb.AppendLine("                }).get().filter(Boolean).join(', ');");
                sb.AppendLine("            } else {");
                sb.AppendLine("                return $field.val()?.trim();");
                sb.AppendLine("            }");
                sb.AppendLine("        }");
                sb.AppendLine("        return '';");
                sb.AppendLine("    }).filter(Boolean).join(` ${delimiterChar} `);");

                sb.AppendLine("    titleElement.siblings(\".field-summary\").remove();");

                sb.AppendLine("    if (!titleElement.parent().hasClass(\"title-flex-wrap\")) {");
                sb.AppendLine("        titleElement.wrap(\"<div class='title-flex-wrap' style='display:flex;align-items:center;gap:8px'></div>\");");
                sb.AppendLine("    }");

                sb.AppendLine("    if (fieldSummaryValue) {");
                sb.AppendLine("        $(`<span class='field-summary' style='font-weight:600;color:#000;font-size:28px;margin-top:-20px'> - ${fieldSummaryValue}</span>`)");
                sb.AppendLine("            .insertAfter(titleElement);");
                sb.AppendLine("    }");
                sb.AppendLine("}");
            }


            foreach (var field in fields)
            {
                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                if (string.Equals(field.TypeId, FieldTypeEnums.Date.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"                if (response.{fieldNameLowerCase}) {{");
                    sb.AppendLine($"                    const {fieldNameLowerCase} = new Date(response.{fieldNameLowerCase});");
                    sb.AppendLine($"                    const picker = $(\"#{fieldNameLowerCase}\").data(\"kendoDatePicker\");");
                    sb.AppendLine($"                if (picker && !isNaN({fieldNameLowerCase})) {{");
                    sb.AppendLine($"                    picker.value({fieldNameLowerCase});");
                    sb.AppendLine("                   }");
                    sb.AppendLine("                 }");
                }
                if (string.Equals(field.TypeId, FieldTypeEnums.Datetime.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"                if (response.{fieldNameLowerCase}) {{");
                    sb.AppendLine($"                    const {fieldNameLowerCase} = new Date(response.{fieldNameLowerCase});");
                    sb.AppendLine($"                    const picker = $(\"#{fieldNameLowerCase}\").data(\"kendoDateTimePicker\");");
                    sb.AppendLine($"                if (picker && !isNaN({fieldNameLowerCase})) {{");
                    sb.AppendLine($"                     picker.value({fieldNameLowerCase});");
                    sb.AppendLine("                   }");
                    sb.AppendLine("                 }");
                }

                if (string.Equals(field.TypeId, FieldTypeEnums.Bit.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    //--- Handle all dynamic checkboxes from response ---
                    sb.AppendLine();
                    sb.AppendLine("                for (const key in response) {");
                    sb.AppendLine($"                    if (response.hasOwnProperty(key) && key.toLowerCase().startsWith('{fieldNameLowerCase}')) {{");
                    sb.AppendLine("                        const val = response[key];");
                    sb.AppendLine("                        const isChecked =");
                    sb.AppendLine("                            val === true ||");
                    sb.AppendLine("                            val === 1 ||");
                    sb.AppendLine("                            val === '1' ||");
                    sb.AppendLine("                            String(val).toLowerCase() === 'true';");
                    sb.AppendLine();
                    sb.AppendLine("                        const $checkbox = $('#' + key);");
                    sb.AppendLine("                        if ($checkbox.length) {");
                    sb.AppendLine("                            const widget = $checkbox.data('kendoCheckBox');");
                    sb.AppendLine("                            if (widget) {");
                    sb.AppendLine("                                widget.check(isChecked);");
                    sb.AppendLine("                            } else {");
                    sb.AppendLine("                                $checkbox.prop('checked', isChecked);");
                    sb.AppendLine("                            }");
                    sb.AppendLine();
                    sb.AppendLine("                            // trigger change + validator update");
                    sb.AppendLine("                            $checkbox.trigger('change');");
                    sb.AppendLine("                            if (typeof validator !== 'undefined') {");
                    sb.AppendLine("                                validator.validateInput($checkbox);");
                    sb.AppendLine("                            }");
                    sb.AppendLine();
                    sb.AppendLine("                            console.log(` Checkbox [${key}] checked:`, isChecked);");
                    sb.AppendLine("                        } else {");
                    sb.AppendLine("                            console.warn(` Checkbox [${key}] not found in DOM`);");
                    sb.AppendLine("                        }");
                    sb.AppendLine("                    }");
                    sb.AppendLine("                }");
                }


                // Now add your richtexteditor field processing code
                if (string.Equals(field.TypeId, FieldTypeEnums.Richtexteditor.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    // var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];

                    sb.AppendLine($"var editor = $(\"#{fieldNameLowerCase}\").data(\"kendoEditor\");");
                    sb.AppendLine($"if (editor && response.{fieldNameLowerCase} !== undefined) {{");
                    sb.AppendLine($"    var plainText = stripHtml(response.{fieldNameLowerCase});");
                    sb.AppendLine("    editor.value(plainText);");
                    sb.AppendLine("}");
                }
                else if (string.Equals(field.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"let {fieldNameLowerCase}ImageUrl = response.{fieldNameLowerCase}ImageBase64 && response.{fieldNameLowerCase}ImageBase64.trim() !== \"\"");
                    sb.AppendLine($"    ? response.{fieldNameLowerCase}ImageBase64");
                    sb.AppendLine("    : null;");
                    sb.AppendLine("");
                    sb.AppendLine("  // Show image preview");
                    sb.AppendLine($"  if ({fieldNameLowerCase}ImageUrl) {{");
                    sb.AppendLine($"    $('#{fieldNameLowerCase}imagePreview').attr('src', {fieldNameLowerCase}ImageUrl).show();");
                    sb.AppendLine(" $(\".image-preview-container\").css(\"display\", \"flex\");\r\n");
                    sb.AppendLine($" $(\"#{fieldNameLowerCase}closeImagePreview\").show();");
                    sb.AppendLine("  }");
                    sb.AppendLine("");
                    sb.AppendLine($"initializeImageEditor({fieldNameLowerCase}ImageUrl,  \"imageEditorContainer_{fieldNameLowerCase}\");");
                }

            }




            // Add the stripHtml function once before your field code

            sb.AppendLine("    //Convert Normal Text to HTML Content With CSS");
            sb.AppendLine("function stripHtml(html) {");
            sb.AppendLine("    var tmp = document.createElement(\"DIV\");");
            sb.AppendLine("    tmp.innerHTML = html;");
            sb.AppendLine("    return tmp.textContent || tmp.innerText || \"\";");
            sb.AppendLine("}");
            sb.AppendLine("setTimeout(function () {");
            sb.AppendLine("    $('input').each(function () {");
            sb.AppendLine("        var fieldId = $(this).attr('id');");
            sb.AppendLine("        fieldId = fieldId ? fieldId.toString().trim() : '';");
            sb.AppendLine("        if (!fieldId) return;");
            sb.AppendLine("        if ($(this).attr('type') === 'radio') {");
            sb.AppendLine("            var name = $(this).attr('name');");
            sb.AppendLine("            if (response[name] !== undefined) {");
            sb.AppendLine("                if ($(this).val() == response[name]) {");
            sb.AppendLine("                    $(this).prop('checked', true);");
            sb.AppendLine("                    $(this).trigger('change');");
            sb.AppendLine("                }");
            sb.AppendLine("            }");
            sb.AppendLine("        }");


            foreach (var field in fields.Where(f =>
                string.Equals(f.TypeId, FieldTypeEnums.Signature.ToString(), StringComparison.OrdinalIgnoreCase)))
            {
                var fieldNameLower = field.FieldName?.Trim().ToLower() ?? string.Empty;
                var canvasVar = $"canvas_{fieldNameLower}";
                var ctxVar = $"ctx_{fieldNameLower}";

                sb.AppendLine($"        if (response.{fieldNameLower}Base64) {{");
                sb.AppendLine($"            const img = new Image();");
                sb.AppendLine($"            img.crossOrigin = 'anonymous';");
                sb.AppendLine($"            img.onload = function() {{");
                sb.AppendLine($"                {canvasVar}.width = {canvasVar}.offsetWidth;");
                sb.AppendLine($"                {canvasVar}.height = {canvasVar}.offsetHeight;");
                sb.AppendLine($"                {ctxVar}.clearRect(0, 0, {canvasVar}.width, {canvasVar}.height);");
                sb.AppendLine($"                {ctxVar}.drawImage(img, 0, 0, {canvasVar}.width, {canvasVar}.height);");
                sb.AppendLine($"                $('#{fieldNameLower}Value').val(response.{fieldNameLower}Base64); // ✅ update hidden field");
                sb.AppendLine($"            }};");
                sb.AppendLine($"            img.src = response.{fieldNameLower}Base64;");
                sb.AppendLine("        } else {");
                sb.AppendLine($"            $('#{fieldNameLower}Value').val(''); // clear if no signature");
                sb.AppendLine("        }");
            }

            //foreach (var field in fields)
            //{
            //    var fieldName = field.FieldName?.Trim() ?? "";
            //    if (string.IsNullOrEmpty(fieldName)) continue;

            //    var fieldNameLower = char.ToLower(fieldName[0]) + fieldName[1..];
            //    var typeId = (field.TypeId ?? "").Trim().ToLower();

            //    sb.AppendLine($"    // Handle {fieldName} ({typeId})");

            //    sb.AppendLine($"    if (response.{fieldNameLower} !== undefined) {{");

            //    // ✅ Case 1: Switches (Kendo Switch)
            //    sb.AppendLine($"        if (\"{typeId}\" === \"switches\") {{");
            //    sb.AppendLine($"            var switchWidget = $(\"#{fieldNameLower}\").data('kendoSwitch');");
            //    sb.AppendLine($"            if (switchWidget) {{");
            //    sb.AppendLine($"                switchWidget.check(response.{fieldNameLower} === true || response.{fieldNameLower} === 1);");
            //    sb.AppendLine($"                switchWidget.trigger('change');");
            //    sb.AppendLine($"            }} else {{");
            //    sb.AppendLine($"                $(\"#{fieldNameLower}\").prop('checked', response.{fieldNameLower} === true || response.{fieldNameLower} === 1);");
            //    sb.AppendLine($"            }}");
            //    sb.AppendLine($"        }}");

            //    // ✅ Case 2: Bit (Checkbox)
            //    sb.AppendLine($"        else if (\"{typeId}\" === \"bit\") {{");
            //    sb.AppendLine($"            var checkboxWidget = $(\"#{fieldNameLower}\").data('kendoCheckBox');");
            //    sb.AppendLine($"            if (checkboxWidget) {{");
            //    sb.AppendLine($"                checkboxWidget.check(response.{fieldNameLower} === true || response.{fieldNameLower} === 1);");
            //    sb.AppendLine($"                checkboxWidget.trigger('change');");
            //    sb.AppendLine($"            }} else {{");
            //    sb.AppendLine($"                $(\"#{fieldNameLower}\").prop('checked', response.{fieldNameLower} === true || response.{fieldNameLower} === 1);");
            //    sb.AppendLine($"            }}");
            //    sb.AppendLine($"        }}");

            //    sb.AppendLine($"    }}"); // end if response[field] !== undefined
            //}

            foreach (var field in fields.Where(f =>
                 string.Equals(f.TypeId?.Trim(), FieldTypeEnums.Switches.ToString(), StringComparison.OrdinalIgnoreCase) ||
                 string.Equals(f.TypeId?.Trim(), FieldTypeEnums.Bit.ToString(), StringComparison.OrdinalIgnoreCase)))
            {
                var fieldName = field.FieldName?.Trim();
                if (string.IsNullOrEmpty(fieldName)) continue;
                var fieldNameLower = char.ToLowerInvariant(fieldName[0]) + (fieldName.Length > 1 ? fieldName[1..] : "");
                var typeId = field.TypeId?.Trim() ?? "";
                var widgetType = string.Equals(typeId, FieldTypeEnums.Switches.ToString(), StringComparison.OrdinalIgnoreCase)
                    ? "kendoSwitch"
                    : "kendoCheckBox";

                sb.AppendLine($"        // Handle {fieldName} ({typeId})");
                sb.AppendLine($"       // if (response.{fieldNameLower} != null) {{");
                sb.AppendLine($"          //  var widget = $('#{fieldNameLower}').data('{widgetType}');");
                sb.AppendLine($"          //  if (widget) {{");
                sb.AppendLine($"              //  widget.check(response.{fieldNameLower} == true || response.{fieldNameLower} == 1);");
                sb.AppendLine($"              //  widget.trigger('change');");
                sb.AppendLine($"           // }} else {{");
                sb.AppendLine($"              //  $('#{fieldNameLower}').prop('checked', response.{fieldNameLower} == true || response.{fieldNameLower} == 1);");
                sb.AppendLine($"           // }}");
                sb.AppendLine("       // }");
            }






            sb.AppendLine("        var dropdown = $(this).data('kendoDropDownList') || $(this).data('kendoMultiColumnComboBox');");
            sb.AppendLine("        if (dropdown) {");
            sb.AppendLine("            var responseKey = response.hasOwnProperty(fieldId) ? fieldId :");
            sb.AppendLine("                              response.hasOwnProperty(fieldId + '_Item') ? fieldId + '_Item' : null;");
            sb.AppendLine("            if (responseKey && response[responseKey] != null) {");
            sb.AppendLine("                var valueToSet = response[responseKey].toString().trim();");
            sb.AppendLine("                if (dropdown.listView && dropdown.listView.dataSource.view().length > 0) {");
            sb.AppendLine("                    dropdown.value(valueToSet);");
            sb.AppendLine("                    dropdown.trigger('change');");
            sb.AppendLine("                } else {");
            sb.AppendLine("                    dropdown.one('dataBound', function () {");
            sb.AppendLine("                        dropdown.value(valueToSet);");
            sb.AppendLine("                        dropdown.trigger('change');");
            sb.AppendLine("                    });");
            sb.AppendLine("                }");
            sb.AppendLine("                console.log('Dropdown [' + fieldId + '] bound with value:', valueToSet);");
            sb.AppendLine("            }");
            sb.AppendLine("        }");
            sb.AppendLine("    });");

            foreach (var field in fields)
            {
                var fieldNameLower = field.FieldName?.Trim().ToLower() ?? string.Empty;

                if (string.Equals(field.TypeId, FieldTypeEnums.Rating.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"    if (response.{fieldNameLower} !== undefined) {{");
                    sb.AppendLine($"        var ratingWidget = $('#{fieldNameLower}').data('kendoRating');");
                    sb.AppendLine("        if (ratingWidget) {");
                    sb.AppendLine($"            var ratingValue = parseFloat(response.{fieldNameLower});");
                    sb.AppendLine("            ratingWidget.value(ratingValue);");
                    sb.AppendLine($"            $('#{fieldNameLower}Value').val(ratingValue || ''); // update hidden input");
                    sb.AppendLine("            if (ratingValue && ratingValue > 0) {");
                    sb.AppendLine($"                var input = $('#{fieldNameLower}Value');");
                    sb.AppendLine($"                var group = $('#{fieldNameLower}').closest('.form-group');");
                    sb.AppendLine("                group.removeClass('is-invalid');");
                    sb.AppendLine("                group.find('.k-invalid-msg').remove();");
                    sb.AppendLine("                input.removeClass('k-invalid is-invalid').attr('aria-invalid', 'false');");
                    sb.AppendLine("            }");
                    sb.AppendLine("        }");
                    sb.AppendLine("    }");
                }
            }

            foreach (var field in fields)
            {
                var fieldNameLower = field.FieldName?.Trim().ToLower() ?? string.Empty;

                if (string.Equals(field.TypeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"    if (response.{fieldNameLower}_itemIds) {{");
                    sb.AppendLine($"        const selectedValues = response.{fieldNameLower}_itemIds.split(',').map(v => v.trim());");
                    sb.AppendLine($"        $('#checkboxgroup_{fieldNameLower} input[type=\"checkbox\"]').prop('checked', false);");
                    sb.AppendLine("        selectedValues.forEach(v => {");
                    sb.AppendLine($"            $('#checkboxgroup_{fieldNameLower} input[value=\"' + v + '\"]').prop('checked', true);");
                    sb.AppendLine("        });");
                    sb.AppendLine($"        const selected = $('#checkboxgroup_{fieldNameLower} input:checked').map(function() {{");
                    sb.AppendLine("            return this.value;");
                    sb.AppendLine("        }).get().join(',');");
                    sb.AppendLine($"        $('#{fieldNameLower}Value').val(selected);");
                    sb.AppendLine("        if (typeof validator !== 'undefined') {");
                    sb.AppendLine("            validator.hideMessages();");
                    sb.AppendLine($"            validator.validateInput($('#{fieldNameLower}Value'));");
                    sb.AppendLine("        }");
                    sb.AppendLine("    }");
                }
            }


            sb.AppendLine("       }, 300);");
            // Now call dropdown initialization
            //  sb.AppendLine("        initDropdowns();");
            foreach (var btn in childForms)
            {
                sb.AppendLine($"                    $('#{btn.TableName}Btn').prop('disabled', false);");
            }

            sb.AppendLine("            },");

            sb.AppendLine("            error: function (jqXHR, textStatus, errorThrown) {");
            sb.AppendLine("                console.error('Error fetching student data: ' + textStatus + ' ' + errorThrown);");
            foreach (var field in fields)
            {
                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;

                if (string.Equals(field.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"                initializePopupImageEditor(null, \"imageEditorContainer_{fieldNameLowerCase}\");");
                }
            }
            sb.AppendLine("            }");
            sb.AppendLine("        });");
            sb.AppendLine("    } else {");
            foreach (var field in fields)
            {
                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;

                if (string.Equals(field.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine($"       initializePopupImageEditor(null, \"imageEditorContainer_{fieldNameLowerCase}\");");
                }
            }
            sb.AppendLine("    }");


            // **Dropdowns & Cascading Dropdowns Generation**
            //           if (table.IsHierarchical)
            //{
            //    sb.AppendLine("    $('#parentId').kendoDropDownTree({");
            //    sb.AppendLine("        placeholder: 'Select Parent',");
            //    sb.AppendLine("        height: 'auto',");
            //    sb.AppendLine($"        dataTextField: 'employeeName',"); // Assuming table.TextField is dynamically defined
            //    sb.AppendLine("        dataValueField: 'id',");
            //    sb.AppendLine("        dataSource: new kendo.data.HierarchicalDataSource({");
            //    sb.AppendLine("            transport: {");
            //    sb.AppendLine("                read: function (options) {");
            //    sb.AppendLine("                    $.ajax({");
            //    sb.AppendLine($"                        url: backendUrl + '{table.Name}/getHierarchy',");
            //    sb.AppendLine("                        type: 'GET',");
            //    sb.AppendLine("                        dataType: 'json',");
            //    sb.AppendLine("                        success: function (response) {");
            //    sb.AppendLine("                            console.log('Hierarchy data:', response);");
            //    sb.AppendLine("                            if (response.length && response[0].children) {");
            //    sb.AppendLine("                                console.log('Children of root node:', response[0].children);");
            //    sb.AppendLine("                            }");
            //    sb.AppendLine("                            options.success(response);");
            //    sb.AppendLine("                        },");
            //    sb.AppendLine("                        error: function (xhr, status, error) {");
            //    sb.AppendLine("                            console.error('Error fetching hierarchy:', error);");
            //    sb.AppendLine("                            options.error(xhr);");
            //    sb.AppendLine("                        }");
            //    sb.AppendLine("                    });");
            //    sb.AppendLine("                }");
            //    sb.AppendLine("            },");
            //    sb.AppendLine("            schema: {");
            //    sb.AppendLine("                model: {");
            //    sb.AppendLine("                    id: 'id',");
            //    sb.AppendLine("                    children: 'children'");
            //    sb.AppendLine("                }");
            //    sb.AppendLine("            }");
            //    sb.AppendLine("        })");
            //    sb.AppendLine("    });");
            //}


            //foreach (var field in fields)
            //{

            //    if (field.TypeId.ToLower() == "colorpicker")
            //    {
            //        var fieldNameLowerCase = char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim().Substring(1);
            //        sb.AppendLine($"        // Handle Kendo ColorPicker for {fieldNameLowerCase}");
            //        sb.AppendLine("        else if ($(this).hasClass('k-colorpicker')) {");
            //        sb.AppendLine($"            var colorPicker = $('#{fieldNameLowerCase}').data('kendoColorPicker');");
            //        sb.AppendLine($"            if (colorPicker && response.{fieldNameLowerCase}) {{");
            //        sb.AppendLine($"                colorPicker.value(response.{fieldNameLowerCase});");
            //        sb.AppendLine("                colorPicker.trigger('change');");
            //        sb.AppendLine("            }");
            //        sb.AppendLine("        }");
            //    }

            //}
            foreach (var field in fields.Where(f =>
        string.Equals(f.TypeId, FieldTypeEnums.Barcode.ToString(), StringComparison.OrdinalIgnoreCase)))
            {
                var fieldName = field.FieldName?.Trim();
                if (string.IsNullOrWhiteSpace(fieldName)) continue;

                var fieldNameLower = fieldName.ToLower();

                // Safely parse barcode type, default to Code128
                if (!Enum.TryParse(field.BarcodeType?.Trim(), true, out BarcodeTypeEnums barcodeTypeEnum))
                    barcodeTypeEnum = BarcodeTypeEnums.Code128;

                // Map enum to Kendo-compatible barcode type name
                string configuredType = barcodeTypeEnum switch
                {
                    BarcodeTypeEnums.Code11 => "code11",
                    BarcodeTypeEnums.Code39 => "code39",
                    BarcodeTypeEnums.Code93 => "code93",
                    BarcodeTypeEnums.Code128 => "code128",
                    BarcodeTypeEnums.QrCode => "QRCODE",
                    _ => "code128"
                };

                sb.AppendLine($"var {fieldNameLower}_barcodeType = '{configuredType}';");

                // --- Validation rules ---
                string pattern = string.Empty;
                string message = string.Empty;
                int? minLength = null;
                int? maxLength = null;

                switch (barcodeTypeEnum)
                {
                    case BarcodeTypeEnums.Code11:
                        pattern = @"/^[0-9\-]+$/";
                        message = "Code11 accepts digits 0–9 and dash (-).";
                        break;

                    case BarcodeTypeEnums.Code39:
                        pattern = @"/^[0-9A-Z\-\.\s\$\+%\/]+$/";
                        message = "Code39 accepts 0–9, A–Z, and (- . $ / + % space).";
                        break;

                    case BarcodeTypeEnums.Code93:
                        pattern = @"/^[0-9A-Z\-\.\s\$\+%\/]+$/";
                        message = "Code93 accepts 0–9, A–Z, and (- . $ / + % space).";
                        break;

                    case BarcodeTypeEnums.Code128:
                        pattern = @"/^[\\x00-\\x7F]{1,80}$/";
                        message = "Code128 accepts 1–80 ASCII characters.";
                        break;

                    case BarcodeTypeEnums.QrCode:
                        message = "QR Code supports up to 4296 characters.";
                        maxLength = 4296;
                        break;

                    default:
                        pattern = @"/^.+$/";
                        message = "Please enter a valid barcode value.";
                        break;
                }

                //  Kendo TextBox
                sb.AppendLine($"$(document).ready(function() {{");
                sb.AppendLine($"    if ($('#{fieldNameLower}').length) $('#{fieldNameLower}').kendoTextBox();");
                sb.AppendLine($"}});");

                // --- Validation Object ---
                sb.AppendLine($"var {fieldNameLower}_validationRule = {{");
                if (!string.IsNullOrEmpty(pattern))
                    sb.AppendLine($"    pattern: {pattern},");
                if (minLength.HasValue)
                    sb.AppendLine($"    minLength: {minLength.Value},");
                if (maxLength.HasValue)
                    sb.AppendLine($"    maxLength: {maxLength.Value},");
                sb.AppendLine($"    message: '{message}'");
                sb.AppendLine("};");

                // --- Validation Function ---
                sb.AppendLine($"function validate_{fieldNameLower}_barcode(value) {{");
                sb.AppendLine("    if (!value || value.trim().length === 0)");
                sb.AppendLine("        return { valid: false, message: 'Barcode value cannot be empty.' };");
                sb.AppendLine("    value = value.trim();");
                sb.AppendLine($"    var rule = {fieldNameLower}_validationRule;");
                sb.AppendLine("    if (rule.pattern && !rule.pattern.test(value)) return { valid: false, message: rule.message };");
                sb.AppendLine("    if (rule.minLength && value.length < rule.minLength) return { valid: false, message: rule.message };");
                sb.AppendLine("    if (rule.maxLength && value.length > rule.maxLength) return { valid: false, message: rule.message };");
                sb.AppendLine("    return { valid: true, message: '' };");
                sb.AppendLine("}");

                // --- Enable/Disable Preview Button ---
                sb.AppendLine($"function update_{fieldNameLower}_btnState() {{");
                sb.AppendLine($"    var $input = $('#{fieldNameLower}');");
                sb.AppendLine($"    var $btn = $('#{fieldNameLower}_previewBtn');");
                sb.AppendLine("    if ($input.length && $btn.length) {");
                sb.AppendLine("        var hasValue = $input.val() && $input.val().trim().length > 0;");
                sb.AppendLine("        $btn.prop('disabled', !hasValue);");
                sb.AppendLine("    }");
                sb.AppendLine("}");
                sb.AppendLine($"$(document).on('input change', '#{fieldNameLower}', function() {{ update_{fieldNameLower}_btnState(); }});");
                sb.AppendLine($"$(document).ready(function() {{ update_{fieldNameLower}_btnState(); }});");

                //  Tooltip for Input & Preview Button
                sb.AppendLine($"$(document).ready(function() {{");
                sb.AppendLine($"    $('#{fieldNameLower}_previewBtn').kendoTooltip({{");
                sb.AppendLine($"        content: 'Preview {field.DisplayName}',");
                sb.AppendLine($"        position: 'top', showOn: 'mouseenter'");
                sb.AppendLine($"    }});");
                sb.AppendLine($"}});");

                // --- Preview Button Click Handler ---
                sb.AppendLine($"$(document).on('click', '#{fieldNameLower}_previewBtn', function() {{");
                sb.AppendLine($"    var value = $('#{fieldNameLower}').val().trim();");
                sb.AppendLine($"    var type = {fieldNameLower}_barcodeType;");
                sb.AppendLine($"    var validation = validate_{fieldNameLower}_barcode(value);");
                //  INVALID VALUE HANDLING
                sb.AppendLine("    if (!validation.valid) {");
                sb.AppendLine($"        var dlg = $('<div></div>').kendoDialog({{");
                sb.AppendLine($"            title: '{field.DisplayName}',");
                sb.AppendLine($"            width: '350px', closable: true, modal: true,");
                sb.AppendLine($"            content: '<div style=\"padding:10px; font-size:14px;\">' + validation.message + '</div>',");
                sb.AppendLine($"            actions: [],");  //  Empty actions array - no buttons
                sb.AppendLine($"            close: function() {{ $('#{fieldNameLower}').val(''); update_{fieldNameLower}_btnState(); }}");
                sb.AppendLine($"        }}).data('kendoDialog');");
                sb.AppendLine("        dlg.open();");
                sb.AppendLine("        return;");
                sb.AppendLine("    }");

                //  If QR or barcode type not configured properly
                sb.AppendLine($"    if (!type) {{");
                sb.AppendLine($"        kendo.alert('Barcode type not configured. Please contact admin.');");
                sb.AppendLine("        return;");
                sb.AppendLine("    }");
                //  Create or reuse Kendo Window with optimized sizing
                sb.AppendLine($"    if (!window['barcodeWindow_{fieldNameLower}']) {{");
                sb.AppendLine($"        window['barcodeWindow_{fieldNameLower}'] = $('<div id=\"barcodePreviewWindow_{fieldNameLower}\"></div>').kendoWindow({{");
                sb.AppendLine($"            title: '{field.DisplayName}',");
                sb.AppendLine("            modal: true,");
                sb.AppendLine("            visible: false,");
                sb.AppendLine("            resizable: false,");
                sb.AppendLine("            actions: ['Close'],");
                sb.AppendLine("            scrollable: false,");
                sb.AppendLine("            width: 340,  //  Smaller, more compact width");
                sb.AppendLine("            height: 280  //  Reduced height for better fit");
                sb.AppendLine("        }).data('kendoWindow');");
                sb.AppendLine("    }");
                sb.AppendLine($"    var wnd = window['barcodeWindow_{fieldNameLower}'];");
                sb.AppendLine($"    var containerId = 'barcodePreview_{fieldNameLower}';");

                //  Clear and create compact container
                sb.AppendLine("    wnd.content('');");
                sb.AppendLine("    wnd.content(\"<div id='\" + containerId + \"' style='display:flex; align-items:center; justify-content:center; width:100%; height:100%; padding:15px; box-sizing:border-box;'></div>\");");
                sb.AppendLine("    wnd.center().open();");

                //  Render with proportional sizing
                sb.AppendLine("    setTimeout(function() {");
                sb.AppendLine("        var $target = $('#' + containerId);");
                sb.AppendLine("        if (type && type.toUpperCase() === 'QRCODE') {");
                sb.AppendLine("            $target.kendoQRCode({");
                sb.AppendLine("                value: value,");
                sb.AppendLine("                size: 180,  //  Compact QR code size");
                sb.AppendLine("                renderAs: 'svg',");
                sb.AppendLine("                errorCorrection: 'M'");
                sb.AppendLine("            });");
                sb.AppendLine("        } else if (type) {");
                sb.AppendLine("            $target.kendoBarcode({");
                sb.AppendLine("                value: value,");
                sb.AppendLine("                type: type,");
                sb.AppendLine("                width: 260,  //  Fits nicely in window");
                sb.AppendLine("                height: 140,  //  Compact barcode height");
                sb.AppendLine("                renderAs: 'svg',");
                sb.AppendLine("                text: { visible: true, font: '12px Arial' }  //  Smaller text");
                sb.AppendLine("            });");
                sb.AppendLine("        } else {");
                sb.AppendLine("            kendo.alert(' Barcode type not configured. Please contact admin.');");
                sb.AppendLine("        }");
                sb.AppendLine("    }, 50);");
                sb.AppendLine("});");


            }


            foreach (var field in fields.Where(f =>
      string.Equals(f.TypeId, FieldTypeEnums.Colorpicker.ToString(), StringComparison.OrdinalIgnoreCase)))

            {
                var fieldName = field.FieldName?.Trim();
                if (string.IsNullOrWhiteSpace(fieldName)) continue;

                //var fieldNameLowerCase = char.ToLower(fieldName[0]) + fieldName[1..];
                var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                var tooltipContent = field.ToolTip?.Trim();

                sb.AppendLine($"// ---- JS Handling for {fieldName} ColorPicker ----");

                // Known color names
                sb.AppendLine($"const knownColors_{fieldNameLowerCase} = {{");
                sb.AppendLine("  \"#000000\": \"Black\", \"#ffffff\": \"White\", \"#ff0000\": \"Red\",");
                sb.AppendLine("  \"#00ff00\": \"Lime\", \"#0000ff\": \"Blue\", \"#ffff00\": \"Yellow\",");
                sb.AppendLine("  \"#00ffff\": \"Cyan\", \"#ff00ff\": \"Magenta\", \"#800000\": \"Maroon\",");
                sb.AppendLine("  \"#5c3838\": \"Brown\", \"#808000\": \"Olive\"");
                sb.AppendLine("};");
                sb.AppendLine($"   var {fieldNameLowerCase}Color = $(\"#{fieldNameLowerCase}\").kendoColorPicker().data(\"kendoColorPicker\");");
                if (!string.IsNullOrEmpty(tooltipContent))
                {
                    sb.AppendLine($"   {fieldNameLowerCase}Color.wrapper.kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                }

                // Function specific to this field
                sb.AppendLine($"function getColorName_{fieldNameLowerCase}(hex) {{");
                sb.AppendLine($"  return knownColors_{fieldNameLowerCase}[hex.toLowerCase()] || hex.toUpperCase();");
                sb.AppendLine("}");

                // Init on page load
                sb.AppendLine("$(function () {");
                sb.AppendLine($"  var formId = $('#formId').val();"); // Hidden field in your form
                sb.AppendLine($"  var $picker = $('#{fieldNameLowerCase}');");
                sb.AppendLine($"  var $nameInput = $('#{fieldNameLowerCase}Name');");

                // ---- NEW RECORD ----
                sb.AppendLine($"  if (!formId) {{");
                sb.AppendLine($"      // Leave picker empty for new record");
                sb.AppendLine($"      $picker.val('');");
                sb.AppendLine($"      $nameInput.val('');");
                sb.AppendLine($"  }} else {{"); // EDIT MODE
                sb.AppendLine($"      // If there is an existing value, trigger change to fill name");
                sb.AppendLine($"      var existingColor = $picker.val();");
                sb.AppendLine($"      if (existingColor) {{ $nameInput.val(getColorName_{fieldNameLowerCase}(existingColor)); }}");
                sb.AppendLine($"  }}");

                // Change event (only update if user picks a color)
                sb.AppendLine($"  $picker.on('input change', function () {{");
                sb.AppendLine($"      var hex = $(this).val();");
                sb.AppendLine($"      if (hex) {{");
                sb.AppendLine($"          $nameInput.val(getColorName_{fieldNameLowerCase}(hex));");
                sb.AppendLine($"      }} else {{");
                sb.AppendLine($"          $nameInput.val('');");
                sb.AppendLine($"      }}");
                sb.AppendLine("  });");

                sb.AppendLine("});");
                sb.AppendLine();

            }



            //foreach (var field in fields)
            //{
            //    if (field.TypeId.ToLower() == "varbinary")
            //    {
            //        var fieldNameLowerCase = char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim().Substring(1);

            //        sb.AppendLine($"        // Handle download link for varbinary field {fieldNameLowerCase}");
            //        sb.AppendLine($"        else if ($('#{fieldNameLowerCase}Download').length > 0) {{");
            //        sb.AppendLine($"            if (response.{fieldNameLowerCase}) {{");
            //        sb.AppendLine($"                var byteCharacters = atob(response.{fieldNameLowerCase});");
            //        sb.AppendLine($"                var byteNumbers = new Array(byteCharacters.length);");
            //        sb.AppendLine($"                for (var i = 0; i < byteCharacters.length; i++) {{ byteNumbers[i] = byteCharacters.charCodeAt(i); }}");
            //        sb.AppendLine($"                var byteArray = new Uint8Array(byteNumbers);");
            //        sb.AppendLine($"                var blob = new Blob([byteArray], {{ type: 'application/octet-stream' }});");
            //        sb.AppendLine($"                var url = URL.createObjectURL(blob);");
            //        sb.AppendLine($"                $('#{fieldNameLowerCase}Download').attr('href', url).attr('download', '{fieldNameLowerCase}.bin');");
            //        sb.AppendLine("            }");
            //        sb.AppendLine("        }");
            //    }
            //}


            sb.AppendLine("let currentParentId = null;");
            sb.AppendLine("var isEditMode = !!FormId;");

            foreach (var field in fields)
            {
                if (string.Equals(field.TypeId, FieldTypeEnums.Richtexteditor.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    //  var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                    var tooltipContent = field.ToolTip?.Trim();


                    // Tooltip for the RichTextEditor button or field
                    if (!string.IsNullOrEmpty(tooltipContent))
                    {
                        sb.AppendLine($"$(\"#{fieldNameLowerCase}editTextBtn\").kendoTooltip({{");
                        sb.AppendLine($"    content: \"{tooltipContent}\",");
                        sb.AppendLine("    position: \"top\",");
                        sb.AppendLine("    showOn: \"mouseenter\"");

                        sb.AppendLine("});");
                        sb.AppendLine("");
                    }
                    sb.AppendLine($"let {fieldNameLowerCase}textEditorWindow;");
                    sb.AppendLine("$(document).ready(function () {");

                    sb.AppendLine($"function reinitializeTextEditorWindow() {{");
                    sb.AppendLine($"    var container = $(\"#{fieldNameLowerCase}textEditorWindow\");");
                    sb.AppendLine("    var existing = container.data(\"kendoWindow\");");
                    sb.AppendLine("    if (existing) existing.destroy(); // remove old instance");
                    sb.AppendLine($"    {fieldNameLowerCase}textEditorWindow = container.kendoWindow({{");
                    sb.AppendLine("        width: \"80%\",");
                    sb.AppendLine("        height: \"80%\",");
                    sb.AppendLine("        modal: true,");
                    sb.AppendLine("        actions: [\"Maximize\", \"Close\"],");
                    sb.AppendLine($"        title: \"{field.DisplayName}\",");
                    sb.AppendLine("        visible: false,");
                    sb.AppendLine("        activate: function() {");
                    sb.AppendLine($"            {fieldNameLowerCase}resizeEditor();");
                    sb.AppendLine("        },");
                    sb.AppendLine("        resize: function() {");
                    sb.AppendLine($"            {fieldNameLowerCase}resizeEditor();");
                    sb.AppendLine("        }");
                    sb.AppendLine("    }).data(\"kendoWindow\");");
                    sb.AppendLine("}");
                    sb.AppendLine("");
                    sb.AppendLine("reinitializeTextEditorWindow();");


                    sb.AppendLine($"function {fieldNameLowerCase}resizeEditor() {{");
                    sb.AppendLine("    var toolbarHeight = $(\".k-editor-toolbar\").outerHeight() || 50;");
                    sb.AppendLine($"    var containerHeight = $(\"#{fieldNameLowerCase}textEditorWindow\").height() - toolbarHeight - 20;");
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}textEditorContainer\").height(containerHeight);");
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}\").closest(\".k-editor\").height(containerHeight);");
                    sb.AppendLine("}");

                    sb.AppendLine("    // Open popup on button click");
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}editTextBtn\").click(function () {{");
                    sb.AppendLine($"        const currentText = $(\"#{fieldNameLowerCase}RichTextContent\").val(); // hidden input or somewhere you store text");
                    sb.AppendLine($"        {fieldNameLowerCase}textEditorWindow.center().open();");
                    sb.AppendLine($"        {fieldNameLowerCase}initializePopupTextEditor(currentText || \"\");");
                    sb.AppendLine("    });");
                    sb.AppendLine("");

                    sb.AppendLine("    // Initialize Add button (blue)");
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}btnAddText\").kendoButton({{");
                    sb.AppendLine("        icon: \"plus\",");
                    sb.AppendLine("        themeColor: \"primary\"");
                    sb.AppendLine("    }).css({");
                    //sb.AppendLine("        \"background-color\": \"#2E37A7\",");
                    sb.AppendLine("        \"border-color\": \"transparent\",");
                    //sb.AppendLine("        \"color\": \"#fff\",");
                    sb.AppendLine("        \"left\": \"-12px\"");
                    sb.AppendLine("    });");
                    sb.AppendLine("");
                    sb.AppendLine("    // Add button click");
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}btnAddText\").off(\"click\").on(\"click\", function () {{");
                    sb.AppendLine($"        const editor = $(\"#{fieldNameLowerCase}\").data(\"kendoEditor\");");
                    sb.AppendLine($"        const hiddenInput = $(\"#{fieldNameLowerCase}RichTextContent\");");
                    sb.AppendLine();
                    sb.AppendLine("        if (editor) {");
                    sb.AppendLine("            const htmlContent = editor.value().trim();");
                    sb.AppendLine();
                    sb.AppendLine("            // handle empty case");
                    sb.AppendLine("            if (htmlContent === \"\" || htmlContent === \"<p>&nbsp;</p>\") {");
                    sb.AppendLine("                fnShowNotification(\"Text cannot be empty.\", \"error\");");
                    sb.AppendLine("                hiddenInput.val(\"\").trigger(\"change\");");
                    sb.AppendLine("                // re-validate explicitly");
                    sb.AppendLine("                validator.validateInput(hiddenInput);");
                    sb.AppendLine("                return;");
                    sb.AppendLine("            }");
                    sb.AppendLine();
                    sb.AppendLine("            // Save HTML to hidden input");
                    sb.AppendLine("            hiddenInput.val(htmlContent).trigger(\"change\");");
                    sb.AppendLine();
                    sb.AppendLine("            // Explicitly re-validate hidden input");
                    sb.AppendLine("            const valid = validator.validateInput(hiddenInput);");
                    sb.AppendLine();
                    sb.AppendLine("            // Optional: remove leftover error styling if valid");
                    sb.AppendLine("            if (valid) {");
                    sb.AppendLine("                hiddenInput.removeClass(\"k-invalid\");");
                    sb.AppendLine("                $(`[data-for='${hiddenInput.attr(\"name\")}']`).remove(); // removes error msg span");
                    sb.AppendLine("            }");
                    sb.AppendLine();
                    sb.AppendLine("            // Close the editor");
                    sb.AppendLine($"            {fieldNameLowerCase}textEditorWindow.close();");
                    sb.AppendLine("        }");
                    sb.AppendLine("    });");

                    sb.AppendLine("");
                    sb.AppendLine($"    $(\"#{fieldNameLowerCase}editTextBtn\").click(function () {{");
                    sb.AppendLine($"        {fieldNameLowerCase}openRichTextEditor();");
                    sb.AppendLine("    });");
                    sb.AppendLine("});");
                    sb.AppendLine("");
                    sb.AppendLine($"function {fieldNameLowerCase}openRichTextEditor() {{");
                    sb.AppendLine($"    const existingContent = $(\"#{fieldNameLowerCase}RichTextContent\").val();");
                    sb.AppendLine($"   {fieldNameLowerCase}initializePopupTextEditor(existingContent || \"\");");
                    sb.AppendLine($"    {fieldNameLowerCase}textEditorWindow.center().open();");
                    sb.AppendLine("}");
                    sb.AppendLine("");
                    sb.AppendLine($"function  {fieldNameLowerCase}initializePopupTextEditor(content) {{");
                    sb.AppendLine($"    const container = $(\"#{fieldNameLowerCase}textEditorContainer\");");
                    sb.AppendLine($"    const existingEditor = $(\"#{fieldNameLowerCase}\").data(\"kendoEditor\");");
                    sb.AppendLine("    if (existingEditor) {");
                    sb.AppendLine("        existingEditor.destroy();");
                    sb.AppendLine("        container.empty();");
                    sb.AppendLine($"        container.append('<textarea id=\"{fieldNameLowerCase}\"></textarea>');");
                    sb.AppendLine("    }");
                    sb.AppendLine("       //Initialize RichTextEditor");
                    sb.AppendLine($"  $(\"#{fieldNameLowerCase}\").kendoEditor(");
                    sb.Append("       {");
                    sb.AppendLine("      stylesheets: [\"../content/shared/styles/editor.css\"],");
                    sb.AppendLine("      tools: [");
                    sb.AppendLine("          \"undo\", \"redo\", { name: \"separator1\", type: \"separator\" },");
                    sb.AppendLine("          {");
                    sb.AppendLine("              name: \"fontName\",");
                    sb.AppendLine("              items: [");
                    sb.AppendLine("                  { text: \"Andale Mono\", value: '\"Andale Mono\"' },");
                    sb.AppendLine("                  { text: \"Arial\", value: \"Arial\" },");
                    sb.AppendLine("                  { text: \"Arial Black\", value: '\"Arial Black\"' },");
                    sb.AppendLine("                  { text: \"Book Antiqua\", value: '\"Book Antiqua\"' },");
                    sb.AppendLine("                  { text: \"Comic Sans MS\", value: '\"Comic Sans MS\"' },");
                    sb.AppendLine("                  { text: \"Courier New\", value: '\"Courier New\"' },");
                    sb.AppendLine("                  { text: \"Georgia\", value: \"Georgia\" },");
                    sb.AppendLine("                  { text: \"Helvetica\", value: \"Helvetica\" },");
                    sb.AppendLine("                  { text: \"Impact\", value: \"Impact\" },");
                    sb.AppendLine("                  { text: \"Symbol\", value: \"Symbol\" },");
                    sb.AppendLine("                  { text: \"Tahoma\", value: \"Tahoma\" },");
                    sb.AppendLine("                  { text: \"Terminal\", value: \"Terminal\" },");
                    sb.AppendLine("                  { text: \"Times New Roman\", value: '\"Times New Roman\"' },");
                    sb.AppendLine("                  { text: \"Trebuchet MS\", value: '\"Trebuchet MS\"' },");
                    sb.AppendLine("                  { text: \"Verdana\", value: \"Verdana\" },");
                    sb.AppendLine("              ],");
                    sb.AppendLine("          },");
                    sb.AppendLine("          \"fontSize\", \"bold\", \"italic\", \"underline\",");
                    sb.AppendLine("          \"backColor\", \"foreColor\",");
                    sb.AppendLine("          { name: \"separator2\", type: \"separator\" },");
                    sb.AppendLine("          \"insertUnorderedList\", \"justifyLeft\", \"justifyCenter\", \"justifyRight\",");
                    sb.AppendLine("          { name: \"separator3\", type: \"separator\" },");
                    sb.AppendLine("          \"formatting\",");
                    sb.AppendLine("          { name: \"separator4\", type: \"separator\" },");
                    sb.AppendLine("          \"createLink\", \"unlink\", \"insertImage\",");
                    sb.AppendLine("          { name: \"separator5\", type: \"separator\" },");
                    sb.AppendLine("          \"tableWizard\", \"tableProperties\", \"tableCellProperties\", \"createTable\",");
                    sb.AppendLine("          \"addRowAbove\", \"addRowBelow\", \"addColumnLeft\", \"addColumnRight\",");
                    sb.AppendLine("          \"deleteRow\", \"deleteColumn\", \"mergeCellsHorizontally\",");
                    sb.AppendLine("          \"mergeCellsVertically\", \"splitCellHorizontally\", \"splitCellVertically\",");
                    sb.AppendLine("          \"tableAlignLeft\", \"tableAlignCenter\", \"tableAlignRight\"");
                    sb.AppendLine("      ],");
                    sb.AppendLine("  });");
                    sb.AppendLine($"  const editor = $(\"#{fieldNameLowerCase}\").data(\"kendoEditor\");");
                    sb.AppendLine("  if (editor && content) {");
                    sb.AppendLine("      editor.value(content);   // use HTML, don’t strip");
                    sb.AppendLine("  }");

                    sb.AppendLine("    }");
                }

            }

            //sb.AppendLine("let currentParentId = null;");
            foreach (var field in fields)
            {

                var defaultValue = !string.IsNullOrWhiteSpace(field.DefaultValue)
                 ? $" value='{System.Net.WebUtility.HtmlEncode(field.DefaultValue)}'"
                 : string.Empty;

                if (field != null)
                {
                    if (string.Equals(field.TypeId, FieldTypeEnums.Hyperlink.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                        //var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                        var tooltipContent = string.IsNullOrWhiteSpace(field.ToolTip) ? "Click to open link" : field.ToolTip?.Trim() ?? "";

                        sb.AppendLine($"                $(\"#{fieldNameLowerCase}\").kendoTooltip({{");
                        sb.AppendLine($"                    content: \"{tooltipContent}\",");
                        sb.AppendLine("                    position: \"top\"");
                        sb.AppendLine("                });");
                        sb.AppendLine($"   $(\"#{fieldNameLowerCase}\").kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                    }


                    if (string.Equals(field.TypeId, FieldTypeEnums.DropDown.ToString(), StringComparison.OrdinalIgnoreCase))
                    {

                        // var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                        var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;
                        //  var textFieldLowerCase = char.ToLower((field.TextFieldName?.Trim() ?? "")[0]) + (field.TextFieldName?.Trim() ?? "")[1..];
                        var textFieldLowerCase = field.TextFieldName?.Trim().ToLower() ?? string.Empty;
                        bool isCascading = await IsCascadingFieldAsync(field.FieldId, field.FormId, configConnectionString);
                        TableModel? sourcetable = await GetTableData(field.SourceTableId, configConnectionString);
                        if (sourcetable != null && !isCascading && sourcetable.IsHierarchical && string.IsNullOrEmpty(field.ParentFieldName))
                        {
                            sb.AppendLine($"$('#{fieldNameLowerCase}').kendoDropDownTree({{");
                            sb.AppendLine("    placeholder: 'Select Parent',");
                            sb.AppendLine("    height: 'auto',");
                            sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
                            sb.AppendLine("    dataValueField: 'id',");
                            sb.AppendLine("    dataSource: new kendo.data.HierarchicalDataSource({");
                            sb.AppendLine($"   sort: {{ field: \"{textFieldLowerCase}\", dir: 'asc' }},");
                            sb.AppendLine("        transport: {");
                            sb.AppendLine("            read: function (options) {");
                            sb.AppendLine("                $.ajax({");
                            // sb.AppendLine($"                    url: backendUrl + '/{field.SourceTableName}',");
                            sb.AppendLine($"                    url: backendUrl + '/{field.SourceTableName?.ToLower() ?? ""}/hierarchy',");
                            sb.AppendLine("                    type: 'GET',");
                            sb.AppendLine("                    dataType: 'json',");
                            sb.AppendLine("                    success: function (response) {");
                            sb.AppendLine("                        options.success(response);");
                            sb.AppendLine($"                        $('#{fieldNameLowerCase}').data('kendoDropDownTree').value('{defaultValue}');");
                            sb.AppendLine("                    },");
                            sb.AppendLine("                    error: function (xhr, status, error) {");
                            sb.AppendLine("                        console.error('Error fetching hierarchy:', error);");
                            sb.AppendLine("                        options.error(xhr);");
                            sb.AppendLine("                    }");
                            sb.AppendLine("                });");
                            sb.AppendLine("            }");
                            sb.AppendLine("        },");
                            sb.AppendLine("        schema: {");
                            sb.AppendLine("            model: { id: 'id', children: 'items' }");
                            sb.AppendLine("        }");
                            sb.AppendLine("    })");
                            sb.AppendLine("});");
                        }

                        if (field.IsMultiColumn == true && string.IsNullOrEmpty(field.ParentFieldName))
                        {
                            sb.AppendLine($"$('#{fieldNameLowerCase}').kendoMultiColumnComboBox({{");
                            sb.AppendLine("    placeholder: '--Select--',");
                            sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
                            sb.AppendLine("    dataValueField: 'id',");

                            // Determine filter type safely
                            var filterType = field.FilterOption?.ToLowerInvariant();
                            var isFilteringEnabled = !string.IsNullOrEmpty(filterType) &&
                                                     (filterType == "startswith" || filterType == "contains");

                            // ✅ Only include filter line if user selected a valid filter type
                            if (isFilteringEnabled)
                                sb.AppendLine($"    filter: '{filterType}',");

                            // ✅ Include filterFields only if filter type is valid
                            if (isFilteringEnabled && field.MultiColumnFieldNames != null && field.MultiColumnFieldNames.Count > 0)
                            {
                                var filterFields = string.Join(", ", field.MultiColumnFieldNames
                                    .Select(f => $"'{f.SourceFieldName?.Trim().ToLower()}'"));
                                sb.AppendLine($"    filterFields: [{filterFields}],");
                            }

                            sb.AppendLine("    minLength: 1,");
                            sb.AppendLine("    autoBind: true,");
                            sb.AppendLine("    suggest: true,");
                            sb.AppendLine("    columns: [");

                            // ✅ Generate dynamic columns
                            if (field.MultiColumnFieldNames != null && field.MultiColumnFieldNames.Count > 0)
                            {
                                for (int i = 0; i < field.MultiColumnFieldNames.Count; i++)
                                {
                                    var column = field.MultiColumnFieldNames[i];
                                    var comma = i < field.MultiColumnFieldNames.Count - 1 ? "," : "";

                                    var fieldNameCamelCase = column.SourceFieldName?.Trim().ToLower() ?? string.Empty;
                                    var formattedTitle = column.SourceDisplayFieldName;

                                    if (string.IsNullOrWhiteSpace(formattedTitle))
                                    {
                                        formattedTitle = System.Text.RegularExpressions.Regex
                                            .Replace(column.SourceFieldName ?? string.Empty, "(\\B[A-Z])", " $1")
                                            .Trim();

                                        if (formattedTitle.EndsWith(" Data", StringComparison.OrdinalIgnoreCase))
                                            formattedTitle = formattedTitle[..^5].Trim();
                                    }

                                    sb.AppendLine($"        {{ field: '{fieldNameCamelCase}', title: '{formattedTitle}' }}{comma}");
                                }
                            }
                            else
                            {
                                sb.AppendLine("        { field: 'id', title: 'ID' },");
                                sb.AppendLine("        { field: 'name', title: 'Name' }");
                            }

                            sb.AppendLine("    ],");
                            sb.AppendLine("    dataSource: {");

                            // ✅ Sorting on first field if available
                            var firstSortField = field.MultiColumnFieldNames?.FirstOrDefault()?.SourceFieldName?.ToLower();
                            if (!string.IsNullOrEmpty(firstSortField))
                                sb.AppendLine($"        sort: {{ field: '{firstSortField}', dir: 'asc' }},");
                            else
                                sb.AppendLine("        sort: { field: 'id', dir: 'asc' },");

                            sb.AppendLine("        transport: {");
                            sb.AppendLine("            read: function (options) {");

                            sb.AppendLine("                $.ajax({");
                            sb.AppendLine($"                    url: backendUrl + '/{field.SourceTableName?.ToLower() ?? ""}',");
                            sb.AppendLine("                    type: 'GET',");
                            sb.AppendLine("                    dataType: 'json',");
                            sb.AppendLine("                    success: function (response) {");
                            sb.AppendLine("                        options.success(response);");
                            sb.AppendLine($"                        $('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').value('{field.DefaultValue}');");
                            sb.AppendLine("                    },");
                            sb.AppendLine("                    error: function (xhr, status, error) {");
                            sb.AppendLine("                        console.error('Error fetching data:', error);");
                            sb.AppendLine("                        options.error(xhr);");
                            sb.AppendLine("                    }");
                            sb.AppendLine("                });");
                            sb.AppendLine("            }");
                            sb.AppendLine("        }");
                            sb.AppendLine("    },");

                            sb.AppendLine("    noDataTemplate: 'No matching records found'");
                            sb.AppendLine("});");

                            // ✅ Set readonly based on filter type
                            if (isFilteringEnabled)
                                sb.AppendLine($"$('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').input.attr('readonly', false);");
                            else
                                sb.AppendLine($"$('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').input.attr('readonly', true);");
                        }
                        if (field != null && sourcetable != null)
                        {
                            // Parent Dropdown(StudentID)
                            if (isCascading && string.IsNullOrEmpty(field.ParentFieldName) && field.IsMultiColumn == false || !isCascading && string.IsNullOrEmpty(field.ParentFieldName) && field.IsMultiColumn == false && !sourcetable.IsHierarchical)
                            {
                                if (field.IsLazyLoaded)
                                {
                                    // Determine the filter type
                                    var filterType = field.FilterOption?.ToLower();

                                    sb.AppendLine($"  $('#{fieldNameLowerCase}').kendoDropDownList({{");
                                    sb.AppendLine($"    dataTextField: \"{textFieldLowerCase}\",");
                                    sb.AppendLine("    dataValueField: \"id\",");

                                    // Apply filter only if specified
                                    if (!string.IsNullOrEmpty(filterType) && (filterType == "startswith" || filterType == "contains"))
                                        sb.AppendLine($"    filter: \"{filterType}\",");

                                    sb.AppendLine("    virtual: {");
                                    sb.AppendLine("        itemHeight: 26,");
                                    sb.AppendLine("        valueMapper: function (options) {");
                                    sb.AppendLine("            $.ajax({");
                                    sb.AppendLine("                url: backendUrl + \"/ValueMapper\",");
                                    sb.AppendLine("                type: \"POST\",");
                                    sb.AppendLine("                contentType: \"application/json\",");
                                    sb.AppendLine("                dataType: \"json\",");
                                    sb.AppendLine("                data: JSON.stringify({");
                                    sb.AppendLine("                    selectedIds: $.isArray(options.value) ? options.value : [options.value],");
                                    sb.AppendLine($"                    sourceTableName: \"{field.SourceTableName?.ToLower() ?? ""}\"");
                                    sb.AppendLine("                }),");
                                    sb.AppendLine("                success: function (data) {");
                                    sb.AppendLine("                    const mappedIds = Object.keys(data).map(k => data[k]);");
                                    sb.AppendLine("                    options.success(mappedIds);");
                                    sb.AppendLine("                },");
                                    sb.AppendLine("                error: function () { options.success([]); }");
                                    sb.AppendLine("            });");
                                    sb.AppendLine("        }");
                                    sb.AppendLine("    },");
                                    sb.AppendLine("    height: 300,");
                                    sb.AppendLine("    dataSource: {");
                                    sb.AppendLine("        transport: {");
                                    sb.AppendLine("            read: function (options) {");
                                    sb.AppendLine("                const filterValue = options.data.filter?.filters?.[0]?.value || '';");

                                    sb.AppendLine("                const requestPayload = {");
                                    sb.AppendLine("                    skip: options.data.skip || 0,");
                                    sb.AppendLine("                    take: options.data.take || 20,");

                                    // Handle filtering conditionally
                                    if (!string.IsNullOrEmpty(filterType) && (filterType == "startswith" || filterType == "contains"))
                                    {
                                        sb.AppendLine("                    filter: {");
                                        sb.AppendLine("                        logic: \"and\",");
                                        sb.AppendLine("                        filters: [{");
                                        sb.AppendLine($"                            field: \"{textFieldLowerCase}\",");
                                        sb.AppendLine($"                            operator: \"{filterType}\",");
                                        sb.AppendLine("                            value: filterValue");
                                        sb.AppendLine("                        }]");
                                        sb.AppendLine("                    }");
                                    }
                                    else
                                    {
                                        // No filtering, just basic pagination
                                        sb.AppendLine("                    filter: null");
                                    }

                                    sb.AppendLine("                };");

                                    sb.AppendLine("                $.ajax({");
                                    sb.AppendLine($"                    url: backendUrl + '/{field.SourceTableName?.ToLower() ?? ""}s',");
                                    sb.AppendLine("                    type: \"POST\",");
                                    sb.AppendLine("                    contentType: \"application/json\",");
                                    sb.AppendLine("                    dataType: \"json\",");
                                    sb.AppendLine("                    data: JSON.stringify(requestPayload),");
                                    sb.AppendLine("                    success: function (response) {");
                                    sb.AppendLine("                        if ((options.data.skip || 0) === 0) {");
                                    sb.AppendLine($"                            response.data.unshift({{ id: \"\", {textFieldLowerCase}: \"--select--\" }});");
                                    sb.AppendLine("                            response.total += 1;");
                                    sb.AppendLine("                        }");
                                    sb.AppendLine("                        options.success({ data: response.data, total: response.total });");
                                    sb.AppendLine("                    },");
                                    sb.AppendLine("                    error: function (xhr) {");
                                    sb.AppendLine("                        options.success({ data: [{ id: '', " + textFieldLowerCase + ": '--select--' }], total: 1 });");
                                    sb.AppendLine("                        options.error(xhr);");
                                    sb.AppendLine("                    }");
                                    sb.AppendLine("                });");
                                    sb.AppendLine("            }");
                                    sb.AppendLine("        },");
                                    sb.AppendLine("        schema: {");
                                    sb.AppendLine("            data: response => response.data || [],");
                                    sb.AppendLine("            total: response => response.total || 0");
                                    sb.AppendLine("        },");
                                    sb.AppendLine("        serverPaging: true,");
                                    sb.AppendLine("        serverFiltering: true,");
                                    sb.AppendLine("        serverSorting: true");
                                    sb.AppendLine("    }");
                                    sb.AppendLine("  });");
                                }
                                else
                                {

                                    sb.AppendLine($"$('#{fieldNameLowerCase}').kendoDropDownList({{");
                                    sb.AppendLine("    optionLabel: '-- Select --',");
                                    sb.AppendLine($"    dataTextField: '{textFieldLowerCase}',");
                                    sb.AppendLine("    dataValueField: \"id\",");

                                    if (field?.FilterOption?.ToLower() == "startswith" || field?.FilterOption?.ToLower() == "contains")
                                    {
                                        sb.AppendLine($"filter: '{field.FilterOption.ToLower()}',");
                                    }
                                    //else
                                    //{
                                    //    sb.AppendLine("filter: NULL,");  // for null or other values
                                    //}
                                    sb.AppendLine("    dataSource: {");
                                    sb.AppendLine($"   sort: {{ field: \"{textFieldLowerCase}\", dir: 'asc' }},");
                                    sb.AppendLine("        transport: {");
                                    sb.AppendLine("            read: function (options) {");
                                    sb.AppendLine($"                $.ajax({{");
                                    sb.AppendLine($"                    url: backendUrl + '/{field?.SourceTableName?.ToLower() ?? ""}',"); // Adjust URL to get Student IDs
                                    sb.AppendLine("                    type: 'GET',");
                                    sb.AppendLine("                    dataType: 'json',");
                                    sb.AppendLine("                    success: function (response) {");
                                    sb.AppendLine($"                    response.unshift({{ id: \"\", {textFieldLowerCase}: \"-- Select --\" }});");
                                    sb.AppendLine("                        options.success(response);");
                                    sb.AppendLine($" $('#{fieldNameLowerCase}').data('kendoDropDownList').value('{field?.DefaultValue}'); ");

                                    if (!string.IsNullOrWhiteSpace(field.ToolTip))
                                    {
                                        sb.AppendLine($"var ddl_{fieldNameLowerCase} = $('#{fieldNameLowerCase}').data('kendoDropDownList');");
                                        sb.AppendLine($"if (ddl_{fieldNameLowerCase} && ddl_{fieldNameLowerCase}.wrapper && !ddl_{fieldNameLowerCase}.wrapper.data('kendoTooltip')) {{");
                                        sb.AppendLine($"    ddl_{fieldNameLowerCase}.wrapper.kendoTooltip({{");
                                        sb.AppendLine($"        content: \"{field.ToolTip.Replace("\"", "\\\"")}\",");
                                        sb.AppendLine("        position: 'top',");
                                        sb.AppendLine("        showOn: 'mouseenter'");
                                        sb.AppendLine("    });");
                                        sb.AppendLine("}");
                                    }

                                    sb.AppendLine("                    },");
                                    sb.AppendLine("                    error: function (xhr, status, error) {");
                                    sb.AppendLine("                        console.error('Error fetching data:', error);");
                                    sb.AppendLine("                        options.error(xhr);");
                                    sb.AppendLine("                    }");
                                    sb.AppendLine("                });");
                                    sb.AppendLine("            }");
                                    sb.AppendLine("        }");
                                    sb.AppendLine("    }");
                                    sb.AppendLine("});");
                                }
                            }


                        }

                        // Child Dropdown (LastName) - Cascading based on selected StudentID
                        if (!string.IsNullOrEmpty(field?.ParentFieldName))
                        {
                            //var fieldNameLowerCase1 = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];

                            //var parentFieldNameLowerCase = char.ToLower(field.ParentFieldName.Trim()[0]) + (field.ParentFieldName?.Trim() ?? "")[1..];
                            var parentFieldNameLowerCase = field.ParentFieldName?.Trim().ToLower();
                            var fieldLowerCase = (field.FieldName?.Trim() ?? "").ToLower();
                            // var textFieldLowerCase1 = char.ToLower((field.TextFieldName?.Trim() ?? "")[0]) + (field.TextFieldName?.Trim() ?? "")[1..];
                            var textFieldLower = field.TextFieldName?.Trim().ToLower() ?? string.Empty;
                            if (field.IsMultiColumn == true)
                            {
                                sb.AppendLine($"$('#{fieldNameLowerCase}').kendoMultiColumnComboBox({{");
                            }
                            else
                            {
                                sb.AppendLine($"$('#{fieldNameLowerCase}').kendoDropDownList({{");
                            }
                            if (field.IsLazyLoaded == true)
                            {
                                sb.AppendLine($"    dataTextField: '{textFieldLower}',");
                                sb.AppendLine("    dataValueField: \"id\",");
                                sb.AppendLine("    filter: \"contains\",");
                                // sb.AppendLine("    value: 10,");
                                sb.AppendLine("    virtual: {");
                                sb.AppendLine("        itemHeight: 26,");
                                sb.AppendLine("        valueMapper: function (options) {");
                                sb.AppendLine("            $.ajax({");
                                sb.AppendLine("                url: backendUrl+ \"/ValueMapper\",");
                                sb.AppendLine("                type: \"POST\",");
                                sb.AppendLine("                contentType: \"application/json\",");
                                sb.AppendLine("                dataType: \"json\",");
                                sb.AppendLine("                data: JSON.stringify({");
                                sb.AppendLine("                    selectedIds: $.isArray(options.value) ? options.value : [options.value],");
                                sb.AppendLine($"                    sourceTableName: \"{field.SourceTableName?.ToLower() ?? ""}\"");
                                sb.AppendLine("                }),");
                                sb.AppendLine("                success: function (data) {");
                                sb.AppendLine("                    const mappedIds = Object.keys(data).map(k => data[k]);");
                                sb.AppendLine("                    options.success(mappedIds);");
                                if (field.IsMultiColumn == true)
                                {
                                    sb.AppendLine($"$('#{fieldNameLowerCase}').data('kendoMultiColumnComboBox').value('{defaultValue}');");
                                }
                                else
                                {
                                    sb.AppendLine($"$('#{fieldNameLowerCase}').data('kendoDropDownList').value('{defaultValue}');");
                                }
                                sb.AppendLine("                },");
                                sb.AppendLine("                error: function (xhr) {");
                                sb.AppendLine("                    console.error(\"ValueMapper Error:\", xhr);");
                                sb.AppendLine("                    options.success([]);");
                                sb.AppendLine("                }");
                                sb.AppendLine("            });");
                                sb.AppendLine("        }");
                                sb.AppendLine("    },");
                                // sb.AppendLine("    height: 300,");
                                sb.AppendLine("    dataSource: {");
                                sb.AppendLine("        transport: {");
                                sb.AppendLine("            read: function (options) {");
                                sb.AppendLine("                console.log(\"location-\", options);");
                                // Get parentId if passed, or use saved value
                                sb.AppendLine("if (options.data && options.data.parentId)");
                                sb.AppendLine("{");

                                sb.AppendLine("currentParentId = options.data.parentId;");
                                sb.AppendLine("}");

                                sb.AppendLine("if (!currentParentId)");
                                sb.AppendLine("{");

                                sb.AppendLine("options.success([]); // return empty result if parentId not set");
                                sb.AppendLine(" return;");
                                sb.AppendLine("}");

                                sb.AppendLine("                $.ajax({");
                                sb.AppendLine($"                    url: backendUrl+'/{field.TableName?.ToLower() ?? ""}/by-{field.ParentFieldName?.ToLower() ?? ""}/' + currentParentId + \"?skip=\" + (options.data.skip || 0) + \"&take=\" + (options.data.take || 20),");
                                sb.AppendLine("                    type: \"GET\",");
                                sb.AppendLine("                    contentType: \"application/json\",");
                                sb.AppendLine("                    dataType: \"json\",");
                                sb.AppendLine("                    success: function (response) {");
                                sb.AppendLine("                        options.success(response);");
                                sb.AppendLine("                    },");
                                sb.AppendLine("                    error: function (xhr) {");
                                sb.AppendLine("                        console.error(\"Data Read Error:\", xhr);");
                                sb.AppendLine("                        options.error(xhr);");
                                sb.AppendLine("                    }");
                                sb.AppendLine("                });");
                                sb.AppendLine("            }");
                                sb.AppendLine("        },");
                                sb.AppendLine("        schema: {");

                                sb.AppendLine("           data: function(response) {");
                                sb.AppendLine("           return response.data || [];");
                                sb.AppendLine("            },");

                                sb.AppendLine("          total: function(response) {");
                                sb.AppendLine("          return response.totalCount || 0;");
                                sb.AppendLine("            }");
                                sb.AppendLine("        },");
                                sb.AppendLine("        pageSize: 20,");
                                sb.AppendLine("        serverPaging: true,");
                                sb.AppendLine("        serverFiltering: true,");
                                sb.AppendLine("        serverSorting: true");
                                sb.AppendLine("    }");
                                sb.AppendLine("});");
                            }
                            else
                            {

                                sb.AppendLine("    optionLabel: '-- Select --',");
                                sb.AppendLine($"    dataTextField: '{textFieldLower}',");
                                sb.AppendLine("    dataValueField: 'id',");

                                if (field?.FilterOption == "startswith" || field?.FilterOption == "contains")
                                {
                                    sb.AppendLine($"filter: '{field.FilterOption}',");
                                }
                                //else
                                //{
                                //    sb.AppendLine("filter: NULL,");  // for null or other values
                                //}
                                sb.AppendLine("    autoBind: true,");
                                sb.AppendLine("    enable: true,");
                                if (field?.IsMultiColumn == true)
                                {
                                    sb.AppendLine("    columns: [");
                                    if (field.MultiColumnFieldNames != null && field.MultiColumnFieldNames.Count != 0)
                                    {
                                        for (int i = 0; i < field.MultiColumnFieldNames.Count; i++)
                                        {
                                            var column = field.MultiColumnFieldNames[i];
                                            var comma = i < field.MultiColumnFieldNames.Count - 1 ? "," : "";
                                            //var trimmedFieldName = (column.SourceFieldName?.TrimEnd() ?? "");
                                            //var fieldNameCamelCase = char.ToLower(trimmedFieldName[0]) + trimmedFieldName[1..];
                                            var fieldNameCamelCase = !string.IsNullOrWhiteSpace(column.SourceFieldName) && column.SourceFieldName.Length > 1 ? column.SourceFieldName?.Trim().ToLower() : string.Empty;
                                            sb.AppendLine($"        {{ field: '{fieldNameCamelCase}', title: '{column.SourceFieldName}' }}{comma}");
                                        }
                                    }
                                    sb.AppendLine("    ],");
                                }

                                sb.AppendLine("    dataSource: {");
                                sb.AppendLine($"   sort: {{ field: \"{textFieldLower}\", dir: 'asc' }},");

                                //if (field?.IsMultiColumn == true)
                                //{
                                //    sb.AppendLine($"   sort: {{ field: \"{char.ToLower(field.MultiColumnFieldNames[0].SourceFieldName[0]) + field.MultiColumnFieldNames[0].SourceFieldName[1..]}\", dir: 'asc' }},");
                                //}
                                if (field?.IsMultiColumn == true && field.MultiColumnFieldNames != null &&
                                    field.MultiColumnFieldNames.Count > 0 && !string.IsNullOrEmpty(field.MultiColumnFieldNames[0]?.SourceFieldName))
                                {
                                    var sourceField = field.MultiColumnFieldNames[0].SourceFieldName!;
                                    var formattedField = char.ToLower(sourceField[0]) + sourceField[1..];

                                    sb.AppendLine($"   sort: {{ field: \"{formattedField}\", dir: 'asc' }},");
                                }

                                sb.AppendLine("        transport: {");
                                sb.AppendLine("            read: function (options) {");
                                sb.AppendLine("                var parentId = options.data.parentId;");
                                sb.AppendLine("                if (parentId) {");
                                sb.AppendLine("                    $.ajax({");

                                //                        if (field.SourceHeaderTableName != null && field.ParentSourceTblName == field.SourceTableName)
                                //                        {
                                //                            sb.AppendLine($"                        url: backendUrl + '{field.SourceTableName}/getby{field.ParentFieldName}Id/' + parentId,"); // Adjust URL to query LastNames by StudentID
                                //                        }
                                //                        if (!string.IsNullOrEmpty(field.ParentFieldName) && field.ParentSourceTblName == field.SourceHeaderTableName)
                                //                        {
                                //                            sb.AppendLine($"                        url: backendUrl + '{table.Name}/getby{field.SourceTableName}/' + parentId,"); // Adjust URL to query LastNames by StudentID
                                //
                                //  }
                                if (field?.SourceHeaderTableName != null && field.ParentSourceTblName == field.SourceTableName)
                                {
                                    sb.AppendLine($"                        url: backendUrl + '/{field.SourceTableName}/getby{field.ParentFieldName}Id/' + parentId,"); // Adjust URL to query LastNames by StudentID
                                }
                                if (field?.SourceHeaderTableName != null && field.ParentSourceTblName == field.SourceTableName && field.IsLazyLoaded)
                                {

                                    sb.AppendLine($"                        url: backendUrl + '/{field.SourceTableName?.ToLower() ?? ""}/by-{field.ParentFieldName?.ToLower() ?? ""}/' + parentId,"); // Adjust URL to query LastNames by StudentID
                                }
                                //if (!string.IsNullOrEmpty(field.ParentFieldName) && field.ParentSourceTblName == field.SourceHeaderTableName)
                                //{
                                //    sb.AppendLine($"                        url: backendUrl + '/{table.Name.ToLower()}/ + parentId,"); // Adjust URL to query LastNames by StudentID
                                //}
                                if (!string.IsNullOrEmpty(field?.ParentFieldName) && field.ParentSourceTblName == field.SourceTableName)
                                {
                                    sb.AppendLine($"                        url: backendUrl + '/{table.Name}/getby{field.SourceTableName}/' + parentId,"); // Adjust URL to query LastNames by StudentID
                                }

                                sb.AppendLine("                        type: 'GET',");
                                sb.AppendLine("                        dataType: 'json',");
                                sb.AppendLine("                        success: function (response) {");
                                sb.AppendLine("                            if (!Array.isArray(response)) {");
                                sb.AppendLine("                                response = [response];");
                                sb.AppendLine("                            }");
                                sb.AppendLine($"                        response.unshift({{ id: \"\", {textFieldLower}: \"-- Select --\" }});");
                                sb.AppendLine("                            options.success(response);");
                                sb.AppendLine("                        },");
                                sb.AppendLine("                        error: function (jqXHR, textStatus, errorThrown) {");
                                sb.AppendLine("                            console.error('Error fetching data: ' + textStatus + ' ' + errorThrown);");
                                sb.AppendLine("                        }");
                                sb.AppendLine("                    });");
                                sb.AppendLine("                } else {");
                                sb.AppendLine("                    // No parent selected: clear dropdown");
                                sb.AppendLine($"                    options.success([{{ id: \"\", {textFieldLower}: \"-- Select --\" }}]);");
                                sb.AppendLine("                }");
                                sb.AppendLine("            }");
                                sb.AppendLine("        }");
                                sb.AppendLine("    }");
                                sb.AppendLine("});");
                            }






                            // Add change event on the Parent dropdown (StudentID)
                            sb.AppendLine($"$('#{parentFieldNameLowerCase}').on('change', function(e) {{");
                            sb.AppendLine($"        let selectedValue = $('#{parentFieldNameLowerCase}').val();");
                            sb.AppendLine($"        currentParentId = selectedValue || null;");
                            if (field?.IsMultiColumn == true)
                            {
                                sb.AppendLine($"        var childDropDown = $('#{fieldLowerCase}').data('kendoMultiColumnComboBox');");
                            }
                            else
                            {
                                sb.AppendLine($"        var childDropDown = $('#{fieldLowerCase}').data('kendoDropDownList');");
                            }
                            sb.AppendLine("        if (selectedValue && childDropDown) {");

                            //  sb.AppendLine("                childDropDown.enable(true);");       commented code due to enable  dd  so that it not desabled but  show no data
                            sb.AppendLine("                childDropDown.dataSource.read({ parentId: selectedValue });");

                            sb.AppendLine("        } else if(childDropDown) {");

                            // sb.AppendLine("                childDropDown.enable(false);");  commented code due to enable  dd  so that it not desabled but  show no data
                            sb.AppendLine("                childDropDown.value('');");
                            sb.AppendLine("                childDropDown.dataSource.data([]);");  // Clear the data
                            sb.AppendLine("                childDropDown.text('');");  // Clear the text
                            sb.AppendLine($"            $('#{fieldLowerCase}').trigger('change');");

                            sb.AppendLine("        }");
                            sb.AppendLine("});");
                        }
                    }



                    /////changes
                    else if (string.Equals(field.TypeId, FieldTypeEnums.Radiogroup.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        var fieldNameLowerCase = !string.IsNullOrWhiteSpace(field.FieldName) && field.FieldName.Trim().Length > 1
                                                 ? char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim()[1..]
                                                 : string.Empty;

                        var tooltipContent = field.ToolTip?.Trim();
                        var textFieldLowerCase = field.TextFieldName?.Trim().ToLower() ?? string.Empty;

                        sb.AppendLine($"$.ajax({{");
                        sb.AppendLine($"    url: backendUrl + '/{field.SourceTableName?.ToLower() ?? ""}',");
                        sb.AppendLine("    type: 'GET',");
                        sb.AppendLine("    dataType: 'json',");
                        sb.AppendLine("    success: function (response) {");
                        sb.AppendLine("        if (!response || response.length === 0) {");
                        sb.AppendLine($"            $('#radiogroup_{fieldNameLowerCase}').html(\"<div class='text-muted p-2'>No options available.</div>\");");
                        sb.AppendLine("            return;");
                        sb.AppendLine("        }");

                        // DIRECT ORIENTATION HERE
                        sb.AppendLine($"        $('#radiogroup_{fieldNameLowerCase}').kendoRadioGroup({{");
                        sb.AppendLine("            items: response.map(function(item) {");
                        sb.AppendLine("                return {");
                        sb.AppendLine($"                    label: item.{textFieldLowerCase},");
                        sb.AppendLine("                    value: item.id");
                        sb.AppendLine("                };");
                        sb.AppendLine("            }),");
                        sb.AppendLine($"            layout: {(field.Orientation == 2 ? "'vertical'" : "'horizontal'")}");
                        sb.AppendLine("        });");

                        sb.AppendLine("        setTimeout(function() {");
                        sb.AppendLine($"            var container = $('#radiogroup_{fieldNameLowerCase}');");

                        sb.AppendLine($"            if ({(field.Orientation == 2 ? "true" : "false")} && response.length > 5) {{");
                        sb.AppendLine("                container.addClass('radio-scroll-vertical');");
                        sb.AppendLine("                container.removeClass('radio-scroll-horizontal');");
                        sb.AppendLine("            }");
                        sb.AppendLine($"            else if ({(field.Orientation == 2 ? "false" : "true")}) {{");
                        sb.AppendLine("                var items = container.find('li.k-radio-list-item');");
                        sb.AppendLine("                if (items.length > 0) {");
                        sb.AppendLine("                    var positions = [];");

                        sb.AppendLine("                    items.each(function() {");
                        sb.AppendLine("                        var top = Math.round($(this).position().top);");
                        sb.AppendLine("                        if (positions.indexOf(top) === -1) positions.push(top);");
                        sb.AppendLine("                    });");

                        sb.AppendLine("                    if (positions.length > 2) {");
                        sb.AppendLine("                        container.addClass('radio-scroll-horizontal');");
                        sb.AppendLine("                        container.removeClass('radio-scroll-vertical');");
                        sb.AppendLine("                    } else {");
                        sb.AppendLine("                        container.removeClass('radio-scroll-horizontal radio-scroll-vertical');");
                        sb.AppendLine("                    }");
                        sb.AppendLine("                }");
                        sb.AppendLine("            }");
                        sb.AppendLine("            else {");
                        sb.AppendLine("                container.removeClass('radio-scroll-horizontal radio-scroll-vertical');");
                        sb.AppendLine("            }");

                        sb.AppendLine("        }, 100);");

                        if (!string.IsNullOrEmpty(tooltipContent))
                        {

                            sb.AppendLine($"        var radioGroup = $('#radiogroup_{fieldNameLowerCase}').data('kendoRadioGroup');");
                            sb.AppendLine($"$(\"#radiogroup_{fieldNameLowerCase}\").data(\"kendoRadioGroup\").wrapper.kendoTooltip({{");
                            sb.AppendLine($"    content: \"{tooltipContent}\",");
                            sb.AppendLine("    position: \"top\",");
                            sb.AppendLine("    showOn: \"mouseenter\"");
                            sb.AppendLine("});");
                        }

                        sb.AppendLine("    },");
                        sb.AppendLine("    error: function (xhr, status, error) {");
                        sb.AppendLine("        console.error('Error loading radio button options:', error);");
                        sb.AppendLine("    }");
                        sb.AppendLine("});");
                    }

                    else if (string.Equals(field.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                        var textFieldLowerCase = field.TextFieldName?.Trim().ToLower() ?? string.Empty;
                        var sourceTable = field.SourceTableName?.ToLower() ?? "";
                        var tooltipContent = field.ToolTip?.Trim();

                        sb.AppendLine("$.ajax({");
                        sb.AppendLine($"    url: backendUrl + '/{sourceTable}/',");
                        sb.AppendLine("    type: 'GET',");
                        sb.AppendLine("    dataType: 'json',");
                        sb.AppendLine("    success: function(data) {");
                        sb.AppendLine($"        original_{fieldNameLowerCase}_data = data;");
                        sb.AppendLine("    },");
                        sb.AppendLine("    error: function() {");
                        sb.AppendLine($"        $('#{fieldNameLowerCase}_block').html(\"<span class='text-danger'>Error loading {fieldNameLowerCase} options.</span>\");");
                        sb.AppendLine("    }");
                        sb.AppendLine("});");
                        sb.AppendLine();

                        sb.AppendLine($" $(\"#{fieldNameLowerCase}\").kendoMultiSelect({{");
                        sb.AppendLine($"   placeholder: \"-- Select --\",");
                        sb.AppendLine($"   dataTextField: \"{textFieldLowerCase}\",");
                        sb.AppendLine("    dataValueField: \"id\",");
                        sb.AppendLine("    filter: \"contains\",");
                        sb.AppendLine("    tagMode: \"single\",");
                        sb.AppendLine("    autoBind: true,");
                        sb.AppendLine("    autoClose: false,");
                        sb.AppendLine("    dataSource: {");
                        sb.AppendLine("        transport: {");
                        sb.AppendLine("            read: {");
                        sb.AppendLine($"                url: backendUrl + \"/{sourceTable}\",");
                        sb.AppendLine("                dataType: \"json\",");
                        sb.AppendLine("                type: \"GET\"");
                        sb.AppendLine("            }");
                        sb.AppendLine("        },");
                        sb.AppendLine("schema: {");
                        sb.AppendLine("    parse: function (response) {");
                        sb.AppendLine("        // Add \"Select All\" option at the top");
                        sb.AppendLine("    if (response && response.length > 0) {");
                        sb.AppendLine($"        response.unshift({{ id: \"select_all\", {textFieldLowerCase}: \"Select All\" }});");
                        sb.AppendLine("     }");
                        sb.AppendLine("        return response;");
                        sb.AppendLine("             }");
                        sb.AppendLine("         }");
                        sb.AppendLine("    },");
                        if (field.IsCheckBox)
                        {
                            sb.AppendLine("template: '# if (id === \"select_all\") { # ' +");
                            sb.AppendLine("        '<input type=\"checkbox\" class=\"k-item-checkbox\" style=\"margin-right:6px;\" />' +");
                            sb.AppendLine("        '<span>Select All</span>' +");
                            sb.AppendLine("      ' # } else { # ' +");
                            sb.AppendLine("        '<input type=\"checkbox\" class=\"k-item-checkbox\" style=\"margin-right:6px;\" />' +");
                            sb.AppendLine($"        '#: {textFieldLowerCase} #' +");
                            sb.AppendLine("      ' # } #',");
                        }
                        sb.AppendLine($"    value: preSelected_{fieldNameLowerCase} , // <-- pre-fill when editing");


                        sb.AppendLine("change: function (e) {");
                        sb.AppendLine("    var multiselect = this;");
                        sb.AppendLine("    var values = multiselect.value();");
                        sb.AppendLine();
                        sb.AppendLine("    var allItems = multiselect.dataSource.data().filter(i => i.id !== 'select_all');");
                        sb.AppendLine("    var allIds = allItems.map(i => i.id);");
                        sb.AppendLine();
                        sb.AppendLine("    if (values.indexOf('select_all') !== -1) {");
                        sb.AppendLine("        if (values.length - 1 === allItems.length) {");
                        sb.AppendLine("            multiselect.value([]);");
                        sb.AppendLine("        } else {");
                        sb.AppendLine("            // Select all");
                        sb.AppendLine("            multiselect.value(allIds);");
                        sb.AppendLine("            multiselect.close();");
                        sb.AppendLine("        }");
                        sb.AppendLine("    } else {");
                        sb.AppendLine("        if (values.length < allItems.length) {");
                        sb.AppendLine("            // Just ensure Select All is not selected");
                        sb.AppendLine("            multiselect.value(values.filter(v => v !== 'select_all'));");
                        sb.AppendLine("        }");
                        sb.AppendLine("    }");
                        sb.AppendLine("if (multiselect.ul.is(':visible')) {");
                        sb.AppendLine("    multiselect.input.val('');");
                        sb.AppendLine("    multiselect.search('');");
                        sb.AppendLine("}");

                        sb.AppendLine();
                        if (field.IsCheckBox)
                        {
                            sb.AppendLine("    syncCheckboxVisuals(multiselect);");
                        }
                        sb.AppendLine();

                        if (field.Mandatory)
                        {
                            sb.AppendLine("    // validation logic");
                            sb.AppendLine("    var validator = $('#Form').data('kendoValidator');");
                            sb.AppendLine($"    var input = $('#{fieldNameLowerCase}');");
                            sb.AppendLine("    validator.validateInput(input);");
                        }
                        sb.AppendLine("},");

                        sb.AppendLine("dataBound: function () {");
                        sb.AppendLine("    var multiselect = this;");
                        sb.AppendLine("    multiselect.ul.find('li').each(function () {");
                        sb.AppendLine("        var dataItem = multiselect.dataItem($(this));");
                        sb.AppendLine("        if (dataItem && dataItem.id === 'select_all') {");
                        sb.AppendLine("            $(this).css({");
                        sb.AppendLine("                'background-color': '#f5f5f5'");
                        sb.AppendLine("            });");
                        sb.AppendLine("        }");
                        sb.AppendLine("    });");
                        if (field.IsCheckBox)
                        {
                            sb.AppendLine("    // Sync checkboxes when dropdown opens");
                            sb.AppendLine("        syncCheckboxVisuals(multiselect);");
                        }
                        sb.AppendLine("}");
                        sb.AppendLine("});");
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    var multiselect = $('#{fieldNameLowerCase}').data('kendoMultiSelect').wrapper;");
                            sb.AppendLine("    multiselect.kendoTooltip({");
                            sb.AppendLine("        position: 'top',");
                            sb.AppendLine($"        content: '{tooltipContent}',");
                            sb.AppendLine("        showAfter: 200");
                            sb.AppendLine("    });");
                        }

                        if (field.IsCheckBox)
                        {
                            sb.AppendLine("function syncCheckboxVisuals(multiselect) {");
                            sb.AppendLine("    var selectedValues = multiselect.value();");
                            sb.AppendLine("    var items = multiselect.ul.find('li');");
                            sb.AppendLine("    var allItems = multiselect.dataSource.data().filter(i => i.id !== 'select_all');");
                            sb.AppendLine();
                            sb.AppendLine("    // count how many actual items are selected");
                            sb.AppendLine("    var selectedCount = selectedValues.length;");
                            sb.AppendLine("    var allCount = allItems.length;");
                            sb.AppendLine();
                            sb.AppendLine("    items.each(function () {");
                            sb.AppendLine("        var dataItem = multiselect.dataItem($(this));");
                            sb.AppendLine("        var checkbox = $(this).find('.k-item-checkbox');");
                            sb.AppendLine("        if (checkbox.length) {");
                            sb.AppendLine("            if (dataItem.id === 'select_all') {");
                            sb.AppendLine("                checkbox.prop('checked', selectedCount === allCount && allCount > 0);");
                            sb.AppendLine("            } else {");
                            sb.AppendLine("                checkbox.prop('checked', selectedValues.indexOf(dataItem.id) !== -1);");
                            sb.AppendLine("            }");
                            sb.AppendLine("        }");
                            sb.AppendLine("    });");
                            sb.AppendLine("}");
                        }


                    }
                    else if (string.Equals(field.TypeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        var fieldNameLowerCase = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                        // var textFieldLowerCase = char.ToLower((field.TextFieldName?.Trim() ?? "")[0]) + (field.TextFieldName?.Trim() ?? "")[1..];
                        var textFieldLowerCase = field.TextFieldName?.Trim().ToLower() ?? string.Empty;
                        var sourceTable = field.SourceTableName?.ToLower() ?? "";
                        var tooltipContent = field.ToolTip?.Trim();

                        var blockId1 = $"{fieldNameLowerCase}_block";
                        sb.AppendLine($"$.ajax({{");
                        sb.AppendLine($"    url: backendUrl + '/{sourceTable}/',");
                        sb.AppendLine("    type: 'GET',");
                        sb.AppendLine("    dataType: 'json',");
                        sb.AppendLine("    success: function(data) {");
                        sb.AppendLine($"        original_{fieldNameLowerCase}_data = data;");
                        sb.AppendLine($"        const sortedData = [...data].sort((a, b) => {{");
                        sb.AppendLine($"            const valA = a.{textFieldLowerCase};");
                        sb.AppendLine($"            const valB = b.{textFieldLowerCase};");
                        sb.AppendLine($"            if (typeof valA === 'string' && typeof valB === 'string') {{");
                        sb.AppendLine($"                return valA.localeCompare(valB);");
                        sb.AppendLine($"            }} else {{");
                        sb.AppendLine($"                return valA - valB;");
                        sb.AppendLine($"            }}");
                        sb.AppendLine($"        }});");

                        //sb.AppendLine($"        const sortedData = [...data].sort((a, b) => a.{textFieldLowerCase}.localeCompare(b.{textFieldLowerCase}));");
                        sb.AppendLine($"        {sourceTable}_{fieldNameLowerCase}DataLoaded = true;");



                        // handling empty checkboxlist
                        sb.AppendLine($"        if (!data || data.length === 0) {{");
                        sb.AppendLine($"        $('#checkboxgroup_{fieldNameLowerCase}').empty();");
                        sb.AppendLine($"            $('#{fieldNameLowerCase}_container').html(\"<div class='text-muted p-2'>No {field.FieldName} options available.</div>\");");
                        sb.AppendLine($"        $('#{fieldNameLowerCase}_options').hide();");
                        //sb.AppendLine($"        $('#search_{fieldNameLowerCase}').closest('.k-textbox').hide();");
                        sb.AppendLine($"        $('#selectAll_{fieldNameLowerCase}').hide();");
                        sb.AppendLine($"        $('label[for=\"selectAll_{fieldNameLowerCase}\"]').hide();");
                        sb.AppendLine("            return;");
                        sb.AppendLine("        }");
                        if (!string.IsNullOrEmpty(tooltipContent))
                        {
                            sb.AppendLine($"    $(\"#{blockId1}\").kendoTooltip({{ content: \"{tooltipContent}\", position: \"top\", showOn: \"mouseenter\" }});");
                        }

                        sb.AppendLine($"        if (preSelected_{fieldNameLowerCase}.length > 0) {{");
                        sb.AppendLine($"            render_{fieldNameLowerCase}_checkboxes(sortedData, preSelected_{fieldNameLowerCase});");
                        sb.AppendLine("        } else {");
                        sb.AppendLine($"            render_{fieldNameLowerCase}_checkboxes(sortedData, []);");
                        sb.AppendLine("        }");

                        sb.AppendLine("    },");
                        sb.AppendLine("    error: function() {");
                        sb.AppendLine($"        $('#{fieldNameLowerCase}_block').html(\"<span class='text-danger'>Error loading {field.FieldName} options.</span>\");");
                        sb.AppendLine("    }");
                        sb.AppendLine("});");


                        // Render function
                        sb.AppendLine($"function render_{fieldNameLowerCase}_checkboxes(data, preSelected = []) {{");
                        sb.AppendLine($"    $('#checkboxgroup_{fieldNameLowerCase}').empty();");
                        sb.AppendLine($"    $('#checkboxgroup_{fieldNameLowerCase}').kendoCheckBoxGroup({{");
                        sb.AppendLine($"        name: '{field.DisplayName}',");
                        sb.AppendLine("        layout: 'vertical',");
                        sb.AppendLine($"        items: data.map(item => ({{ label: item.{textFieldLowerCase}, value: item.id.toString() }})),");
                        sb.AppendLine($"        value: preSelected.length ? preSelected : selected_{fieldNameLowerCase}_values");
                        sb.AppendLine("    });");
                        sb.AppendLine($"    bind_{fieldNameLowerCase}_selectAll();");
                        // ✅ Recalculate select all after render
                        sb.AppendLine($"    updateSelectAllState_{fieldNameLowerCase}();");
                        sb.AppendLine($"    if (data.length > 5) {{");
                        sb.AppendLine($"        $('#{fieldNameLowerCase}_container').addClass('checkbox-scroll');");
                        sb.AppendLine("    } else {");
                        sb.AppendLine($"        $('#{fieldNameLowerCase}_container').removeClass('checkbox-scroll');");
                        sb.AppendLine("    }");
                        sb.AppendLine(" }");
                        sb.AppendLine($"function updateSelectAllState_{fieldNameLowerCase}() {{");
                        sb.AppendLine($"    const checkboxes = $('#{fieldNameLowerCase}_container input[type=\"checkbox\"]');");
                        sb.AppendLine($"    const allChecked = checkboxes.length > 0 && checkboxes.length === checkboxes.filter(':checked').length;");
                        sb.AppendLine($"    $('#selectAll_{fieldNameLowerCase}').prop('checked', allChecked);");
                        sb.AppendLine("}");

                        // Select All Binding
                        sb.AppendLine($"function bind_{fieldNameLowerCase}_selectAll() {{");
                        sb.AppendLine($" const container = $('#{fieldNameLowerCase}_container');");
                        sb.AppendLine($"    $('#selectAll_{fieldNameLowerCase}').off('change').on('change', function () {{");
                        sb.AppendLine("        const shouldCheck = this.checked;");
                        sb.AppendLine("  container.find('input[type=\"checkbox\"]').each(function() {");
                        sb.AppendLine("  $(this).prop('checked', shouldCheck).trigger('change');");
                        sb.AppendLine("    });");
                        sb.AppendLine("    });");
                        sb.AppendLine($"    container.off('change').on('change', 'input[type=\"checkbox\"]', function () {{");
                        sb.AppendLine("     const checkboxes = container.find('input[type=\"checkbox\"]');");
                        sb.AppendLine("     const allChecked = checkboxes.length > 0 && checkboxes.length === checkboxes.filter(':checked').length;");
                        sb.AppendLine($"        $('#selectAll_{fieldNameLowerCase}').prop('checked', allChecked);");
                        sb.AppendLine($"        selected_{fieldNameLowerCase}_values = checkboxes.filter(':checked').map(function () {{ return $(this).val(); }}).get();");
                        sb.AppendLine("    });");
                        sb.AppendLine("}");

                        // Searching textbox initialization
                        //sb.AppendLine($"$('#search_{fieldNameLowerCase}').kendoTextBox({{");
                        //sb.AppendLine($"    placeholder: 'Search {fieldNameLowerCase}..',");
                        //sb.AppendLine("     clearButton: true");
                        //sb.AppendLine("});");


                        //sb.AppendLine($"var searchBox = $('#search_{fieldNameLowerCase}').data('kendoTextBox');");


                        //sb.AppendLine("searchBox.element.on('input', function() {");
                        //sb.AppendLine("    const searchText = this.value.toLowerCase();");
                        //sb.AppendLine($"    const filtered = original_{fieldNameLowerCase}_data.filter(item =>");
                        //sb.AppendLine($"        item.{textFieldLowerCase}.toLowerCase().includes(searchText)");
                        //sb.AppendLine("    );");
                        //sb.AppendLine($"    render_{fieldNameLowerCase}_checkboxes(filtered);");
                        //sb.AppendLine("});");

                        ////clearButton
                        //sb.AppendLine("searchBox.element.on('change', function() {");
                        //sb.AppendLine("    if (this.value === '') {");
                        //sb.AppendLine("        // Reset to full list");
                        //sb.AppendLine($"        render_{fieldNameLowerCase}_checkboxes(original_{fieldNameLowerCase}_data);");
                        //sb.AppendLine("    }");
                        //sb.AppendLine("});");

                    }
                }
            }


            //sb.AppendLine("        $('#notification').kendoNotification({");
            //sb.AppendLine("            position: {");
            //sb.AppendLine("                top: 50,");
            //sb.AppendLine("                right: 40");
            //sb.AppendLine("            },");
            //sb.AppendLine("            allowHideAfter: 1000,");
            //sb.AppendLine("            button: true");
            //sb.AppendLine("        });");
            //sb.AppendLine("        var notification = $('#notification').getKendoNotification();");

            //tabStrip code 

            sb.AppendLine("var tabStrip = $(\"#tabstrip\").kendoTabStrip({");
            sb.AppendLine("    animation: {");
            sb.AppendLine("        open: { effects: \"fadeIn\" }");
            sb.AppendLine("    },");
            sb.AppendLine("    activate: function (e) {");
            sb.AppendLine("        const tabText = $.trim($(e.item).text());");

            // Update URL with selected tab
            sb.AppendLine("        const urlParams = new URLSearchParams(window.location.search);");
            sb.AppendLine("        urlParams.set('tab', tabText);");
            sb.AppendLine("        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;");
            sb.AppendLine("        window.history.replaceState(null, '', newUrl);");

            string TableName = !string.IsNullOrEmpty(table.HeaderTableName) ? table.HeaderTableName : table.Name;

            //Document Tab Partial view
            if (parentForm != null && parentForm.IsDocumentEnabled)
            {
                sb.AppendLine("        if (tabText === \"Document\" && $(\"#Document\").is(':empty')) {");
                sb.AppendLine("            $.ajax({");
                sb.AppendLine($"                url: `/{TableName}Document/{parentForm.Name}DocumentList?id=${{FormId}}`,");
                sb.AppendLine("                success: function (data) {");
                sb.AppendLine("                    $(\"#Document\").html(data);");
                sb.AppendLine("                },");
                sb.AppendLine("                error: function () {");
                sb.AppendLine("                    $(\"#Document\").html(\"Failed to load document list.\");");
                sb.AppendLine("                }");
                sb.AppendLine("            });");
                sb.AppendLine("        }");
            }

            // Child tabs
            foreach (var form in childForms)
            {
                var displayName = string.IsNullOrWhiteSpace(form.DisplayName) ? form.Name : form.DisplayName?.Trim() ?? "";
                sb.AppendLine($"        if (tabText === \"{displayName}\" && $(\"#{form.TableName}\").is(':empty')) {{");
                sb.AppendLine("            $.ajax({");
                sb.AppendLine($"                url: `/{table.Name}/{form.Name}List1?id=${{FormId}}`,");
                sb.AppendLine("                success: function (data) {");
                sb.AppendLine($"                    $(\"#{form.TableName}\").html(data);");
                sb.AppendLine("                },");
                sb.AppendLine("                error: function () {");
                sb.AppendLine($"                    $(\"#{form.TableName}\").html(\"Failed to load form list.\");");
                sb.AppendLine("                }");
                sb.AppendLine("            });");
                sb.AppendLine("        }");
            }

            sb.AppendLine("    }");
            sb.AppendLine("}).data(\"kendoTabStrip\");");

            //anable/disable
            sb.AppendLine("if (!isEditMode) {");
            sb.AppendLine("    $('#tabstrip ul li').each(function(index) {");
            sb.AppendLine("        if (index !== 0) { // disable all except the first tab (index 0)");
            sb.AppendLine("            tabStrip.disable(tabStrip.tabGroup.children().eq(index));");
            sb.AppendLine("        }");
            sb.AppendLine("    });");
            sb.AppendLine("}");

            // Add tab activation from query string
            sb.AppendLine("const tabParam = new URLSearchParams(window.location.search).get('tab');");
            sb.AppendLine("if (tabParam) {");
            sb.AppendLine("    const tabIndex = $(\"#tabstrip ul li\").filter(function () {");
            sb.AppendLine("        return $.trim($(this).text()) === tabParam;");
            sb.AppendLine("    }).index();");
            sb.AppendLine("    if (tabIndex >= 0) {");
            sb.AppendLine("        tabStrip.select(tabIndex);");
            sb.AppendLine("    }");
            sb.AppendLine("}");



            //validator Function
            //sb.AppendLine("    var validator = $('#Form').kendoValidator({");
            //sb.AppendLine("        errorTemplate: \"<span class='k-invalid-msg'>#=message#</span>\",");
            //sb.AppendLine("        messages: {");
            //sb.AppendLine("            required: function (input) {");
            //sb.AppendLine("                return input.data('required-msg');");
            //sb.AppendLine("            }");
            //sb.AppendLine("        }");
            //sb.AppendLine("    }).data('kendoValidator');");


            //sb.AppendLine("");
            //sb.AppendLine("    $('.required_field').on('input change', function () {");
            //sb.AppendLine("        $(this).removeClass('k-invalid');"); // Remove red border
            //sb.AppendLine("        $(this).siblings('.k-invalid-msg').addClass('k-hidden');"); // Hide error message
            //sb.AppendLine("    });");

            sb.AppendLine("        // Save button click event");
            //sb.AppendLine("        $('#btnSave').click(async function (event) {");
            //sb.AppendLine("        event.preventDefault();");
            //sb.AppendLine("        if (!validator.validate()) return;");


            ////sb.AppendLine("        // Save button click event");
            ////sb.AppendLine("        $('#btnSave').click(function () {");
            //sb.AppendLine("            var formData = {};");
            //sb.AppendLine("            formData['ID'] = FormId ? FormId : 0;");
            //HashSet<int> formIds = new HashSet<int>();
            //foreach (var field in fields)
            //{
            //    formIds.Add(field.FormId);
            //}
            //var firstFormId = formIds.FirstOrDefault();
            //sb.AppendLine($"            formData['formId'] = {firstFormId};");
            //// Loop through each input field and capture its value
            //// Step 1: Add all ActionName-based values first
            //var handledActions = new HashSet<string>();

            //foreach (var modelItem in formActionQuery)
            //{
            //    if (modelItem.ActionName == "SetValue")
            //    {
            //        if (modelItem.FormId == firstFormId)
            //        {
            //            sb.AppendLine($"            formData['{modelItem.FieldName.Trim()}'] = \"{modelItem.Value}\";");
            //            handledActions.Add(modelItem.FieldName.Trim().ToLower());
            //        }
            //    }
            //}
            ////foreach (var modelItem in formActionQuery.Where(x => x.FormId == firstFormId && x.ActionID == 1))
            ////{
            ////    if (modelItem.FormId == firstFormId)
            ////    {
            ////        if (modelItem.Value != null)
            ////        {
            ////            sb.AppendLine($"            formData['{modelItem.FieldName.Trim()}'] = \"{modelItem.Value}\";");
            ////        }
            ////        handledActions.Add(modelItem.FieldName.Trim().ToLower());
            ////    }
            ////}
            ////foreach (var field in fields)
            ////{
            ////    sb.AppendLine($"            formData['{field.FieldName}'] = $('#{field.FieldName.ToLower()}').val();");

            ////}
            //foreach (var field in fields)
            //{
            //    if (field.TypeId == "Image")
            //    {
            //        sb.AppendLine("  var editedImageBase64 = $(\"#ImageBase64\").val();");
            //        sb.AppendLine("");
            //        sb.AppendLine("  if (editedImageBase64 && editedImageBase64.trim() !== '') {");
            //        sb.AppendLine("    // Use the edited image from the preview");
            //        sb.AppendLine("    formData[\"ImageBase64\"] = editedImageBase64;");
            //        sb.AppendLine("  } else {");
            //        sb.AppendLine("    // Fallback to current preview image if no edited image is stored");
            //        sb.AppendLine("    var previewSrc = $(\"#imagePreview\").attr(\"src\");");
            //        sb.AppendLine("    if (previewSrc && previewSrc.startsWith('data:image/')) {");
            //        sb.AppendLine("      formData[\"ImageBase64\"] = previewSrc;");
            //        sb.AppendLine("    } else {");
            //        sb.AppendLine("      console.log(\"No image to save\");");
            //        sb.AppendLine("    }");
            //        sb.AppendLine("  }");
            //        sb.AppendLine("");
            //        sb.AppendLine("  var canvas = $(\"#imageEditor\").find(\"canvas\")[0];");
            //        sb.AppendLine("  if (canvas && canvas.toDataURL) {");
            //        sb.AppendLine("    formData[\"ImageBase64\"] = canvas.toDataURL(\"image/jpeg\", 0.9);");
            //        sb.AppendLine("  }");
            //    }
            //}
            //    // Step 2: Add form fields if not handled by ActionName
            //    foreach (var field in fields)
            //{
            //    var fieldNameTrimmed = field.FieldName.Trim();
            //    var fieldNameLowerCase = char.ToLower(fieldNameTrimmed[0]) + fieldNameTrimmed.Substring(1);

            //    // Only add the field if it's NOT already handled by an ActionName
            //    if (!handledActions.Contains(fieldNameLowerCase))
            //    {
            //        if (field.TypeId == "bit" || field.TypeId == "boolean")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}').is(':checked');");
            //        }
            //        else if (field.TypeId == "switchs")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameLowerCase}'] = $(\"#{fieldNameLowerCase}\").data(\"kendoSwitch\").check();");
            //        }
            //        else if (field.TypeId.ToLower() == "radiogroup")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}').data('kendoRadioGroup').value() || null;");
            //        }
            //        else if (field.TypeId.ToLower() == "rating")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = parseInt($('#{fieldNameLowerCase}').val()) || 0;");

            //        }
            //        else if (field.TypeId.ToLower() == "rangeslider")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}Value').val();");
            //        }
            //        else if (field.TypeId.ToLower() == "timeduration")
            //        {
            //            sb.AppendLine($@"            var picker = $('#{fieldNameLowerCase}').data('kendoTimeDurationPicker')._old;
            //            let numbers = picker.match(/\d+/g);
            //            let result = numbers
            //                ? (numbers.length === 1
            //                    ? `${{numbers[0].padStart(2, '0')}}:00:00`
            //                    : numbers.length === 2
            //                        ? `${{numbers[0].padStart(2, '0')}}:${{numbers[1].padStart(2, '0')}}:00`
            //                        : `${{numbers[0].padStart(2, '0')}}:${{numbers[1].padStart(2, '0')}}:${{numbers[2].padStart(2, '0')}}`)
            //                : '00:00:00';
            //            formData['{fieldNameTrimmed}'] = result;");
            //        }
            //        else if (field.TypeId.ToLower() == "checkboxgroup")
            //        {
            //            var fieldNameTrimmed1 = field.FieldName.Trim();
            //            var fieldNameLower = char.ToLower(fieldNameTrimmed1[0]) + fieldNameTrimmed1.Substring(1);

            //            // Generate JavaScript for collecting selected checkbox values
            //            sb.AppendLine($"            var selectedValues_{fieldNameLower} = [];");
            //            sb.AppendLine($"            $('#{fieldNameLower}_container input[type=\"checkbox\"]:checked').each(function () {{");
            //            sb.AppendLine($"                selectedValues_{fieldNameLower}.push($(this).val());");
            //            sb.AppendLine($"            }});");
            //            sb.AppendLine($"            console.log(selectedValues_{fieldNameLower});");

            //            // Assign selected values to formData for saving
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = selectedValues_{fieldNameLower}.join(',');");

            //            // Save map values in local variable for secondary AJAX call
            //            sb.AppendLine($"            var map_{fieldNameLower} = selectedValues_{fieldNameLower};");
            //        }
            //        else if (field.TypeId.ToLower() == "captcha")
            //        {
            //            sb.AppendLine("            const userInputCaptcha = $('#captchaCode').val();");
            //            sb.AppendLine("            const sessionCaptcha = sessionStorage.getItem(\"simpleCaptcha\");");
            //            sb.AppendLine("");
            //            sb.AppendLine("            if (userInputCaptcha !== sessionCaptcha) {");
            //            sb.AppendLine("                notification.show(\"Invalid CAPTCHA code.\", \"error\");");
            //            sb.AppendLine("                refreshCaptcha();");
            //            sb.AppendLine("                return;");
            //            sb.AppendLine("            }");
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = userInputCaptcha; // CAPTCHA value assigned to '{fieldNameTrimmed}'");
            //        }
            //        else if (field.TypeId.ToLower() == "signature")
            //        {
            //            sb.AppendLine($"            var signatureData_{fieldNameLowerCase} = $('#{fieldNameLowerCase}')[0].toDataURL('image/png');");
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = signatureData_{fieldNameLowerCase};");
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}_FileName'] = '{fieldNameLowerCase}_' + (FormId || 'new') + '.png';");
            //        }
            //        //else if (field.TypeId.ToLower() == "imageupload")
            //        else if (field.TypeId.ToLower() == "imageupload" || field.TypeId.ToLower() == "varbinary")

            //        {
            //            var uploadField = imageUploadFields.FirstOrDefault(u => u.FieldName == field.FieldName);
            //            if (!uploadField.Equals(default((string FieldName, string UploadId))))
            //            {
            //                var uploadId = uploadField.UploadId;

            //                sb.AppendLine($@"
            //const kendoUpload_{uploadId} = $('#{uploadId}').data('kendoUpload');
            //const file_{uploadId} = kendoUpload_{uploadId} && kendoUpload_{uploadId}.getFiles().length > 0
            //    ? kendoUpload_{uploadId}.getFiles()[0].rawFile
            //    : null;

            //if (file_{uploadId}) {{
            //    console.log('Reading file: ' + file_{uploadId}.name);
            //    formData['{fieldNameTrimmed}'] = await toBase64(file_{uploadId});
            //    formData['{fieldNameTrimmed}Name'] = file_{uploadId}.name;
            //}} else {{
            //    console.warn('No file selected for {fieldNameTrimmed}.');
            //    formData['{fieldNameTrimmed}'] = null;
            //    formData['{fieldNameTrimmed}Name'] = null;
            //}}");
            //            }
            //        }
            //        else
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}').val();");
            //        }
            //    }
            //}
            //if (table.IsHierarchical)
            //{
            //    sb.AppendLine("            formData['ParentID'] = $('#parentId').data('kendoDropDownTree')?.value() || null;");
            //}
            //if (table.HeaderTableId > 0)
            //{
            //    sb.AppendLine($"            formData['{table.HeaderTableName}Id'] = FkId;");
            //}
            //int actualFormId = fields
            //                   .FirstOrDefault()?.FormId ?? 0;


            //// Add ParentId to formData
            //sb.AppendLine("            formData['ParentId'] = ParentId ? ParentId : null;");
            ////sb.AppendLine($"            formData['FormId'] = '{actualFormId}';");

            //// Conditionally add ParentId to formData only if it exists
            //sb.AppendLine("            if (ParentId) {");
            //sb.AppendLine($"                formData['ParentId'] = ParentId;");
            //sb.AppendLine("            } else {");
            //sb.AppendLine("                formData['ParentId'] = null;");
            //sb.AppendLine("            }");




            ////int Counter = 0;
            ////var forms = await _form.GetFormByTableId(ClientId, ProjectId, item.ID, originalConnectionString);


            ////List<FormActionModel> formActionModel = new List<FormActionModel>();
            ////foreach (var field in forms)
            ////{
            ////    FormActionModel model = new FormActionModel();
            ////    model.FormId = field.ID;
            ////    model.FormName = field.Name;
            ////    formActionModel.Add(model);
            ////}


            ////sb.AppendLine($"            formData['{formActionModel}'] = $('{formActionModel}');");


            //sb.AppendLine($"            formData['FormId'] = {actualFormId};");
            //HashSet<string> formNames = new HashSet<string>();
            //foreach (var field in fields)
            //{
            //    formNames.Add(field.FormName);
            //}
            //foreach (var field in fields)
            //{
            //    if (field.TypeId == "Image")
            //    {
            //        sb.AppendLine("    var canvas = $(\"#imageEditor\").find(\"canvas\")[0];");
            //        sb.AppendLine("    if (canvas && canvas.toDataURL) {");
            //        sb.AppendLine("        formData[\"ImageBase64\"] = canvas.toDataURL(\"image/jpeg\", 0.9);");
            //        sb.AppendLine("    }");
            //    }
            //}
            //var firstFormName = formNames.FirstOrDefault();
            //sb.AppendLine("            // Log the form data to the console");
            //sb.AppendLine("            console.log(formData);");

            //sb.AppendLine("            // Send data to the server via AJAX");
            //sb.AppendLine("        // If id is not null, make a PUT request");
            ////sb.AppendLine("        if (FormId != null) {");
            //sb.AppendLine("$.ajax({");
            //sb.AppendLine($"    url: backendUrl + '/forms/{firstFormName.ToLower()}',");
            //sb.AppendLine("    type: 'POST',");
            //sb.AppendLine("    contentType: 'application/json',");
            //sb.AppendLine("    data: JSON.stringify(formData),");
            //sb.AppendLine("    success: function(response) {");
            //sb.AppendLine("        console.log('Response:', response);");
            //sb.AppendLine("        console.log('FormData:', formData);");
            //sb.AppendLine("        localStorage.setItem('recentFormId', response.id);");

            //// Handle checkbox list mappings
            //foreach (var field in fields.Where(f => f.TypeId.ToLower() == "checkboxgroup"))
            //{
            //    var fieldNameLower = char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim().Substring(1);
            //    string mapClassName = $"{table.Name}_{field.FieldName}";
            //    string tableIdName = $"{table.Name}Id";
            //    string sourceIdName = $"{field.SourceTableName}Id";
            //    sb.AppendLine($" var {table.Name}_data = FormId ? FormId : response.id;");

            //    sb.AppendLine($"        // Submit mappings for {field.FieldName}");
            //    sb.AppendLine($"        $.ajax({{");
            //    sb.AppendLine($"            url: backendUrl + '/{mapClassName.ToLower()}',");
            //    sb.AppendLine($"            type: 'POST',");
            //    sb.AppendLine($"            contentType: 'application/json',");
            //    sb.AppendLine($"            data: JSON.stringify(");
            //    sb.AppendLine($"                (map_{fieldNameLower} && map_{fieldNameLower}.length > 0)");
            //    sb.AppendLine($"                    ? map_{fieldNameLower}.map(function(val) {{");
            //    sb.AppendLine($"                        return {{");
            //    sb.AppendLine($"                            {tableIdName}: parseInt( {table.Name}_data, 10),");
            //    sb.AppendLine($"                            {sourceIdName}: parseInt(val, 10)");
            //    sb.AppendLine($"                        }};");
            //    sb.AppendLine($"                    }})");
            //    sb.AppendLine($"                    : [{{ {tableIdName}: parseInt( {table.Name}_data, 10), {sourceIdName}: 0 }}]");
            //    sb.AppendLine($"            ),");
            //    sb.AppendLine($"            success: function(mapResponse) {{");
            //    sb.AppendLine($"                console.log('Mappings saved for {field.FieldName}:', mapResponse);");
            //    sb.AppendLine($"            }},");
            //    sb.AppendLine($"            error: function(xhr, status, error) {{");
            //    sb.AppendLine($"                console.error('Map error for {field.FieldName}:', error);");
            //    sb.AppendLine($"            }}");
            //    sb.AppendLine($"        }});");
            //}

            //// Error handling and success logic
            //sb.AppendLine("        if (response.id === 0 && response.message) {");
            //sb.AppendLine("            const cleanedMessages = response.message");
            //sb.AppendLine("                .trim()");
            //sb.AppendLine("                .replace(/\\t/g, '')");
            //sb.AppendLine("                .split(',')");
            //sb.AppendLine("                .map(msg => msg.trim())");
            //sb.AppendLine("                .filter(msg => msg);");
            //sb.AppendLine("            cleanedMessages.forEach(msg => {");
            //sb.AppendLine("                notification.show(msg, 'error');");
            //sb.AppendLine("            });");
            //sb.AppendLine("        } else {");
            //sb.AppendLine("            notification.show('Form submitted successfully', 'success');");

            //// Navigation logic
            //sb.AppendLine("            if (FormId == null) {");
            //foreach (var btn in childForms)
            //{
            //    sb.AppendLine($"                window.location.href = '/{table.Name}/{btn.HeaderFormName}Details?id=' + response.id;");
            //    sb.AppendLine($"                $('#{btn.TableName}Btn').prop('disabled', false);");
            //}
            //sb.AppendLine("            } else {");
            //foreach (var btn in childForms)
            //{
            //    sb.AppendLine($"                window.location.href = '/{table.Name}/{btn.HeaderFormName}Details?id=' + formData.ID;");
            //    sb.AppendLine($"                $('#{btn.TableName}Btn').prop('disabled', false);");
            //}
            //sb.AppendLine("            }");

            //// Reports handling (following your pattern)
            //sb.AppendLine("            // Handle reports if available");
            //sb.AppendLine("            if (response.extraData && Array.isArray(response.extraData)) {");
            //sb.AppendLine("                reportsToOpen = response.extraData;");
            //sb.AppendLine("                openAllReportsInNewTabs();");
            //sb.AppendLine("            }");

            //sb.AppendLine("        }");
            //sb.AppendLine("    },");
            //sb.AppendLine("    error: function(xhr, status, error) {");
            //sb.AppendLine("        console.error('Error:', error);");
            //sb.AppendLine("        notification.show('An error occurred during form submission.', 'error');");
            //sb.AppendLine("    }");
            //sb.AppendLine("});");

            //sb.AppendLine("        $(\"#editImageRemoveBtn\").kendoButton({");
            //sb.AppendLine("            themeColor: \"base\"");
            //sb.AppendLine("        });");






            //sb.AppendLine("            // Clear any existing image in the image editor");
            //sb.AppendLine("            if (imageEditor) {");
            //sb.AppendLine("                try {");
            //sb.AppendLine("                    imageEditor.destroy();");
            //sb.AppendLine("                    $(\"#imageEditor\").empty();");
            //sb.AppendLine("                    initializeImageEditor(null, FormId ? true : false);");
            //sb.AppendLine("                } catch (error) {");
            //sb.AppendLine("                    console.log(\"Image editor reset:\", error);");
            //sb.AppendLine("                }");
            //sb.AppendLine("            }");
            //sb.AppendLine();
            //sb.AppendLine("            // Clear popup editor too");
            //sb.AppendLine("            const popupEditor = $(\"#imageEditorContainer\").data(\"kendoImageEditor\");");
            //sb.AppendLine("            if (popupEditor) {");
            //sb.AppendLine("                try {");
            //sb.AppendLine("                    // Reset/clear the image but keep the editor open");
            //sb.AppendLine("                    popupEditor.executeCommand({ command: \"Reset\" });");
            //sb.AppendLine("                } catch (error) {");
            //sb.AppendLine("                    console.log(\"Popup image reset:\", error);");
            //sb.AppendLine("                }");
            //sb.AppendLine("            }");


            sb.AppendLine("function hmsStringToMs(hms) {");
            sb.AppendLine("    if (!hms) return 0;");
            sb.AppendLine("    const [h, m, s] = hms.split(':').map(Number);");
            sb.AppendLine("    return ((h * 3600) + (m * 60) + s) * 1000;");
            sb.AppendLine("}");


            sb.AppendLine("function handleFormSubmission(btnId) {");

            if (showSaveContinue)
            {
                sb.AppendLine("    const isContinue = btnId === 'btnSaveContinue';");
            }
            if (showSaveReuse)
            {
                sb.AppendLine("    const isReuse = btnId === 'btnSaveReuse';");
            }
            sb.AppendLine("    if (!validator.validate()) return;");
            //sb.AppendLine("    if (!formValidator.validate()) return;");

            // (Insert your formData construction logic here OR call existing method if already done)
            sb.AppendLine("    var formData = {};");
            // You already built the full formData logic above


            string defaultIdValue = table.PrimaryKeyType?.ToUpper() != PKTypeEnum.UniqueIdentifier.ToString().ToUpper()
            ? "0"
            : "'00000000-0000-0000-0000-000000000000'";

            sb.AppendLine($"            formData['ID'] = FormId ? FormId : {defaultIdValue};");

            HashSet<int> formIds = [];
            foreach (var field in fields)
            {
                formIds.Add(field.FormId);
            }
            var firstFormId = formIds.FirstOrDefault();
            sb.AppendLine($"            formData['formId'] = {firstFormId};");

            // Loop through each input field and capture its value
            // Step 1: Add all ActionName-based values first
            //var handledActions = new HashSet<string>();

            //foreach (var modelItem in formActionQuery)
            //{
            //    if (modelItem.ActionName == "SetValue")
            //    {
            //        if (modelItem.FormId == firstFormId)
            //        {
            //            sb.AppendLine($"            formData['{modelItem.FieldName?.Trim() ?? ""}'] = \"{modelItem.Value}\";");
            //            handledActions.Add(modelItem.FieldName?.Trim() ?? "".ToLower());
            //        }
            //    }
            //}

            var handledActions = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var modelItem in formActionQuery)
            {
                if (modelItem.ActionName == "SetValue" && modelItem.FormId == firstFormId)
                {
                    var fieldName = modelItem.FieldName?.Trim() ?? "";
                    if (!string.IsNullOrEmpty(fieldName))
                    {
                        sb.AppendLine($"formData['{fieldName}'] = \"{modelItem.Value}\";");
                        handledActions.Add(fieldName.ToLower());
                    }
                }
            }

            foreach (var field in fields)
            {
                if (string.Equals(field.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    var fieldNameLowerCase = field.FieldName?.Trim().ToLower() ?? string.Empty;

                    sb.AppendLine($"  var editedImageBase64 = $(\"#{fieldNameLowerCase}ImageBase64\").val();");
                    sb.AppendLine("");
                    sb.AppendLine("  if (editedImageBase64 && editedImageBase64.trim() !== '') {");
                    sb.AppendLine("    // Use the edited image from the preview");
                    sb.AppendLine($"    formData[\"{fieldNameLowerCase}ImageBase64\"] = editedImageBase64;");
                    sb.AppendLine("  } else {");
                    sb.AppendLine("    // Fallback to current preview image if no edited image is stored");
                    sb.AppendLine($"    var previewSrc = $(\"#{fieldNameLowerCase}imagePreview\").attr(\"src\");");
                    sb.AppendLine("    if (previewSrc && previewSrc.startsWith('data:image/')) {");
                    sb.AppendLine($"      formData[\"{fieldNameLowerCase}ImageBase64\"] = previewSrc;");
                    sb.AppendLine("    } else {");
                    sb.AppendLine("      console.log(\"No image to save\");");
                    sb.AppendLine("    }");
                    sb.AppendLine("  }");
                    sb.AppendLine("");
                    sb.AppendLine("  var canvas = $(\"#imageEditor\").find(\"canvas\")[0];");
                    sb.AppendLine("  if (canvas && canvas.toDataURL) {");
                    sb.AppendLine($"    formData[\"{fieldNameLowerCase}ImageBase64\"] = canvas.toDataURL(\"image/jpeg\", 0.9);");
                    sb.AppendLine("  }");
                }
                if (string.Equals(field.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    var fieldNameLower = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                    string mapClassName = $"{table.Name}_{field.FieldName}";
                    string tableIdName = $"{table.Name}Id";
                    string sourceIdName = $"{field.SourceTableName}Id";

                    sb.AppendLine($"var multiselect = $(\"#{fieldNameLower}\").data(\"kendoMultiSelect\");");
                    sb.AppendLine($"var selectedValues_{fieldNameLower} = multiselect.value();   // array of IDs");
                    sb.AppendLine($"formData['{fieldNameLower}'] = selectedValues_{fieldNameLower}.join(',');");
                    sb.AppendLine($"var map_{fieldNameLower} = selectedValues_{fieldNameLower};");
                }

            }
            //foreach (var modelItem in formActionQuery.Where(x => x.FormId == firstFormId && x.ActionID == 1))
            //{
            //    if (modelItem.FormId == firstFormId)
            //    {
            //        if (modelItem.Value != null)
            //        {
            //            sb.AppendLine($"            formData['{modelItem.FieldName.Trim()}'] = \"{modelItem.Value}\";");
            //        }
            //        handledActions.Add(modelItem.FieldName.Trim().ToLower());
            //    }
            //}
            //foreach (var field in fields)
            //{
            //    sb.AppendLine($"            formData['{field.FieldName}'] = $('#{field.FieldName.ToLower()}').val();");

            //foreach (var field in fields)
            //{
            //    if (string.Equals(field.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
            //    {
            //        sb.AppendLine("  var editedImageBase64 = $(\"#ImageBase64\").val();");
            //        sb.AppendLine("");
            //        sb.AppendLine("  if (editedImageBase64 && editedImageBase64.trim() !== '') {");
            //        sb.AppendLine("    // Use the edited image from the preview");
            //        sb.AppendLine("    formData[\"ImageBase64\"] = editedImageBase64;");
            //        sb.AppendLine("  } else {");
            //        sb.AppendLine("    // Fallback to current preview image if no edited image is stored");
            //        sb.AppendLine("    var previewSrc = $(\"#imagePreview\").attr(\"src\");");
            //        sb.AppendLine("    if (previewSrc && previewSrc.startsWith('data:image/')) {");
            //        sb.AppendLine("      formData[\"ImageBase64\"] = previewSrc;");
            //        sb.AppendLine("    } else {");
            //        sb.AppendLine("      console.log(\"No image to save\");");
            //        sb.AppendLine("    }");
            //        sb.AppendLine("  }");
            //        sb.AppendLine("");
            //        sb.AppendLine("  var canvas = $(\"#imageEditor\").find(\"canvas\")[0];");
            //        sb.AppendLine("  if (canvas && canvas.toDataURL) {");
            //        sb.AppendLine("    formData[\"ImageBase64\"] = canvas.toDataURL(\"image/jpeg\", 0.9);");
            //        sb.AppendLine("  }");
            //    }
            //}
            // Step 2: Add form fields if not handled by ActionName
            //foreach (var field in fields)
            //{
            //    var fieldNameTrimmed = (field.FieldName?.Trim() ?? "");
            //    var fieldNameLowerCase = char.ToLower(fieldNameTrimmed[0]) + fieldNameTrimmed[1..];

            //    // Only add the field if it's NOT already handled by an ActionName
            //    if (!handledActions.Contains(fieldNameLowerCase))
            //    {
            //        if (field.TypeId == "bit" || field.TypeId == "boolean")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}').is(':checked');");
            //        }
            //        else if (field.TypeId == "switches")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameLowerCase}'] = $(\"#{fieldNameLowerCase}\").data(\"kendoSwitch\").check();");
            //        }
            //        else if ((field.TypeId?.ToLower() ?? "") == "radiogroup")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#radiogroup_{fieldNameLowerCase}').data('kendoRadioGroup').value() || null;");
            //        }
            //        else if ((field.TypeId?.ToLower() ?? "") == "rating")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = parseInt($('#{fieldNameLowerCase}').val()) || 0;");

            //        }
            //        else if ((field.TypeId?.ToLower() ?? "") == "rangeslider")
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}Value').val();");
            //        }
            //        else if ((field.TypeId?.ToLower() ?? "") == "
            //
            //        ")
            //        {
            //            sb.AppendLine($@"            var picker = $('#{fieldNameLowerCase}').data('kendoTimeDurationPicker')._old;
            //let numbers = picker.match(/\d+/g);
            //let result = numbers
            //    ? (numbers.length === 1
            //        ? `${{numbers[0].padStart(2, '0')}}:00:00`
            //        : numbers.length === 2
            //            ? `${{numbers[0].padStart(2, '0')}}:${{numbers[1].padStart(2, '0')}}:00`
            //            : `${{numbers[0].padStart(2, '0')}}:${{numbers[1].padStart(2, '0')}}:${{numbers[2].padStart(2, '0')}}`)
            //    : '00:00:00';
            //formData['{fieldNameTrimmed}'] = result;");
            //        }
            //        else if ((field.TypeId?.ToLower() ?? "") == "checkboxgroup")
            //        {
            //            var fieldNameTrimmed1 = (field.FieldName?.Trim() ?? "");
            //            var fieldNameLower = char.ToLower(fieldNameTrimmed1[0]) + fieldNameTrimmed1[1..];

            //            // Generate JavaScript for collecting selected checkbox values
            //            sb.AppendLine($"            var selectedValues_{fieldNameLower} = [];");
            //            sb.AppendLine($"            $('#{fieldNameLower}_container input[type=\"checkbox\"]:checked').each(function () {{");
            //            sb.AppendLine($"                selectedValues_{fieldNameLower}.push($(this).val());");
            //            sb.AppendLine($"            }});");
            //            sb.AppendLine($"            console.log(selectedValues_{fieldNameLower});");

            //            // Assign selected values to formData for saving
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = selectedValues_{fieldNameLower}.join(',');");

            //            // Save map values in local variable for secondary AJAX call
            //            sb.AppendLine($"            var map_{fieldNameLower} = selectedValues_{fieldNameLower};");
            //        }

            //        else if ((field.TypeId?.ToLower() ?? "") == "signature")
            //        {
            //            sb.AppendLine($"                var {fieldNameLowerCase}Data = $('#{fieldNameLowerCase}')[0].toDataURL('image/png');");
            //            sb.AppendLine($"                formData['{fieldNameTrimmed}'] = {fieldNameLowerCase}Data.split(',')[1]; // send just base64");
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}_FileName'] = '{fieldNameLowerCase}_' + (FormId || 'new') + '.png';");
            //        }
            //        //else if (field.TypeId.ToLower() == "imageupload")
            //        else if ((field.TypeId?.ToLower() ?? "") == "imageupload" || (field.TypeId?.ToLower() ?? "") == "varbinary")

            //        {
            //            var uploadField = imageUploadFields.FirstOrDefault(u => u.FieldName == field.FieldName);
            //            if (!uploadField.Equals(default((string FieldName, string UploadId))))
            //            {
            //                var uploadId = uploadField.UploadId;

            //                sb.AppendLine($@"
            //                const kendoUpload_{uploadId} = $('#{uploadId}').data('kendoUpload');
            //                const file_{uploadId} = kendoUpload_{uploadId} && kendoUpload_{uploadId}.getFiles().length > 0
            //                    ? kendoUpload_{uploadId}.getFiles()[0].rawFile
            //                    : null;

            //                if (file_{uploadId}) {{
            //                    console.log('Reading file: ' + file_{uploadId}.name);
            //                    formData['{fieldNameTrimmed}'] = await toBase64(file_{uploadId});
            //                    formData['{fieldNameTrimmed}Name'] = file_{uploadId}.name;
            //                }} else {{
            //                    console.warn('No file selected for {fieldNameTrimmed}.');
            //                    formData['{fieldNameTrimmed}'] = null;
            //                    formData['{fieldNameTrimmed}Name'] = null;
            //                }}");
            //            }
            //        }
            //        else if (string.Equals(field.TypeId, FieldTypeEnums.Colorpicker.ToString(), StringComparison.OrdinalIgnoreCase))

            //            {
            //            sb.AppendLine($"           var {fieldNameTrimmed}Val = $('#{fieldNameLowerCase}').val();");
            //            sb.AppendLine($"           {fieldNameTrimmed}Val = {fieldNameTrimmed}Val ? {fieldNameTrimmed}Val.toLowerCase() : null;");

            //            sb.AppendLine($"           formData['{fieldNameTrimmed}'] = ({fieldNameTrimmed}Val && {fieldNameTrimmed}Val.toLowerCase() !== '#000000') ? {fieldNameTrimmed}Val : null;");
            //        }
            //        else
            //        {
            //            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}').val();");
            //        }
            //    }
            //}
            foreach (var field in fields)
            {
                //var fieldNameTrimmed = (field.FieldName?.Trim() ?? "");
                var fieldNameTrimmed = string.IsNullOrWhiteSpace(field.FieldName)
    ? ""
    : char.ToUpper(field.FieldName.Trim()[0]) + field.FieldName.Trim().Substring(1).ToLower();

                if (string.IsNullOrEmpty(fieldNameTrimmed)) continue;

                var fieldNameLowerCase = char.ToLower(fieldNameTrimmed[0]) + fieldNameTrimmed[1..];
                var fieldNameLowerCaseRadio = !string.IsNullOrWhiteSpace(field.FieldName) && field.FieldName.Trim().Length > 1
                                                 ? char.ToLower(field.FieldName.Trim()[0]) + field.FieldName.Trim()[1..]
                                                 : string.Empty;

                // Only add the field if it's NOT already handled by an ActionName
                if (!handledActions.Contains(fieldNameLowerCase))
                {
                    // Parse the field type to enum
                    FieldTypeEnums fieldType;
                    if (!Enum.TryParse(field.TypeId, true, out fieldType))
                    {
                        fieldType = FieldTypeEnums.Unknown;
                    }

                    switch (fieldType)
                    {
                        case FieldTypeEnums.Date:
                            sb.AppendLine($"var dateValue = $(\"#{fieldNameLowerCase}\").data(\"kendoDatePicker\").value();");
                            sb.AppendLine("if (dateValue) {");
                            sb.AppendLine("    var formattedDate = kendo.toString(dateValue, \"yyyy-MM-dd\");");
                            sb.AppendLine($"    formData.{fieldNameLowerCase} = formattedDate;");
                            sb.AppendLine("} else {");
                            sb.AppendLine($"    formData.{fieldNameLowerCase} = null;");
                            sb.AppendLine("}");
                            break;

                        case FieldTypeEnums.Timeduration:
                            sb.AppendLine($"var {fieldNameLowerCase}Picker = $('#{fieldNameLowerCase}').data('kendoTimeDurationPicker');");
                            sb.AppendLine($"var value = {fieldNameLowerCase}Picker ? {fieldNameLowerCase}Picker.value() : null;");
                            sb.AppendLine("if (value) {");
                            sb.AppendLine("    var h = Math.floor(value / 3600000);");
                            sb.AppendLine("    var m = Math.floor((value % 3600000) / 60000);");
                            sb.AppendLine("    var s = Math.floor((value % 60000) / 1000);");
                            sb.AppendLine($"    formData['{fieldNameLowerCase}'] = `${{h.toString().padStart(2, '0')}}:${{m.toString().padStart(2, '0')}}:${{s.toString().padStart(2, '0')}}`;");
                            sb.AppendLine("} else {");
                            sb.AppendLine($"    formData['{fieldNameLowerCase}'] = null;");
                            sb.AppendLine("}");

                            break;

                        case FieldTypeEnums.Bit:
                            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}').is(':checked');");
                            break;

                        case FieldTypeEnums.Switches:
                            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}').data('kendoSwitch') ? $('#{fieldNameLowerCase}').data('kendoSwitch').check() : false;");
                            break;

                        case FieldTypeEnums.Radiogroup:

                            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#radiogroup_{fieldNameLowerCaseRadio}').data('kendoRadioGroup').value() || null;");
                            break;

                        case FieldTypeEnums.Rating:
                            //sb.AppendLine($"            formData['{fieldNameTrimmed}'] = parseInt($('#{fieldNameLowerCase}').val()) || 0;");
                            sb.AppendLine($"            var ratingWidget = $(\"#{fieldNameLowerCase}\").data(\"kendoRating\");");
                            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = ratingWidget ? (ratingWidget.value() ? ratingWidget.value() : null) : null;");
                            break;

                        case FieldTypeEnums.Rangeslider:
                            sb.AppendLine($"formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}Value').val();");
                            break;

                        case FieldTypeEnums.Slider:
                            sb.AppendLine($"formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}').val();");
                            break;

                        //                sb.AppendLine($@"            var picker = $('#{fieldNameLowerCase}').data('kendoTimeDurationPicker')._old;
                        //let numbers = picker.match(/\d+/g);
                        //let result = numbers
                        //    ? (numbers.length === 1
                        //        ? `${{numbers[0].padStart(2, '0')}}:00:00`
                        //        : numbers.length === 2
                        //            ? `${{numbers[0].padStart(2, '0')}}:${{numbers[1].padStart(2, '0')}}:00`
                        //            : `${{numbers[0].padStart(2, '0')}}:${{numbers[1].padStart(2, '0')}}:${{numbers[2].padStart(2, '0')}}`)
                        //    : '00:00:00';
                        //formData['{fieldNameTrimmed}'] = result;");



                        //            case FieldTypeEnums.Timeduration:
                        //                sb.AppendLine($@"            var picker = $('#{fieldNameLowerCase}').data('kendoTimeDurationPicker')._old;
                        //let numbers = picker.match(/\d+/g);
                        //let result = numbers
                        //    ? (numbers.length === 1
                        //        ? `${{numbers[0].padStart(2, '0')}}:00:00`
                        //        : numbers.length === 2
                        //            ? `${{numbers[0].padStart(2, '0')}}:${{numbers[1].padStart(2, '0')}}:00`
                        //            : `${{numbers[0].padStart(2, '0')}}:${{numbers[1].padStart(2, '0')}}:${{numbers[2].padStart(2, '0')}}`)
                        //    : '00:00:00';
                        //formData['{fieldNameTrimmed}'] = result;");
                        //                break;

                        case FieldTypeEnums.Checkboxgroup:
                            var fieldNameTrimmed1 = field.FieldName?.Trim() ?? "";
                            var fieldNameLower = char.ToLower(fieldNameTrimmed1[0]) + fieldNameTrimmed1[1..];

                            // Generate JavaScript for collecting selected checkbox values
                            sb.AppendLine($"            var selectedValues_{fieldNameLower} = [];");
                            sb.AppendLine($"            $('#{fieldNameLower}_container input[type=\"checkbox\"]:checked').each(function () {{");
                            sb.AppendLine($"                selectedValues_{fieldNameLower}.push($(this).val());");
                            sb.AppendLine($"            }});");
                            sb.AppendLine($"            console.log(selectedValues_{fieldNameLower});");

                            // Assign selected values to formData for saving
                            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = selectedValues_{fieldNameLower}.join(',');");

                            // Save map values in local variable for secondary AJAX call
                            sb.AppendLine($"            var map_{fieldNameLower} = selectedValues_{fieldNameLower};");
                            break;

                        case FieldTypeEnums.Signature:
                            sb.AppendLine($"                var {fieldNameLowerCase}Data = $('#{fieldNameLowerCase}')[0].toDataURL('image/png');");
                            sb.AppendLine($"                formData['{fieldNameTrimmed}'] = {fieldNameLowerCase}Data.split(',')[1]; // send just base64");
                            sb.AppendLine($"            formData['{fieldNameTrimmed}_FileName'] = '{fieldNameLowerCase}_' + (FormId || 'new') + '.png';");
                            break;

                        case FieldTypeEnums.ImageUpload:
                        case FieldTypeEnums.Varbinary:
                            var uploadField = imageUploadFields.FirstOrDefault(u => u.FieldName == field.FieldName);
                            if (!uploadField.Equals(default((string FieldName, string UploadId))))
                            {
                                var uploadId = uploadField.UploadId;

                                sb.AppendLine($@"
                            const kendoUpload_{uploadId} = $('#{uploadId}').data('kendoUpload');
                            const file_{uploadId} = kendoUpload_{uploadId} && kendoUpload_{uploadId}.getFiles().length > 0
                                ? kendoUpload_{uploadId}.getFiles()[0].rawFile
                                : null;

                            if (file_{uploadId}) {{
                                console.log('Reading file: ' + file_{uploadId}.name);
                                formData['{fieldNameTrimmed}'] = await toBase64(file_{uploadId});
                                formData['{fieldNameTrimmed}Name'] = file_{uploadId}.name;
                            }} else {{
                                console.warn('No file selected for {fieldNameTrimmed}.');
                                formData['{fieldNameTrimmed}'] = null;
                                formData['{fieldNameTrimmed}Name'] = null;
                            }}");
                            }
                            break;


                        case FieldTypeEnums.Barcode:
                            sb.AppendLine($"           var {fieldNameTrimmed}Val = $('#{fieldNameLowerCase}').val();");
                            sb.AppendLine($"           {fieldNameTrimmed}Val = {fieldNameTrimmed}Val ? {fieldNameTrimmed}Val.trim() : null;");
                            sb.AppendLine($"           var {fieldNameTrimmed}Validation = validate_{fieldNameLowerCase}_barcode({fieldNameTrimmed}Val);");
                            sb.AppendLine($"           if (!{fieldNameTrimmed}Validation.valid) {{");
                            sb.AppendLine($"               isValid = false;  // Just mark as invalid, no alert or message");
                            sb.AppendLine($"           }} else {{");
                            sb.AppendLine($"               formData['{fieldNameTrimmed}'] = {fieldNameTrimmed}Val && {fieldNameTrimmed}Val !== '' ? {fieldNameTrimmed}Val : null;");
                            sb.AppendLine($"           }}");
                            break;



                        case FieldTypeEnums.Colorpicker:
                            sb.AppendLine($"           var {fieldNameTrimmed}Val = $('#{fieldNameLowerCase}').val();");
                            sb.AppendLine($"           {fieldNameTrimmed}Val = {fieldNameTrimmed}Val ? {fieldNameTrimmed}Val.toLowerCase() : null;");

                            sb.AppendLine($"           formData['{fieldNameTrimmed}'] = ({fieldNameTrimmed}Val && {fieldNameTrimmed}Val.toLowerCase() !== '#000000') ? {fieldNameTrimmed}Val : null;");
                            break;

                        case FieldTypeEnums.Richtexteditor:

                            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}RichTextContent').val();");
                            break;
                        default:
                            sb.AppendLine($"            formData['{fieldNameTrimmed}'] = $('#{fieldNameLowerCase}').val();");
                            break;
                    }
                }
            }

            if (table.IsHierarchical)
            {
                sb.AppendLine("            formData['ParentID'] = $('#parentId').data('kendoDropDownTree')?.value() || null;");
            }
            if (table.HeaderTableId > 0)
            {
                sb.AppendLine($"            formData['{table.HeaderTableName}Id'] = FkId;");
            }
            int actualFormId = fields
                               .FirstOrDefault()?.FormId ?? 0;


            // Add ParentId to formData
            sb.AppendLine("            formData['ParentId'] = ParentId ? ParentId : null;");
            //sb.AppendLine($"            formData['FormId'] = '{actualFormId}';");

            // Conditionally add ParentId to formData only if it exists
            sb.AppendLine("            if (ParentId) {");
            sb.AppendLine($"                formData['ParentId'] = ParentId;");
            sb.AppendLine("            } else {");
            sb.AppendLine("                formData['ParentId'] = null;");
            sb.AppendLine("            }");
            sb.AppendLine($"            formData['FormId'] = {actualFormId};");
            HashSet<string> formNames = [];
            foreach (var field in fields)
            {
                // formNames.Add(field.FormName);
                if (!string.IsNullOrWhiteSpace(field.FormName))
                {
                    formNames.Add(field.FormName);
                }
            }
            foreach (var field in fields)
            {
                if (string.Equals(field.TypeId, FieldTypeEnums.Image.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    sb.AppendLine("    var canvas = $(\"#imageEditor\").find(\"canvas\")[0];");
                    sb.AppendLine("    if (canvas && canvas.toDataURL) {");
                    sb.AppendLine("        formData[\"ImageBase64\"] = canvas.toDataURL(\"image/jpeg\", 0.9);");
                    sb.AppendLine("    }");
                }
            }


            var firstFormName = formNames.FirstOrDefault();
            sb.AppendLine("            // Log the form data to the console");
            sb.AppendLine("            console.log(formData); $(\"#editLoader\").show();");

            // Always use the common save API
            sb.AppendLine("    const ajaxUrl = backendUrl + '/forms/" + (firstFormName?.ToLower() ?? "") + "';");


            sb.AppendLine("    $.ajax({");
            sb.AppendLine("        url: ajaxUrl,");
            sb.AppendLine("        type: 'POST',");
            sb.AppendLine("        contentType: 'application/json',");
            sb.AppendLine("        data: JSON.stringify(formData),");
            sb.AppendLine("headers: {");
            sb.AppendLine("    \"Authorization\": \"Bearer \" + localStorage.jwtToken");
            sb.AppendLine("},");
            sb.AppendLine("        success: function (response) {");
            sb.AppendLine("             $(\"#editLoader\").hide(); ");
            foreach (var field in fields.Where(f =>
            string.Equals(f.TypeId, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase)))
            {
                var fieldNameLower = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                string mapClassName = $"{table.Name}_{field.FieldName}";
                string tableIdName = $"{table.Name}Id";
                string sourceIdName = $"{field.SourceTableName}Id";
                sb.AppendLine($" var {table.Name}_data = FormId ? FormId : response.id;");

                sb.AppendLine($"        // Submit mappings for {field.FieldName}");
                sb.AppendLine($"        $.ajax({{");
                sb.AppendLine($"            url: backendUrl + '/{mapClassName.ToLower()}',");
                sb.AppendLine($"            type: 'POST',");
                sb.AppendLine($"            contentType: 'application/json',");
                sb.AppendLine($"            data: JSON.stringify(");
                sb.AppendLine($"                (map_{fieldNameLower} && map_{fieldNameLower}.length > 0)");
                sb.AppendLine($"                    ? map_{fieldNameLower}.map(function(val) {{");
                sb.AppendLine($"                        return {{");
                var isGuidPk = table.PrimaryKeyType?.ToUpper() == PKTypeEnum.UniqueIdentifier.ToString().ToUpper();
                string idExpr = isGuidPk
                    ? $"{table.Name}_data"
                    : $"parseInt( {table.Name}_data, 10)";
                string guidPk = isGuidPk ? $"parseInt(val, 10)" : $"val";
                sb.AppendLine($"                            {tableIdName}: {idExpr},");
                sb.AppendLine($"                            {sourceIdName}: {guidPk}");
                sb.AppendLine($"                        }};");
                sb.AppendLine($"                    }})");
                sb.AppendLine($"                    : [{{ {tableIdName}: parseInt( {table.Name}_data, 10), {sourceIdName}: 0 }}]");
                sb.AppendLine($"            ),");

                //sb.AppendLine("headers: {");
                //sb.AppendLine("    \"Authorization\": \"Bearer \" + localStorage.getItem('jwToken')");
                //sb.AppendLine("},");
                sb.AppendLine($"            success: function(mapResponse) {{");
                sb.AppendLine($"                console.log('Mappings saved for {field.FieldName}:', mapResponse);");
                sb.AppendLine($"            }},");
                sb.AppendLine($"            error: function(xhr, status, error) {{");
                sb.AppendLine($"                console.error('Map error for {field.FieldName}:', error);");
                sb.AppendLine($"            }}");
                sb.AppendLine($"        }});");
            }

            foreach (var field in fields.Where(f =>
             string.Equals(f.TypeId, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase)))
            {
                var fieldNameLower = char.ToLower((field.FieldName?.Trim() ?? "")[0]) + (field.FieldName?.Trim() ?? "")[1..];
                string mapClassName = $"{table.Name}_{field.FieldName}";
                string tableIdName = $"{table.Name}Id";
                string sourceIdName = $"{field.SourceTableName}Id";

                sb.AppendLine($" var {table.Name}_data = FormId ? FormId : response.id;");
                sb.AppendLine($"// Submit mappings for {mapClassName}");
                sb.AppendLine("$.ajax({");
                sb.AppendLine($"    url: backendUrl + '/{mapClassName}',");
                sb.AppendLine("    type: 'POST',");
                sb.AppendLine("    contentType: 'application/json',");
                sb.AppendLine("    data: JSON.stringify(");
                sb.AppendLine($"                (map_{fieldNameLower} && map_{fieldNameLower}.length > 0)");
                sb.AppendLine($"                    ? map_{fieldNameLower}.map(function(val) {{");
                sb.AppendLine($"                        return {{");
                sb.AppendLine($"                            {tableIdName}: parseInt( {table.Name}_data, 10),");
                sb.AppendLine($"                            {sourceIdName}: parseInt(val, 10)");
                sb.AppendLine($"                        }};");
                sb.AppendLine($"                    }})");
                sb.AppendLine($"                    : [{{ {tableIdName}: parseInt( {table.Name}_data, 10), {sourceIdName}: 0 }}]");
                sb.AppendLine("    ),");
                sb.AppendLine("    success: function(mapResponse) {");
                sb.AppendLine($"        console.log('Mappings saved for {mapClassName}', mapResponse);");
                sb.AppendLine("    },");
                sb.AppendLine("    error: function(xhr, status, error) {");
                sb.AppendLine("        console.error('Map error for datalist:', error);");
                sb.AppendLine("    }");
                sb.AppendLine("});");
            }

            // After the checkbox mapping logic and before the error handling
            sb.AppendLine("  " + (table.PrimaryKeyType?.ToUpper() != PKTypeEnum.UniqueIdentifier.ToString().ToUpper()
                  ? "if (!response.id || response.id === 0) {"
                  : "if (!response.id || response.id === \"00000000-0000-0000-0000-000000000000\") {"));

            sb.AppendLine("                const messages = response.message ? response.message.trim().replace(/\\t/g, '').split(',').map(x => x.trim()).filter(x => x) : [];");
            sb.AppendLine("                if (messages.length > 0) {GlobalErrorHandler.showErrorInDiv(messages, 'errorMessageContainer');}");
            sb.AppendLine("                else { fnShowNotification('Unexpected error occurred.', 'error'); }");



            sb.AppendLine("                return;");
            sb.AppendLine("            }");

            sb.AppendLine("            // Common success notification");
            //sb.AppendLine("            showNotification('success', 'Form created successfully.');");
            if (showSaveReuse)
            {
                sb.AppendLine("    if (isReuse) {");
                sb.AppendLine("        fnShowNotification('Form Data saved and Reloaded.','success');");
                sb.AppendLine("    } else {");
                sb.AppendLine("        fnShowNotification('Form created successfully.','success');");
                sb.AppendLine("    }");
            }
            else
            {
                // Only show the normal create success message
                sb.AppendLine("    fnShowNotification('Form created successfully.','success');");
            }
            sb.AppendLine("            localStorage.setItem('recentFormId', response.id);");
            //sb.AppendLine("            if (!FormId) FormId = response.id;");
            sb.AppendLine("");


            sb.AppendLine("$('#tabstrip ul li').each(function(index) {");
            sb.AppendLine("    tabStrip.enable(tabStrip.tabGroup.children().eq(index));");
            sb.AppendLine("});");


            sb.AppendLine("            // --- Handle reports consistently for both Save and Continue ---");
            sb.AppendLine("            if (response.extraData && Array.isArray(response.extraData) && response.extraData.length > 0) {");
            sb.AppendLine("                localStorage.setItem('reportsToOpen', JSON.stringify(response.extraData));");
            sb.AppendLine("                localStorage.setItem('reportsOpenLocation', 'listPage');");
            sb.AppendLine("                response.extraData.forEach((reportName, index) => {");
            sb.AppendLine("                    setTimeout(() => {");
            sb.AppendLine("                        openReportInNewBrowserWindow(reportName, response.id, false);");
            sb.AppendLine("                    }, index * 12); // small delay if multiple reports");
            sb.AppendLine("                });");
            sb.AppendLine("            }");

            if (showSaveReuse)
            {
                sb.AppendLine("        if (isReuse) {");
                var resetFields = new List<ClientCardViewFields>();

                // Get only the reset fields
                if (fields.Any(f => f.ResetFieldNames != null && f.ResetFieldNames.Any()))
                {
                    resetFields = fields.Where(f => f.ResetFieldNames?.Contains(f.FieldName, StringComparer.OrdinalIgnoreCase) ?? false).ToList();

                    if (resetFields.Count > 0)
                    {
                        foreach (var field in resetFields)
                        {
                            //  ALWAYS lowercase for HTML ID (required fix)
                            var fieldNameLower = field.FieldName?.Trim().ToLower() ?? string.Empty;

                            FieldTypeEnums fieldType;
                            if (!Enum.TryParse(field.TypeId, true, out fieldType))
                            {
                                fieldType = FieldTypeEnums.Unknown;
                            }

                            switch (fieldType)
                            {
                                case FieldTypeEnums.Nvarchar:
                                case FieldTypeEnums.Varchar:
                                    sb.AppendLine($"            $('#{fieldNameLower}').val('').trigger('change');");
                                    break;

                                case FieldTypeEnums.Int:
                                case FieldTypeEnums.Decimal:
                                case FieldTypeEnums.Float:
                                case FieldTypeEnums.Money:
                                case FieldTypeEnums.Bigint:
                                case FieldTypeEnums.Smallint:
                                case FieldTypeEnums.Tinyint:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoNumericTextBox');");
                                    sb.AppendLine($"            if (widget) widget.value(null);");
                                    break;

                                case FieldTypeEnums.Date:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoDatePicker');");
                                    sb.AppendLine($"            if (widget) widget.value(null);");
                                    break;

                                case FieldTypeEnums.Datetime:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoDateTimePicker');");
                                    sb.AppendLine($"            if (widget) widget.value(null);");
                                    break;

                                case FieldTypeEnums.DropDown:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoDropDownList');");
                                    sb.AppendLine($"            if (widget) widget.value('');");
                                    break;

                                case FieldTypeEnums.Multiselect:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoMultiSelect');");
                                    sb.AppendLine($"            if (widget) widget.value([]);");
                                    break;

                                case FieldTypeEnums.Checkboxgroup:
                                    sb.AppendLine($"            $('#{fieldNameLower}_container input[type=\"checkbox\"]').prop('checked', false).trigger('change');");
                                    sb.AppendLine($"            $('#{fieldNameLower}Value').val('');");
                                    break;

                                case FieldTypeEnums.Radiogroup:
                                    sb.AppendLine($"            var widget = $('#radiogroup_{fieldNameLower}').data('kendoRadioGroup');");
                                    sb.AppendLine($"            if (widget) widget.value(null);");
                                    sb.AppendLine($"            $('#{fieldNameLower}Value').val('');");
                                    break;

                                case FieldTypeEnums.Bit:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoCheckBox');");
                                    sb.AppendLine($"            if (widget) widget.check(false); else $('#{fieldNameLower}').prop('checked', false);");
                                    break;

                                case FieldTypeEnums.Switches:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoSwitch');");
                                    sb.AppendLine($"            if (widget) widget.check(false);");
                                    break;

                                case FieldTypeEnums.Slider:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoSlider');");
                                    sb.AppendLine($"            if (widget) {{ var minVal = widget.options.min || 0; widget.value(minVal); }}");
                                    break;

                                case FieldTypeEnums.Rangeslider:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoRangeSlider');");
                                    sb.AppendLine($"            if (widget) {{ var minVal = widget.options.min || 0; var maxVal = widget.options.max || 100; widget.values([minVal, maxVal]); $('#{fieldNameLower}Value').val(minVal + ',' + maxVal); $('#rangeValues_{fieldNameLower}').text('Selected Range: $ ' + minVal + ' - $ ' + maxVal); }}");
                                    break;

                                case FieldTypeEnums.Rating:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoRating');");
                                    sb.AppendLine($"            if (widget) widget.value(null);");
                                    sb.AppendLine($"            $('#{fieldNameLower}Value').val('');");
                                    break;

                                case FieldTypeEnums.Colorpicker:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoColorPicker');");
                                    sb.AppendLine($"            if (widget) widget.value('#000000');");
                                    sb.AppendLine($"            $('#{fieldNameLower}').val('#000000').trigger('change');");
                                    sb.AppendLine($"            $('#{fieldNameLower}Name').val('').trigger('change');");
                                    break;

                                case FieldTypeEnums.Richtexteditor:
                                    sb.AppendLine($"            $('#{fieldNameLower}RichTextContent').val('');");
                                    break;

                                case FieldTypeEnums.Signature:
                                    sb.AppendLine($"            var canvas = document.getElementById('{fieldNameLower}');");
                                    sb.AppendLine($"            if (canvas) {{ var ctx = canvas.getContext('2d'); ctx.clearRect(0, 0, canvas.width, canvas.height); }}");
                                    sb.AppendLine($"            $('#{fieldNameLower}Value').val('');");
                                    break;

                                case FieldTypeEnums.Image:
                                    sb.AppendLine($"            $('#imagePreview').attr('src', '/Icon/default_image.png').show();");
                                    sb.AppendLine($"            $('#ImageBase64').val('');");
                                    sb.AppendLine($"            $('#closeImagePreview').hide();");
                                    break;

                                case FieldTypeEnums.ImageUpload:
                                case FieldTypeEnums.Varbinary:
                                    var uploadField = imageUploadFields.FirstOrDefault(u => u.FieldName == field.FieldName);
                                    if (!uploadField.Equals(default((string, string))))
                                    {
                                        sb.AppendLine($"            var widget = $('#{uploadField.UploadId}').data('kendoUpload');");
                                        sb.AppendLine($"            if (widget) widget.clearAllFiles();");
                                    }
                                    break;

                                case FieldTypeEnums.Timeduration:
                                    sb.AppendLine($"            var widget = $('#{fieldNameLower}').data('kendoTimeDurationPicker');");
                                    sb.AppendLine($"            if (widget) widget.value(null);");
                                    break;

                                default:
                                    sb.AppendLine($"            $('#{fieldNameLower}').val('').trigger('change');");
                                    break;
                            }
                        }
                    }
                }

                sb.AppendLine("            // Restore old values for NON-reset fields");
                sb.AppendLine("            if (TempData) {");
                sb.AppendLine("                const savedData = JSON.parse(TempData);");

                foreach (var field in fields)
                {
                    var fieldNameLower = field.FieldName?.Trim().ToLower() ?? string.Empty;

                    if (resetFields.Any(r => r.FieldName.Equals(field.FieldName, StringComparison.OrdinalIgnoreCase)))
                        continue;

                    if (fieldNameLower.Contains("date"))
                    {
                        sb.AppendLine($"                $('#{fieldNameLower}').val(savedData.{field.FieldName} ? savedData.{field.FieldName}.split('T')[0] : '').trigger('change');");
                    }
                    else
                    {
                        sb.AppendLine($"                $('#{fieldNameLower}').val(savedData.{field.FieldName}).trigger('change');");
                    }
                }

                sb.AppendLine("            }");
                sb.AppendLine("            FormId = null;");
                sb.AppendLine("            return;");
                sb.AppendLine("        }");
            }







            if (showSaveContinue)
            {
                sb.AppendLine("if (!isContinue) {");
                sb.AppendLine("    redirectToPage();");
                sb.AppendLine("} else {");
                sb.AppendLine("            if (!FormId) FormId = response.id;");
                sb.AppendLine("}");
            }
            else
            {
                sb.AppendLine("    redirectToPage();");
            }

            sb.AppendLine("");

            //if (showSaveContinue)
            //{
            //    sb.AppendLine("            if (isContinue) {");
            //    sb.AppendLine("            if (!FormId) FormId = response.id;");

            //    sb.AppendLine("                return;");
            //    sb.AppendLine("            } ");

            //}

            //sb.AppendLine("            // ✅ Always redirect using your function");
            //sb.AppendLine("            redirectToPage();");
            //sb.AppendLine("            // Handle reports redirection - Modified Logic");
            //sb.AppendLine("            if (isContinue) {");
            //sb.AppendLine("                // Save & Continue: Stay on current page, open reports inline");
            //sb.AppendLine("                if (response.extraData && Array.isArray(response.extraData) && response.extraData.length > 0) {");
            //sb.AppendLine("                    console.log('Save & Continue: Opening reports on current page');");
            //sb.AppendLine("                    notification.show(`Opening ${response.extraData.length} report(s) on current page...`, 'info');");
            //sb.AppendLine("                    setTimeout(() => {");
            //sb.AppendLine("                        response.extraData.forEach((reportName, index) => {");
            //sb.AppendLine("                            setTimeout(() => {");
            //sb.AppendLine("                                console.log(`Opening report ${index + 1} on Details page:`, reportName);");
            //sb.AppendLine("                                openReportDirectlyOnCurrentPage(reportName);");
            //sb.AppendLine("                            }, index * 500);");
            //sb.AppendLine("                        });");
            //sb.AppendLine("                    }, 1000);");
            //sb.AppendLine("                }");
            //sb.AppendLine("                return; // No redirect on Save & Continue");
            //sb.AppendLine("            }");

            //sb.AppendLine("            // Regular Save: Redirect to list page + open reports if any");
            //sb.AppendLine("            if (response.extraData && Array.isArray(response.extraData) && response.extraData.length > 0) {");
            //sb.AppendLine("                console.log('Save: Redirecting to list page with reports');");
            //sb.AppendLine("                localStorage.setItem('reportsToOpen', JSON.stringify(response.extraData));");
            //sb.AppendLine("                localStorage.setItem('reportsOpenLocation', 'listPage');");

            //sb.AppendLine("                setTimeout(() => {");

            //if (isDetailsForm)
            //{
            //    sb.AppendLine($"                   window.location.href = `/{table.HeaderTableName}/{table.HeaderTableName}Details?id=${{FkId}}&tab={table.Name}`;");

            //}

            //else
            //{
            //    sb.AppendLine("            if (isContinue) {");
            //    sb.AppendLine("                if (!FormId) FormId = response.id;");
            //    sb.AppendLine("                return;");
            //    sb.AppendLine("            }");
            //    sb.AppendLine("");
            //}

            //sb.AppendLine("                }, 1500);");
            //sb.AppendLine("            } ");
            //sb.AppendLine("             else {");
            ////sb.AppendLine("            redirectToPage();");
            //sb.AppendLine("            //Delay redirect so success notification shows");
            //sb.AppendLine("            setTimeout(() => {");
            //sb.AppendLine("                redirectToPage();");
            //sb.AppendLine("            }, 1500);");
            ////sb.AppendLine("                // No reports to show, handle child forms or go back");
            ////sb.AppendLine("                setTimeout(function() {");
            //sb.AppendLine("        }");
            //sb.AppendLine("                    if (!FormId) {");
            //foreach (var btn in childForms)
            //{
            //    sb.AppendLine($"                        $('#{btn.TableName}Btn').prop('disabled', false);");
            //    sb.AppendLine($"                        window.location.href = '/{table.Name}/{btn.HeaderFormName}Details?id=' + response.id;");
            //}
            //if (childForms.Count == 0)
            //{
            //    sb.AppendLine($"                        window.location.href = `/{table.HeaderTableName}/{parentForm?.HeaderFormName ?? "DefaultForm"}Details?id=${{FkId}}&tab={table.Name}`;");
            //}
            //sb.AppendLine("                    } else {");
            //foreach (var btn in childForms)
            //{
            //    sb.AppendLine($"                        $('#{btn.TableName}Btn').prop('disabled', false);");
            //    sb.AppendLine($"                        window.location.href = '/{table.Name}/{btn.HeaderFormName}Details?id=' + formData.ID;");
            //}
            //if (childForms.Count == 0)
            //{
            //    sb.AppendLine("                        window.history.back();");
            //}
            //sb.AppendLine("                    }");
            //sb.AppendLine("                }, 700);");
            //sb.AppendLine("            }");


            sb.AppendLine("        },");
            sb.AppendLine("        error: function (xhr) {");
            sb.AppendLine("              $(\"#editLoader\").hide(); ");
            sb.AppendLine("        const responseText = xhr.responseText || \"\";");
            if (showSaveReuse && showSaveContinue)
            {
                sb.AppendLine("            const msg = isReuse ? 'Error saving reuse template.' : isContinue ? 'Failed to save data.' : 'Error submitting form.';");
            }
            else if (showSaveReuse)
            {
                sb.AppendLine("            let msg = isReuse ? 'Failed to save data.' : 'Error submitting form.';");
            }
            else if (showSaveContinue)
            {
                sb.AppendLine("            let msg = isContinue ? 'Error saving reuse template.' : 'Error submitting form.';");
            }
            else
            {
                sb.AppendLine("            let msg = 'Error submitting form.';");
            }
            foreach (var field in fields)
            {
                var displayName = string.IsNullOrWhiteSpace(field.DisplayName) ? field.FieldName : field.DisplayName?.Trim() ?? "";
                var FieldName = field.FieldName;
                if (string.Equals(field.TypeId, FieldTypeEnums.Decimal.ToString(), StringComparison.OrdinalIgnoreCase))

                {
                    sb.AppendLine("");
                    sb.AppendLine("        if (responseText.includes(\"Arithmetic overflow error converting numeric to data type numeric\")) {");
                    sb.AppendLine($"            msg = \"Please enter a valid allowed range for {displayName}.\";");
                    sb.AppendLine("        }");
                    sb.AppendLine("");
                }
                if (string.Equals(field.TypeId, FieldTypeEnums.Varchar.ToString(), StringComparison.OrdinalIgnoreCase))

                {
                    sb.AppendLine("");
                    sb.AppendLine($"        if (responseText.includes(\"String or binary data would be truncated\") && responseText.includes(\"column '{FieldName}'\")) {{");
                    sb.AppendLine($"            msg = \"⚠️{displayName} Limit Exceeded.\";");
                    sb.AppendLine("        } ");
                }
            }
            sb.AppendLine("            fnShowNotification(msg,'error');");
            sb.AppendLine("        }");
            sb.AppendLine("    });");
            sb.AppendLine("}");


            bool hasCaptcha = fields.Any(f =>
     string.Equals(f.TypeId, FieldTypeEnums.Captcha.ToString(), StringComparison.OrdinalIgnoreCase));

            if (hasCaptcha)
            {
                sb.AppendLine("$('#btnSave').click(function (e) {");
                sb.AppendLine("    e.preventDefault();");
                sb.AppendLine("if (!validator.validate()) return;");
                sb.AppendLine("");
                sb.AppendLine("var userValue = $(\"#captcha\").val();");
                sb.AppendLine("var captchaId = $(\"input[name='captchaId']\").val();");
                sb.AppendLine("");
                sb.AppendLine("$.ajax({");
                sb.AppendLine("    url: backendUrl + \"/Captcha/Validate\",");
                sb.AppendLine("    type: \"GET\",");
                sb.AppendLine("    data: {");
                sb.AppendLine("        captchaId: captchaId,");
                sb.AppendLine("        captcha: userValue");
                sb.AppendLine("    },");
                sb.AppendLine("    success: function (response) {");
                sb.AppendLine("");
                sb.AppendLine("        if (response === true) {");
                sb.AppendLine("            // captcha OK");
                sb.AppendLine("            handleFormSubmission('btnSave');");
                sb.AppendLine("        }");
                sb.AppendLine("else {");
                sb.AppendLine("    fnShowNotification(\"The text you entered doesn't match the captcha.\", \"error\");");
                sb.AppendLine("}");

                sb.AppendLine("    },");
                sb.AppendLine("    error: function () {");
                sb.AppendLine("        fnShowNotification(\"Captcha is Invalid\",\"error\");");
                sb.AppendLine("    }");
                sb.AppendLine("});");
                sb.AppendLine("});");
            }
            else
            {
                sb.AppendLine("$('#btnSave').click(function (e) { e.preventDefault(); handleFormSubmission('btnSave');  });");
            }

            if (showSaveContinue)
            {
                sb.AppendLine("$('#btnSaveContinue').click(function (e) { e.preventDefault(); handleFormSubmission('btnSaveContinue');   });");
            }

            if (showSaveReuse)
            {
                sb.AppendLine("$('#btnSaveReuse').click(function (e) { e.preventDefault(); handleFormSubmission('btnSaveReuse');   });");
            }

            // Add the report opening function


            //sb.AppendLine("     });");
            if (uploadControlIds.Count != 0)
            {
                sb.AppendLine(@"
    function initUploadControl() {");

                foreach (var id in uploadControlIds)
                {
                    sb.AppendLine($@"
        $('#{id}').kendoUpload({{
            async: false,
            multiple: false,
            showFileList: true
        }});");
                }

                sb.AppendLine("}"); // Close initUploadControl
            }


            if (imageUploadFields.Count != 0)
            {
                sb.AppendLine(@"
        function toBase64(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = () => {
                    const base64String = reader.result.split(',')[1];
                    resolve(base64String);
                };
                reader.onerror = error => reject(error);
            });
        }
    ");
            }

            sb.AppendLine(" });");  // Close document ready
            if (isDetailsForm)
            {
                var displayName = string.IsNullOrWhiteSpace(parentForm?.DisplayName) ? parentForm?.Name : parentForm?.DisplayName?.Trim() ?? "";
                if (childForms.Count == 0)
                {
                    sb.AppendLine($@"   function redirectToPage() 
                    {{                  
                    setTimeout(function () {{
                      //window.location.href = '/{table.HeaderTableName}/{parentForm?.HeaderFormName}Details?id='+ FkId;
                          window.location.href = `/{table.HeaderTableName}/{parentForm?.HeaderFormName ?? "DefaultForm"}Details?id=${{FkId}}&tab={displayName}`;
                        }},1000);
                    }} ");
                }
            }
            else
            {
                sb.AppendLine($@"   function redirectToPage() 
                   {{   
                   setTimeout(function () {{
                        window.location.href = '/{table.Name}/{firstFormName}List';
                      }},1000);
                   }} ");
            }


            sb.AppendLine("</script>");


            // Create folder and file
            //string projectFolderName = $"{projectName}_{clientName}";
            //string directoryPath = $@"C:\ClientProject\{projectFolderName}\DynamicFormBuilder_UI\Views\{table.Name}";

            //if (!Directory.Exists(directoryPath))
            //{
            //    Directory.CreateDirectory(directoryPath);
            //}

            ////string filePath = Path.Combine(directoryPath, $"{tableName + Counter}Details.cshtml");
            //string filePath = "";
            //foreach (var field in fields)
            //{
            //    if (table.Name == field.TableName)
            //    {

            //        filePath = Path.Combine(directoryPath, $"{field.FormName}Details.cshtml");
            //    }
            //    else
            //    {
            //        return "Table Id Not Matched";
            //    }
            //}


            //try
            //{
            //    File.WriteAllText(filePath, sb.ToString());
            //    Console.WriteLine($"File created: {filePath}");
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"Error writing file: {ex.Message}");
            //}


            //return sb.ToString();
            //string projectFolderName = $"{projectName}_{clientName}";
            //string filePath = string.Empty;

            //// Determine folder and filename based on whether it's a detail or main form
            //bool isDetailsForm = table.HeaderTablename != null;

            //string directoryPath = isDetailsForm
            //    ? $@"C:\ClientProject\{projectFolderName}\DynamicFormBuilder_UI\Views\{table.HeaderTablename}"
            //    : $@"C:\ClientProject\{projectFolderName}\DynamicFormBuilder_UI\Views\{table.Name}";

            //if (!Directory.Exists(directoryPath))
            //{
            //    Directory.CreateDirectory(directoryPath);
            //}

            //foreach (var field in fields)
            //{
            //    if ((isDetailsForm && table.HeaderTablename != null) ||
            //        (!isDetailsForm && table.Name == field.TableName))
            //    {
            //        string formName = field.FormName ?? table.Name; // fallback
            //        string fileName = $"{formName}Details.cshtml";

            //        filePath = Path.Combine(directoryPath, fileName);
            //        break; // Assuming one file per form, exit after setting filePath
            //    }
            //    else
            //    {
            //        return "Table Id Not Matched";
            //    }
            //}

            //try
            //{
            //    File.WriteAllText(filePath, sb.ToString());
            //    Console.WriteLine($"File created: {filePath}");
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"Error writing file: {ex.Message}");
            //}

            //return sb.ToString();
            // string projectFolderName = $"{projectName}_{clientName}";
            string projectFolderName = $@"{clientName}\{projectName}";

            string directoryPath;
            string filePath = "";

            string signatureDirectory = $@"C:\ClientProject\{projectFolderName}\Presentation\ClientProjectBuilder.Api\wwwroot\image\";
            if (!Directory.Exists(signatureDirectory))
            {
                Directory.CreateDirectory(signatureDirectory);
            }

            if (isDetailsForm)
            {
                // Folder = HeaderTablename, file = {table.Name}Details1.cshtml
                if (string.IsNullOrEmpty(table.HeaderTableName))
                {
                    return "Header table name is missing for details form.";
                }

                directoryPath = $@"C:\ClientProject\{projectFolderName}\Presentation\ClientProjectBuilder.MvcUI\Views\{table.HeaderTableName}";
                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                string formName = string.IsNullOrEmpty(parentForm?.Name)
                    ? parentForm?.TableName ?? "Unknown"
                    : parentForm.Name;

                filePath = Path.Combine(directoryPath, $"{formName}Details1.cshtml");
            }
            else
            {
                // Folder = table.Name, file = {field.FormName}Details.cshtml
                directoryPath = $@"C:\ClientProject\{projectFolderName}\Presentation\ClientProjectBuilder.MvcUI\Views\{table.Name}";
                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                foreach (var field in fields)
                {
                    if (table.Name == field.TableName)
                    {
                        string formName = field.FormName ?? table.Name;
                        filePath = Path.Combine(directoryPath, $"{formName}Details.cshtml");
                        break;
                    }
                }

                if (string.IsNullOrEmpty(filePath))
                {
                    return "Table Id Not Matched for main form.";
                }
            }

            try
            {
                File.WriteAllText(filePath, sb.ToString());
                Console.WriteLine($"File created: {filePath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error writing file: {ex.Message}");
            }

            return sb.ToString();
        }
    }
}


