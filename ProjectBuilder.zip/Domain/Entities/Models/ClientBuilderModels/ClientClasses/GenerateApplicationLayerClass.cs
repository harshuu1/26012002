﻿using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using System.Text;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateApplicationLayerClass
    {
        #region Helper Method

        private static string GetCSharpType(string dbType)
        {
            dbType = (dbType ?? "").Trim().ToLower();
            return Enum.TryParse<PKTypeEnum>(dbType, true, out var type)
                ? type.GetDescription()
                : PKTypeEnum.Int.GetDescription();
        }

        #endregion

        #region Application Layer For Controller

        public void GenerateApplicationLayer(ClientTable table, string modelName, string ProjectName, string ClientName, IEnumerable<ClientForm> FormList, IEnumerable<ClientFieldDefinition> AddEditFields, List<ClientActionDetail> formAction)
        {
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Application\Application\Modules";

            string modelFolderPath = Path.Combine(directoryPath, modelName);

            // Subfolders
            string commandsFolder = Path.Combine(modelFolderPath, "Commands");
            string handlersFolder = Path.Combine(modelFolderPath, "Handlers");
            string queriesFolder = Path.Combine(modelFolderPath, "Queries");

            // Create all directories if they don’t exist
            Directory.CreateDirectory(commandsFolder);
            Directory.CreateDirectory(handlersFolder);
            Directory.CreateDirectory(queriesFolder);

            var sb = new StringBuilder();

            var ckType = table.PrimaryKeyType?.ToString()?.Trim().ToLowerInvariant() ?? "int";
            var ckreturnType = GetCSharpType((table.PrimaryKeyType ?? "").Trim().ToLower());

            #region Query

            sb.AppendLine($"using Entities.Models.{modelName};");
            sb.AppendLine("using Entities.Models.Request;");
            sb.AppendLine("using Entities.Models.Response;");
            sb.AppendLine("using MediatR;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{modelName}.Queries");
            sb.AppendLine("{");

            sb.AppendLine($"     public sealed record GetAll{modelName}sQuery() : IRequest<IEnumerable<{modelName}Model>>;");
            sb.AppendLine($"     public sealed record Get{modelName}ByIdQuery({ckreturnType} Id) : IRequest<{modelName}Model>;");
            sb.AppendLine($"     public sealed record Get{modelName}Query(Request Request) : IRequest<Response>;");

            if (table.IsHierarchical)
            {
                sb.AppendLine($"     public sealed record GetHierarchyQuery : IRequest<List<{modelName}Model>>;");
            }

            if (FormList.Any(x => x.IsAddToList == true))
            {
                sb.AppendLine($"     public sealed record GetSelected{modelName}sQuery() : IRequest<List<{modelName}Model>>;");
            }

            //if (table.HeaderTableId > 0)
            //{
            //    foreach (var field in AddEditFields)
            //    {
            //        if (field.TypeName == "dropdown")
            //        {
            //            sb.AppendLine($"     public sealed record Get{table.Name}By{table.HeaderTableName}IdQuery(int Id) : IRequest<IEnumerable<{modelName}Model>>;");




            //            var sBuilder = new StringBuilder();

            //            sBuilder.AppendLine("using MediatR;");
            //            sBuilder.AppendLine("using Interfaces;");
            //            sBuilder.AppendLine($"using Entities.Models.{modelName};");
            //            sBuilder.AppendLine($"using Application.Modules.{modelName}.Queries;");


            //            sBuilder.AppendLine();
            //            sBuilder.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
            //            sBuilder.AppendLine("{");
            //            sBuilder.AppendLine($"    public class Get{table.Name}By{table.HeaderTableName}IdHandler(I{modelName} context) : IRequestHandler<Get{table.Name}By{table.HeaderTableName}IdQuery, IEnumerable<{modelName}Model>>");
            //            sBuilder.AppendLine("    {");
            //            sBuilder.AppendLine($"        private readonly I{modelName} _context = context;");
            //            sBuilder.AppendLine();
            //            sBuilder.AppendLine($"        public async Task<IEnumerable<{modelName}Model>> Handle(Get{table.Name}By{table.HeaderTableName}IdQuery request, CancellationToken cancellationToken)");
            //            sBuilder.AppendLine("        {");
            //            sBuilder.AppendLine($"            return await _context.Get{table.Name}By{table.HeaderTableName}Id(request.Id);");
            //            sBuilder.AppendLine("        }");
            //            sBuilder.AppendLine("    }");
            //            sBuilder.AppendLine("}");

            //            var getById = Path.Combine(handlersFolder, $"Get{table.Name}By{table.HeaderTableName}IdHandler.cs");
            //            File.WriteAllText(getById, sBuilder.ToString());

            //        }
            //    }

            //}

            sb.AppendLine("}");


            string fileName = $"{modelName}Queries.cs";
            string filePath = Path.Combine(queriesFolder, fileName);

            // Ensure directory exists
            Directory.CreateDirectory(queriesFolder);

            // Write file to disk
            File.WriteAllText(filePath, sb.ToString());

            #endregion

            #region Command

            var stringBuilder = new StringBuilder();


            stringBuilder.AppendLine($"using Entities.Models.{modelName};");
            stringBuilder.AppendLine("using Entities.Models.CreationResponse;");
            stringBuilder.AppendLine("using MediatR;");

            stringBuilder.AppendLine();
            stringBuilder.AppendLine($"namespace Application.Modules.{modelName}.Commands");
            stringBuilder.AppendLine("{");

            stringBuilder.AppendLine($"     public sealed record Create{modelName}Command({modelName}Model {modelName}) : IRequest<CreationResponseModel<{ckreturnType}>>;");
            stringBuilder.AppendLine($"     public sealed record Update{modelName}Command({modelName}Model {modelName}) : IRequest<CreationResponseModel<{ckreturnType}>>;");
            stringBuilder.AppendLine($"     public sealed record Delete{modelName}Command({ckreturnType} Id) : IRequest<string>;");

            foreach (var formItem in FormList)
            {
                stringBuilder.AppendLine($"     public sealed record Save{formItem.Name}Command({modelName}Model {modelName}) : IRequest<CreationResponseModel<{ckreturnType}>>;");
            }

            if (FormList.Any(x => x.IsAddToList == true))
            {
                stringBuilder.AppendLine($"     public sealed record AddTo{modelName}ListCommand(List<int> {modelName}Ids) : IRequest<string>;");
                stringBuilder.AppendLine($"     public sealed record Clear{modelName}ListCommand() : IRequest<string>;");
            }

            stringBuilder.AppendLine("}");

            string commandFileName = $"{modelName}Commands.cs";
            string commandFilePath = Path.Combine(commandsFolder, commandFileName);

            // Ensure directory exists
            Directory.CreateDirectory(commandsFolder);

            // Write file to disk
            File.WriteAllText(commandFilePath, stringBuilder.ToString());

            #endregion

            #region Handler

            #region GetAll

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Entities.Models.{modelName};");
            sb.AppendLine($"using Application.Modules.{modelName}.Queries;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class GetAll{modelName}sHandler(I{modelName} context) : IRequestHandler<GetAll{modelName}sQuery, IEnumerable<{modelName}Model>>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{modelName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<IEnumerable<{modelName}Model>> Handle(GetAll{modelName}sQuery request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine($"            return await _context.GetAll{modelName}();");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            var getAllHandler = Path.Combine(handlersFolder, $"GetAll{modelName}sHandler.cs");
            File.WriteAllText(getAllHandler, sb.ToString());

            #endregion

            #region GetById

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Entities.Models.{modelName};");
            sb.AppendLine($"using Application.Modules.{modelName}.Queries;");


            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class Get{modelName}ByIdHandler(I{modelName} context) : IRequestHandler<Get{modelName}ByIdQuery, {modelName}Model>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{modelName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<{modelName}Model> Handle(Get{modelName}ByIdQuery request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine($"            return await _context.Get{modelName}ById(request.Id);");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");


            var getByIdHandler = Path.Combine(handlersFolder, $"Get{modelName}ByIdHandler.cs");
            File.WriteAllText(getByIdHandler, sb.ToString());

            #endregion

            #region Create

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{modelName}.Commands;");
            sb.AppendLine("using Entities.Models.CreationResponse;");
            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class Create{modelName}Handler(I{modelName} context) : IRequestHandler<Create{modelName}Command, CreationResponseModel<{ckreturnType}>>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{modelName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<CreationResponseModel<{ckreturnType}>> Handle(Create{modelName}Command request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine($"            return await _context.Create{modelName}(request.{modelName});");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            var createHandler = Path.Combine(handlersFolder, $"Create{modelName}Handler.cs");
            File.WriteAllText(createHandler, sb.ToString());

            #endregion

            #region Update

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{modelName}.Commands;");
            sb.AppendLine("using Entities.Models.CreationResponse;");
            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class Update{modelName}Handler(I{modelName} context) : IRequestHandler<Update{modelName}Command, CreationResponseModel<{ckreturnType}>>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{modelName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<CreationResponseModel<{ckreturnType}>> Handle(Update{modelName}Command request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine($"            return await _context.Update{modelName}(request.{modelName});");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            var updateHandler = Path.Combine(handlersFolder, $"Update{modelName}Handler.cs");
            File.WriteAllText(updateHandler, sb.ToString());

            #endregion

            #region Delete

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{modelName}.Commands;");
            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class Delete{modelName}Handler(I{modelName} context) : IRequestHandler<Delete{modelName}Command, string>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{modelName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<string> Handle(Delete{modelName}Command request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine($"            return await _context.Delete{modelName}(request.Id);");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            var deleteHandler = Path.Combine(handlersFolder, $"Delete{modelName}Handler.cs");
            File.WriteAllText(deleteHandler, sb.ToString());

            #endregion

            #region Server Side Pagination

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{modelName}.Queries;");
            sb.AppendLine("using Entities.Models.Response;");
            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class Get{modelName}Handler(I{modelName} context) : IRequestHandler<Get{modelName}Query, Response>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{modelName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<Response> Handle(Get{modelName}Query request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine($"            var result = await _context.Get{modelName}(request.Request);");
            sb.AppendLine("            return result;");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");


            var getHandler = Path.Combine(handlersFolder, $"Get{modelName}Handler.cs");
            File.WriteAllText(getHandler, sb.ToString());

            #endregion

            #region Save For Each Form

            foreach (var formItem in FormList)
            {
                sb.Clear();
                sb.AppendLine("using MediatR;");
                sb.AppendLine("using Interfaces;");
                sb.AppendLine("using Entities.Models.CreationResponse;");
                sb.AppendLine($"using Application.Modules.{modelName}.Commands;");
                sb.AppendLine();
                sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
                sb.AppendLine("{");
                sb.AppendLine($"    public class Save{formItem.Name}CommandHandler(I{modelName} context) : IRequestHandler<Save{formItem.Name}Command, CreationResponseModel<{ckreturnType}>>");
                sb.AppendLine("    {");
                sb.AppendLine($"        private readonly I{modelName} _context = context;");
                sb.AppendLine();
                sb.AppendLine($"        public async Task<CreationResponseModel<{ckreturnType}>> Handle(Save{formItem.Name}Command request, CancellationToken cancellationToken)");
                sb.AppendLine("        {");
                sb.AppendLine($"             return await _context.Save{formItem.Name}(request.{modelName});");
                sb.AppendLine("        }");
                sb.AppendLine("    }");
                sb.AppendLine("}");


                var saveFormHandler = Path.Combine(handlersFolder, $"Save{formItem.Name}Handler.cs");
                File.WriteAllText(saveFormHandler, sb.ToString());
            }

            #endregion

            #region For Hierarchical

            if (table.IsHierarchical)
            {
                sb.Clear();
                sb.AppendLine("using MediatR;");
                sb.AppendLine("using Interfaces;");
                sb.AppendLine($"using Entities.Models.{modelName};");
                sb.AppendLine($"using Application.Modules.{modelName}.Queries;");
                sb.AppendLine();
                sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
                sb.AppendLine("{");
                sb.AppendLine($"    public class GetHierarchyQueryHandler(I{modelName} context) : IRequestHandler<GetHierarchyQuery, List<{modelName}Model>>");
                sb.AppendLine("    {");
                sb.AppendLine($"        private readonly I{modelName} _context = context;");
                sb.AppendLine();
                sb.AppendLine($"        public async Task<List<{modelName}Model>> Handle(GetHierarchyQuery request, CancellationToken cancellationToken)");
                sb.AppendLine("        {");
                sb.AppendLine($"             return await _context.GetHierarchyAsync();");
                sb.AppendLine("        }");
                sb.AppendLine("    }");
                sb.AppendLine("}");


                var saveFormHandler = Path.Combine(handlersFolder, $"GetHierarchyQueryHandler.cs");
                File.WriteAllText(saveFormHandler, sb.ToString());
            }

            #endregion

            #region For AddToList

            if (FormList.Any(x => x.IsAddToList == true))
            {

                sb.Clear();
                sb.AppendLine("using MediatR;");
                sb.AppendLine("using Interfaces;");
                sb.AppendLine($"using Application.Modules.{modelName}.Commands;");
                sb.AppendLine();
                sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
                sb.AppendLine("{");
                sb.AppendLine($"    public class AddTo{modelName}ListHandler(I{modelName} context) : IRequestHandler<AddTo{modelName}ListCommand, string>");
                sb.AppendLine("    {");
                sb.AppendLine($"        private readonly I{modelName} _context = context;");
                sb.AppendLine();
                sb.AppendLine($"        public async Task<string> Handle(AddTo{modelName}ListCommand request, CancellationToken cancellationToken)");
                sb.AppendLine("        {");
                sb.AppendLine($"             return await _context.Add{modelName}sToList(request.{modelName}Ids);");
                sb.AppendLine("        }");
                sb.AppendLine("    }");
                sb.AppendLine("}");


                var addListHandler = Path.Combine(handlersFolder, $"AddTo{modelName}ListHandler.cs");
                File.WriteAllText(addListHandler, sb.ToString());


                sb.Clear();
                sb.AppendLine("using MediatR;");
                sb.AppendLine("using Interfaces;");
                sb.AppendLine($"using Application.Modules.{modelName}.Queries;");
                sb.AppendLine($"using Entities.Models.{modelName};");
                sb.AppendLine();
                sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
                sb.AppendLine("{");
                sb.AppendLine($"    public class GetSelected{modelName}sHandler(I{modelName} context) : IRequestHandler<GetSelected{modelName}sQuery, List<{modelName}Model>>");
                sb.AppendLine("    {");
                sb.AppendLine($"        private readonly I{modelName} _context = context;");
                sb.AppendLine();
                sb.AppendLine($"        public async Task<List<{modelName}Model>> Handle(GetSelected{modelName}sQuery request, CancellationToken cancellationToken)");
                sb.AppendLine("        {");
                sb.AppendLine($"             return await _context.GetSelected{modelName}s();");
                sb.AppendLine("        }");
                sb.AppendLine("    }");
                sb.AppendLine("}");


                var getListHandler = Path.Combine(handlersFolder, $"GetSelected{modelName}sHandler.cs");
                File.WriteAllText(getListHandler, sb.ToString());


                sb.Clear();
                sb.AppendLine("using MediatR;");
                sb.AppendLine("using Interfaces;");
                sb.AppendLine($"using Entities.Models.{modelName};");
                sb.AppendLine($"using Application.Modules.{modelName}.Commands;");
                sb.AppendLine();
                sb.AppendLine($"namespace Application.Modules.{modelName}.Handlers");
                sb.AppendLine("{");
                sb.AppendLine($"    public class Clear{modelName}ListHandler(I{modelName} context) : IRequestHandler<Clear{modelName}ListCommand, string>");
                sb.AppendLine("    {");
                sb.AppendLine($"        private readonly I{modelName} _context = context;");
                sb.AppendLine();
                sb.AppendLine($"        public async Task<string> Handle(Clear{modelName}ListCommand request, CancellationToken cancellationToken)");
                sb.AppendLine("        {");
                sb.AppendLine($"             return await _context.ClearList();");
                sb.AppendLine("        }");
                sb.AppendLine("    }");
                sb.AppendLine("}");


                var clearListHandler = Path.Combine(handlersFolder, $"Clear{modelName}ListHandler.cs");
                File.WriteAllText(clearListHandler, sb.ToString());

            }

            #endregion

            #region For Mapping Fields

            foreach (var field in AddEditFields)
            {
                if (field.TypeName == "checkboxgroup" || field.TypeName == "Multiselect")
                {
                    GenerateForMappingLayer(table, field, ProjectName, ClientName);
                }

            }

            #endregion

            #endregion

        }

        #endregion

        #region Application Layer For Mapping Fields (CheckboxGroup, Multiselect)

        public void GenerateForMappingLayer(ClientTable table, ClientFieldDefinition checkboxField, string ProjectName, string ClientName)
        {

            string modelName = table.Name;

            string mapTableName = $"{table.Name}_{checkboxField.Name}";

            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Application\Application\Modules";

            string modelFolderPath = Path.Combine(directoryPath, mapTableName);

            // Subfolders
            string commandsFolder = Path.Combine(modelFolderPath, "Commands");
            string handlersFolder = Path.Combine(modelFolderPath, "Handlers");
            string queriesFolder = Path.Combine(modelFolderPath, "Queries");

            // Create all directories if they don’t exist
            Directory.CreateDirectory(commandsFolder);
            Directory.CreateDirectory(handlersFolder);
            Directory.CreateDirectory(queriesFolder);

            #region Query

            var sb = new StringBuilder();

            sb.AppendLine($"using Entities.Models.{modelName};");
            sb.AppendLine("using MediatR;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{mapTableName}.Queries");
            sb.AppendLine("{");

            sb.AppendLine($"    public sealed record GetAll{mapTableName}Query : IRequest<List<{mapTableName}Model>>;");
            sb.AppendLine($"    public sealed record Get{mapTableName}ByIdQuery(int Id) : IRequest<{mapTableName}Model>;");


            sb.AppendLine("}");


            string fileName = $"{mapTableName}Queries.cs";
            string filePath = Path.Combine(queriesFolder, fileName);

            // Ensure directory exists
            Directory.CreateDirectory(queriesFolder);

            // Write file to disk
            File.WriteAllText(filePath, sb.ToString());

            #endregion

            #region Command

            var ckType = table.PrimaryKeyType?.ToString()?.Trim().ToLowerInvariant() ?? "int";
            var ckreturnType = GetCSharpType((table.PrimaryKeyType ?? "").Trim().ToLower());

            sb.Clear();

            sb.AppendLine($"using Entities.Models.{modelName};");
            sb.AppendLine("using MediatR;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{mapTableName}.Commands");
            sb.AppendLine("{");

            sb.AppendLine($"    public sealed record Update{mapTableName}Command(int Id, {mapTableName}Model Entity) : IRequest<int>;");
            sb.AppendLine($"    public sealed record Save{mapTableName}Command({ckreturnType} {table.Name?.ToLower() ?? ""}Id, List<{mapTableName}Model> Entities) : IRequest<object>;");
            sb.AppendLine($"    public sealed record Delete{mapTableName}ByParentIdCommand(int ParentId) : IRequest<bool>;");


            sb.AppendLine("}");


            var commandPath = Path.Combine(commandsFolder, $"{mapTableName}Commands.cs");
            File.WriteAllText(commandPath, sb.ToString());

            #endregion

            #region Handlers

            #region GetAll

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Entities.Models.{modelName};");
            sb.AppendLine($"using Application.Modules.{mapTableName}.Queries;");
            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{mapTableName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class GetAll{mapTableName}QueryHandler(I{mapTableName} context) : IRequestHandler<GetAll{mapTableName}Query, List<{mapTableName}Model>>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{mapTableName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<List<{mapTableName}Model>> Handle(GetAll{mapTableName}Query request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine("            return await _context.GetAllAsync();");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");


            var getHandler = Path.Combine(handlersFolder, $"GetAll{mapTableName}QueryHandler.cs");
            File.WriteAllText(getHandler, sb.ToString());

            #endregion

            #region GetById

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Entities.Models.{modelName};");
            sb.AppendLine($"using Application.Modules.{mapTableName}.Queries;");
            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{mapTableName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class Get{mapTableName}ByIdQueryHandler(I{mapTableName} context) : IRequestHandler<Get{mapTableName}ByIdQuery, {mapTableName}Model>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{mapTableName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<{mapTableName}Model> Handle(Get{mapTableName}ByIdQuery request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine("            return await _context.GetByIdAsync(request.Id);");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");


            var getByIdHandler = Path.Combine(handlersFolder, $"Get{mapTableName}ByIdQueryHandler.cs");
            File.WriteAllText(getByIdHandler, sb.ToString());

            #endregion

            #region Update

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{mapTableName}.Commands;");
            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{mapTableName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class Update{mapTableName}CommandHandler(I{mapTableName} context) : IRequestHandler<Update{mapTableName}Command, int>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{mapTableName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<int> Handle(Update{mapTableName}Command request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine("            return await _context.UpdateAsync(request.Id, request.Entity);");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");


            var updateHandler = Path.Combine(handlersFolder, $"Update{mapTableName}CommandHandlerHandler.cs");
            File.WriteAllText(updateHandler, sb.ToString());

            #endregion

            #region Delete

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{mapTableName}.Commands;");
            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{mapTableName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class Delete{mapTableName}ByParentIdCommandHandler(I{mapTableName} context) : IRequestHandler<Delete{mapTableName}ByParentIdCommand, bool>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{mapTableName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<bool> Handle(Delete{mapTableName}ByParentIdCommand request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine("            return await _context.DeleteByParentIdAsync(request.ParentId);");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");


            var deleteHandler = Path.Combine(handlersFolder, $"Delete{mapTableName}ByParentIdCommandHandler.cs");
            File.WriteAllText(deleteHandler, sb.ToString());

            #endregion

            #region Create

            sb.Clear();
            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{mapTableName}.Commands;");
            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{mapTableName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class Save{mapTableName}CommandHandler(I{mapTableName} context) : IRequestHandler<Save{mapTableName}Command, object>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{mapTableName} _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<object> Handle(Save{mapTableName}Command request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine($"            var {table.Name?.ToLower() ?? ""}Id = request.{table.Name?.ToLower() ?? ""}Id;");
            sb.AppendLine();
            var idCondition = ckreturnType == "Guid"
                ? $"{table.Name?.ToLower() ?? ""}Id != Guid.Empty"
                : $"{table.Name?.ToLower() ?? ""}Id > 0";
            sb.AppendLine($"            if ({idCondition})");
            sb.AppendLine("            {");
            sb.AppendLine($"                await _context.UpdateMappingsAsync({table.Name?.ToLower() ?? ""}Id, request.Entities);");
            sb.AppendLine("            }");
            sb.AppendLine("            else");
            sb.AppendLine("            {");
            sb.AppendLine($"                {table.Name?.ToLower() ?? ""}Id = await _context.CreateAsync(request.Entities.First());");
            sb.AppendLine("            }");
            sb.AppendLine();
            sb.AppendLine($"            return new {{ id = {table.Name?.ToLower() ?? ""}Id, message = \"Saved successfully\" }};");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");



            var createHandler = Path.Combine(handlersFolder, $"Save{mapTableName}CommandHandler.cs");
            File.WriteAllText(createHandler, sb.ToString());

            #endregion

            #endregion

        }

        #endregion

        #region Application Layer For Document

        public void GenerateApplicationLayerForDocument(ClientForm document, string ProjectName, string ClientName)
        {
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Application\Application\Modules";
            var FormName = document.Name ?? "Default";

            string modelFolderPath = Path.Combine(directoryPath, FormName);

            // Subfolders
            string commandsFolder = Path.Combine(modelFolderPath, "Commands");
            string handlersFolder = Path.Combine(modelFolderPath, "Handlers");
            string queriesFolder = Path.Combine(modelFolderPath, "Queries");

            // Create all directories if they don’t exist
            Directory.CreateDirectory(commandsFolder);
            Directory.CreateDirectory(handlersFolder);
            Directory.CreateDirectory(queriesFolder);

            var sb = new StringBuilder();

            #region Query

            sb.AppendLine($"using Entities.Models.{document.TableName};");
            sb.AppendLine("using Entities.Models.Request;");
            sb.AppendLine("using Entities.Models.Response;");
            sb.AppendLine("using MediatR;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{FormName}.Queries");
            sb.AppendLine("{");

            sb.AppendLine($"     public sealed record GetDocumentByIdCommand(int Id) : IRequest<{FormName}DocumentModel>;");
            sb.AppendLine($"     public sealed record GetDocumentsCommand(Request Request, int Id) : IRequest<Response>;");


            sb.AppendLine("}");


            string fileName = $"{FormName}Queries.cs";
            string filePath = Path.Combine(queriesFolder, fileName);

            // Ensure directory exists
            Directory.CreateDirectory(queriesFolder);

            // Write file to disk
            File.WriteAllText(filePath, sb.ToString());

            #endregion

            #region Command

            var stringBuilder = new StringBuilder();


            stringBuilder.AppendLine($"using Entities.Models.{document.TableName};");
            stringBuilder.AppendLine("using MediatR;");

            stringBuilder.AppendLine();
            stringBuilder.AppendLine($"namespace Application.Modules.{FormName}.Commands");
            stringBuilder.AppendLine("{");

            stringBuilder.AppendLine($"     public sealed record CreateDocumentCommand({FormName}DocumentModel Document) : IRequest<object>;");
            stringBuilder.AppendLine($"     public sealed record UpdateDocumentCommand({FormName}DocumentModel Document, int Id) : IRequest<object>;");
            stringBuilder.AppendLine($"     public sealed record DeleteDocumentCommand(int Id) : IRequest<object>;");

            stringBuilder.AppendLine("}");

            string commandFileName = $"{FormName}Commands.cs";
            string commandFilePath = Path.Combine(commandsFolder, commandFileName);

            // Ensure directory exists
            Directory.CreateDirectory(commandsFolder);

            // Write file to disk
            File.WriteAllText(commandFilePath, stringBuilder.ToString());

            #endregion

            #region Handlers

            #region Create

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{FormName}.Commands;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{FormName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class CreateDocumentCommandHandler(I{FormName}Document context) : IRequestHandler<CreateDocumentCommand, object>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{FormName}Document _context = context;");
            sb.AppendLine();
            sb.AppendLine("        public async Task<object> Handle(CreateDocumentCommand request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine("            var result = await _context.CreateDocument(request.Document);");
            sb.AppendLine("            return new {message = \"Document created successfully\",data = result};");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            var createHandler = Path.Combine(handlersFolder, "CreateDocumentCommandHandler.cs");
            File.WriteAllText(createHandler, sb.ToString());

            #endregion

            #region Update

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{FormName}.Commands;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{FormName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class UpdateDocumentCommandHandler(I{FormName}Document context) : IRequestHandler<UpdateDocumentCommand, object>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{FormName}Document _context = context;");
            sb.AppendLine();
            sb.AppendLine("        public async Task<object> Handle(UpdateDocumentCommand request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine("            var result = await _context.UpdateDocument(request.Document, request.Id);");
            sb.AppendLine("            return new {message = \"Document updated successfully\",data = result};");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            var updateHandler = Path.Combine(handlersFolder, "UpdateDocumentCommandHandler.cs");
            File.WriteAllText(updateHandler, sb.ToString());

            #endregion

            #region Delete

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Application.Modules.{FormName}.Commands;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{FormName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class DeleteDocumentCommandHandler(I{FormName}Document context) : IRequestHandler<DeleteDocumentCommand, object>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{FormName}Document _context = context;");
            sb.AppendLine();
            sb.AppendLine("        public async Task<object> Handle(DeleteDocumentCommand request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine("            var result = await _context.DeleteDocument(request.Id);");
            sb.AppendLine("            return result == \"Id does not exist\"");
            sb.AppendLine("                 ? new { message = \"Document not found\" }");
            sb.AppendLine("                 : new { message = \"Document deleted successfully\", data = result };");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            var deleteHandler = Path.Combine(handlersFolder, "DeleteDocumentCommandHandler.cs");
            File.WriteAllText(deleteHandler, sb.ToString());

            #endregion

            #region GetById

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Entities.Models.{document.TableName};");
            sb.AppendLine($"using Application.Modules.{FormName}.Queries;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{FormName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class GetDocumentByIdCommandHandler(I{FormName}Document context) : IRequestHandler<GetDocumentByIdCommand, {FormName}DocumentModel>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{FormName}Document _context = context;");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<{FormName}DocumentModel> Handle(GetDocumentByIdCommand request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine("            return await _context.GetDocumentById(request.Id);");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            var getByIdHandler = Path.Combine(handlersFolder, "GetDocumentByIdCommandHandler.cs");
            File.WriteAllText(getByIdHandler, sb.ToString());

            #endregion

            #region GetAll Server Side Pagination

            sb.Clear();

            sb.AppendLine("using MediatR;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine("using Entities.Models.Response;");
            sb.AppendLine($"using Application.Modules.{FormName}.Queries;");

            sb.AppendLine();
            sb.AppendLine($"namespace Application.Modules.{FormName}.Handlers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class GetDocumentsCommandHandler(I{FormName}Document context) : IRequestHandler<GetDocumentsCommand, Response>");
            sb.AppendLine("    {");
            sb.AppendLine($"        private readonly I{FormName}Document _context = context;");
            sb.AppendLine();
            sb.AppendLine("        public async Task<Response> Handle(GetDocumentsCommand request, CancellationToken cancellationToken)");
            sb.AppendLine("        {");
            sb.AppendLine("            return await _context.GetDocument(request.Request, request.Id);");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            var getAllHandler = Path.Combine(handlersFolder, "GetDocumentsCommandHandler.cs");
            File.WriteAllText(getAllHandler, sb.ToString());

            #endregion

            #endregion
        }

        #endregion
    }
}