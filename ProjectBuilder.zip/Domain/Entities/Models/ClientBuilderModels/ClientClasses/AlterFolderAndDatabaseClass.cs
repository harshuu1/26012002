﻿using Dapper;
using DapperDB;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class AlterFolderAndDatabaseClass(DapperDbContext.DbContext context, IConfiguration configuration)
    {

        private readonly DapperDbContext.DbContext _context = context;

        public async Task ModifyClientMenu(string databaseName, int clientId, int projectId, string adminDatabaseName)
        {
            string getClientMenuQuery = $@"
        SELECT ID, Name, Description, ParentID, CreatedBy, CreatedDate, 
               ModifiedBy, ModifiedDate, FormPath, ImportProfilePath, 
               FormId, MenuIcon, IsCardView, IsClientMenu, InOrder, ImportProfile, TableId 
        FROM [{databaseName}].[dbo].[ClientMenu]";

            string getAdminMenuQuery = $@"
        SELECT m.ID, m.Name, m.Description, m.ParentID, m.CreatedBy, m.CreatedDate,
               m.ModifiedBy, m.ModifiedDate,
               CASE 
                   WHEN m.FormId IS NULL THEN NULL
                   ELSE ISNULL(t.Name + '/', '') + ISNULL(f.Name, '') + 
                       CASE WHEN m.IsCardView = 1 THEN 'Details' ELSE 'List' END
               END AS FormPath,
               CASE WHEN m.ImportProfile = 1 THEN 'ImportProfile/ImportProfileList' ELSE NULL END AS ImportProfilePath,
               m.FormId, m.MenuIcon, m.IsCardView, m.IsClientMenu, m.InOrder, m.ImportProfile,
               t.ID AS TableId
        FROM [{adminDatabaseName}].[{DatabaseSchema.Config.ToSchemaName()}].[Menu] m
        LEFT JOIN [{adminDatabaseName}].[{DatabaseSchema.Config.ToSchemaName()}].[Form] f ON m.FormId = f.ID
        LEFT JOIN [{adminDatabaseName}].[{DatabaseSchema.Config.ToSchemaName()}].[TableDefination] t ON m.TableId = t.ID
        WHERE NOT (m.FormId IS NULL AND m.ParentId IS NULL AND NOT EXISTS (
                  SELECT 1 FROM [{adminDatabaseName}].[{DatabaseSchema.Config.ToSchemaName()}].[Menu] m2 WHERE m2.ParentId = m.ID))
              OR m.ImportProfile = 0 AND m.FormId IS NULL
              OR m.ImportProfile = 1
        ORDER BY m.ID";

            string insertDataQuery = $@"
        INSERT INTO [{databaseName}].[dbo].[ClientMenu] (
            Name, Description, ParentID, CreatedBy, CreatedDate, 
            ModifiedBy, ModifiedDate, FormPath, ImportProfilePath, MenuIcon,
            FormId, IsCardView, IsClientMenu, ImportProfile, TableId)
        VALUES (
            @Name, @Description, @ParentID, @CreatedBy, @CreatedDate,
            @ModifiedBy, @ModifiedDate, @FormPath, @ImportProfilePath, @MenuIcon,
            @FormId, @IsCardView, @IsClientMenu, @ImportProfile, @TableId)";

            string updateQuery = $@"
        UPDATE cm
        SET Name = @Name,
            Description = @Description,
            ParentID = @ParentID,
            ModifiedBy = @ModifiedBy,
            ModifiedDate = @ModifiedDate,
            FormPath = @FormPath,
            ImportProfilePath = @ImportProfilePath,
            MenuIcon = @MenuIcon,
            FormId = @FormId,
            IsCardView = @IsCardView,
            IsClientMenu = @IsClientMenu,
            ImportProfile = @ImportProfile,
            TableId = @TableId
        FROM [{databaseName}].[dbo].[ClientMenu] cm
        WHERE cm.ID = @ID";

            using (var connection = _context.CreateConnection())
            {
                var getAdminMenu = (await connection.QueryAsync(getAdminMenuQuery)).ToList();
                var getClientMenu = (await connection.QueryAsync(getClientMenuQuery)).ToList();

                // Logical keys for mapping
                var adminMenuMap = getAdminMenu.Where(m => m.Name != null)
                    .ToDictionary(m => $"{m.Name}|{clientId}|{projectId}", m => m);

                var clientMenuMap = getClientMenu.Where(m => m.Name != null)
                    .ToDictionary(m => $"{m.Name}|{clientId}|{projectId}", m => m);

                var newMenus = new List<dynamic>();
                var menuForUpdate = new List<dynamic>();
                var existingAdminKeys = new HashSet<string>(adminMenuMap.Keys);

                foreach (var key in adminMenuMap.Keys)
                {
                    var adminMenu = adminMenuMap[key];
                    if (!clientMenuMap.TryGetValue(key, out dynamic? clientMenu))
                    {
                        newMenus.Add(adminMenu);
                    }
                    else if (!(clientMenu.IsClientMenu ?? false))
                    {
                        adminMenu.ID = clientMenu.ID;
                        menuForUpdate.Add(adminMenu);
                    }
                }

                // Insert new menus
                foreach (var menu in newMenus)
                {
                    await connection.ExecuteAsync(insertDataQuery, new
                    {
                        menu.Name,
                        menu.Description,
                        menu.ParentID,
                        menu.CreatedBy,
                        menu.CreatedDate,
                        menu.ModifiedBy,
                        menu.ModifiedDate,
                        menu.FormPath,
                        menu.ImportProfilePath,
                        menu.FormId,
                        menu.MenuIcon,
                        menu.IsCardView,
                        IsClientMenu = false,
                        menu.ImportProfile,
                        menu.TableId
                    });
                }

                // Update existing menus
                foreach (var menu in menuForUpdate)
                {
                    await connection.ExecuteAsync(updateQuery, new
                    {
                        menu.ID,
                        menu.Name,
                        menu.Description,
                        menu.ParentID,
                        menu.ModifiedBy,
                        menu.ModifiedDate,
                        menu.FormPath,
                        menu.ImportProfilePath,
                        menu.MenuIcon,
                        menu.FormId,
                        menu.IsCardView,
                        menu.IsClientMenu,
                        menu.ImportProfile,
                        menu.TableId
                    });
                }

                // Delete dynamic menus not present in admin
                var dynamicClientMenusToDelete = getClientMenu
                    .Where(m => m.IsClientMenu == false && m.ID != null)
                    .Where(m => !existingAdminKeys.Contains($"{m.Name}|{clientId}|{projectId}"))
                    .Select(m => (int)m.ID)
                    .ToList();

                if (dynamicClientMenusToDelete.Count > 0)
                {
                    var deleteQuery = $"DELETE FROM [{databaseName}].[dbo].[ClientMenu] WHERE ID IN @Ids";
                    await connection.ExecuteAsync(deleteQuery, new { Ids = dynamicClientMenusToDelete });
                }
            }

            // Insert base static menus
            //var createMenuTableClass = new CreateMenuTableClass(_context);
            //await createMenuTableClass.InsertBaseStaticMenus(databaseName, clientId, projectId);

            // Re-sequence InOrder based on Admin menu order (static first, then dynamic)
            string resequenceSql = $@"
        ;WITH OrderedMenus AS (
            SELECT cm.ID,
                   ROW_NUMBER() OVER (
                       ORDER BY 
                           CASE WHEN cm.IsClientMenu = 0 THEN 0 ELSE 1 END,
                           a.ID
                   ) AS NewOrder
            FROM [{databaseName}].[dbo].[ClientMenu] cm
            LEFT JOIN [{adminDatabaseName}].[{DatabaseSchema.Config.ToSchemaName()}].[Menu] a ON cm.Name = a.Name
        )
        UPDATE cm
        SET InOrder = om.NewOrder
        FROM [{databaseName}].[dbo].[ClientMenu] cm
        INNER JOIN OrderedMenus om ON cm.ID = om.ID;";

            using (var connection = _context.CreateConnection())
            {
                await connection.ExecuteAsync(resequenceSql);
            }

            // Fix ParentIDs
            string fixParentIdSql = $@"
        UPDATE child
        SET child.ParentID = parent.ID
        FROM [{databaseName}].[dbo].[ClientMenu] child
        INNER JOIN [{adminDatabaseName}].[{DatabaseSchema.Config.ToSchemaName()}].[Menu] mChild ON mChild.Name = child.Name
        INNER JOIN [{adminDatabaseName}].[{DatabaseSchema.Config.ToSchemaName()}].[Menu] mParent ON mChild.ParentID = mParent.ID
        INNER JOIN [{databaseName}].[dbo].[ClientMenu] parent ON parent.Name = mParent.Name
        WHERE child.ParentID IS NULL OR child.ParentID != parent.ID";

            using (var connection = _context.CreateConnection())
            {
                await connection.ExecuteAsync(fixParentIdSql);
            }
        }

        public async Task ModifyClientForm(string databaseName, int clientId, int projectId, string adminDatabaseName)
        {
            string getClientFormQuery = $@"
    SELECT ID, Name, TableId,CreatedBy, CreatedDate,
           ModifiedBy, ModifiedDate, DetailTableId, ParentId, ListProfileId, CardViewProfileId,DisplayName
    FROM [{databaseName}].[dbo].[ClientForm]";

            string getAdminFormQuery = $@"
    SELECT f.ID, f.Name, f.TableId, f.CreatedBy, f.CreatedDate,
           f.ModifiedBy, f.ModifiedDate, f.DetailTableId, f.ParentId, f.ListProfileId, f.CardViewProfileId,f.DisplayName
    FROM [{adminDatabaseName}].[{DatabaseSchema.Config.ToSchemaName()}].[Form] f
    ORDER BY f.ID ASC";

            string insertQuery = $@"
    INSERT INTO [{databaseName}].[dbo].[ClientForm] (
        ID, Name, TableId, CreatedBy, CreatedDate,
        ModifiedBy, ModifiedDate, DetailTableId, ParentId, ListProfileId, CardViewProfileId,DisplayName
    )
    VALUES (
        @ID, @Name, @TableId,@CreatedBy, @CreatedDate,
        @ModifiedBy, @ModifiedDate, @DetailTableId, @ParentId, @ListProfileId, @CardViewProfileId,@DisplayName
    )";

            string updateQuery = $@"
    UPDATE [{databaseName}].[dbo].[ClientForm]
    SET Name = @Name,
        TableId = @TableId,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = @ModifiedDate,
        DetailTableId = @DetailTableId,
        ParentId = @ParentId,
        ListProfileId = @ListProfileId,
        CardViewProfileId = @CardViewProfileId,
        DisplayName=@DisplayName
    WHERE ID = @ID";

            using var connection = _context.CreateConnection();
            // ✅ Fetch both with dynamic parameters
            var adminForms = (await connection.QueryAsync(getAdminFormQuery, null)).ToList();
            var clientForms = (await connection.QueryAsync(getClientFormQuery, null)).ToList();

            var clientFormIds = clientForms.Select(f => (int)f.ID).ToHashSet();
            var adminFormIds = adminForms.Select(f => (int)f.ID).ToHashSet();

            var newForms = new List<dynamic>();
            var updateForms = new List<dynamic>();

            foreach (var adminForm in adminForms)
            {
                if (!clientFormIds.Contains((int)adminForm.ID))
                {
                    newForms.Add(adminForm); // Insert new
                }
                else
                {
                    updateForms.Add(adminForm); // Update existing
                }
            }

            // Insert new forms
            foreach (var form in newForms)
            {
                await connection.ExecuteAsync(insertQuery, new
                {
                    form.ID,
                    form.Name,
                    form.TableId,
                    form.CreatedBy,
                    form.CreatedDate,
                    form.ModifiedBy,
                    form.ModifiedDate,
                    form.DetailTableId,
                    form.ParentId,
                    form.ListProfileId,
                    form.CardViewProfileId,
                    form.DisplayName
                });
            }

            //  Update existing forms
            foreach (var form in updateForms)
            {
                await connection.ExecuteAsync(updateQuery, new
                {
                    form.ID,
                    form.Name,
                    form.TableId,
                    form.ModifiedBy,
                    form.ModifiedDate,
                    form.DetailTableId,
                    form.ParentId,
                    form.ListProfileId,
                    form.CardViewProfileId,
                    form.DisplayName
                });
            }

            //  Delete extra forms from client DB that are not in admin DB
            var formsToDelete = clientForms
                .Where(f => !adminFormIds.Contains((int)f.ID))
                .Select(f => (int)f.ID)
                .ToList();

            if (formsToDelete.Count != 0)
            {
                var deletePermissionQuery = $"DELETE FROM [{databaseName}].[dbo].[FormPermission] WHERE FormId IN @Ids";
                await connection.ExecuteAsync(deletePermissionQuery, new { Ids = formsToDelete });

                var deleteQuery = $"DELETE FROM [{databaseName}].[dbo].[ClientForm] WHERE ID IN @Ids";
                await connection.ExecuteAsync(deleteQuery, new { Ids = formsToDelete });
            }
        }
        public static async Task InsertRestoredTablesMetadata(string databaseName, string newConnectionString)
        {
            using var connection = new SqlConnection(newConnectionString);
            await connection.OpenAsync();

            // 1. Create the metadata table in the target database (no DB prefix needed)
            var createTableQuery = @"
                     CREATE TABLE dbo.DefaultTable (
                         TableName NVARCHAR(255),
                         IsDefault BIT);";
            await connection.ExecuteAsync(createTableQuery);

            // 2. Query table names from the specified database (use database prefix in query)
            var tableNames = await connection.QueryAsync<string>(
                $"SELECT name FROM [{databaseName}].sys.tables WHERE is_ms_shipped = 0");

            // 3. Insert each table name into the metadata table in current DB connection
            var insertQuery = "INSERT INTO dbo.DefaultTable (TableName, IsDefault) VALUES (@TableName, 1)";
            foreach (var tableName in tableNames)
            {
                await connection.ExecuteAsync(insertQuery, new { TableName = tableName });
            }
            await connection.ExecuteAsync(insertQuery, new { TableName = "ClientMenu" });
        }


        //Getting DefaultTable
        public static async Task<List<string>> GetRestoredTables(string newConnectionString)
        {
            using var connection = new SqlConnection(newConnectionString);
            await connection.OpenAsync();

            var query = "SELECT TableName FROM dbo.DefaultTable";

            var result = await connection.QueryAsync<string>(query);

            return result.ToList();
        }

        //method to drop table and drop constraints foreign key and drop column where use as forign key
        public static async Task<List<string>> DropTableWithForeignKey(List<string> droppedTables, string databaseName, string newConnectionString)
        {
            //ArgumentNullException.ThrowIfNull(databaseName);

            using (var connection = new SqlConnection(newConnectionString))
            {
                await connection.OpenAsync();

                foreach (var dropTable in droppedTables)
                {
                    var fkQuery = @"
         SELECT 
             fk.name AS ForeignKeyName, 
             tp.name AS ParentTableName,
             cp.name AS ParentColumnName
         FROM sys.foreign_keys fk
         INNER JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
         INNER JOIN sys.tables tp ON fkc.parent_object_id = tp.object_id
         INNER JOIN sys.columns cp ON fkc.parent_object_id = cp.object_id AND fkc.parent_column_id = cp.column_id
         INNER JOIN sys.tables tr ON fkc.referenced_object_id = tr.object_id
         WHERE tr.name = @TableName";


                    var foreignKeys = await connection.QueryAsync<(string ForeignKeyName, string ParentTableName, string ParentColumnName)>(
                        fkQuery, new { TableName = dropTable });

                    foreach (var (ForeignKeyName, ParentTableName, ParentColumnName) in foreignKeys)
                    {
                        // Drop the foreign key constraint
                        var dropFkSql = $"ALTER TABLE [dbo].[{ParentTableName}] DROP CONSTRAINT [{ForeignKeyName}]";
                        await connection.ExecuteAsync(dropFkSql);
                        Console.WriteLine($"Dropped foreign key: {ForeignKeyName} on table {ParentTableName}");

                        // Drop the foreign key column (parent column)
                        var dropColumnSql = $"ALTER TABLE [dbo].[{ParentTableName}] DROP COLUMN [{ParentColumnName}]";
                        await connection.ExecuteAsync(dropColumnSql);
                        Console.WriteLine($"Dropped column: {ParentColumnName} from table {ParentTableName}");
                    }

                    // Drop the referenced table
                    var dropTableSql = $"DROP TABLE [dbo].[{dropTable}]";
                    await connection.ExecuteAsync(dropTableSql);
                    Console.WriteLine($"Dropped table: {dropTable}");
                }
            }

            return droppedTables;
        }

        public async Task AlterDatabase(int existDatabase, string databaseName, string newConnectionString, IEnumerable<ClientTable> GetallTableList, IEnumerable<string> mappingtableList, IEnumerable<string> documentMappingTables)
        {
            List<string> defaultTable = [];
            AlterFolderAndDatabaseClass alterFolderAndDatabaseClass = new(_context, configuration);
            using var connection = _context.CreateConnection();
            if (existDatabase > 0)
            {
                var alterDbQuery = $"ALTER DATABASE {databaseName} SET MULTI_USER WITH ROLLBACK IMMEDIATE";
                await connection.ExecuteAsync(alterDbQuery);
                defaultTable = await GetRestoredTables(newConnectionString);
                var clientTable = $"SELECT TABLE_SCHEMA, TABLE_NAME FROM {databaseName}.INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE';";
                var clientQueryExecute = await connection.QueryAsync(clientTable);
                //  Extract list of table names from clientQueryExecute (dynamic)
                var clientTableNames = clientQueryExecute                                   //16
                    .Select(r => (string)r.TABLE_NAME)
                    .ToList();
                var adminTableNames = GetallTableList.Select(r => r.Name).ToList();        //3              
                                                                                           //Tables in client DB but NOT in admin list extra tables on client DB
                var extraTables = clientTableNames                                         //13
                    .Except(adminTableNames, StringComparer.OrdinalIgnoreCase)
                    .ToList();
                var allProtectedTables = new HashSet<string>(
                mappingtableList.Concat(documentMappingTables),
                StringComparer.OrdinalIgnoreCase);

                var droppedTables = extraTables
                    .Except(defaultTable, StringComparer.OrdinalIgnoreCase)
                    .Except(allProtectedTables, StringComparer.OrdinalIgnoreCase)

                    .ToList();
                if (droppedTables.Count > 0)
                {
                    await DropTableWithForeignKey(droppedTables, databaseName, newConnectionString);
                }
            }
        }

        public async Task AlterTableAndFields(ClientTable table, string databaseName, IEnumerable<ClientFieldDefinition> result, string checkExistTable)
        {
            BuildCreateTableQueryClass buildCreateTableQueryClass = new(_context, configuration);
            using var connection = _context.CreateConnection();
            var checkColumns = $"SELECT COLUMN_NAME FROM {databaseName}.information_schema.columns WHERE table_name = '{table.Name}'";
            var existingColumns = await connection.QueryAsync<string>(checkColumns);//18
            var newColumns = result.Select(r => r.Name ?? "").ToList(); // names from Admin Fielddefinition ---9
                                                                        //deleted Fields include Default Fields
            var deletedColumns = existingColumns.Except(newColumns, StringComparer.OrdinalIgnoreCase).ToList();
            var defaultColumns = new List<string> { "ID", "CreatedBy", "ModifiedBy", "CreatedDate", "ModifiedDate" };

            var filteredDeletedColumns = deletedColumns.Except(defaultColumns, StringComparer.OrdinalIgnoreCase).ToList();

            var missingColumnNames = newColumns.Except(existingColumns); // get new Fields

            var missingFieldDefinitions = result
                .Where(r => missingColumnNames.Contains(r.Name))
                .ToList();


            var alterTable = buildCreateTableQueryClass.BuildCreateTableQuery(table, table.IsHierarchical, missingFieldDefinitions, checkExistTable, databaseName, newColumns, existingColumns, filteredDeletedColumns
            );

            if (!string.IsNullOrWhiteSpace(alterTable))
            {
                await connection.ExecuteAsync(alterTable);
            }
        }
    }
}
