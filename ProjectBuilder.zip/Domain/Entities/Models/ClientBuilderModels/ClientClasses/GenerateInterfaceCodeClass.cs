﻿using System.Text;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateInterfaceCodeClass
    {
        public static void GenerateCheckboxInterfaceCode(ClientTable table, ClientFieldDefinition checkboxField, string ProjectName, string ClientName)
        {
            var sb = new StringBuilder();
            var ckType = table.PrimaryKeyType?.ToString()?.Trim().ToLowerInvariant() ?? "int";
            var ckreturnType = GetCSharpType((table.PrimaryKeyType ?? "").Trim().ToLower());
            string mapModelName = $"{table.Name}_{checkboxField.Name}";
            string interfaceName = $"I{mapModelName}";

            sb.AppendLine("using System.Collections.Generic;");
            sb.AppendLine("using System.Threading.Tasks;");
            sb.AppendLine("using System.Data;");
            sb.AppendLine($"using Entities.Models.{table.Name};");
            sb.AppendLine();
            sb.AppendLine("namespace Interfaces");
            sb.AppendLine("{");
            sb.AppendLine($"    public interface {interfaceName}");
            sb.AppendLine("    {");
            sb.AppendLine($"        Task<List<{mapModelName}Model>> GetAllAsync();");
            sb.AppendLine($"        Task<{mapModelName}Model> GetByIdAsync(int id);");
            sb.AppendLine($"        Task<{ckreturnType}> CreateAsync({mapModelName}Model model);");
            sb.AppendLine($"        Task<int> UpdateAsync(int id, {mapModelName}Model model);");
            sb.AppendLine($"        Task UpdateMappingsAsync({ckreturnType} id, List<{mapModelName}Model> mappings);");
            sb.AppendLine($"        Task<bool> DeleteByParentIdAsync(int id);");
            //sb.AppendLine($"        Task<string> GetEmailBodyByTemplateId(int templateId);");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            // Build file path
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Domain\Interfaces";
            if (!Directory.Exists(directoryPath))
                Directory.CreateDirectory(directoryPath);

            string filePath = Path.Combine(directoryPath, $"{interfaceName}.cs");

            File.WriteAllText(filePath, sb.ToString());
        }

        private static string GetCSharpType(string dbType)
        {
            dbType = (dbType ?? "").Trim().ToLower();
            return Enum.TryParse<PKTypeEnum>(dbType, true, out var type)
                ? type.GetDescription()
                : PKTypeEnum.Int.GetDescription();
        }

        private static string GetClassType(string dbType)
        {
            dbType = dbType?.Trim().ToLower() ?? string.Empty;

            return Enum.TryParse<PKTypeEnum>(dbType, true, out var type)
                ? type.GetResponseDescription(asCreationResponse: true)
                : PKTypeEnum.Int.GetResponseDescription(asCreationResponse: true);
        }

        public  void GenerateInterfaceCode(ClientTable table, string ProjectName, string ClientName, IEnumerable<ClientForm> formList, List<ClientCardViewFields> cardViewFields, IEnumerable<ClientFieldDefinition> Fields)

        {
            //ArgumentNullException.ThrowIfNull(cardViewFields);

            var pkType = table.PrimaryKeyType?.ToString()?.Trim().ToLowerInvariant() ?? "int";
            var responseClassName = GetClassType(pkType);
            var returnType = GetCSharpType((table.PrimaryKeyType ?? "").Trim().ToLower());


            var sb = new StringBuilder();

            sb.AppendLine("using System.Collections.Generic;");

            sb.AppendLine("using Interfaces;");

            sb.AppendLine("using Entities.Models.Request;");

            sb.AppendLine("using Entities.Models.Response;");
            
            sb.AppendLine("using Entities.Models.CreationResponse;");
            
            sb.AppendLine($"using Entities.Models.{table.Name};");

            foreach (var fields in Fields)
            {
                if (!string.IsNullOrEmpty(fields.ParentFieldName) && fields.ParentSourceTblName != fields.SourceHeaderTableName && fields.IsLazyLoaded == true)
                {
                    sb.AppendLine("   using Entities.Models.PagedResult;");
                    sb.AppendLine($"   using Entities.Models.{fields.SourceTableName};");
                }
            }

            sb.AppendLine();

            sb.AppendLine($"namespace Interfaces");

            sb.AppendLine("{");

            sb.AppendLine($"    public interface I{table.Name}");

            sb.AppendLine("    {");

            sb.AppendLine($"       public Task<Response>Get{table.Name}(Request request);");

            sb.AppendLine($"       public Task<List<{table.Name}Model>> GetAll{table.Name}();");


            sb.AppendLine($"       public Task<{table.Name}Model> Get{table.Name}ById({returnType} id);");

            //sb.AppendLine($"       public Task<string>Create{tableName}({tableName} {tableName.ToLower()},int tableId, int formIdCollection);");
            sb.AppendLine($"       public Task<{responseClassName}>Create{table.Name}({table.Name}Model {table.Name.ToLower()});");

            sb.AppendLine($"       public Task<{responseClassName}>Update{table.Name}({table.Name}Model {table.Name.ToLower()});");

            sb.AppendLine($"       public Task<string>Delete{table.Name}({returnType} id);");
            if (table.IsHierarchical)
            {
                sb.AppendLine($"       public Task<string>RemoveChild{table.Name}({returnType} id);");
            }

            sb.AppendLine($"       public Task<string> GetEmailBodyByTemplateId(int templateId);");

            sb.AppendLine($"       public Task<string> GetAllEmailsByRole(string roleIds);");

            sb.AppendLine($"       public Task<IEnumerable<{table.Name}ReferenceResponse>> Get{table.Name}ReferencesAsync({returnType} {table.Name.ToLower()}Id);");

            if (formList.Any(x => x.IsAddToList == true))
            {
                sb.AppendLine($"       public Task<string> Add{table.Name}sToList(List<int> {table.Name.ToLower()}Ids);");
                sb.AppendLine($"       public Task<List<{table.Name}Model>> GetSelected{table.Name}s();");
                sb.AppendLine($"       public Task<string> ClearList();");
            }
            foreach (var formItem in formList)
            {
                sb.AppendLine($"       public Task<{responseClassName}>Save{formItem.Name}({table.Name}Model {table.Name.ToLower()});");
                //sb.AppendLine($"       public Task<CreationResponse>Update{formItem.Name}({tableName} {tableName.ToLower()});");

            }
            //if (table.HeaderTableId > 0 )
            //{
            //    foreach (var fields in Fields)
            //    {
                    
            //        if(fields.TypeName == "dropdown")
            //        {
            //             sb.AppendLine($"   Task<IEnumerable<{table.Name}Model>>  Get{table.Name}By{table.HeaderTableName}Id({returnType} Id);");
            //        }
            //    }
            //}
            foreach (var fields in Fields)
            {
                if (!string.IsNullOrEmpty(fields.ParentFieldName) && fields.ParentSourceTblName != fields.SourceHeaderTableName && fields.IsLazyLoaded == true)
                {
                    sb.AppendLine($"   Task<PagedResultModel<{fields.SourceTableName}Model>>  Get{fields.SourceTableName}By{fields.ParentFieldName}Id({returnType} Id,int skip, int take);");
                }
               else if (!string.IsNullOrEmpty(fields.ParentFieldName) && fields.ParentSourceTblName != /*fields.SourceHeaderTableName*/ null)
                {

                    //sb.AppendLine($"   Task<IEnumerable<{fields.SourceTableName}>>  Get{fields.SourceTableName}By{fields.ParentFieldName}(int {fields.ParentFieldName},int skip, int take);");
                    sb.AppendLine($"   Task<IEnumerable<{fields.SourceTableName}>>  Get{fields.SourceTableName}By{fields.ParentFieldName}({returnType} {fields.ParentFieldName});");
                }
            }

            if (table.IsHierarchical)
            {
                sb.AppendLine($"  public  Task<List<{table.Name}Model>> GetHierarchyAsync();");
            }

            sb.AppendLine("    }");

            sb.AppendLine("}");

            string projectfoldername = $@"{ClientName}\{ProjectName}";

            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Domain\Interfaces";

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            // Create the file path (using the table name as the file name)
            string filePath = Path.Combine(directoryPath, $"I{table.Name}.cs");

            // Write the model code to the file
            File.WriteAllText(filePath, sb.ToString());
            foreach (var field in Fields)
            {
                if (field.TypeName == "checkboxgroup" || field.TypeName == "Multiselect")
                {
                    GenerateCheckboxInterfaceCode(table, field, ProjectName, ClientName);
                }
            }
        }
    }
}
