﻿using Dapper;
using Entities.Enums;
using Microsoft.Data.SqlClient;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateImportProfileViews
    {
        //        public async Task CopyExcelFilesToTargetAsync(string sourceRootFolder, string targetRootFolder, string originalConnectionString, string newConnectionString)
        //        {
        //            string sourceExcelFolder = Path.Combine(sourceRootFolder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), "wwwroot", "ImportProfileExcelSheets");
        //            string targetExcelFolder = Path.Combine(targetRootFolder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), "wwwroot", "ImportProfileExcelSheets");

        //            string sourceCsvFolder = Path.Combine(sourceRootFolder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), "wwwroot", "ImportProfileCVSSheets");
        //            string targetCsvFolder = Path.Combine(targetRootFolder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), "wwwroot", "ImportProfileCVSSheets");

        //            if (!Directory.Exists(targetExcelFolder))
        //                Directory.CreateDirectory(targetExcelFolder);

        //            if (!Directory.Exists(targetCsvFolder))
        //                Directory.CreateDirectory(targetCsvFolder);

        //            using var sourceConn = new SqlConnection(originalConnectionString);
        //            using var targetConn = new SqlConnection(newConnectionString);

        //            sourceConn.Open();
        //            targetConn.Open();

        //            var profiles = (await sourceConn.QueryAsync<ImportProfile>("SELECT ip.*,md.MenuId,m.Name AS MenuName FROM ImportProfile ip INNER JOIN MenuDetail md ON ip.ID = md.ImportProfileId INNER JOIN Menu m ON md.MenuId = m.Id")).ToList();

        //            foreach (var profile in profiles)
        //            {
        //                string sanitizedName = string.Concat(profile.Name.Where(c => !Path.GetInvalidFileNameChars().Contains(c)));
        //                string excelFileName = $"{sanitizedName}.xlsx";
        //                string csvFileName = $"{sanitizedName}.csv";

        //                string sourceExcelFilePath = Path.Combine(sourceExcelFolder, excelFileName);
        //                string targetExcelFilePath = Path.Combine(targetExcelFolder, excelFileName);

        //                string sourceCsvFilePath = Path.Combine(sourceCsvFolder, csvFileName);
        //                string targetCsvFilePath = Path.Combine(targetCsvFolder, csvFileName);

        //                if (File.Exists(sourceExcelFilePath))
        //                {
        //                    File.Copy(sourceExcelFilePath, targetExcelFilePath, overwrite: true);
        //                }
        //                else
        //                {
        //                    targetExcelFilePath = null; // or string.Empty if you prefer
        //                }

        //                if (File.Exists(sourceCsvFilePath))
        //                {
        //                    File.Copy(sourceCsvFilePath, targetCsvFilePath, overwrite: true);
        //                }
        //                else
        //                {
        //                    targetCsvFilePath = null;
        //                }

        //                string insertLogSql = @"
        //INSERT INTO ImportProfileImportLog (ImportProfileName, ExcelPath, CsvPath, TableName,TableId,MenuId,MenuName)
        //VALUES (@ImportProfileName, @ExcelPath, @CsvPath, @TableName,@TableId,@MenuId,@MenuName)";

        //                await targetConn.ExecuteAsync(insertLogSql, new
        //                {
        //                    ImportProfileName = profile.Name,
        //                    ExcelPath = targetExcelFilePath,
        //                    CsvPath = targetCsvFilePath,
        //                    TableName = profile.TableName,
        //                    TableId = profile.TableId,
        //                    MenuId=profile.MenuId,
        //                    MenuName=profile.MenuName
        //                });
        //            }

        //            // Step 1: Get profile IDs from your earlier query
        //            var profileIds = profiles.Select(p => p.ID).ToList();

        //            // Step 2: Fetch related ImportProfileField rows
        //            var importProfileFields = (await sourceConn.QueryAsync<ImportProfileField>(
        //                @"SELECT ImportProfileId, FieldId, FieldName, TabIndex, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate 
        //      FROM ImportProfileField 
        //      WHERE ImportProfileId IN @Ids", new { Ids = profileIds }
        //            )).ToList();

        //            // Step 3: Insert into ImportProfileFieldMapping
        //            string insertFieldSql = @"
        //INSERT INTO ImportProfileFieldMapping 
        //(ProfileId, FieldId, FieldName, TabIndex, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
        //VALUES 
        //(@ProfileId, @FieldId, @FieldName, @TabIndex, @CreatedBy, @CreatedDate, @ModifiedBy, @ModifiedDate)";

        //            foreach (var field in importProfileFields)
        //            {
        //                await targetConn.ExecuteAsync(insertFieldSql, new
        //                {
        //                    ProfileId = field.ImportProfileId,
        //                    FieldId = field.FieldId,
        //                    FieldName = field.FieldName,
        //                    TabIndex = field.TabIndex,
        //                    CreatedBy = field.CreatedBy,
        //                    CreatedDate = field.CreatedDate,
        //                    ModifiedBy = field.ModifiedBy,
        //                    ModifiedDate = field.ModifiedDate
        //                });
        //            }

        //        }



        //        public async Task CopyExcelFilesToTargetAsync(string sourceRootFolder, string targetRootFolder, string originalConnectionString, string newConnectionString)
        //        {
        //            string sourceExcelFolder = Path.Combine(sourceRootFolder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), "wwwroot", "ImportProfileExcelSheets");
        //            string targetExcelFolder = Path.Combine(targetRootFolder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), "wwwroot", "ImportProfileExcelSheets");

        //            string sourceCsvFolder = Path.Combine(sourceRootFolder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), "wwwroot", "ImportProfileCVSSheets");
        //            string targetCsvFolder = Path.Combine(targetRootFolder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), "wwwroot", "ImportProfileCVSSheets");

        //            if (!Directory.Exists(targetExcelFolder))
        //                Directory.CreateDirectory(targetExcelFolder);

        //            if (!Directory.Exists(targetCsvFolder))
        //                Directory.CreateDirectory(targetCsvFolder);

        //            using var sourceConn = new SqlConnection(originalConnectionString);
        //            using var targetConn = new SqlConnection(newConnectionString);

        //            sourceConn.Open();
        //            targetConn.Open();

        //            var profiles = (await sourceConn.QueryAsync<ImportProfile>(
        //                @"SELECT ip.*, md.MenuId, m.Name AS MenuName 
        //          FROM ImportProfile ip 
        //          INNER JOIN MenuDetail md ON ip.ID = md.ImportProfileId 
        //          INNER JOIN Menu m ON md.MenuId = m.Id")).ToList();

        //            // Map: old ImportProfile.ID → new ImportProfileImportLog.ID
        //            var profileIdMap = new Dictionary<int, int>();

        //            foreach (var profile in profiles)
        //            {
        //                string sanitizedName = string.Concat(profile.Name.Where(c => !Path.GetInvalidFileNameChars().Contains(c)));
        //                string excelFileName = $"{sanitizedName}.xlsx";
        //                string csvFileName = $"{sanitizedName}.csv";

        //                string sourceExcelFilePath = Path.Combine(sourceExcelFolder, excelFileName);
        //                string targetExcelFilePath = Path.Combine(targetExcelFolder, excelFileName);

        //                string sourceCsvFilePath = Path.Combine(sourceCsvFolder, csvFileName);
        //                string targetCsvFilePath = Path.Combine(targetCsvFolder, csvFileName);

        //                bool copied = false;

        //                if (File.Exists(sourceExcelFilePath))
        //                {
        //                    File.Copy(sourceExcelFilePath, targetExcelFilePath, overwrite: true);
        //                    copied = true;
        //                }
        //                else
        //                {
        //                    targetExcelFilePath = null;
        //                }

        //                if (File.Exists(sourceCsvFilePath))
        //                {
        //                    File.Copy(sourceCsvFilePath, targetCsvFilePath, overwrite: true);
        //                    copied = true;
        //                }
        //                else
        //                {
        //                    targetCsvFilePath = null;
        //                }

        //                if (copied)
        //                {
        //                    string insertLogSql = @"
        //INSERT INTO ImportProfileImportLog 
        //(ImportProfileName, ExcelPath, CsvPath, TableName, TableId, MenuId, MenuName)
        //OUTPUT INSERTED.ID
        //VALUES 
        //(@ImportProfileName, @ExcelPath, @CsvPath, @TableName, @TableId, @MenuId, @MenuName)";

        //                    int importLogId = await targetConn.ExecuteScalarAsync<int>(insertLogSql, new
        //                    {
        //                        ImportProfileName = profile.Name,
        //                        ExcelPath = targetExcelFilePath,
        //                        CsvPath = targetCsvFilePath,
        //                        TableName = profile.TableName,
        //                        TableId = profile.TableId,
        //                        MenuId = profile.MenuId,
        //                        MenuName = profile.MenuName
        //                    });

        //                    profileIdMap[profile.ID] = importLogId; // map old profile ID → new import log ID
        //                }
        //            }

        //            if (profileIdMap.Any())
        //            {
        //                // Fetch fields only for profiles that were logged
        //                var importProfileFields = (await sourceConn.QueryAsync<ImportProfileField>(
        //                    @"SELECT ProfileId, FieldId, FieldName, TabIndex, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate 
        //              FROM ImportProfileField 
        //              WHERE ProfileId IN @Ids", new { Ids = profileIdMap.Keys.ToList() }
        //                )).ToList();

        //                string insertFieldSql = @"
        //INSERT INTO ImportProfileFieldMapping 
        //(ProfileId,  FieldName, TabIndex)
        //VALUES 
        //(@ProfileId,  @FieldName, @TabIndex)";

        //                foreach (var field in importProfileFields)
        //                {
        //                    if (profileIdMap.TryGetValue(field.ProfileId, out int newProfileId))
        //                    {
        //                        await targetConn.ExecuteAsync(insertFieldSql, new
        //                        {
        //                            ProfileId = newProfileId, // ✅ Mapped FK to ImportProfileImportLog

        //                            FieldName = field.FieldName,
        //                            TabIndex = field.TabIndex
        //                        });
        //                    }
        //                }
        //            }
        //        }

        public  void CopyProjectData(string sourceConnectionString, string targetConnectionString, int clientId, int projectId)
        {
            string tableDefinitionQuery = $@"
         SELECT * FROM [{DatabaseSchema.Config.ToSchemaName()}].TableDefination;
    ";

            string sectionQuery = $@"
       SELECT s.*
FROM [{DatabaseSchema.Config.ToSchemaName()}].section s
INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination t ON s.TableId = t.ID;
    ";

            string fieldDefinitionQuery = $@"
       SELECT f.*
FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldDefination f
INNER JOIN [{DatabaseSchema.Config.ToSchemaName()}].TableDefination t ON f.TableId = t.ID;
    ";

            using var sourceConnection = new SqlConnection(sourceConnectionString);
            using var targetConnection = new SqlConnection(targetConnectionString);
            sourceConnection.Open();
            targetConnection.Open();
            // Step 0: Delete existing records in reverse dependency order
            string deleteControlTypeQuery = @"
            DELETE FROM ControlType;
           
        ";
            string deleteFieldTypeQuery = @"
            DELETE FROM FieldType;
           
        ";
            string deleteFieldDefQuery = @"
            DELETE f
            FROM FieldDefination f
            INNER JOIN TableDefination t ON f.TableId = t.ID;
        ";

            string deleteSectionQuery = @"
            DELETE s
            FROM section s
            INNER JOIN TableDefination t ON s.TableId = t.ID;
        ";


            string deletepkQuery = @"
            DELETE FROM PrimaryKeyType;
        ";
            string deleteTableDefQuery = @"
            DELETE FROM TableDefination;
        ";


            // Execute deletions
        
            targetConnection.Execute(deletepkQuery);
            targetConnection.Execute(deleteFieldDefQuery, null);
            targetConnection.Execute(deleteSectionQuery, null);
            targetConnection.Execute(deleteTableDefQuery, null);
            targetConnection.Execute(deleteFieldTypeQuery);
            targetConnection.Execute(deleteControlTypeQuery);



            var pkTypes = sourceConnection.Query($"SELECT * FROM [{DatabaseSchema.Config.ToSchemaName()}].PrimaryKeyType").ToList();
            targetConnection.Execute("SET IDENTITY_INSERT PrimaryKeyType ON");
            foreach (var row in pkTypes)
            {
                string insertQuery = @"
        INSERT INTO PrimaryKeyType (
            ID, Name,Type, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate
        )
        VALUES (
            @ID, @Name,@Type,@CreatedBy, @CreatedDate, @ModifiedBy, @ModifiedDate
        )";

                targetConnection.Execute(insertQuery, (object)row);
            }
            targetConnection.Execute("SET IDENTITY_INSERT PrimaryKeyType OFF");

            // Step 1: Copy TableDefination
            var tableDefinitions = sourceConnection.Query(tableDefinitionQuery, null).ToList();
            targetConnection.Execute("SET IDENTITY_INSERT TableDefination ON");
            foreach (var row in tableDefinitions)
            {
                string insertQuery = @"
                INSERT INTO TableDefination (
                    ID, Name, CreatedBy, CreatedDate,
                    ModifiedBy, ModifiedDate, IsHierarchical, ParentId,PrimaryKeyType
                )
                VALUES (
                    @ID, @Name, @CreatedBy, @CreatedDate,
                    @ModifiedBy, @ModifiedDate, @IsHierarchical, @ParentId,@PrimaryKeyType
                )";

                targetConnection.Execute(insertQuery, (object)row);

            }
            // Turn OFF IDENTITY_INSERT
            targetConnection.Execute("SET IDENTITY_INSERT TableDefination OFF");
            // Step 2: Copy section
            var sections = sourceConnection.Query(sectionQuery, null).ToList();
            targetConnection.Execute("SET IDENTITY_INSERT section ON");
            foreach (var row in sections)
            {
                string insertQuery = @"
                INSERT INTO section (
                    ID, TableId, Name, [Order], Description,
                    CreatedBy, CreatedDate, ModifiedBy, ModifiedDate
                )
                VALUES (
                    @ID, @TableId, @Name, @Order, @Description,
                    @CreatedBy, @CreatedDate, @ModifiedBy, @ModifiedDate
                )";

                targetConnection.Execute(insertQuery, (object)row);

            }
            targetConnection.Execute("SET IDENTITY_INSERT section OFF");

            var ControlTypes = sourceConnection.Query($"SELECT * FROM [{DatabaseSchema.Config.ToSchemaName()}].ControlType").ToList();
            targetConnection.Execute("SET IDENTITY_INSERT ControlType ON");
            foreach (var row in ControlTypes)
            {
                string insertQuery = @"
        INSERT INTO ControlType (
            ID, Name, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate
        )
        VALUES (
            @ID, @Name, @CreatedBy, @CreatedDate, @ModifiedBy, @ModifiedDate
        )";

                targetConnection.Execute(insertQuery, (object)row);
            }
            targetConnection.Execute("SET IDENTITY_INSERT ControlType OFF");


            var fieldTypes = sourceConnection.Query($"SELECT * FROM [{DatabaseSchema.Config.ToSchemaName()}].FieldType").ToList();
            targetConnection.Execute("SET IDENTITY_INSERT FieldType ON");
            foreach (var row in fieldTypes)
            {
                string insertQuery = @"
        INSERT INTO FieldType (
            ID, Name, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate,DisplayName,ControlTypeId
        )
        VALUES (
            @ID, @Name, @CreatedBy, @CreatedDate, @ModifiedBy, @ModifiedDate,@DisplayName,@ControlTypeId
        )";

                targetConnection.Execute(insertQuery, (object)row);
            }
            targetConnection.Execute("SET IDENTITY_INSERT FieldType OFF");

            // Step 3: Copy fielddefinition
            var fieldDefinitions = sourceConnection.Query(fieldDefinitionQuery, null).ToList();
            targetConnection.Execute("SET IDENTITY_INSERT FieldDefination ON");
            foreach (var row in fieldDefinitions)
            {
                string insertQuery = @"
                INSERT INTO FieldDefination (
                    ID, Name, TableId, SectionId, Mandatory, DisplayName, Description,
                    DeleteFlag, UpdateFlag, TypeId, Length, Max, Precision, Scale,
                    TextFieldId, ValueId, SourceTableId, CreatedBy, CreatedDate,
                    ModifiedBy, ModifiedDate, ParentFieldId, FilterFieldId,
                    IsMultiColumn, FilterBy, IsLazyLoaded, SwitchLabel1, SwitchLabel2,
                    MinValue, MaxValue, SmallStep, LargeStep, ToolTip, Link,Orientation,ShowButton,Symbol,SymbolPosition
                )
                VALUES (
                    @ID, @Name, @TableId, @SectionId, @Mandatory, @DisplayName, @Description,
                    @DeleteFlag, @UpdateFlag, @TypeId, @Length, @Max, @Precision, @Scale,
                    @TextFieldId, @ValueId, @SourceTableId, @CreatedBy, @CreatedDate,
                    @ModifiedBy, @ModifiedDate, @ParentFieldId, @FilterFieldId,
                    @IsMultiColumn, @FilterBy, @IsLazyLoaded, @SwitchLabel1, @SwitchLabel2,
                    @MinValue, @MaxValue, @SmallStep, @LargeStep, @ToolTip, @Link,@Orientation,@ShowButton,@Symbol,@SymbolPosition
                
                )";

                targetConnection.Execute(insertQuery, (object)row);

            }
            targetConnection.Execute("SET IDENTITY_INSERT FieldDefination OFF");
        }



        //public void GenerateImportProfileAll(string projectName, string clientName)
        //{
        //    string projectfoldername = $@"{clientName}\{projectName}";


        //    // ---- 1. Model ----
        //    string modelFolder = $@"C:\ClientProject\{projectfoldername}\Models";
        //    Directory.CreateDirectory(modelFolder);
        //    string modelPath = Path.Combine(modelFolder, "ImportProfile.cs");

        //    var modelCode = new StringBuilder();
        //    modelCode.AppendLine("using System;");
        //    modelCode.AppendLine();
        //    modelCode.AppendLine("namespace Models");
        //    modelCode.AppendLine("{");
        //    modelCode.AppendLine("    public class ImportProfile");
        //    modelCode.AppendLine("    {");
        //    modelCode.AppendLine("        public int Id { get; set; }");
        //    modelCode.AppendLine("        public string ImportProfileName { get; set; }");
        //    modelCode.AppendLine("        public string TableName { get; set; }");
        //    modelCode.AppendLine("        public int TableId { get; set; }");
        //    modelCode.AppendLine("    }");
        //    modelCode.AppendLine("}");
        //    File.WriteAllText(modelPath, modelCode.ToString());

        //    // ---- 2. Interface ----
        //    string interfaceFolder = $@"C:\ClientProject\{projectfoldername}\Interface";
        //    Directory.CreateDirectory(interfaceFolder);
        //    string interfacePath = Path.Combine(interfaceFolder, "IImportProfileRepository.cs");

        //    var interfaceCode = new StringBuilder();
        //    interfaceCode.AppendLine("using System.Collections.Generic;");
        //    interfaceCode.AppendLine("using System.Threading.Tasks;");
        //    interfaceCode.AppendLine("using Models;");
        //    interfaceCode.AppendLine();
        //    interfaceCode.AppendLine("public interface IImportProfileRepository");
        //    interfaceCode.AppendLine("{");
        //    interfaceCode.AppendLine("    Task<IEnumerable<dynamic>> GetProfilesByMenuIdAsync(int tableId);");
        //    interfaceCode.AppendLine("    Task<ImportProfile> GetByIdAsync(int id);");
        //    interfaceCode.AppendLine("    Task<ImportProfile> GetByNameAsync(string profileName);");
        //    interfaceCode.AppendLine("}");
        //    File.WriteAllText(interfacePath, interfaceCode.ToString());

        //    // ---- 3. Repository ----
        //    string repoFolder = $@"C:\ClientProject\{projectfoldername}\Repository";
        //    Directory.CreateDirectory(repoFolder);
        //    string repoPath = Path.Combine(repoFolder, "ImportProfileRepository.cs");

        //    var repoCode = new StringBuilder();
        //    repoCode.AppendLine("using System.Collections.Generic;");
        //    repoCode.AppendLine("using System.Text;");
        //    repoCode.AppendLine("using System.Threading.Tasks;");
        //    repoCode.AppendLine("using System.Data.SqlClient;");
        //    repoCode.AppendLine("using Dapper;");
        //    repoCode.AppendLine("using DapperDbContext;");
        //    repoCode.AppendLine("using Models;");
        //    repoCode.AppendLine();
        //    repoCode.AppendLine("public class ImportProfileRepository : IImportProfileRepository");
        //    repoCode.AppendLine("{");
        //    repoCode.AppendLine("    private readonly DbContext _context;");
        //    repoCode.AppendLine();
        //    repoCode.AppendLine("    public ImportProfileRepository(DbContext context)");
        //    repoCode.AppendLine("    {");
        //    repoCode.AppendLine("        _context = context;");
        //    repoCode.AppendLine("    }");
        //    repoCode.AppendLine();
        //    repoCode.AppendLine("    public async Task<IEnumerable<dynamic>> GetProfilesByMenuIdAsync(int tableId)");
        //    repoCode.AppendLine("    {");
        //    repoCode.AppendLine("        var sb = new StringBuilder();");
        //    repoCode.AppendLine("        sb.AppendLine(\"SELECT\");");
        //    repoCode.AppendLine("        sb.AppendLine(\"    Id,\");");
        //    repoCode.AppendLine("        sb.AppendLine(\"    ImportProfileName,\");");
        //    repoCode.AppendLine("        sb.AppendLine(\"    ExcelPath,\");");
        //    repoCode.AppendLine("        sb.AppendLine(\"    TableName\");");
        //    repoCode.AppendLine("        sb.AppendLine(\"FROM ImportProfileImportLog\");");
        //    repoCode.AppendLine("        sb.AppendLine(\"WHERE tableId = @tableId\");");
        //    repoCode.AppendLine();
        //    repoCode.AppendLine("        string query = sb.ToString();");
        //    repoCode.AppendLine("        using (var connection = _context.CreateConnection())");
        //    repoCode.AppendLine("        {");
        //    repoCode.AppendLine("            return await connection.QueryAsync(query, new { tableId = tableId });");
        //    repoCode.AppendLine("        }");
        //    repoCode.AppendLine("    }");
        //    repoCode.AppendLine();
        //    repoCode.AppendLine("    public async Task<ImportProfile> GetByIdAsync(int id)");
        //    repoCode.AppendLine("    {");
        //    repoCode.AppendLine("        string sql = \"SELECT Id, ImportProfileName, TableName FROM ImportProfileImportLog WHERE Id = @Id\";");
        //    repoCode.AppendLine("        using (var connection = _context.CreateConnection())");
        //    repoCode.AppendLine("        {");
        //    repoCode.AppendLine("            return await connection.QueryFirstOrDefaultAsync<ImportProfile>(sql, new { Id = id });");
        //    repoCode.AppendLine("        }");
        //    repoCode.AppendLine("    }");
        //    repoCode.AppendLine();
        //    repoCode.AppendLine("    public async Task<ImportProfile> GetByNameAsync(string profileName)");
        //    repoCode.AppendLine("    {");
        //    repoCode.AppendLine("        var query = \"SELECT * FROM ImportProfileImportLog WHERE ImportProfileName = @ImportProfileName\";");
        //    repoCode.AppendLine("        using (var connection = _context.CreateConnection())");
        //    repoCode.AppendLine("        {");
        //    repoCode.AppendLine("            return await connection.QueryFirstOrDefaultAsync<ImportProfile>(query, new { ImportProfileName = profileName });");
        //    repoCode.AppendLine("        }");
        //    repoCode.AppendLine("    }");
        //    repoCode.AppendLine("}");
        //    File.WriteAllText(repoPath, repoCode.ToString());

        //    // ---- 4. API Controller ----
        //    string apiControllerFolder = $@"C:\ClientProject\{projectfoldername}\DynamicFormBuilder\Controllers";
        //    Directory.CreateDirectory(apiControllerFolder);
        //    string apiControllerPath = Path.Combine(apiControllerFolder, "ImportProfileController.cs");

        //    var apiControllerCode = new StringBuilder();
        //    apiControllerCode.AppendLine("using System.Text;");
        //    apiControllerCode.AppendLine("using Interface;");
        //    apiControllerCode.AppendLine("using Microsoft.AspNetCore.Http;");
        //    apiControllerCode.AppendLine("using Microsoft.AspNetCore.Mvc;");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("namespace DynamicFormBuilder.Controllers");
        //    apiControllerCode.AppendLine("{");
        //    apiControllerCode.AppendLine("    [Route(\"api/[controller]\")]");
        //    apiControllerCode.AppendLine("    [ApiController]");
        //    apiControllerCode.AppendLine("    public class ImportProfileController : ControllerBase");
        //    apiControllerCode.AppendLine("    {");
        //    apiControllerCode.AppendLine("        private readonly IImportProfileRepository _importProfileRepository;");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("        public ImportProfileController(IImportProfileRepository importProfileRepository)");
        //    apiControllerCode.AppendLine("        {");
        //    apiControllerCode.AppendLine("            _importProfileRepository = importProfileRepository;");
        //    apiControllerCode.AppendLine("        }");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("        [HttpGet(\"by-table/{tableId}\")]");
        //    apiControllerCode.AppendLine("        public async Task<IActionResult> GetProfilesByMenuIdAsync(int tableId)");
        //    apiControllerCode.AppendLine("        {");
        //    apiControllerCode.AppendLine("            var profiles = await _importProfileRepository.GetProfilesByMenuIdAsync(tableId);");
        //    apiControllerCode.AppendLine("            return Ok(profiles);");
        //    apiControllerCode.AppendLine("        }");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("        [HttpGet(\"{id}\")]");
        //    apiControllerCode.AppendLine("        public async Task<IActionResult> GetById(int id)");
        //    apiControllerCode.AppendLine("        {");
        //    apiControllerCode.AppendLine("            var profile = await _importProfileRepository.GetByIdAsync(id);");
        //    apiControllerCode.AppendLine("            if (profile == null)");
        //    apiControllerCode.AppendLine("                return NotFound();");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("            return Ok(profile);");
        //    apiControllerCode.AppendLine("        }");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("        [HttpGet(\"downloadExcel/{profileName}\")]");
        //    apiControllerCode.AppendLine("        public async Task<IActionResult> DownloadExcelProfile(string profileName)");
        //    apiControllerCode.AppendLine("        {");
        //    apiControllerCode.AppendLine("            var profile = await _importProfileRepository.GetByNameAsync(profileName);");
        //    apiControllerCode.AppendLine("            if (profile == null)");
        //    apiControllerCode.AppendLine("                return NotFound();");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("            string sanitizedName = string.Concat(profileName.Where(c => !System.IO.Path.GetInvalidFileNameChars().Contains(c)));");
        //    apiControllerCode.AppendLine("            string filePath = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), \"wwwroot\", \"ImportProfileExcelSheets\", sanitizedName + \".xlsx\");");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("            if (!System.IO.File.Exists(filePath))");
        //    apiControllerCode.AppendLine("                return NotFound();");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("            byte[] fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);");
        //    apiControllerCode.AppendLine("            return File(fileBytes, \"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\", sanitizedName + \".xlsx\");");
        //    apiControllerCode.AppendLine("        }");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("        [HttpGet(\"downloadCsv/{profileName}\")]");
        //    apiControllerCode.AppendLine("        public async Task<IActionResult> DownloadCsvProfile(string profileName)");
        //    apiControllerCode.AppendLine("        {");
        //    apiControllerCode.AppendLine("            var profile = await _importProfileRepository.GetByNameAsync(profileName);");
        //    apiControllerCode.AppendLine("            if (profile == null)");
        //    apiControllerCode.AppendLine("                return NotFound();");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("            string sanitizedName = string.Concat(profileName.Where(c => !System.IO.Path.GetInvalidFileNameChars().Contains(c)));");
        //    apiControllerCode.AppendLine("            string filePath = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), \"wwwroot\", \"ImportProfileCVSSheets\", sanitizedName + \".csv\");");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("            if (!System.IO.File.Exists(filePath))");
        //    apiControllerCode.AppendLine("                return NotFound();");
        //    apiControllerCode.AppendLine();
        //    apiControllerCode.AppendLine("            byte[] fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);");
        //    apiControllerCode.AppendLine("            return File(fileBytes, \"text/csv\", sanitizedName + \".csv\");");
        //    apiControllerCode.AppendLine("        }");

        //    apiControllerCode.AppendLine("    }");
        //    apiControllerCode.AppendLine("}");
        //    File.WriteAllText(apiControllerPath, apiControllerCode.ToString());

        //    // ---- 5. MVC Controller for UI ----
        //    string uiControllerFolder = $@"C:\ClientProject\{projectfoldername}\DynamicFormBuilder_UI\Controllers";
        //    Directory.CreateDirectory(uiControllerFolder);
        //    string uiControllerPath = Path.Combine(uiControllerFolder, "ImportProfileController.cs");

        //    var uiControllerCode = new StringBuilder();
        //    uiControllerCode.AppendLine("using Microsoft.AspNetCore.Mvc;");
        //    uiControllerCode.AppendLine("using Models;");
        //    uiControllerCode.AppendLine();
        //    uiControllerCode.AppendLine("namespace DynamicFormBuilder_UI.Controllers");
        //    uiControllerCode.AppendLine("{");
        //    uiControllerCode.AppendLine("    public class ImportProfileController : Controller");
        //    uiControllerCode.AppendLine("    {");
        //    uiControllerCode.AppendLine("        public IActionResult ImportProfileList()");
        //    uiControllerCode.AppendLine("        {");
        //    uiControllerCode.AppendLine("            return View();");
        //    uiControllerCode.AppendLine("        }");
        //    uiControllerCode.AppendLine();
        //    uiControllerCode.AppendLine("        public IActionResult ImportProfileDetails(int id)");
        //    uiControllerCode.AppendLine("        {");
        //    uiControllerCode.AppendLine("            // Fetch profile by id and pass to view");
        //    uiControllerCode.AppendLine();
        //    uiControllerCode.AppendLine("            return View(); // This must not be null!");
        //    uiControllerCode.AppendLine("        }");
        //    uiControllerCode.AppendLine("    }");
        //    uiControllerCode.AppendLine("}");
        //    File.WriteAllText(uiControllerPath, uiControllerCode.ToString());
        //}

        //        public void GenerateImportViews(string projectName, string clientName)
        //        {
        //            string projectFolderName = $@"{clientName}\{projectName}";
        //            string viewsPath = $@"C:\ClientProject\{projectFolderName}\DynamicFormBuilder_UI\Views";
        //            string importProfilePath = Path.Combine(viewsPath, "ImportProfile");

        //            // Check that the parent "Views" directory exists
        //            if (!Directory.Exists(viewsPath))
        //            {
        //                throw new DirectoryNotFoundException($"Views folder not found at: {viewsPath}");
        //            }

        //            // Only create ImportProfile folder if it does not exist
        //            if (!Directory.Exists(importProfilePath))
        //            {
        //                Directory.CreateDirectory(importProfilePath);
        //            }

        //            string indexViewPath = Path.Combine(importProfilePath, "ImportProfileList.cshtml");
        //            string editViewPath = Path.Combine(importProfilePath, "ImportProfileDetails.cshtml");

        //            string indexViewContent = @"<div class='mt-4 main-section w-100 mb-4'>  

        //    <div id='grid' class='card p-4 rounded'></div>
        //    <span id='notification'></span>
        //</div>

        //<script>
        //    var backendUrl = '@ViewData[""BackendUrl""]';

        //    function loadGrid(tableId) {
        //        $('#grid').kendoGrid({
        //            dataSource: {
        //                transport: {
        //                    read: {
        //                        url: backendUrl + `ImportProfile/by-table/` + encodeURIComponent(tableId),
        //                        dataType: 'json'
        //                    }
        //                }
        //            },
        //            columns: [
        //                { field: 'ImportProfileName', title: 'ImportProfileName', width: '150px' },
        //                {
        //                    title: 'Actions',
        //                    width: '80px',
        //                    attributes: { style: 'text-align: center;' },
        //                    template: `<button class='btn btn-primary btn-sm k-button-icontext' style='min-width: 40px;' onclick='return EditUser(this);' data-id='#= Id #'>
        //                                 <i class='k-icon k-font-icon k-i-pencil'></i>
        //                               </button>`
        //                }
        //            ],
        //            pageable: true,
        //            sortable: true,
        //            filterable: true
        //        });
        //    }

        //    $(document).ready(function () {
        //        loadGrid($('#tableSelector').val());

        //        $('#tableSelector').change(function () {
        //            $('#grid').data('kendoGrid').destroy();
        //            $('#grid').empty();
        //            loadGrid($(this).val());
        //        });
        //    });

        //    function EditUser(button) {
        //        var id = $(button).data('id');
        //        window.location.href = '/ImportProfile/ImportProfileDetails?id=' + id;
        //        return false;
        //    }
        //</script>";
        //            string editViewContent = @"@{
        //    ViewData[""Title""] = ""Edit Import Profile"";
        //}

        //<div class='mt-4 main-section w-100 mb-4'>
        //    <h3 id='pageTitle' class='text-start text-primary mb-4'>Edit Import Profile</h3>

        //    <form id='Form' method='post'>
        //        <div class='row mb-3'>
        //            <div class='col-md-6'>
        //                <div class='form-group'>
        //                    <input type='text' class='form-control1' id='importProfileName' name='importProfileName' readonly />
        //                    <label for='importProfileName' class='form-label1'>Profile Name</label>
        //                </div>
        //            </div>
        //            <div class='col-md-6'>
        //                <div class='form-group'>
        //                    <input type='text' class='form-control1' id='tableName' name='tableName' readonly />
        //                    <label for='tableName' class='form-label1'>Table Name</label>
        //                </div>
        //            </div>
        //        </div>

        //        <div class='row mb-3'>
        //            <div class='col-md-6'>
        //                <label for='fileTypeSelect' class='form-label1'>Select File Type</label>
        //                <select id='fileTypeSelect' class='form-select'>
        //                    <option value='xlsx' selected>Excel (.xlsx)</option>
        //                    <option value='csv'>CSV (.csv)</option>
        //                </select>
        //            </div>
        //        </div>

        //        <div class='row'>
        //            <div class='form-submit text-end mb-4'>
        //                <button type='button' id='btnImport' class='btn btn-primary me-2 text-white'>Import</button>
        //                <button type='button' id='btnExport' class='btn cancel-form'>Export</button>
        //            </div>
        //        </div>
        //    </form>
        //</div>

        //<div id='notification'></div>

        //<script>
        //    $(document).ready(function () {
        //        var backendUrl = '@ViewData[""BackendUrl""]';
        //        const urlParams = new URLSearchParams(window.location.search);
        //        const id = urlParams.get('id');

        //        if (!id) {
        //            $('#notification').kendoNotification().data('kendoNotification').show('Error: No profile ID specified.', 'error');
        //            return;
        //        }

        //        fetch(backendUrl + `ImportProfile/` + id)
        //            .then(response => {
        //                if (!response.ok) throw new Error('Profile not found');
        //                return response.json();
        //            })
        //            .then(profile => {
        //                $('#importProfileName').val(profile.importProfileName);
        //                $('#tableName').val(profile.tableName);

        //                $('#btnExport').click(() => {
        //                    const fileType = $('#fileTypeSelect').val();
        //                    let downloadUrl = '';
        //                    if (fileType === 'xlsx') {
        //                        downloadUrl = backendUrl + 'ImportProfile/downloadExcel/' + encodeURIComponent(profile.importProfileName);
        //                    } else if (fileType === 'csv') {
        //                        downloadUrl = backendUrl + 'ImportProfile/downloadCsv/' + encodeURIComponent(profile.importProfileName);
        //                    }
        //                    window.location.href = downloadUrl;
        //                });

        //                $('#btnImport').click(() => {
        //                    alert('Import logic not implemented yet.');
        //                });
        //            })
        //            .catch(error => {
        //                $('#notification').kendoNotification().data('kendoNotification').show(error.message, 'error');
        //            });

        //        $('#notification').kendoNotification({
        //            position: { top: 20, right: 20 },
        //            stacking: 'down',
        //            autoHideAfter: 3000,
        //            hideOnClick: true
        //        });
        //    });
        //</script>";


        //            File.WriteAllText(indexViewPath, indexViewContent);
        //            File.WriteAllText(editViewPath, editViewContent);
        //        }




        //public async Task CopyImage(string projectLogo, string databaseName)
        //{
        //    var fileName = projectLogo; // This should be just the filename, e.g., "image.png"

        //    // Full source path to the image
        //    var sourceFolder = @"C:\Users\Admin\Desktop\working\ProjectBuilder\DemoWeb\wwwroot\Image\";
        //    var sourcePath = Path.Combine(sourceFolder, fileName);

        //var destinationFolder = $@"C:\ClientProject\{databaseName}\DynamicFormBuilder_UI\wwwroot\Image";

        //    // Ensure the destination directory exists
        //    Directory.CreateDirectory(destinationFolder);

        //    // Full destination path including the file name
        //    var destinationPath = Path.Combine(destinationFolder, fileName);

        //    if (System.IO.File.Exists(sourcePath))
        //    {
        //        // true = overwrite if the file already exists
        //        System.IO.File.Copy(sourcePath, destinationPath, true);
        //        Console.WriteLine($"File copied successfully to: {destinationPath}");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Source file not found: " + sourcePath);
        //    }
        //}



    }
}
