﻿using System.Text;
using Entities.Models.ClientBuilderModels.ClientModels;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateFormDocumentClass
    {
        GenerateApplicationLayerClass generateApplicationLayerClass = new();

        public static async Task GenerateFormDocumentList(ClientForm document, string projectName, string clientName)
        {
            string? TableName = !string.IsNullOrEmpty(document.ParentTableName) ? document.ParentTableName : document.TableName;
            var FormName = document.Name;
            StringBuilder sb = new();
            sb.AppendLine("@inject BackendSettings BackendSettings");
            sb.AppendLine("@{");
            sb.AppendLine("    ViewData[\"BackendUrl\"] = BackendSettings.BackendUrl;");
            sb.AppendLine("}");
            // HTML Structure
            sb.AppendLine("    <div>");
            sb.AppendLine("        <div class=\"mb-2\">");
            sb.AppendLine("        <button class=\"btn\" id=\"textButton\" disabled><i class='k-icon k-font-icon k-i-plus'></i>New</button>");
            sb.AppendLine("        </div>");
            sb.AppendLine("");
            sb.AppendLine("        <div id=\"grid\" class=\"card p-4 rounded\"></div>");
            sb.AppendLine("");
            sb.AppendLine("        <span id=\"notification\"></span>");
            sb.AppendLine("    </div>");

            // JavaScript Section
            sb.AppendLine("<script>");
            sb.AppendLine("    var backendUrl = '@ViewData[\"BackendUrl\"]';");
            sb.AppendLine("    var Id = parseInt('@ViewBag.Id');");
            sb.AppendLine("    var notification;");
            sb.AppendLine("    console.log('Id:', Id);");
            sb.AppendLine("    if (Id) {");
            sb.AppendLine("        document.getElementById('textButton').disabled = false;");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    function downloadFile(button) {");
            sb.AppendLine("        var fileName = $(button).data(\"file\");");
            sb.AppendLine("        var downloadUrl = backendUrl + \"/Document/download?fileName=\" + encodeURIComponent(fileName);");
            sb.AppendLine("        var token = localStorage.getItem(\"jwtToken\");");
            sb.AppendLine("");
            sb.AppendLine("        fetch(downloadUrl, {");
            sb.AppendLine("            method: 'GET',");
            sb.AppendLine("            headers: {");
            sb.AppendLine("                'Authorization': 'Bearer ' + token");
            sb.AppendLine("            }");
            sb.AppendLine("        })");
            sb.AppendLine("        .then(response => {");
            sb.AppendLine("            if (!response.ok) {");
            sb.AppendLine("                throw new Error(\"Download failed. Status: \" + response.status);");
            sb.AppendLine("            }");
            sb.AppendLine("            return response.blob();");
            sb.AppendLine("        })");
            sb.AppendLine("        .then(blob => {");
            sb.AppendLine("            const url = window.URL.createObjectURL(blob);");
            sb.AppendLine("            const a = document.createElement('a');");
            sb.AppendLine("            a.href = url;");
            sb.AppendLine("            a.download = fileName;");
            sb.AppendLine("            document.body.appendChild(a);");
            sb.AppendLine("            a.click();");
            sb.AppendLine("            a.remove();");
            sb.AppendLine("            window.URL.revokeObjectURL(url);");
            sb.AppendLine("        })");
            sb.AppendLine("        .catch(error => {");
            sb.AppendLine("            console.error(\"Download error:\", error);");
            sb.AppendLine("            notification.show(\"Download failed: \" + error.message, \"error\");");
            sb.AppendLine("        });");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    $(document).ready(function () {");
            sb.AppendLine("        notification = $(\"#notification\").kendoNotification({");
            sb.AppendLine("            animation: {");
            sb.AppendLine("                open: { effects: \"slideIn:left\" },");
            sb.AppendLine("                close: { effects: \"slideIn:left\", reverse: true }");
            sb.AppendLine("            },");
            sb.AppendLine("            position: { top: 91, right: 80 },");
            sb.AppendLine("            stacking: \"down\",");
            sb.AppendLine("            autoHideAfter: 5000,");
            sb.AppendLine("            hideOnClick: true");
            sb.AppendLine("        }).data(\"kendoNotification\");");
            sb.AppendLine("");
            sb.AppendLine("        $(\"#grid\").kendoGrid({");
            sb.AppendLine("            columns: [");
            sb.AppendLine("                   {");
            sb.AppendLine("             width: \"180px\",");
            sb.AppendLine("             template: `");
            sb.AppendLine("                  <button class=\"btn btn-sm btn-primary edit-button edit-btn me-1\"");
            sb.AppendLine("                    data-id=\"#= id #\" onclick=\"return EditForm(this);\">");
            sb.AppendLine("                    <i class=\"k-icon k-font-icon k-i-pencil\"></i>");
            sb.AppendLine("                  </button>");
            sb.AppendLine("                  <button class=\"btn btn-sm btn-danger remove-button delete-btn me-1\"");
            sb.AppendLine("                    data-id=\"#= documentId #\" onclick=\"return DeleteForm(this);\">");
            sb.AppendLine("                    <i class=\"k-icon k-font-icon k-i-trash\"></i>");
            sb.AppendLine("                  </button>");
            sb.AppendLine("                  <button class=\"btn btn-sm btn-success download-btn\"");
            sb.AppendLine("                    data-file=\"#= fileName #\" onclick=\"return downloadFile(this);\">");
            sb.AppendLine("                    <i class=\"k-icon k-font-icon k-i-download\"></i>");
            sb.AppendLine("                  </button>");
            sb.AppendLine("                      `,");
            sb.AppendLine("            attributes: { style: \"text-align:center; white-space:nowrap;\" },");
            sb.AppendLine("            headerAttributes: { style: \"text-align:center;\" }");
            sb.AppendLine("          },");
            sb.AppendLine("       { field: \"name\", title: \"Name\" },");
            sb.AppendLine("       { field: \"fileName\", title: \"File Name\" }");
            sb.AppendLine("     ],");
            sb.AppendLine("            dataSource: {");
            sb.AppendLine("                transport: {");
            sb.AppendLine("                    read: function (options) {");
            sb.AppendLine("                        var requestData = {");
            sb.AppendLine("                            skip: (options.data.page - 1) * options.data.pageSize || 0,");
            sb.AppendLine("                            take: options.data.pageSize || 5,");
            sb.AppendLine("                            sort: options.data.sort || null,");
            sb.AppendLine("                            filter: options.data.filter || null");
            sb.AppendLine("                        };");
            sb.AppendLine("");
            sb.AppendLine("                        $.ajax({");
            sb.AppendLine($"                            url: `${{backendUrl}}/{FormName}Document/Documents/${{Id}}`,");
            sb.AppendLine("                            type: 'POST',");
            sb.AppendLine("                            dataType: \"json\",");
            sb.AppendLine("                            contentType: \"application/json\",");
            sb.AppendLine("                            data: JSON.stringify(requestData),");
            sb.AppendLine("                            beforeSend: function (xhr) {");
            sb.AppendLine("                                const token = localStorage.getItem(\"jwtToken\");");
            sb.AppendLine("                                if (token) {");
            sb.AppendLine("                                    xhr.setRequestHeader(\"Authorization\", \"Bearer \" + token);");
            sb.AppendLine("                                }");
            sb.AppendLine("                            },");
            sb.AppendLine("                            success: function (response) {");
            sb.AppendLine("                                options.success({");
            sb.AppendLine("                                    data: response.data,");
            sb.AppendLine("                                    total: response.total");
            sb.AppendLine("                                });");
            sb.AppendLine("                            },");
            sb.AppendLine("                            error: function (xhr, status, error) {");
            sb.AppendLine("                                console.error(\"API Error:\", xhr.responseText || error);");
            sb.AppendLine("                                notification.show(\"Failed to load attachments.\", \"error\");");
            sb.AppendLine("                                options.error(xhr);");
            sb.AppendLine("                            }");
            sb.AppendLine("                        });");
            sb.AppendLine("                    }");
            sb.AppendLine("                },");
            sb.AppendLine("                schema: {");
            sb.AppendLine("                    id: \"id\",");
            sb.AppendLine("                    data: \"data\",");
            sb.AppendLine("                    total: \"total\",");
            sb.AppendLine("                      model:");
            sb.AppendLine("                      {");
            sb.AppendLine("                          id: \"id\",");
            sb.AppendLine("                          fields: {");
            sb.AppendLine("                          id: { type: \"number\", editable: false },");
            sb.AppendLine("                          name: { type: \"string\" },");
            sb.AppendLine("                          fileName: { type: \"string\" },");
            sb.AppendLine("");
            sb.AppendLine("                          }");
            sb.AppendLine("                      }");
            sb.AppendLine("                },");
            sb.AppendLine("                pageSize: 5,");
            sb.AppendLine("                serverPaging: true,");
            sb.AppendLine("                serverSorting: true,");
            sb.AppendLine("                serverFiltering: true");
            sb.AppendLine("            },");
            sb.AppendLine("            toolbar: [\"search\"],");
            sb.AppendLine("            search: { fields: [");
            sb.AppendLine("                { name: \"name\" },");
            sb.AppendLine("            { name: \"fileName\" }");
            sb.AppendLine("");
            sb.AppendLine("            ] },");
            sb.AppendLine("            sortable: true,");
            sb.AppendLine("            pageable: {");
            sb.AppendLine("                responsive: false,");
            sb.AppendLine("                pageSizes: [10, 20, 30, 50],");
            sb.AppendLine("                pageSize: 5,");
            sb.AppendLine("                buttonCount: 5");
            sb.AppendLine("            },");
            sb.AppendLine("            noRecords: true,");
            sb.AppendLine("            messages: {");
            sb.AppendLine("                noRecords: \"No records available.\"");
            sb.AppendLine("            },");
            sb.AppendLine("            filterable: { extra: false, operators: { string: { contains: 'Contains', doesnotcontain: 'Does not contain', startswith: 'Starts with', endswith: 'Ends with', eq:'Is equal to', neq:'Is not equal to',isempty:'Is empty', isnotempty:'Is not empty',isnull:'Is null', isnotnull:'Is not null', hasvalue:'Has value', hasnovalue:'Has no value' } } },");
            sb.AppendLine("            dataBound: function () {");
            sb.AppendLine("         initTooltips();");
            sb.AppendLine("               fixScrollableHeight(this);");
            sb.AppendLine("               fnClearSearch();");
            sb.AppendLine("           }");
            sb.AppendLine("        });");
            sb.AppendLine("");
            sb.AppendLine("        $(\"#textButton\").on(\"click\", function () {");
            sb.AppendLine($"            window.location.href = `/{TableName}Document/{FormName}DocumentDetails?FkId=${{Id}}`;");
            sb.AppendLine("        });");
            sb.AppendLine("    });");
            sb.AppendLine("");
            sb.AppendLine("    function EditForm(button) {");
            sb.AppendLine("        let attachId = $(button).data(\"id\");");
            sb.AppendLine("        if (attachId) {");
            sb.AppendLine($"            window.location.href = `/{TableName}Document/{FormName}DocumentDetails?id=${{attachId}}&FkId=${{Id}}`;");
            sb.AppendLine("        } else {");
            sb.AppendLine("            notification.show(\"Invalid ID for editing.\", \"error\");");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("function DeleteForm(button) {");
            sb.AppendLine("    let id = $(button).data('id');");
            sb.AppendLine("    const grid = $('#grid').data('kendoGrid');");
            sb.AppendLine("    const dataSource = grid.dataSource;");
            sb.AppendLine("    const currentPage = dataSource.page();");
            sb.AppendLine("    const pageSize = dataSource.pageSize();");
            sb.AppendLine("");
            sb.AppendLine("    // 🔹 Bind confirm button click");
            sb.AppendLine("    $('#confirmDeleteBtn')");
            sb.AppendLine("        .off('click')");
            sb.AppendLine("        .on('click', function () {");
            sb.AppendLine("            $.ajax({");
            sb.AppendLine($"                url: `${{backendUrl}}/{FormName}Document/${{id}}`,");
            sb.AppendLine("                type: 'DELETE',");
            sb.AppendLine("                beforeSend: function (xhr) {");
            sb.AppendLine("                    const token = localStorage.getItem('jwtToken');");
            sb.AppendLine("                    if (token) {");
            sb.AppendLine("                        xhr.setRequestHeader('Authorization', 'Bearer ' + token);");
            sb.AppendLine("                    }");
            sb.AppendLine("                },");
            sb.AppendLine("                success: function () {");
            sb.AppendLine("                    dataSource.read().then(function () {");
            sb.AppendLine("                        const total = dataSource.total();");
            sb.AppendLine("                        const totalPages = Math.ceil(total / pageSize);");
            sb.AppendLine("");
            sb.AppendLine("                        if (currentPage > totalPages && totalPages > 0) {");
            sb.AppendLine("                            dataSource.page(totalPages);");
            sb.AppendLine("                        } else if (total === 0) {");
            sb.AppendLine("                            dataSource.page(1);");
            sb.AppendLine("                        } else {");
            sb.AppendLine("                            dataSource.page(currentPage);");
            sb.AppendLine("                        }");
            sb.AppendLine("");
            sb.AppendLine("                        notification.show('Record deleted successfully', 'success');");
            sb.AppendLine("                              setTimeout(function() {");
            sb.AppendLine("                                  location.reload();");
            sb.AppendLine("                                }, 200);");
            sb.AppendLine("                    });");
            sb.AppendLine("");
            sb.AppendLine("                    deleteWindow.close();");
            sb.AppendLine("                    setTimeout(() => location.reload(), 1000);");
            sb.AppendLine("                },");
            sb.AppendLine("                error: function (xhr, status, error) {");
            sb.AppendLine("                    console.error('Delete Error:', xhr.responseText || error);");
            sb.AppendLine("                    notification.show('Error deleting record!', 'error');");
            sb.AppendLine("                    deleteWindow.close();");
            sb.AppendLine("                }");
            sb.AppendLine("            });");
            sb.AppendLine("        });");
            sb.AppendLine("");
            sb.AppendLine("    // 🔹 Open confirmation popup");
            sb.AppendLine("    deleteWindow.center().open();");
            sb.AppendLine("}");

            sb.AppendLine("</script>");

            //string projectfoldername = $@"{clientName}\{projectName}";
            //string folderPath = $@"C:\ClientProject\{projectfoldername}\DynamicFormBuilder_UI\Views\{FormName}Document";

            //// Check and create folder if it doesn't exist
            //if (!Directory.Exists(folderPath))
            //{
            //    Directory.CreateDirectory(folderPath);
            //}

            //string filePath = Path.Combine(folderPath, $"{FormName}DocumentList.cshtml");


            //await File.WriteAllTextAsync(filePath, sb.ToString());


            string projectfoldername = $@"{clientName}\{projectName}";
            string folderPath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.MvcUI\Views\{TableName}Document";

            // Ensure the folder exists
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            // File name for List page only
            string fileName = $"{FormName}DocumentList.cshtml";

            // Full file path
            string filePath = Path.Combine(folderPath, fileName);

            // Write the content to the file
            await File.WriteAllTextAsync(filePath, sb.ToString());

        }

        public static async Task GenerateFormDocumentDetails(ClientForm document, string projectName, string clientName)
        {
            string? TableName = !string.IsNullOrEmpty(document.ParentTableName) ? document.ParentTableName : document.TableName;
            var FormName = document.Name;
            StringBuilder sb = new();

            // CSS Section
            sb.AppendLine("<style>");
            sb.AppendLine("    .image-preview {");
            sb.AppendLine("        position: relative;");
            sb.AppendLine("        vertical-align: top;");
            sb.AppendLine("        height: 45px;");
            sb.AppendLine("        border-radius: 4px;");
            sb.AppendLine("        cursor: pointer;");
            sb.AppendLine("    }");
            sb.AppendLine("    .k-file-name {");
            sb.AppendLine("        max-width: 550px;");
            sb.AppendLine("        display: inline-block;");
            sb.AppendLine("        white-space: nowrap;");
            sb.AppendLine("        overflow: hidden;");
            sb.AppendLine("        text-overflow: ellipsis;");
            sb.AppendLine("        vertical-align: middle;");
            sb.AppendLine("    }");
            sb.AppendLine("    .k-icon {");
            sb.AppendLine("        font-family: \"WebComponentsIcons\", \"Kendo UI Icons\" !important;");
            sb.AppendLine("        font-style: normal;");
            sb.AppendLine("        font-weight: normal;");
            sb.AppendLine("        speak: none;");
            sb.AppendLine("    }");
            sb.AppendLine("    .k-file-icon-wrapper .k-icon {");
            sb.AppendLine("        font-size: 32px;");
            sb.AppendLine("        line-height: 1;");
            sb.AppendLine("        display: inline-block;");
            sb.AppendLine("        vertical-align: middle;");
            sb.AppendLine("    }");
            sb.AppendLine("</style>");

            // HTML Section
            sb.AppendLine("<div class=\"mt-4 main-section\">");
            sb.AppendLine("    <form id=\"documentForm\" method=\"post\" class=\"mt-4\" enctype=\"multipart/form-data\">");
            sb.AppendLine("        <div class=\"row\">");
            sb.AppendLine("            <div class=\"col-md-6\">");
            sb.AppendLine("                <label for=\"fname\" class=\"form-label-text\">Name <span class=\"required\">*</span></label>");
            sb.AppendLine("                <input type=\"text\" id=\"fname\" class=\"required_field\" name=\"Name\" required />");
            sb.AppendLine("                <span class=\"k-invalid-msg\" data-for=\"Name\" id=\"nameError\" style=\"display:none;\"></span>");
            sb.AppendLine("            </div>");
            sb.AppendLine("            <div class=\"col-md-6\">");
            sb.AppendLine("                <label class=\"form-label-text\">Upload File <span class=\"text-danger\">*</span></label>");
            sb.AppendLine("                <input type=\"file\" name=\"FormFile\" id=\"formFile\" />");
            sb.AppendLine("                <span class=\"k-invalid-msg\" id=\"fileError\" style=\"display:none;\">File is required.</span>");
            sb.AppendLine("            </div>");
            sb.AppendLine("        </div>");
            sb.AppendLine("        <div class=\"row mt-3\">");
            sb.AppendLine("            <div class=\"col-md-6\">");
            sb.AppendLine("                <label for=\"description\" class=\"form-label-text\">Description</label>");
            sb.AppendLine("                <textarea id=\"description\" name=\"Description\"></textarea>");
            sb.AppendLine("            </div>");
            sb.AppendLine("        </div>");
            sb.AppendLine("        <div class=\"row mt-3 mb-3\">");
            sb.AppendLine("            <div class=\"form-submit text-end\">");
            sb.AppendLine("                <button type=\"submit\" id=\"save\" class=\"btn btn-primary me-2 text-white\">Save</button>");
            sb.AppendLine("                <button type=\"button\" id=\"cancelButton\" class=\"btn btn-secondary cancel-form\">Cancel</button>");
            sb.AppendLine("            </div>");
            sb.AppendLine("        </div>");
            sb.AppendLine("    </form>");
            sb.AppendLine("</div>");

            sb.AppendLine("");

            // JavaScript Section
            sb.AppendLine("<script>");
            sb.AppendLine("    $(document).ready(function () {");
            sb.AppendLine("        let existingFileName = \"\";");
            sb.AppendLine("        const imageExts = ['png','jpg','jpeg','gif','bmp','svg','webp'];");
            sb.AppendLine("        const backendUrl = '@ViewData[\"BackendUrl\"]';");
            sb.AppendLine("        var urlParams = new URLSearchParams(window.location.search);");
            sb.AppendLine("        var FkId = urlParams.get('FkId');");
            sb.AppendLine("        var documentId = urlParams.get('id')");
            sb.AppendLine("");
            sb.AppendLine("        // Kendo Buttons");
            sb.AppendLine("        $('#save').kendoButton({ icon: 'save' });");
            sb.AppendLine("        $('#cancelButton').kendoButton({ icon: 'cancel' });");
            sb.AppendLine("");
            sb.AppendLine("        const fname = $('#fname').kendoTextBox().data('kendoTextBox');");
            sb.AppendLine("        const description = $('#description').kendoTextArea({ autoSize:true, resize:'vertical', rows:4 }).data('kendoTextArea');");
            sb.AppendLine("");
            sb.AppendLine("     const kendoUpload = $('#formFile').kendoUpload({");
            sb.AppendLine("         multiple:false,");
            sb.AppendLine("         async:{ autoUpload:false },");
            sb.AppendLine("         showFileList:true,");
            sb.AppendLine("         validation:{ allowedExtensions:['.jpg','.jpeg','.png','.gif','.bmp','.pdf','.docx','.svg','.webp'], maxFileSize:25*1024*1024 },");
            sb.AppendLine("         select: function(e) {");
            sb.AppendLine("             $('.k-file[data-existing=\"true\"]').remove();");
            sb.AppendLine("             existingFileName = '';");
            sb.AppendLine("             $('#fileError').hide();");
            sb.AppendLine("             $(\"#formFile\").removeClass(\"k-invalid\").removeAttr(\"aria-invalid\");");
            sb.AppendLine("             $(\"#formFile\").closest(\".k-upload\").removeClass(\"k-invalid\").removeAttr(\"aria-invalid\");");
            sb.AppendLine("             e.files.forEach(function(file){");
            sb.AppendLine("                 if(file.rawFile && file.rawFile.type.startsWith('image/')){");
            sb.AppendLine("                     var reader = new FileReader();");
            sb.AppendLine("                     reader.onloadend = function(){");
            sb.AppendLine("                         $('.k-file[data-uid=\"'+file.uid+'\"] .k-file-icon-wrapper')");
            sb.AppendLine("                              .html($('<img>').attr('src', this.result).addClass('image-preview'));");
            sb.AppendLine("                         $('.k-file[data-uid=\"'+file.uid+'\"] .image-preview').on('click', function(){");
            sb.AppendLine("                             $('<div/>').kendoWindow({");
            sb.AppendLine("                                 content: '<img src=\"'+this.src+'\" style=\"max-width:100%;height:auto;\"/>' ,");
            sb.AppendLine("                                 width: '700px',");
            sb.AppendLine("                                 title: file.name || 'Preview',");
            sb.AppendLine("                                 modal: true,");
            sb.AppendLine("                                 visible: false,");
            sb.AppendLine("                                 close: function(){ this.destroy(); }");
            sb.AppendLine("                             }).data('kendoWindow').center().open();");
            sb.AppendLine("                         });");
            sb.AppendLine("                     };");
            sb.AppendLine("                     reader.readAsDataURL(file.rawFile);");
            sb.AppendLine("                  }");
            sb.AppendLine("             });");
            sb.AppendLine("         },");
            sb.AppendLine("         remove: function () {");
            sb.AppendLine("             existingFileName = '';");
            sb.AppendLine("             $('#fileError').show().text('File is required.');");
            sb.AppendLine("             $('#formFile').addClass('k-invalid').attr('aria-invalid', 'true');");
            sb.AppendLine("             $('#formFile').closest('.k-upload').addClass('k-invalid').attr('aria-invalid', 'true');");
            sb.AppendLine("         }");
            sb.AppendLine("     }).data('kendoUpload');");

            sb.AppendLine("");
            sb.AppendLine("        // Load existing document");
            sb.AppendLine("        if (documentId) {");
            sb.AppendLine("            $.ajax({");
            sb.AppendLine("                url: `${backendUrl}/" + FormName + "Document/${documentId}`,");
            sb.AppendLine("                method: 'GET',");
            sb.AppendLine("                beforeSend: function (xhr) {");
            sb.AppendLine("                    const token = localStorage.getItem('jwtToken');");
            sb.AppendLine("                    if (token) xhr.setRequestHeader('Authorization', 'Bearer ' + token);");
            sb.AppendLine("                },");
            sb.AppendLine("                success: function (data) {");
            sb.AppendLine("                    fname.value(data.name || '');");
            sb.AppendLine("                    description.value(data.description || '');");
            sb.AppendLine("                    existingFileName = data.fileName || '';");
            sb.AppendLine("                 if (existingFileName) {");
            sb.AppendLine("                     renderExistingFile(kendoUpload, existingFileName, backendUrl, imageExts);");
            sb.AppendLine("                 }");
            sb.AppendLine("              },");
            sb.AppendLine("                error: function () {");
            sb.AppendLine("                    fnShowNotification('Failed to load document.', 'error');");
            sb.AppendLine("                }");
            sb.AppendLine("            });");
            sb.AppendLine("        }");

            sb.AppendLine("");
            sb.AppendLine("     // file upload control validation");
            sb.AppendLine("     function renderExistingFile(uploadWidget, fileName, backendUrl, imageExts) {");
            sb.AppendLine("         if (!uploadWidget || !fileName) return;");
            sb.AppendLine("");
            sb.AppendLine("         uploadWidget.clearAllFiles();");
            sb.AppendLine("");
            sb.AppendLine("         const fileExt = fileName.split('.').pop().toLowerCase();");
            sb.AppendLine("         const isImage = imageExts.includes(fileExt);");
            sb.AppendLine("         const uid = kendo.guid();");
            sb.AppendLine("");
            sb.AppendLine("         let ul = uploadWidget.wrapper.find(\".k-upload-files\");");
            sb.AppendLine("         if (ul.length === 0) { ul = $(\"<ul class='k-upload-files k-reset'></ul>\").appendTo(uploadWidget.wrapper); }");
            sb.AppendLine("");
            sb.AppendLine("         ul.find(\"li[data-existing='true']\").remove();");
            sb.AppendLine("");
            sb.AppendLine("         const li = $(`");
            sb.AppendLine("             <li class='k-file k-file-success d-flex align-items-center justify-content-between gap-3 flex-wrap'");
            sb.AppendLine("                 data-uid='${uid}' data-existing='true' style='padding: 0.5rem 1rem;'>");
            sb.AppendLine("                 <div class='d-flex align-items-center gap-3'>");
            sb.AppendLine("                     <span class='k-file-icon-wrapper'></span>");
            sb.AppendLine("                     <div class='k-file-name-size-wrapper'>");
            sb.AppendLine("                         <span class='k-file-name' title='${fileName}'>${fileName}</span>");
            sb.AppendLine("                         <span class='k-file-size'></span>");
            sb.AppendLine("                     </div>");
            sb.AppendLine("                 </div>");
            sb.AppendLine("                 <div class='k-upload-actions'>");
            sb.AppendLine("                     <button type='button' class='btn btn-lg k-upload-action k-delete' title='Remove' aria-label='Remove'>");
            sb.AppendLine("                         <span aria-hidden='true' style='font-size: 1.75rem;'>&times;</span>");
            sb.AppendLine("                     </button>");
            sb.AppendLine("                 </div>");
            sb.AppendLine("             </li>");
            sb.AppendLine("         `);");

            sb.AppendLine("");
            sb.AppendLine("         ul.append(li);");
            sb.AppendLine("");
            sb.AppendLine("         if (isImage) {");
            sb.AppendLine("             const imageUrl = `${backendUrl}/uploads/${fileName}`;");
            sb.AppendLine("             li.find(\".k-file-icon-wrapper\").html(`<img src='${imageUrl}' class='image-preview' style='max-height:60px;border-radius:4px;'>`);");
            sb.AppendLine("             li.find('img.image-preview').on('click', function() {");
            sb.AppendLine("                 $('<div/>').kendoWindow({");
            sb.AppendLine("                     content: `<img src=\"${imageUrl}\" style=\"max-width:100%;height:auto;\"/>`,");
            sb.AppendLine("                     width: '700px',");
            sb.AppendLine("                     title: fileName,");
            sb.AppendLine("                     modal: true,");
            sb.AppendLine("                     visible: false,");
            sb.AppendLine("                     close: function() { this.destroy(); }");
            sb.AppendLine("                 }).data('kendoWindow').center().open();");
            sb.AppendLine("             });");
            sb.AppendLine("         } else {");
            sb.AppendLine("             const iconClass = getKendoIconClass(fileExt);");
            sb.AppendLine("             li.find('.k-file-icon-wrapper').html(`<span class='k-icon ${iconClass}'></span>`);");
            sb.AppendLine("         }");
            sb.AppendLine("");
            sb.AppendLine("         li.find('.k-upload-action.k-delete').on('click', function() {");
            sb.AppendLine("             li.remove();");
            sb.AppendLine("             existingFileName = '';");
            sb.AppendLine("             existingReportName = '';");

            sb.AppendLine("             $('#documentForm').data('kendoValidator')?.validateInput($('#formFile'));");
            sb.AppendLine("         });");
            sb.AppendLine("     }");
            sb.AppendLine("");
            sb.AppendLine("        // Validator");
            sb.AppendLine("         var validator = $(\"#documentForm\").kendoValidator({");
            sb.AppendLine("             validateOnBlur: true,");
            sb.AppendLine("             messages: {");
            sb.AppendLine("                 required: function (input) {");
            sb.AppendLine("                      return input.data(\"requiredMsg\") || (input.attr(\"name\") + \" is required.\");");
            sb.AppendLine("                 },");
            sb.AppendLine("                 fileRequired: \"File is required.\"");
            sb.AppendLine("             },");
            sb.AppendLine("             rules: {");
            sb.AppendLine("                 uploadRequired: function (input) {");
            sb.AppendLine("                     if (input.is(\"#formFile\")) {");
            sb.AppendLine("                         const files = kendoUpload.getFiles();");
            sb.AppendLine("                         const hasFile = files.length > 0 || existingFileName;");
            sb.AppendLine("                         if (!hasFile) {");
            sb.AppendLine("                             $(\"#fileError\").show().text(\"File is required.\");");
            sb.AppendLine("                             return false;");
            sb.AppendLine("                         }");
            sb.AppendLine("                         $(\"#fileError\").hide();");
            sb.AppendLine("                     }");
            sb.AppendLine("                     return true;");
            sb.AppendLine("                 }");
            sb.AppendLine("             }");
            sb.AppendLine("         }).data(\"kendoValidator\");");
            sb.AppendLine(" ");
            sb.AppendLine("         // ✅ Extra Fix: remove border on file select");
            sb.AppendLine("         $(\"#formFile\").on(\"change\", function () {");
            sb.AppendLine("             $(\"#fileError\").hide();");
            sb.AppendLine("             $(this).removeClass(\"k-invalid\").removeAttr(\"aria-invalid\");");
            sb.AppendLine("             $(this).closest(\".k-upload\").removeClass(\"k-invalid\").removeAttr(\"aria-invalid\");");
            sb.AppendLine("      });");
            sb.AppendLine("");
            sb.AppendLine("        $('#documentForm').submit(function(e){ e.preventDefault(); $('#save').click(); });");
            sb.AppendLine("");

            sb.AppendLine("        // Button click handler");
            sb.AppendLine("        $('#save').click(function (e) {");
            sb.AppendLine("            e.preventDefault();");
            sb.AppendLine("            const button = $(this);");
            sb.AppendLine("            button.prop('disabled', true);");
            sb.AppendLine("");
            sb.AppendLine("            // Validate form first");
            sb.AppendLine("            if (!validator.validate()) {");
            sb.AppendLine("                button.prop('disabled', false);");
            sb.AppendLine("                return;");
            sb.AppendLine("            }");
            sb.AppendLine("");
            sb.AppendLine("            // Prepare formData");
            sb.AppendLine("            const files = kendoUpload.getFiles();");
            sb.AppendLine("            const formData = new FormData();");
            sb.AppendLine("            formData.append('Name', $('#fname').val());");
            sb.AppendLine("            formData.append('Description', $('#description').val());");
            sb.AppendLine("            formData.append(\"FormId\", FkId);");
            sb.AppendLine("");
            sb.AppendLine("            if (files.length > 0) {");
            sb.AppendLine("                const file = files[0].rawFile;");
            sb.AppendLine("                formData.append('File', file);");
            sb.AppendLine("                formData.append('FileName', file.name);");
            sb.AppendLine("            } else if (existingFileName) {");
            sb.AppendLine("                formData.append('FileName', existingFileName);");
            sb.AppendLine("            }");
            sb.AppendLine("");
            sb.AppendLine("            if (documentId) formData.append('Id', documentId);");
            sb.AppendLine("");
            sb.AppendLine("            $.ajax({");
            sb.AppendLine($"                url: documentId ? `${{backendUrl}}/{FormName}Document/${{documentId}}` : `${{backendUrl}}/{FormName}Document`,");
            sb.AppendLine("                type: documentId ? 'PUT' : 'POST',");
            sb.AppendLine("                data: formData,");
            sb.AppendLine("                contentType: false,");
            sb.AppendLine("                processData: false,");
            sb.AppendLine("                beforeSend: function (xhr) {");
            sb.AppendLine("                    const token = localStorage.getItem('jwtToken');");
            sb.AppendLine("                    if (token) xhr.setRequestHeader('Authorization', 'Bearer ' + token);");
            sb.AppendLine("                },");
            sb.AppendLine("                success: function () {");
            sb.AppendLine("                    fnShowNotification(documentId ? 'Document updated successfully.' : 'Document created successfully.', 'success');");
            if (document.ParentFormName != null)
            {
                //sb.AppendLine($"                    setTimeout(() => window.location.href = `/{TableName}/{FormName}Details1?id=${{FkId}}`, 1000);");
                sb.AppendLine($"                    setTimeout(() => {{ window.history.back();}}, 1000);");
            }
            else
            {
                //sb.AppendLine($"                    setTimeout(() => window.location.href = `/{TableName}/{FormName}Details?id=${{FkId}}`, 1000);");
                sb.AppendLine($"                    setTimeout(() =>{{ window.history.back();}}, 1000);");
            }
            sb.AppendLine("                },");
            sb.AppendLine("                error: function (xhr) {");
            sb.AppendLine("                    const msg = xhr.status === 401");
            sb.AppendLine("                        ? \"Unauthorized access — please login again.\"");
            sb.AppendLine("                        : \"Save failed: \" + (xhr.responseText || xhr.statusText);");
            sb.AppendLine("                    notification.show(msg, \"error\");");
            sb.AppendLine("                }");
            sb.AppendLine("            });");
            sb.AppendLine("        });");
            sb.AppendLine("");
            sb.AppendLine("        $(\"#cancelButton\").click(function () {");
            if (document.ParentFormName != null)
            {
                //sb.AppendLine($"            window.location.href = `/{TableName}/{FormName}Details1?id=${{FkId}}`;");
                sb.AppendLine("            window.history.back();");
            }
            else
            {
                //sb.AppendLine($"            window.location.href = `/{TableName}/{FormName}Details?id=${{FkId}}`;");
                sb.AppendLine("            window.history.back();");
            }
            sb.AppendLine("        });");
            sb.AppendLine("    });");
            sb.AppendLine("</script>");


            //sb.AppendLine("                success: function () {");
            //sb.AppendLine("                    notification.show(documentId ? \"Attachment updated!\" : \"Attachment saved!\", \"success\");");

            ////  Redirect with document structure
            //sb.AppendLine($"                    setTimeout(() => window.location.href = `/{TableName}/{FormName}Details?id=${{FormId}}&fkid=${{FkId}}`, 1000);");

            //sb.AppendLine("                },");
            //sb.AppendLine("                error: function (xhr) {");
            //sb.AppendLine("                    const msg = xhr.status === 401");
            //sb.AppendLine("                        ? \"Unauthorized access — please login again.\"");
            //sb.AppendLine("                        : \"Save failed: \" + (xhr.responseText || xhr.statusText);");
            //sb.AppendLine("                    notification.show(msg, \"error\");");
            //sb.AppendLine("                }");
            //sb.AppendLine("            });");
            //sb.AppendLine("        });");
            //sb.AppendLine("");
            //sb.AppendLine("        $(\"#cancelButton\").click(function () {");

            ////  Cancel redirect with document structure
            //sb.AppendLine($"            window.location.href = `/{TableName}/{FormName}Details?id=${{FkId}}`;");

            //sb.AppendLine("        });");
            //sb.AppendLine("    });");
            //sb.AppendLine("</script>");



            string projectfoldername = $@"{clientName}\{projectName}";
            string folderPath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.MvcUI\Views\{TableName}Document";

            // Ensure the folder exists
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            // File name for Details page only
            string fileName = $"{FormName}DocumentDetails.cshtml";

            // Full file path
            string filePath = Path.Combine(folderPath, fileName);

            // Write the content to the file
            await File.WriteAllTextAsync(filePath, sb.ToString());

        }

        public static async Task GenerateFormDocumentModel(ClientForm document, string projectName, string clientName)
        {
            var FormName = document.Name;
            StringBuilder sb = new();

            sb.AppendLine("using System.Text.Json.Serialization;");
            sb.AppendLine("using Microsoft.AspNetCore.Http;");
            sb.AppendLine($"namespace Entities.Models.{document.TableName}");
            sb.AppendLine("{");
            sb.AppendLine($"    public class {FormName}DocumentModel : CommonFields");
            sb.AppendLine("    {");
            sb.AppendLine("        [JsonIgnore]");
            sb.AppendLine("        public int Id { get; set; }");
            sb.AppendLine("        public IFormFile? File { get; set; }");
            sb.AppendLine("        public string? FileName { get; set; }");
            sb.AppendLine("        public string? Name { get; set; }");
            sb.AppendLine("        public string? Description { get; set; }");
            sb.AppendLine("        public string? FilePath { get; set; }");
            sb.AppendLine("        public int? FormId { get; set; }");
            sb.AppendLine("        public int? DocumentId { get; set; }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            // Create the actual .cs file
            string projectfoldername = $@"{clientName}\{projectName}";
            string filePath = $@"C:\ClientProject\{projectfoldername}\Domain\Entities\Models\{document.TableName}\{FormName}DocumentModel.cs";

            await File.WriteAllTextAsync(filePath, sb.ToString());
        }

        public static async Task GenerateFormDocumentRepository(ClientForm document, string projectName, string clientName)
        {
            var FormName = document.Name;
            var sb = new StringBuilder();

            sb.AppendLine("using Dapper;");
            sb.AppendLine("using static DapperDB.DapperDbContext;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine($"using Entities.Models.{document.TableName};");
            sb.AppendLine("using Entities.Models.Request;");
            sb.AppendLine("using Entities.Models.Response;");
            sb.AppendLine();
            sb.AppendLine("namespace Repositories");
            sb.AppendLine("{");
            sb.AppendLine($"    public class {FormName}DocumentRepository : I{FormName}Document");
            sb.AppendLine("    {");
            sb.AppendLine("        private readonly DbContext _context;");
            sb.AppendLine($"        public {FormName}DocumentRepository(DbContext context)");
            sb.AppendLine("        {");
            sb.AppendLine("            _context = context;");
            sb.AppendLine("        }");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<string> CreateDocument({FormName}DocumentModel document)");
            sb.AppendLine("        {");
            sb.AppendLine("            string response = string.Empty;");
            sb.AppendLine();
            sb.AppendLine("            var insertDocumentQuery = @\"");
            sb.AppendLine("            INSERT INTO Documents (Name, Description, FileName, CreatedBy, FilePath, CreatedDate, FormId)");
            sb.AppendLine("            VALUES (@Name, @Description, @FileName, @CreatedBy, @FilePath, GETDATE(), @FormId);");
            sb.AppendLine("            SELECT CAST(SCOPE_IDENTITY() AS INT);\";");
            sb.AppendLine();
            sb.AppendLine($"            var insert{FormName}DocumentQuery = @\"");
            sb.AppendLine($"            INSERT INTO {FormName}Document ({FormName}ID, DocumentID)");
            sb.AppendLine($"            VALUES (@{FormName}ID, @DocumentID);\";");
            sb.AppendLine();
            sb.AppendLine("            using (var connection = _context.CreateConnection())");
            sb.AppendLine("            {");
            sb.AppendLine("                try");
            sb.AppendLine("                {");
            sb.AppendLine("                    var documentId = await connection.ExecuteScalarAsync<int>(");
            sb.AppendLine("                        insertDocumentQuery,");
            sb.AppendLine("                        document");
            sb.AppendLine("                    );");
            sb.AppendLine();
            sb.AppendLine($"                    var {FormName}DocParams = new");
            sb.AppendLine("                    {");
            sb.AppendLine($"                        {FormName}ID = document.FormId,");
            sb.AppendLine("                        DocumentID = documentId");
            sb.AppendLine("                    };");
            sb.AppendLine();
            sb.AppendLine("                    await connection.ExecuteAsync(");
            sb.AppendLine($"                        insert{FormName}DocumentQuery,");
            sb.AppendLine($"                        {FormName}DocParams");
            sb.AppendLine("                    );");
            sb.AppendLine();
            sb.AppendLine("                    response = \"Document Added Successfully\";");
            sb.AppendLine("                }");
            sb.AppendLine("                catch (Exception)");
            sb.AppendLine("                {");
            sb.AppendLine("                    throw;");
            sb.AppendLine("                }");
            sb.AppendLine("            }");
            sb.AppendLine();
            sb.AppendLine("            return response;");
            sb.AppendLine("        }");
            sb.AppendLine();
            sb.AppendLine("        public async Task<string> DeleteDocument(int id)");
            sb.AppendLine("        {");
            sb.AppendLine("            var response = string.Empty;");
            sb.AppendLine();
            sb.AppendLine("            var getFileQuery = \"SELECT FileName, FilePath FROM Documents WHERE Id = @id\";");
            sb.AppendLine($"            var delete{FormName}DocQuery = \"DELETE FROM {FormName}Document WHERE DocumentID = @id\";");
            sb.AppendLine("            var deleteDocQuery = \"DELETE FROM Documents WHERE Id = @id\";");
            sb.AppendLine();
            sb.AppendLine("            using (var connection = _context.CreateConnection())");
            sb.AppendLine("            {");
            sb.AppendLine("                var fileData = await connection.QueryFirstOrDefaultAsync<(string FileName, string FilePath)>(");
            sb.AppendLine("                    getFileQuery, new { id });");
            sb.AppendLine();
            sb.AppendLine("                if (fileData.FileName == null)");
            sb.AppendLine("                    return \"Id does not exist\";");
            sb.AppendLine();
            sb.AppendLine("                if (!string.IsNullOrWhiteSpace(fileData.FilePath))");
            sb.AppendLine("                {");
            sb.AppendLine("                    var physicalPath = Path.Combine(Directory.GetCurrentDirectory(), \"wwwroot\", fileData.FilePath);");
            sb.AppendLine("                    if (System.IO.File.Exists(physicalPath))");
            sb.AppendLine("                    {");
            sb.AppendLine("                        System.IO.File.Delete(physicalPath);");
            sb.AppendLine("                    }");
            sb.AppendLine("                }");
            sb.AppendLine();
            sb.AppendLine($"                await connection.ExecuteAsync(delete{FormName}DocQuery, new {{ id }});");
            sb.AppendLine("                int rowsAffected = await connection.ExecuteAsync(deleteDocQuery, new { id });");
            sb.AppendLine("                response = rowsAffected > 0 ? \"Document Deleted\" : \"Failed to delete document\";");
            sb.AppendLine("            }");
            sb.AppendLine();
            sb.AppendLine("            return response;");
            sb.AppendLine("        }");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<Response> GetDocument(Request request, int id)");
            sb.AppendLine("        {");
            sb.AppendLine($"            var whereClause = \"WHERE SD.{FormName}ID = @id\";");
            sb.AppendLine();
            sb.AppendLine("            if (request.Filter != null)");
            sb.AppendLine("            {");
            sb.AppendLine("                var dynamicClause = new Filter().BuildWhereClause(request.Filter);");
            sb.AppendLine("                if (!string.IsNullOrWhiteSpace(dynamicClause))");
            sb.AppendLine("                    whereClause += \" AND \" + dynamicClause;");
            sb.AppendLine("            }");
            sb.AppendLine();
            sb.AppendLine($"            var totalCountQuery = $\"SELECT COUNT(*) FROM {FormName}Document AS SD INNER JOIN Documents AS D ON SD.DocumentID = D.Id {{whereClause}}\";");
            sb.AppendLine();
            sb.AppendLine("            var baseQuery = $@\"");
            sb.AppendLine($"                SELECT SD.ID, D.Id AS DocumentId, D.Name, D.FileName, D.FilePath FROM {FormName}Document AS SD INNER JOIN Documents AS D ON SD.DocumentID = D.Id");
            sb.AppendLine("                {whereClause}");
            sb.AppendLine("                ORDER BY {(request.Sort != null && request.Sort.Any()");
            sb.AppendLine("                            ? string.Join(',', request.Sort.Select(s => $\"{s.Field} {s.Dir}\"))");
            sb.AppendLine("                            : \"SD.ID\")}");
            sb.AppendLine("                OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY;\";");
            sb.AppendLine();
            sb.AppendLine("            using (var connection = _context.CreateConnection())");
            sb.AppendLine("            {");
            sb.AppendLine("                var parameters = new DynamicParameters();");
            sb.AppendLine("                parameters.Add(\"id\", id);");
            sb.AppendLine("                parameters.Add(\"skip\", request.Skip);");
            sb.AppendLine("                parameters.Add(\"take\", request.Take);");
            sb.AppendLine();
            sb.AppendLine("                var total = await connection.ExecuteScalarAsync<int>(totalCountQuery, parameters);");
            sb.AppendLine($"                var result = await connection.QueryAsync<{FormName}DocumentModel>(baseQuery, parameters);");
            sb.AppendLine("                var aggregates = new Dictionary<string, Dictionary<string, string>>();");
            sb.AppendLine("                return new Response(result.ToList(), aggregates, total, isGrouped: false);");
            sb.AppendLine("            }");
            sb.AppendLine("        }");

            sb.AppendLine();
            sb.AppendLine($"        public async Task<{FormName}DocumentModel> GetDocumentById(int id)");
            sb.AppendLine("        {");
            sb.AppendLine($"            const string query = \"SELECT SD.Id AS Id, D.Id As DocumentId, D.Name, D.FileName, D.Description, D.FilePath FROM {FormName}Document AS SD INNER JOIN Documents AS D ON SD.DocumentID = D.Id WHERE SD.ID = @id\";");
            sb.AppendLine("            using (var connection = _context.CreateConnection())");
            sb.AppendLine("            {");
            sb.AppendLine($"                return await connection.QueryFirstOrDefaultAsync<{FormName}DocumentModel>(query, new {{ id }});");
            sb.AppendLine("            }");
            sb.AppendLine("        }");
            sb.AppendLine();
            sb.AppendLine($"        public async Task<string> UpdateDocument({FormName}DocumentModel document, int id)");
            sb.AppendLine("        {");
            sb.AppendLine("            using (var connection = _context.CreateConnection())");
            sb.AppendLine("            {");
            sb.AppendLine("                var existingData = await connection.QueryFirstOrDefaultAsync<(string FileName, string FilePath)>(");
            sb.AppendLine("                    \"SELECT FileName, FilePath FROM Documents WHERE Id = @documentId\", new { document.DocumentId });");
            sb.AppendLine();
            sb.AppendLine("                if (existingData.FileName == null)");
            sb.AppendLine("                    return \"Id does not exist\";");
            sb.AppendLine();
            sb.AppendLine("                string newFileName = !string.IsNullOrWhiteSpace(document.FileName) ? document.FileName : existingData.FileName;");
            sb.AppendLine("                string newFilePath = !string.IsNullOrWhiteSpace(document.FilePath) ? document.FilePath : existingData.FilePath;");
            sb.AppendLine();
            sb.AppendLine("                if (document.File != null && document.File.Length > 0)");
            sb.AppendLine("                {");
            sb.AppendLine("                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), \"wwwroot\", \"uploads\");");
            sb.AppendLine("                    Directory.CreateDirectory(uploadsFolder);");
            sb.AppendLine();
            sb.AppendLine("                    newFileName = Path.GetFileName(document.File.FileName);");
            sb.AppendLine("                    var physicalPath = Path.Combine(uploadsFolder, newFileName);");
            sb.AppendLine("                    newFilePath = Path.Combine(\"uploads\", newFileName);");
            sb.AppendLine();
            sb.AppendLine("                    using (var stream = new FileStream(physicalPath, FileMode.Create))");
            sb.AppendLine("                    {");
            sb.AppendLine("                        await document.File.CopyToAsync(stream);");
            sb.AppendLine("                    }");
            sb.AppendLine();
            sb.AppendLine("                    var oldPhysicalPath = Path.Combine(Directory.GetCurrentDirectory(), \"wwwroot\", existingData.FilePath);");
            sb.AppendLine("                    if (!string.Equals(newFilePath, existingData.FilePath, StringComparison.OrdinalIgnoreCase)");
            sb.AppendLine("                        && System.IO.File.Exists(oldPhysicalPath))");
            sb.AppendLine("                    {");
            sb.AppendLine("                        System.IO.File.Delete(oldPhysicalPath);");
            sb.AppendLine("                    }");
            sb.AppendLine("                }");
            sb.AppendLine();
            sb.AppendLine("                var query = @\"");
            sb.AppendLine("                UPDATE Documents");
            sb.AppendLine("                SET ");
            sb.AppendLine("                    Name = @Name,");
            sb.AppendLine("                    Description = @Description,");
            sb.AppendLine("                    FileName = @FileName,");
            sb.AppendLine("                    FilePath = @FilePath,");
            sb.AppendLine("                    ModifiedBy = @ModifiedBy,");
            sb.AppendLine("                    ModifiedDate = GETDATE()");
            sb.AppendLine("                WHERE Id = @Id\";");
            sb.AppendLine();
            sb.AppendLine("                var result = await connection.ExecuteAsync(query, new");
            sb.AppendLine("                {");
            sb.AppendLine("                    Name = document.Name,");
            sb.AppendLine("                    Description = document.Description,");
            sb.AppendLine("                    FileName = newFileName,");
            sb.AppendLine("                    FilePath = newFilePath,");
            sb.AppendLine("                    ModifiedBy = document.MODIFIEDBY,");
            sb.AppendLine("                    Id = document.DocumentId");
            sb.AppendLine("                });");
            sb.AppendLine();
            sb.AppendLine("                return result > 0 ? \"Document Updated\" : \"Failed to update record\";");
            sb.AppendLine("            }");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            // Create the actual .cs file
            string projectfoldername = $@"{clientName}\{projectName}";
            string filePath = $@"C:\ClientProject\{projectfoldername}\Infrastructure\Repositories\{FormName}DocumentRepository.cs";

            await File.WriteAllTextAsync(filePath, sb.ToString());


        }

        public static async Task GenerateFormDocumentController(ClientForm document, string projectName, string clientName)
        {
            var FormName = document.Name;
            var sb = new StringBuilder();

            sb.AppendLine("using Microsoft.AspNetCore.Authorization;");
            sb.AppendLine("using Microsoft.AspNetCore.Mvc;");
            sb.AppendLine($"using Entities.Models.{document.TableName};");
            sb.AppendLine("using Entities.Models.Request;");
            sb.AppendLine("using MediatR;");
            sb.AppendLine($"using Application.Modules.{FormName}.Commands;");
            sb.AppendLine($"using Application.Modules.{FormName}.Queries;");
            sb.AppendLine();
            sb.AppendLine("[Authorize]");
            sb.AppendLine("[ApiController]");
            sb.AppendLine("[Route(\"[controller]\")]");
            sb.AppendLine($"public class {FormName}DocumentController : ControllerBase");
            sb.AppendLine("{");
            //sb.AppendLine($"    private readonly I{FormName}Document _documentRepo;");
            sb.AppendLine("    private readonly IWebHostEnvironment _env;");
            sb.AppendLine("    private readonly IMediator _mediator;");
            sb.AppendLine();
            sb.AppendLine($"    public {FormName}DocumentController(IMediator mediator, IWebHostEnvironment env)");
            sb.AppendLine("    {");
            sb.AppendLine("        _mediator = mediator;");
            sb.AppendLine("        _env = env;");
            sb.AppendLine("    }");
            sb.AppendLine();
            sb.AppendLine("    [HttpGet(\"download\")]");
            sb.AppendLine("    public IActionResult DownloadFile(string fileName)");
            sb.AppendLine("    {");
            sb.AppendLine("        if (string.IsNullOrWhiteSpace(fileName))");
            sb.AppendLine("            return BadRequest(\"File name must be provided.\");");
            sb.AppendLine();
            sb.AppendLine("        var filePath = Path.Combine(_env.WebRootPath, \"uploads\", fileName);");
            sb.AppendLine();
            sb.AppendLine("        if (!System.IO.File.Exists(filePath))");
            sb.AppendLine("            return NotFound($\"File '{fileName}' not found.\");");
            sb.AppendLine();
            sb.AppendLine("        var fileBytes = System.IO.File.ReadAllBytes(filePath);");
            sb.AppendLine("        var mimeType = \"application/octet-stream\";");
            sb.AppendLine();
            sb.AppendLine("        return File(fileBytes, mimeType, fileName);");
            sb.AppendLine("    }");
            sb.AppendLine();
            sb.AppendLine("    [HttpPost]");
            sb.AppendLine($"    public async Task<IActionResult> CreateDocument([FromForm] {FormName}DocumentModel document)");
            sb.AppendLine("    {");
            sb.AppendLine("        if (document?.File == null || document.File.Length == 0)");
            sb.AppendLine("            return BadRequest(\"No file uploaded.\");");
            sb.AppendLine();
            sb.AppendLine("        try");
            sb.AppendLine("        {");
            sb.AppendLine("            string uploadsFolder = Path.Combine(_env.WebRootPath, \"uploads\");");
            sb.AppendLine("            Directory.CreateDirectory(uploadsFolder);");
            sb.AppendLine();
            sb.AppendLine("            string fileName = Path.GetFileName(document.File.FileName);");
            sb.AppendLine("            string filePath = Path.Combine(uploadsFolder, fileName);");
            sb.AppendLine();
            sb.AppendLine("            using (var stream = new FileStream(filePath, FileMode.Create))");
            sb.AppendLine("            {");
            sb.AppendLine("                await document.File.CopyToAsync(stream);");
            sb.AppendLine("            }");
            sb.AppendLine();
            sb.AppendLine("            document.FilePath = filePath;");
            sb.AppendLine("            document.FileName = fileName;");
            sb.AppendLine();
            sb.AppendLine("            var result = await _mediator.Send(new CreateDocumentCommand(document));");
            //sb.AppendLine("            var result = await _documentRepo.CreateDocument(document);");
            sb.AppendLine("            return Ok(new { message = \"Document created successfully\", data = result });");
            sb.AppendLine("        }");
            sb.AppendLine("        catch (Exception ex)");
            sb.AppendLine("        {");
            sb.AppendLine("            return StatusCode(500, $\"File upload failed: {ex.Message}\");");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine();
            sb.AppendLine("    [HttpPut(\"{id}\")]");
            sb.AppendLine($"    public async Task<IActionResult> UpdateDocument([FromForm] {FormName}DocumentModel document, int id)");
            sb.AppendLine("    {");
            sb.AppendLine("        if (document == null)");
            sb.AppendLine("            return BadRequest(\"No document data provided.\");");
            sb.AppendLine();
            sb.AppendLine("        var existing = await _mediator.Send(new GetDocumentByIdCommand(id));");
            //sb.AppendLine("        var existing = await _documentRepo.GetDocumentById(id);");
            sb.AppendLine("        if (existing == null)");
            sb.AppendLine("            return NotFound(\"Document not found.\");");
            sb.AppendLine();
            sb.AppendLine("        document.DocumentId = existing.DocumentId;");
            sb.AppendLine("        existing.Name = document.Name;");
            sb.AppendLine("        existing.Description = document.Description;");
            sb.AppendLine();
            sb.AppendLine("        if (document.File != null && document.File.Length > 0)");
            sb.AppendLine("        {");
            sb.AppendLine("            string uploadsFolder = Path.Combine(_env.WebRootPath, \"uploads\");");
            sb.AppendLine("            Directory.CreateDirectory(uploadsFolder);");
            sb.AppendLine();
            sb.AppendLine("            string fileName = Path.GetFileName(document.File.FileName);");
            sb.AppendLine("            string filePath = Path.Combine(uploadsFolder, fileName);");
            sb.AppendLine();
            sb.AppendLine("            using (var stream = new FileStream(filePath, FileMode.Create))");
            sb.AppendLine("            {");
            sb.AppendLine("                await document.File.CopyToAsync(stream);");
            sb.AppendLine("            }");
            sb.AppendLine();
            sb.AppendLine("            existing.FileName = fileName;");
            sb.AppendLine("            existing.FilePath = filePath;");
            sb.AppendLine("        }");
            sb.AppendLine();
            sb.AppendLine("        var updated = await _mediator.Send(new UpdateDocumentCommand(document, id));");
            //sb.AppendLine("        var updated = await _documentRepo.UpdateDocument(existing, id);");
            sb.AppendLine("        return Ok(new { message = \"Document updated successfully\", data = updated });");
            sb.AppendLine("    }");
            sb.AppendLine();
            sb.AppendLine("    [HttpDelete(\"{id}\")]");
            sb.AppendLine("    public async Task<IActionResult> DeleteDocument(int id)");
            sb.AppendLine("    {");
            sb.AppendLine("            var result = await _mediator.Send(new DeleteDocumentCommand(id));");
            //sb.AppendLine("        var result = await _documentRepo.DeleteDocument(id);");
            sb.AppendLine("        return result == \"Id does not exist\"");
            sb.AppendLine("            ? NotFound(new { message = \"Document not found\" })");
            sb.AppendLine("            : Ok(new { message = \"Document deleted successfully\", data = result });");
            sb.AppendLine("    }");
            sb.AppendLine();
            sb.AppendLine("    [HttpPost(\"Documents/{id}\")]");
            sb.AppendLine("    public async Task<IActionResult> GetDocuments([FromBody] Request request, int id)");
            sb.AppendLine("    {");
            sb.AppendLine("        try");
            sb.AppendLine("        {");
            sb.AppendLine("            var result = await _mediator.Send(new GetDocumentsCommand(request, id));");
            //sb.AppendLine("            var result = await _documentRepo.GetDocument(request, id);");
            sb.AppendLine("            return Ok(result.ToResult());");
            sb.AppendLine("        }");
            sb.AppendLine("        catch (Exception ex)");
            sb.AppendLine("        {");
            sb.AppendLine("            return StatusCode(500, ex.Message);");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine();
            sb.AppendLine("    [HttpGet(\"{id}\")]");
            sb.AppendLine("    public async Task<IActionResult> GetDocumentById(int id)");
            sb.AppendLine("    {");
            sb.AppendLine("         var record = await _mediator.Send(new GetDocumentByIdCommand(id));");
            //sb.AppendLine("        var record = await _documentRepo.GetDocumentById(id);");
            sb.AppendLine("        return record != null");
            sb.AppendLine("            ? Ok(record)");
            sb.AppendLine("            : NotFound(new { message = \"Document not found\" });");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            // Create the actual .cs file
            string projectfoldername = $@"{clientName}\{projectName}";
            string filePath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.Api\Controllers\{FormName}DocumentController.cs";

            await File.WriteAllTextAsync(filePath, sb.ToString());



        }

        public static async Task GenerateFormDocumentInterface(ClientForm document, string projectName, string clientName)
        {
            var FormName = document.Name;
            var sb = new StringBuilder();

            sb.AppendLine($"using Entities.Models.{document.TableName};");
            sb.AppendLine("using Entities.Models.Request;");
            sb.AppendLine("using Entities.Models.Response;");
            sb.AppendLine();
            sb.AppendLine("namespace Interfaces");
            sb.AppendLine("{");
            sb.AppendLine($"    public interface I{FormName}Document");
            sb.AppendLine("    {");
            sb.AppendLine($"        Task<string> CreateDocument({FormName}DocumentModel document);");
            sb.AppendLine($"        Task<string> UpdateDocument({FormName}DocumentModel document, int id);");
            sb.AppendLine("        Task<string> DeleteDocument(int id);");
            sb.AppendLine($"        Task<{FormName}DocumentModel> GetDocumentById(int id);");
            sb.AppendLine("        Task<Response> GetDocument(Request request, int id);");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            // Create the actual .cs file
            string projectfoldername = $@"{clientName}\{projectName}";
            string filePath = $@"C:\ClientProject\{projectfoldername}\Domain\Interfaces\I{FormName}Document.cs";

            await File.WriteAllTextAsync(filePath, sb.ToString());

        }

        public async Task GenerateFormDocumentMvcController(ClientForm parent, List<ClientForm> childs, string projectName, string clientName)
        {
            var TableName = parent.TableName;
            var FormName = parent.Name;
            var sb = new StringBuilder();

            sb.AppendLine("using Microsoft.AspNetCore.Mvc;");
            sb.AppendLine();
            sb.AppendLine("namespace ClientProjectBuilder.MvcUI.Controllers");
            sb.AppendLine("{");
            sb.AppendLine($"    public class {TableName}DocumentController : Controller");
            sb.AppendLine("    {");

            // Add action methods for the parent
            sb.AppendLine($"        public IActionResult {FormName}DocumentList(int id)");
            sb.AppendLine("        {");
            sb.AppendLine("            ViewBag.Id = id;");
            sb.AppendLine("            return PartialView();");
            sb.AppendLine("        }");
            sb.AppendLine();
            sb.AppendLine($"        public IActionResult {FormName}DocumentDetails()");
            sb.AppendLine("        {");
            sb.AppendLine("            return View();");
            sb.AppendLine("        }");
            sb.AppendLine();

            // Loop through children and add actions for each
            foreach (var child in childs)
            {
                var childFormName = child.Name;

                sb.AppendLine($"        public IActionResult {childFormName}DocumentList(int id)");
                sb.AppendLine("        {");
                sb.AppendLine("            ViewBag.Id = id;");
                sb.AppendLine("            return PartialView();");
                sb.AppendLine("        }");
                sb.AppendLine();
                sb.AppendLine($"        public IActionResult {childFormName}DocumentDetails()");
                sb.AppendLine("        {");
                sb.AppendLine("            return View();");
                sb.AppendLine("        }");
                sb.AppendLine();
            }

            sb.AppendLine("    }");
            sb.AppendLine("}");

            // Create the actual .cs file
            string projectfoldername = $@"{clientName}\{projectName}";
            string filePath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.MvcUI\Controllers\{parent.TableName}DocumentController.cs";

            await File.WriteAllTextAsync(filePath, sb.ToString());

        }

        public async Task GenerateDocumentFormFiles(ClientForm document, string projectName, string clientName)
        {
            try
            {
                await GenerateFormDocumentList(document, projectName, clientName);
                Console.WriteLine("List generated");

                await GenerateFormDocumentDetails(document, projectName, clientName);
                Console.WriteLine("Details generated");

                await GenerateFormDocumentModel(document, projectName, clientName);
                Console.WriteLine("Model generated");

                await GenerateFormDocumentRepository(document, projectName, clientName);
                Console.WriteLine("Repository generated");

                await GenerateFormDocumentController(document, projectName, clientName);
                Console.WriteLine("Controller generated");

                await GenerateFormDocumentInterface(document, projectName, clientName);
                Console.WriteLine("Interface generated");

                generateApplicationLayerClass.GenerateApplicationLayerForDocument(document, projectName, clientName);

                //await GenerateFormDocumentMvcController(document, projectName, clientName);
                //Console.WriteLine("MVC generated");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                throw;
            }
        }


    }

}
