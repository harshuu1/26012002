﻿using System;
using System.Data;
using System.Text;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateRuleClass
    {
        public  void GenerateRule(ClientTable table, string modelName, string ProjectName, string ClientName, IEnumerable<ClientForm> FormList, List<ClientCardViewFields> RuleList)
        {


            var modelNameObject = modelName.ToLower();
            bool hasPredefineQueryId = RuleList.Any(r => r.PredefineQueryId > 0);

            var controllerCode = new StringBuilder();
            controllerCode.AppendLine($"using Entities.Models.{table.Name};");
            controllerCode.AppendLine("using Entities.Models.RuleCriteria;");

            controllerCode.AppendLine(hasPredefineQueryId ? "using Interfaces;" : string.Empty);

            controllerCode.AppendLine();
            controllerCode.AppendLine($"namespace BusinessRule.{table.Name}");
            controllerCode.AppendLine("{");
            controllerCode.AppendLine($"    public class {table.Name}Rule");
            controllerCode.AppendLine("    {");

            controllerCode.AppendLine(hasPredefineQueryId ?
             "    private readonly IPredefinedQuery _repository;\n" +
             $"\n    public {table.Name}Rule(IPredefinedQuery repository)\n" +
             "    {\n" +
             "        _repository = repository;\n" +
             "    }"
             : string.Empty);

            // --- ValidateRules Method ---
            var ruleGroups = RuleList.GroupBy(r => r.RuleId);

            //----Main Method ValidateAllRule ----//

            controllerCode.AppendLine($"public async Task<string> ValidateAllRule({modelName}Model {modelNameObject} , string FormName)");
            controllerCode.AppendLine("{");
            controllerCode.AppendLine("    var errors = new List<string>();");
            controllerCode.AppendLine("");

            var firstForm = FormList?.FirstOrDefault();

            if (firstForm != null && firstForm.RuleTableId != null)
            {

                controllerCode.AppendLine($"var lstFailResponse = await ValidateTable_{table.Name}({modelNameObject});");
                controllerCode.AppendLine("var tableValidation = lstFailResponse.Any()");
                controllerCode.AppendLine("    ? string.Join(\", \", lstFailResponse.Select(x => x.FailMessage))");
                controllerCode.AppendLine("    : \"\";");
                controllerCode.AppendLine("if (!string.IsNullOrEmpty(tableValidation))");
                controllerCode.AppendLine("{");
                controllerCode.AppendLine("    errors.Add(tableValidation);");
                controllerCode.AppendLine("}");
                controllerCode.AppendLine("");
            }

            if (FormList != null)
            { 
                foreach (var formItem in FormList)
                {
                    if (formItem.RuleFormId != null)
                    {
                        controllerCode.AppendLine($"if (FormName == \"{formItem.Name}\")");
                        controllerCode.AppendLine("{");
                        controllerCode.AppendLine($"    var formValidation = await ValidateForm_{formItem.Name}({modelNameObject});");
                        controllerCode.AppendLine("      if (!string.IsNullOrEmpty(formValidation))");
                        controllerCode.AppendLine("{");
                        controllerCode.AppendLine("   errors.Add(formValidation);");
                        controllerCode.AppendLine("}");
                        controllerCode.AppendLine("}");
                        controllerCode.AppendLine(); // Adds an empty line for spacing
                    }
                }
            }

            controllerCode.AppendLine("    return errors.Any() ? string.Join(\", \", errors) : \"Validation passed\";");
            controllerCode.AppendLine("}");

            //----Main Method ValidateTable && ValidateForm ----//

            //ValidateTable

            var tableRules = RuleList
                .Where(r => r.TableId == table.ID && r.FormId == 0)
                .GroupBy(r => r.RuleId);

            if (table.ID != 0)
            {
                controllerCode.AppendLine($"        public async Task<List<ValidationModel>> ValidateTable_{table.Name}({modelName}Model {modelNameObject})");
                controllerCode.AppendLine("        {");
                controllerCode.AppendLine("            var failResponse = new List<ValidationModel>();");
                foreach (var group in tableRules)
                {
                    // Fetch rule name directly from RuleList
                    var ruleId = RuleList.FirstOrDefault(r => r.RuleId == group.Key);
                    var ruleName = ruleId != null ? ruleId.RuleName : $"UnknownRule_{group.Key}";

                    //var newname = ruleName.Trim().Replace(" ", "");
                    var newname = (ruleName ?? string.Empty).Trim().Replace(" ", "");

                    newname = char.ToLower(newname[0]) + newname[1..];
                    var methodName = (ruleName ?? string.Empty).Trim().Replace(" ", "_");
                    methodName = char.ToUpper(methodName[0]) + methodName[1..];

                    if (ruleId != null  && ruleId.ValidateCriteria.HasValue && (CriteriaEnum)ruleId.ValidateCriteria == CriteriaEnum.All)
                    {
                        controllerCode.AppendLine($"  var {newname} = {methodName}_{table.Name}({modelNameObject});");
                        controllerCode.AppendLine($"if (!{newname}.All(v => v.Success))");
                        controllerCode.AppendLine("{");
                        controllerCode.AppendLine("    failResponse.AddRange(");
                        controllerCode.AppendLine($"        {newname}.Where(item => !item.Success)");
                        controllerCode.AppendLine("                    .Select(item => new ValidationModel");
                        controllerCode.AppendLine("                    {");
                        controllerCode.AppendLine("                        FieldName = item.FieldName,");
                        controllerCode.AppendLine("                        FailMessage = item.FailMessage");
                        controllerCode.AppendLine("                    }));");
                        controllerCode.AppendLine("}");
                    }

                    else
                    {
                        controllerCode.AppendLine($"  var {newname} = {methodName}_{table.Name}({modelNameObject});");
                        controllerCode.AppendLine($"if (!{newname}.Any(v => v.Success))");
                        controllerCode.AppendLine("{");
                        controllerCode.AppendLine("    failResponse.AddRange(");
                        controllerCode.AppendLine($"        {newname}.Where(item => !item.Success)");
                        controllerCode.AppendLine("                    .Select(item => new ValidationModel");
                        controllerCode.AppendLine("                    {");
                        controllerCode.AppendLine("                        FieldName = item.FieldName,");
                        controllerCode.AppendLine("                        FailMessage = item.FailMessage");
                        controllerCode.AppendLine("                    }));");
                        controllerCode.AppendLine("}");
                    }

                }
                controllerCode.AppendLine("            return failResponse;");
                controllerCode.AppendLine("        }");
                controllerCode.AppendLine();
            }

            //Form vise form method
            //
            if (FormList != null)
            {
                foreach (var formItem in FormList)
                {
                    var ruleGroupsForm = RuleList.Where(r => r.FormId == formItem.ID).GroupBy(r => r.RuleId);
                    if (formItem.RuleFormId != null)
                    {
                        controllerCode.AppendLine($"        private async Task<string> ValidateForm_{formItem.Name}({modelName}Model {modelNameObject})");
                        controllerCode.AppendLine("        {");
                        controllerCode.AppendLine("            var errors = new List<string>();");
                        foreach (var group in ruleGroupsForm)
                        {
                            // Fetch rule name directly from RuleList
                            var ruleId = RuleList.FirstOrDefault(r => r.RuleId == group.Key);
                            var ruleName = ruleId != null ? ruleId.RuleName : $"UnknownRule_{group.Key}";
                        var newname = ruleName.Trim().Replace(" ", "");
                        newname = char.ToLower(newname[0]) + newname.Substring(1);
                        var methodName = ruleName.Trim().Replace(" ", "_");
                        methodName = char.ToUpper(methodName[0]) + methodName.Substring(1);

                            if (ruleId != null  &&  ruleId.ValidateCriteria.HasValue && (CriteriaEnum)ruleId.ValidateCriteria == CriteriaEnum.All)
                            {
                                controllerCode.AppendLine($"  var {newname} = {methodName}_{formItem.Name}({modelNameObject});");
                                controllerCode.AppendLine($"if (!{newname}.All(v => v.Success))");
                                controllerCode.AppendLine("{");
                                controllerCode.AppendLine($"    errors.AddRange({newname}.Where(e => !e.Success).Select(e => e.FailMessage));");
                                controllerCode.AppendLine("}");
                            }
                            else
                            {
                                controllerCode.AppendLine($"  var {newname} = {methodName}_{formItem.Name}({modelNameObject});");
                                controllerCode.AppendLine($"if (!{newname}.Any(v => v.Success))");
                                controllerCode.AppendLine("{");
                                controllerCode.AppendLine($"    errors.AddRange({newname}.Where(e => !e.Success).Select(e => e.FailMessage));");
                                controllerCode.AppendLine("}");
                            }
                        }
                        controllerCode.AppendLine("            return errors.Any() ? string.Join(\", \", errors) : \"\";");
                        controllerCode.AppendLine("        }");
                        controllerCode.AppendLine();
                    }
                }
            }

            // --- Rule Methods for each RuleId in this form ---
            HashSet<int> ConditionalRuleIds = [];

            foreach (var group in ruleGroups)
            {
                // Fetch rule name directly from RuleList
                var ruleId = RuleList.FirstOrDefault(r => r.RuleId == group.Key);
                var ruleName = ruleId != null ? ruleId.RuleName : $"UnknownRule_{group.Key}";
                var methodName = (ruleName ?? string.Empty).Trim().Replace(" ", "_");
                methodName = char.ToUpper(methodName[0]) + methodName[1..];

                if (ruleId != null && ruleId.FormId == 0)
                {
                    controllerCode.AppendLine($"        List<ValidationModel> {methodName}_{table.Name}({modelName}Model {modelNameObject})");
                    controllerCode.AppendLine("        {");
                    controllerCode.AppendLine("            var validations = new List<ValidationModel>();");
                    string indent = "            ";
                    foreach (var rule in group)
                    {
                        EvaluateRule(controllerCode, modelName, rule, [.. group], indent, ConditionalRuleIds);
                        //TODO EvaluateRule(controllerCode, modelName, rule, group.ToList(), indent, ConditionalRuleIds);
                    }

                    controllerCode.AppendLine("            return validations;");
                    controllerCode.AppendLine("        }");
                }
                else
                {
                    controllerCode.AppendLine($"        List<ValidationModel> {methodName}_{ruleId?.FormName}({modelName}Model {modelNameObject})");
                    controllerCode.AppendLine("        {");
                    controllerCode.AppendLine("            var validations = new List<ValidationModel>();");
                    string indent = "            ";
                    foreach (var rule in group)
                    {
                        EvaluateRule(controllerCode, modelName, rule, [.. group], indent, ConditionalRuleIds);
                    }

                    controllerCode.AppendLine("            return validations;");
                    controllerCode.AppendLine("        }");
                }

                controllerCode.AppendLine();
            }

            // EvaluateRule Method (keeping your existing logic)
            void EvaluateRule(StringBuilder controllerCode, string modelName, ClientCardViewFields rule, List<ClientCardViewFields> allRules, string indent, HashSet<int> ConditionalRuleIds)
            {
                string condition = "";
                var fieldNameTrimmed = string.IsNullOrWhiteSpace(rule.FieldName)
     ? ""
     : char.ToUpper(rule.FieldName.Trim()[0]) + rule.FieldName.Trim().Substring(1).ToLower();

           
                foreach (var rule1 in allRules)
                {
                    switch (rule.FieldTypeName)
                    {
                        case "int":
                        case "smallint":
                        case "bigint":
                        case "float":
                        case "slider":
                            if (rule.FieldValue == "0")
                            {
                                condition = $"({modelNameObject}.{fieldNameTrimmed} {rule.Operator} {rule.FieldValue})";
                            }
                            else
                            {
                             condition = $"({modelNameObject}.{fieldNameTrimmed} {rule.Operator}      {rule.FieldValue})";
                            }
                            break;

                        case "number":
                        case "decimal":
                        case "numeric":
                        case "money":
                        case "rating":
                            if (rule.FieldValue == "0")
                            {
                                condition = $"({modelNameObject}.{fieldNameTrimmed} {rule.Operator} {rule.FieldValue})";
                            }
                            else
                            {
                                condition = $"({modelNameObject}.{fieldNameTrimmed} {rule.Operator}   {rule.FieldValue}m)";
                            }
                            break;


                        case "varchar":
                        case "nvarchar":
                        case "varbinary":
                        case "colorpicker":
                            if (rule.Operator == "==" || rule.Operator == "!=")
                            {
                                condition = $"{modelNameObject}.{fieldNameTrimmed} {rule.Operator}        (\"{rule.FieldValue}\")";
                            }
                            else
                            {
                            condition = $"{modelNameObject}.{fieldNameTrimmed}.{rule.Operator}    (\"{rule.FieldValue}\")";
                            }
                            
                            break;

                        case "bit":
                        case "checkbox":
                        case "switches":
                        case "radiogroup":
                            if (rule.FieldValue?.ToLower() == "true")
                            {
                                condition = $"((bool){modelNameObject}.{fieldNameTrimmed} )";
                            }
                            else
                            {
                                condition = $"(!(bool){modelNameObject}.{fieldNameTrimmed} )";
                            }
                            break;

                        case "date":
                            condition = $"{modelNameObject}.{fieldNameTrimmed} {rule.Operator} DateOnly.Parse(\"{rule.FieldValue}\")";
                            break;

                        case "datetime":
                            condition = $"{modelNameObject}.{fieldNameTrimmed} {rule.Operator} DateTime.Parse(\"{rule.FieldValue}\")";
                            break;

                        case "timeduration":
                            condition = $"{modelNameObject}.{fieldNameTrimmed} {rule.Operator} TimeSpan.Parse(\"{rule.FieldValue}\")";
                            break;

                        case "barcode":
                            switch (rule.Operator)
                            {
                                case "==":
                                case "!=":
                                case "<=":
                                case ">=":
                                    // Numeric or Date comparison
                                    condition = $"{modelNameObject}.{fieldNameTrimmed} {rule.Operator} \"{rule.FieldValue}\"";
                                    break;

                                case "StartsWith":
                                    condition = $"{modelNameObject}.{fieldNameTrimmed}.StartsWith(\"{rule.FieldValue}\")";
                                    break;

                                case "EndsWith":
                                    condition = $"{modelNameObject}.{fieldNameTrimmed}.EndsWith(\"{rule.FieldValue}\")";
                                    break;

                                default:
                                    throw new InvalidOperationException($"Unsupported operator for barcode: {rule.Operator}");
                            }
                            break;

                    }
                }
                // Your existing conditional rule logic...
                if (rule.ConditionalRuleId != 0)
                {
                    ConditionalRuleIds.Add(rule.ConditionalRuleId);

                    if (rule.FormId == 0)
                    {
                        var methodName = (rule.ConditionalRuleName ?? string.Empty).Trim().Replace(" ", "_");
                        methodName = char.ToUpper(methodName[0]) + methodName[1..];

                        if ((CriteriaEnum)Enum.Parse(typeof(CriteriaEnum), rule.ConditionalRuleValidateCriteria ?? string.Empty) == CriteriaEnum.All)
                        {
                            controllerCode.AppendLine($"{indent}if ({methodName}_{table.Name}({modelNameObject}).All(r => r.Success))");
                        }

                        else
                        {
                            controllerCode.AppendLine($"{indent}if ({methodName}_{table.Name}({modelNameObject}).Any(r => r.Success))");
                        }
                    }

                    else
                    {
                        //var methodName = rule.ConditionalRuleName.Trim().Replace(" ", "_");
                        var methodName = (rule.ConditionalRuleName ?? string.Empty).Trim().Replace(" ", "_");

                        methodName = char.ToUpper(methodName[0]) + methodName[1..];

                        if ((CriteriaEnum)Enum.Parse(typeof(CriteriaEnum), rule.ConditionalRuleValidateCriteria ?? string.Empty) == CriteriaEnum.All)
                        {
                            controllerCode.AppendLine($"{indent}if ({methodName}_{rule.FormName}({modelNameObject}).All(r => r.Success))");
                        }

                        else
                        {
                            controllerCode.AppendLine($"{indent}if ({methodName}_{rule.FormName}({modelNameObject}).Any(r => r.Success))");
                        }
                    }
                    controllerCode.AppendLine($"{indent}{{");
                    controllerCode.AppendLine(
                        rule.PredefineQueryId > 0
                        ? $"{indent}bool result_{new string(rule.PredefineQueryName.Trim().Select(c => char.IsWhiteSpace(c) ? '_' : c).ToArray())} = _repository.ExecuteDynamicQuery(\"{rule.PredefineQueryName}\", {modelNameObject}).GetAwaiter().GetResult();\n" +
                          $"{indent}if (result_{new string(rule.PredefineQueryName.Trim().Select(c => char.IsWhiteSpace(c) ? '_' : c).ToArray())})\n" +
                          $"{indent}{{\n" +
                          $"{indent}    validations.Add(new ValidationModel {{ Success = true }});\n" +
                          $"{indent}}}\n" +
                          $"{indent}else\n" +
                          $"{indent}{{"
                        : $"{indent}if ({condition})\n" +
                          $"{indent}{{\n" +
                          $"{indent}    validations.Add(new ValidationModel {{ Success = true, FieldName = \"{rule.FieldName}\" }});\n" +
                          $"{indent}}}\n" +
                          $"{indent}else\n" +
                          $"{indent}{{"
                     );


                    if (!string.IsNullOrWhiteSpace(rule.FailMessage))
                    {
                        controllerCode.AppendLine(
                            rule.PredefineQueryId > 0
                            ? $"{indent}    validations.Add(new ValidationModel {{ FailMessage = \"{rule.FailMessage}\", Success = false }});"
                            : $"{indent}    validations.Add(new ValidationModel {{ FailMessage = \"{rule.DisplayName}: {rule.FailMessage}\", Success = false, FieldName = \"{rule.FieldName}\" }});"
                        );
                    }

                    controllerCode.AppendLine($"{indent}    }}");
                    controllerCode.AppendLine($"{indent}}}");
                }


                // Your existing Not conditional rule logic...

                if (rule.ConditionalRuleId == 0 || !ConditionalRuleIds.Contains(rule.ConditionalRuleId))
                {
                    controllerCode.AppendLine(
                    rule.PredefineQueryId > 0
                    ? $"{indent}bool result_{new string(rule.PredefineQueryName.Trim().Select(c => char.IsWhiteSpace(c) ? '_' : c).ToArray())} = _repository.ExecuteDynamicQuery(\"{rule.PredefineQueryName}\", {modelNameObject}).GetAwaiter().GetResult();\n" +
                      $"{indent}if (result_{new string(rule.PredefineQueryName.Trim().Select(c => char.IsWhiteSpace(c) ? '_' : c).ToArray())})\n" +
                      $"{indent}{{\n" +
                      $"{indent}    validations.Add(new ValidationModel {{ Success = true }});\n" +
                      $"{indent}}}\n" +
                      $"{indent}else\n" +
                      $"{indent}{{"
                    : $"{indent}if ({condition})\n" +
                      $"{indent}{{\n" +
                      $"{indent}    validations.Add(new ValidationModel {{ Success = true, FieldName = \"{rule.FieldName}\" }});\n" +
                      $"{indent}}}\n" +
                      $"{indent}else\n" +
                      $"{indent}{{"
                 );


                    if (!string.IsNullOrWhiteSpace(rule.FailMessage))
                    {
                        controllerCode.AppendLine(
                            rule.PredefineQueryId > 0
                            ? $"{indent}    validations.Add(new ValidationModel {{ FailMessage = \"{rule.FailMessage}\", Success = false }});"
                            : $"{indent}    validations.Add(new ValidationModel {{ FailMessage = \"{rule.DisplayName}: {rule.FailMessage}\", Success = false, FieldName = \"{rule.FieldName}\" }});"
                        );


                    }

                    controllerCode.AppendLine($"{indent}}}");
                }
            }

            controllerCode.AppendLine("        }");
            controllerCode.AppendLine("    }");
            // Write to file

            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Infrastructure\BusinessRule\{table.Name}";
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
            string filePath = Path.Combine(directoryPath, $"{modelName}Rule.cs");
            File.WriteAllText(filePath, controllerCode.ToString());
        }
    }
}

