﻿namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class CopyFolderContentsClass
    {
        public void CopyFolderContents(string sourceFolder, string destinationFolder, List<string>? excludedFolders = null)
        {
            try
            {
                if (!Directory.Exists(sourceFolder))
                {
                    Console.WriteLine($"Source folder '{sourceFolder}' not found.");
                    return;
                }

                if (!Directory.Exists(destinationFolder))
                {
                    Directory.CreateDirectory(destinationFolder);
                }

                // Copy files (skip if inside excluded folders)
                var files = Directory.GetFiles(sourceFolder);
                foreach (var file in files)
                {
                    var fileName = Path.GetFileName(file);
                    var destinationFile = Path.Combine(destinationFolder, fileName);

                    File.Copy(file, destinationFile, overwrite: true);
                }

                // Handle subdirectories
                var subdirectories = Directory.GetDirectories(sourceFolder);
                foreach (var subdirectory in subdirectories)
                {
                    var subdirectoryName = Path.GetFileName(subdirectory);

                    // Skip excluded folders (case-insensitive match)
                    if (excludedFolders != null &&
                        excludedFolders.Any(ex =>
                            subdirectoryName.Equals(ex, StringComparison.OrdinalIgnoreCase)))
                    {
                        Console.WriteLine($"⚠️ Skipped copying folder: {subdirectoryName}");
                        continue;
                    }

                    // Skip .git, bin, obj, Debug
                    if (subdirectoryName.Equals(".git", StringComparison.OrdinalIgnoreCase) ||
                        subdirectoryName.Equals("bin", StringComparison.OrdinalIgnoreCase) ||
                        subdirectoryName.Equals("obj", StringComparison.OrdinalIgnoreCase) ||
                        subdirectoryName.Equals("Debug", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    var newDestSubDir = Path.Combine(destinationFolder, subdirectoryName);
                    CopyFolderContents(subdirectory, newDestSubDir, excludedFolders);
                }

                Console.WriteLine($"Contents from '{sourceFolder}' copied to '{destinationFolder}'.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during folder copy: {ex.Message}");
            }
        }
    }

}
