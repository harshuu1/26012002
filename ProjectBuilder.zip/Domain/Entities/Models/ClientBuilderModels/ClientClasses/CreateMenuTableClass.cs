﻿using Dapper;
using DapperDB;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using System.Data;
using System.Text;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class CreateMenuTableClass(DapperDbContext.DbContext context)
    {
        private readonly DapperDbContext.DbContext _context = context;

        public async Task CreateMenuTable(string databaseName)
        {
            // SQL to create the table
            string createTableQuery = @$"
            CREATE TABLE [{databaseName}].[dbo].[ClientMenu] (
                ID INT PRIMARY KEY IDENTITY(1, 1),
                Name VARCHAR(MAX),
                Description VARCHAR(MAX),
                ParentID INT,
                CreatedBy VARCHAR(MAX),
                CreatedDate DATETIME,
                ModifiedBy VARCHAR(MAX), 
                ModifiedDate DATETIME,
                FormPath VARCHAR(MAX),    
                ImportProfilePath VARCHAR(MAX),    
                ClientId INT,
                ProjectId INT,
                FormId INT,
                MenuIcon VARCHAR(MAX),
                IsCardView bit,
                IsClientMenu bit NOT NULL,
                InOrder INT,
                ImportProfile bit,
                TableId INT                
            )";
            // Using Dapper to execute the query
            using var connection = _context.CreateConnection();  // Assuming _context.CreateConnection() is used to create a connection to the database
            await connection.ExecuteAsync(createTableQuery);  // Executes the SQL command asynchronously

            // SQL to create the table

            //CREATE TABLE[{ databaseName}].[dbo].[MenuPermission](
            //    [Id][int] PRIMARY KEY IDENTITY(1, 1) NOT NULL,
            //    [PermissionRoleId][int] NOT NULL,
            //    [MenuId][int] NULL,
            //)

            //ALTER TABLE[{ databaseName}].[dbo].[MenuPermission]  WITH CHECK ADD CONSTRAINT[FK_MenuPermission_Role] FOREIGN KEY([PermissionRoleId])
            //    REFERENCES[dbo].[Role]([ID])
            //GO
            //string createMenuPermissionTableQuery = @$"
            //ALTER TABLE [{databaseName}].[dbo].[MenuPermission]  WITH CHECK ADD  CONSTRAINT [FK_MenuPermission_ClientMenu] FOREIGN KEY([MenuId])
            //    REFERENCES [dbo].[ClientMenu] ([ID])
            //    ON DELETE CASCADE
            //GO
            //ALTER TABLE [{databaseName}].[dbo].[MenuPermission] CHECK CONSTRAINT [FK_MenuPermission_ClientMenu]
            //GO
            //ALTER TABLE [{databaseName}].[dbo].[MenuPermission] CHECK CONSTRAINT [FK_MenuPermission_Role]
            //GO";


            //using (var connection = _context.CreateConnection())
            //{
            //    await connection.ExecuteAsync(createMenuPermissionTableQuery);
            //}
        }


        public async Task InsertDataIntoClientMenu(string databaseName, int clientId, int projectId, string adminDatabaseName)
        {
            // Use Dapper to execute the insert query with parameters
            //using (var connection = _context.CreateConnection())  // Assuming _context.CreateConnection() creates a valid connection
            //{
            //    var createMenuTableClass = new CreateMenuTableClass(_context);
            //    await createMenuTableClass.InsertBaseStaticMenus(databaseName, clientId, projectId);
            //}

            // The insert data query with parameterized values for clientId and projectId
            string insertDataQuery = $@"
        DECLARE @StartInOrder INT;
SELECT @StartInOrder = ISNULL(MAX(InOrder), 0) FROM [{databaseName}].[dbo].[ClientMenu];
 
WITH ClientMenu  AS (
    SELECT
        m.Name,
        m.Description,
        m.ParentID,
        m.CreatedBy,
        m.CreatedDate,
        m.ModifiedBy,
        m.ModifiedDate,
        CASE 
            WHEN m.FormId IS NULL THEN NULL
            ELSE ISNULL(t.Name + '/', '') + ISNULL(f.Name, '') + 
                CASE 
                    WHEN m.IsCardView = 1 THEN 'Details'
                    ELSE 'List'
                END
        END AS FormPath,
        CASE 
            WHEN m.ImportProfile = 1 THEN 
                'ImportProfile/ImportProfileList' 
            ELSE NULL 
        END AS ImportProfilePath,
        m.FormId,
        m.MenuIcon,
        m.IsCardView,
        m.IsClientMenu,             
         ROW_NUMBER() OVER (ORDER BY m.Id) + @StartInOrder AS InOrder,
                        m.ImportProfile,
        m.TableId AS TableId  -- Use the actual TableId value from Menu table                                      
    FROM [{adminDatabaseName}].[{DbSchemaEnums.config.ToString()}].[Menu] m
    LEFT JOIN [{adminDatabaseName}].[{DbSchemaEnums.config.ToString()}].[Form] f ON m.FormId = f.ID 
    LEFT JOIN [{adminDatabaseName}].[{DbSchemaEnums.config.ToString()}].[TableDefination] t ON m.TableId = t.ID                     
    WHERE 
      NOT (
      m.FormId IS NULL AND m.ParentId IS NULL
      AND NOT EXISTS (
          SELECT 1 
          FROM [{adminDatabaseName}].[{DbSchemaEnums.config.ToString()}].[Menu] m2 
          WHERE m2.ParentId = m.ID
      )) or m.ImportProfile  =0 and m.FormId Is Null OR (m.ImportProfile = 1) 

)
INSERT INTO [{databaseName}].[dbo].[ClientMenu] (
    Name, Description, ParentID, CreatedBy, CreatedDate, 
    ModifiedBy, ModifiedDate, FormPath, ImportProfilePath,
    FormId, MenuIcon, IsCardView, IsClientMenu, InOrder, ImportProfile, TableId)
SELECT 
    Name, Description, ParentID, CreatedBy, CreatedDate, 
    ModifiedBy, ModifiedDate, FormPath, ImportProfilePath,
    FormId, MenuIcon, IsCardView, IsClientMenu,
    InOrder, ImportProfile, TableId
FROM ClientMenu
ORDER BY InOrder;";

            // Use Dapper to execute the insert query with parameters
            using (var connection = _context.CreateConnection())
            {
                //var parameters = new { ClientId = clientId, ProjectId = projectId };
                await connection.ExecuteAsync(insertDataQuery, null);
                //var createMenuTableClass = new CreateMenuTableClass(_context);
                //await createMenuTableClass.InsertBaseStaticMenus(databaseName, clientId, projectId);
            }

            // parent id update on client menu table 
            string fixParentIdSql = @$"UPDATE child SET child.ParentID = parent.ID FROM [{databaseName}].[dbo].[ClientMenu] child
                                INNER JOIN [{adminDatabaseName}].[{DbSchemaEnums.config.ToString()}].[Menu] mChild
                                    ON mChild.Name = child.Name
                                INNER JOIN [{adminDatabaseName}].[{DbSchemaEnums.config.ToString()}].[Menu] mParent
                                    ON mChild.ParentID = mParent.ID
                                INNER JOIN [{databaseName}].[dbo].[ClientMenu] parent
                                    ON parent.Name = mParent.Name
                                WHERE child.ParentID != parent.ID OR child.ParentID IS NULL;";

            using (var connection = _context.CreateConnection())
            {
                await connection.ExecuteAsync(fixParentIdSql);
            }
        }
    //    public async Task InsertBaseStaticMenus(string databaseName, int clientId, int projectId)
    //    {

    //        using var connection = _context.CreateConnection();
    //        var query = $@"SELECT ISNULL(MAX(InOrder), 0) FROM [{databaseName}].[dbo].[ClientMenu]";
    //        int lastInOrder = await connection.ExecuteScalarAsync<int>(query);

    //        // Define the static menu data
    //        var staticMenus = new List<(string Name, string? Description, string? FormPath, string Icon)>
    //        {
    //            //("Dashboard", "Dashboard", "Notification/NotificationDisplay", "/Icon/dashboard-tile-solid-svgrepo-com.svg", 1),
    //            ("Admin", "Admin", null, "/Icon/circle-user-regular.svg"),
    //            ("Role", "Role", "Role/RoleList", "/Icon/users-gear-solid.svg"),
    //            ("Notification", "Notification", "Notification/NotificationList", "/Icon/bell-regular.svg"),
    //            ("Link", "Link", "Link/LinkList", "/Icon/link-solid.svg"),
    //            ("Users", "Users", "AppUser/AppUserList", "/Icon/user-regular.svg"),
    //            ("Document", "Document", "Document/DocumentList", "/Icon/paperclip-solid.svg"),
    //            ("Report", "Report", "Report/ReportList", "/Icon/report.svg"),
    //            ("Report Category", "Report Category", "ReportCategory/ReportCategoryList", "/Icon/report-file.svg"),
    //            ("App Setting", "App Setting" , "AppSetting/AppSettingList" , "/Icon/gear-solid.svg"),
    //            ("Password Policy", "Password Policy", "PasswordPolicy/PasswordPolicyList", "/Icon/user-lock-solid.svg"),
    //            ("Email Template", "Email Template" , "EmailTemplate/EmailTemplateList" , "/Icon/envelope-open-text-solid.svg"),
    //            ("Kpi", "Kpi", "Kpi/KpiList", "/Icon/icons8-benchmark-50.png"),
    //            ("Chart Configuration", "Chart Configuration" , "Chart/ChartList" , "/Icon/free-chart-icon-646-thumb.png"),
    //            ("DashboardProfile", "DashboardProfile", "DashboardProfile/DashboardProfileList", "/Icon/free-chart-icon-646-thumb.png"),
    //            ("Reports", "Reports", null, "/Icon/report-main.svg"),
    //            ("PredefinedQuery", "PredefinedQuery", "predefinedQuery/PredefinedQuerylist", "/Icon/data-searching.png"),
    //            ("ResourceString", "ResourceString", "ResourceString/ResourceStringList", "/Icon/resourcestring.png"),
    //            ("SequenceFormat", "SequenceFormat", "SequenceFormat/SequenceFormatList", "/Icon/sequence-format.png"),
    //            ("Integration Framework","Integration Framework",null,"/Icon/report.svg"),
    //            ("Integration Settings","Integration Settings","FileIntegration/IntegrationFrameworkSettings","/Icon/report.svg"),
    //            ("File Integration","File Integration","FileIntegration/HeaderConfigurationList","/Icon/report.svg"),
    //             ("REST Pull API Integration","REST Pull API Integration","RestPullIntegration/HeaderConfigurationList","/Icon/report.svg"),
    //            ("REST Push API Integration","REST Push API Integration","RestPushIntegration/HeaderConfigurationList","/Icon/report.svg"),
    //            ("Pdf Report Configuration", "Pdf Report Configuration", "PdfReportConfiguration/PdfReportConfigurationList", "/Icon/PdfReport.png"),

    //      };
    //        var rawMenus = staticMenus
    //.Select((menu, index) => (
    //    menu.Name,
    //    menu.Description,
    //    menu.FormPath,
    //    menu.Icon,
    //    InOrder: lastInOrder + index + 1
    //)).ToList();

    //        // Fetch current static records from ClientMenu
    //        var dbMenus = (await connection.QueryAsync<dynamic>(
    //            $@"SELECT ID, Name, Description, FormPath, MenuIcon, InOrder, ParentID
    //        FROM [{databaseName}].[dbo].[ClientMenu]
    //        WHERE IsClientMenu = 1",
    //            null)).ToList();

    //        var nameToId = dbMenus.ToDictionary(m => (string)m.Name, m => (int)m.ID);

    //        // Insert/update loop
    //        foreach (var (Name, Description, FormPath, Icon, InOrder) in rawMenus)
    //        {
    //            string name = Name;

    //            // Set ParentID
    //            int? parentId = null;
    //            if (name != "Dashboard" && name != "Admin")
    //            {
    //                if (name == "Report Category")
    //                    parentId = nameToId.TryGetValue("Report", out int value) ? value : 0;
    //                else if (name == "Integration Framework")
    //                    parentId = nameToId.TryGetValue("Admin", out int value) ? value : 0;
    //                else if (name == "Integration Settings")
    //                    parentId = nameToId.TryGetValue("Integration Framework", out int value) ? value : 0;
    //                else if (name == "File Integration")
    //                    parentId = nameToId.TryGetValue("Integration Framework", out int value) ? value : 0;
    //                else if (name == "REST Pull API Integration")
    //                    parentId = nameToId.TryGetValue("Integration Framework", out int value) ? value : 0;
    //                else if (name == "REST Push API Integration")
    //                    parentId = nameToId.TryGetValue("Integration Framework", out int value) ? value : 0;
    //                else
    //                    parentId = nameToId.TryGetValue("Admin", out int value) ? value : 0;
    //            }




    //            if (nameToId.ContainsKey(name))
    //            {
    //                var dbItem = dbMenus.First(m => m.Name == name);
    //                bool needsUpdate =
    //                    dbItem.Description != Description ||
    //                    dbItem.FormPath != FormPath ||
    //                    dbItem.MenuIcon != Icon ||
    //                    dbItem.InOrder != InOrder ||
    //                    dbItem.ParentID != parentId;

    //                if (needsUpdate)
    //                {
    //                    await connection.ExecuteAsync($@"
    //            UPDATE [{databaseName}].[dbo].[ClientMenu]
    //            SET Description = @Description,
    //                FormPath = @FormPath,
    //                MenuIcon = @MenuIcon,
    //                InOrder = @InOrder,
    //                ParentID = @ParentID,
    //                ModifiedDate = GETUTCDATE()
    //            WHERE ID = @ID",
    //                        new
    //                        {
    //                            Description,
    //                            FormPath,
    //                            MenuIcon = Icon,
    //                            InOrder,
    //                            ParentID = parentId,
    //                            dbItem.ID
    //                        });
    //                }
    //            }
    //            else
    //            {
    //                // Insert new record
    //                int newId = await connection.ExecuteScalarAsync<int>($@"
    //        INSERT INTO [{databaseName}].[dbo].[ClientMenu]
    //            ([Name], [Description], ParentID, CreatedDate, ModifiedDate, FormPath, MenuIcon, IsClientMenu, InOrder)
    //            OUTPUT INSERTED.ID
    //            VALUES
    //            (@Name, @Description, @ParentID, GETUTCDATE(), GETUTCDATE(), @FormPath, @MenuIcon, 1, @InOrder)",
    //                    new
    //                    {
    //                        Name = name,
    //                        Description,
    //                        FormPath,
    //                        MenuIcon = Icon,
    //                        ParentID = parentId,
    //                        InOrder
    //                    });
    //                nameToId[name] = newId;
    //            }
    //        }

    //        // Delete static records from DB that are no longer in the list
    //        var staticNames = staticMenus.Select(m => m.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
    //        var dbStaticNames = dbMenus.Select(m => (string)m.Name);

    //        var namesToDelete = dbStaticNames.Where(name => !staticNames.Contains(name)).ToList();

    //        if (namesToDelete.Count != 0)
    //        {
    //            await connection.ExecuteAsync(
    //                $@"DELETE FROM [{databaseName}].[dbo].[ClientMenu]
    //                WHERE Name IN @Names AND IsClientMenu = 1",
    //                new { Names = namesToDelete });
    //        }
    //    }
        public void CopyMenuIcon(IEnumerable<ClientMenu> menuList, string destinationfolder, string webRootPath, string projectName, string clientName)
        {
            bool isInteractive = Environment.UserInteractive;

            string uploadsFolder1;

            if (isInteractive)
            {
                // Localhost path
                uploadsFolder1 = Path.Combine(@"C:\ClientConfigurationProject", clientName, projectName, "Presentation", "ClientManagement.Api", "wwwroot", "Icon");
            }
            else
            {
                // Server path
                uploadsFolder1 = Path.Combine(@"C:\inetpub\wwwroot", projectName + "Configuration", "wwwroot", "Icon");
            }

            // Ensure the source directory exists
            if (!Directory.Exists(uploadsFolder1))
            {
                Directory.CreateDirectory(uploadsFolder1);
            }

            // Destination path
            var destinationFolder = Path.Combine(destinationfolder, "Presentation", "ClientProjectBuilder.MvcUI", "wwwroot", "Icon");

            // Ensure the destination directory exists
            Directory.CreateDirectory(destinationFolder);

            foreach (var menu in menuList)
            {
                var fileName = Path.GetFileName(menu.MenuIcon);

                if (string.IsNullOrEmpty(fileName))
                {
                    Console.WriteLine("MenuIcon filename is null or empty. Skipping...");
                    continue;
                }

                var sourcePath = Path.Combine(uploadsFolder1, fileName);
                var destinationPath = Path.Combine(destinationFolder, fileName);

                if (File.Exists(sourcePath))
                {
                    File.Copy(sourcePath, destinationPath, true);
                    Console.WriteLine($"File copied successfully to: {destinationPath}");
                }
                else
                {
                    Console.WriteLine($"Source file not found: {sourcePath}");
                }
            }
        }
        public void SetProjectLogo(string projectLogo, string clientPath, string childAdminFolderPath, string webRootPath)
        {
            var fileName = projectLogo;
            //TODO:
            //var DirPath = Path.GetFullPath("ProjectBuilder\\DemoWeb");
            //var MainDirPath = DirPath.Split("ProjectBuilder");

            //var ActualPath = MainDirPath[0];
            //var relativePath = @"ProjectBuilder\DemoWeb\wwwroot\Image\";

            //var uploadsFolder = Path.GetFullPath(Path.Combine(ActualPath, relativePath));
            //var solutionRoot1 = Path.GetFullPath(
            //        Path.Combine(Directory.GetCurrentDirectory(), "..")
            //    );
            var uploadsFolder1 = Path.Combine(webRootPath, "ProjectLogo");

            // Ensure the directory exists
            if (!Directory.Exists(uploadsFolder1))
            {
                Directory.CreateDirectory(uploadsFolder1);
            }
            // Full source path to the image
            //var sourceFolder = @"C:\Users\Admin\Desktop\working\ProjectBuilder\DemoWeb\wwwroot\Image\";
            var sourcePath = Path.Combine(uploadsFolder1, fileName);

            //var destinationFolder = $@"C:\ClientProject\{databaseName}\DynamicFormBuilder_UI\wwwroot\Image";
            var destinationFolder = $@"{clientPath}\Presentation\ClientProjectBuilder.MvcUI\wwwroot\Image";
            Directory.CreateDirectory(destinationFolder);

            var adminDestinationFolder = $@"{childAdminFolderPath}\Presentation\ClientAdmin.MvcUI\wwwroot\Image";
            Directory.CreateDirectory(adminDestinationFolder);

            var destinationPath = Path.Combine(destinationFolder, "logo_basic.png");

            var adminDestinationPath = Path.Combine(adminDestinationFolder, "logo_basic.png");

            // Check if "logo_basic.png" already exists, and delete it if true
            //if (System.IO.File.Exists(destinationPath))
            //{
            //    System.IO.File.Delete(destinationPath);
            //    Console.WriteLine($"Existing file 'logo_basic.png' deleted from: {destinationPath}");
            //}

            if (File.Exists(sourcePath))
            {
                // true = overwrite if the file already exists
                File.Copy(sourcePath, destinationPath, true);
                File.Copy(sourcePath, adminDestinationPath, true);
                Console.WriteLine($"File copied successfully, renamed to 'logo_basic.png' at: {destinationPath}");
            }
            else
            {
                Console.WriteLine("Source file not found: " + sourcePath);
            }
        }

        public void SetAlignmentType(string childAdminFolderPath, int alignmentType)
        {
            StringBuilder sb = new();

            sb.AppendLine("@using ClientAdmin.MvcUI.Models");
            sb.AppendLine("@inject BackendSettings BackendSettings");
            sb.AppendLine("@{");
            sb.AppendLine("    ViewData[\"BackendUrl\"] = BackendSettings.BackendUrl;");
            sb.AppendLine("    ViewData[\"BackendUiUrl\"] = BackendSettings.BackendUiUrl;");
            sb.AppendLine($"    ViewBag.LabelClass = \"{(alignmentType == 1 ? "label-left" : "label-top")}\";");
            sb.AppendLine("    TempData[\"LabelClass\"] = ViewBag.LabelClass;");
            sb.AppendLine("}");
            sb.AppendLine("@{");
            sb.AppendLine("    Layout = \"_Layout\";");
            sb.AppendLine("}");

            string viewsDirectory = Path.Combine(childAdminFolderPath, @"Presentation\ClientAdmin.MvcUI\Views");
            Directory.CreateDirectory(viewsDirectory); 

            string filePath = Path.Combine(viewsDirectory, "_ViewStart.cshtml");

            File.WriteAllText(filePath, sb.ToString());

        }

    }
}
