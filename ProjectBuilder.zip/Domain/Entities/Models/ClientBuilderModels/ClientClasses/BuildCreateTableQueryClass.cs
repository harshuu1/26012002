﻿using Dapper;
using DapperDB;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using Microsoft.Extensions.Configuration;
using System.Text;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class BuildCreateTableQueryClass(DapperDbContext.DbContext context, IConfiguration configuration)
    {
        private readonly DapperDbContext.DbContext _context = context;
        public string BuildCreateTableQuery(ClientTable table, bool IsHierarchical, IEnumerable<ClientFieldDefinition> fields, string? checkExistTable, string databaseName, List<string>? newColumns, IEnumerable<string>? existingColumns, List<string>? filteredDeletedColumns)
        {
            //ArgumentNullException.ThrowIfNull(IsHierarchical);
            // Initialize the StringBuilder for the SQL query
            var sb = new StringBuilder();
            var checkboxTables = new List<string>();
            var columnLines = new List<string>();
            var fieldList = fields.ToList();
            var constraintLines = new List<string>();
            if (checkExistTable != null)
            {

                var foreignKeyName = string.Empty;
                using (var connection = _context.CreateConnection())
                {
                    // var extraColumns = existingColumns.Except(newColumns).ToList();

                    var extraColumns = (existingColumns ?? []).Except(newColumns ?? []).ToList();


                    foreach (var extraColumn in extraColumns)
                    {
                        var foreignKeyQuery = $@"SELECT fk.name AS ForeignKeyName FROM {databaseName}.sys.foreign_keys fk INNER 
                 JOIN {databaseName}.sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
                  INNER JOIN {databaseName}.sys.columns c ON fkc.parent_object_id = c.object_id AND fkc.parent_column_id = c.column_id INNER JOIN {databaseName}.sys.tables t ON c.object_id = t.object_id WHERE t.name = '{table.Name}' AND c.name = '{extraColumn}';";

                        foreignKeyName = connection.ExecuteScalar<string>(foreignKeyQuery);
                        if (table.HeaderTableId == null)
                        {
                            // Columns to drop                    
                            if (!string.IsNullOrEmpty(foreignKeyName))
                            {
                                try
                                {
                                    if (table.IsHierarchical)
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        var dropForeignKeySql = $"ALTER TABLE {databaseName}.dbo.{table.Name} DROP CONSTRAINT [{foreignKeyName}];";
                                        connection.ExecuteAsync(dropForeignKeySql).GetAwaiter().GetResult();

                                        var dropColumnSql = $"ALTER TABLE {databaseName}.dbo.{table.Name} DROP COLUMN [{extraColumn}];";
                                        connection.ExecuteAsync(dropColumnSql).GetAwaiter().GetResult();
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine($"Error dropping foreign key or column: {ex.Message}");
                                }
                            }
                        }
                    }
                    if (foreignKeyName == null)
                    {
                        if (filteredDeletedColumns != null)
                        {
                            foreach (var deletedColumn in filteredDeletedColumns)
                            {
                                if (deletedColumn == $"{table.HeaderTableName}Id")
                                {
                                    continue;
                                }
                                else if (table.IsHierarchical)
                                {
                                    var hierarchicalColumn = $"SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = '{table.Name}'AND COLUMN_NAME = 'ParentID';";
                                    var hierarchical = connection.ExecuteScalar<int>(hierarchicalColumn);
                                    if (hierarchical <= 0)
                                    {
                                        columnLines.Add($"    ParentID {table.PrimaryKeyType?.ToLower()} NULL");
                                        constraintLines.Add($"    CONSTRAINT FK_{table.Name}_Parent FOREIGN KEY (ParentID) REFERENCES {table.Name}(ID)");
                                    }
                                }
                                else
                                {
                                    var droppedClumn = $"ALTER TABLE [dbo].[{table.Name}] DROP COLUMN [{deletedColumn}]";
                                    connection.ExecuteAsync(droppedClumn).GetAwaiter().GetResult(); ;
                                }
                            }
                        }
                    }
                    if (table.IsHierarchical)
                    {
                        var hierarchicalColumn = $"SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = '{table.Name}'AND COLUMN_NAME = 'ParentID';";
                        var hierarchical = connection.ExecuteScalar<int>(hierarchicalColumn);
                        if (hierarchical <= 0)
                        {
                            columnLines.Add($"    ParentID {table.PrimaryKeyType?.ToLower()} NULL");
                            constraintLines.Add($"    CONSTRAINT FK_{table.Name}_Parent FOREIGN KEY (ParentID) REFERENCES {table.Name}(ID)");
                        }
                    }
                    // }
                    if (table.HeaderTableId > 0)
                    {
                        //if (foreignKeyName == null && !string.IsNullOrWhiteSpace(table.HeaderTableName))
                        //{
                        //    columnLines.Add($"    {table.HeaderTableName.Trim()}Id INT NOT NULL");
                        //    constraintLines.Add($"    CONSTRAINT FK_{table.Name}_{table.HeaderTableName.Trim()}Id FOREIGN KEY ({table.HeaderTableName.Trim()}Id) REFERENCES {table.HeaderTableName.Trim()}(ID) ON UPDATE CASCADE ON DELETE CASCADE");
                        //}
                        var existColumn = $"SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = '{table.Name}'AND COLUMN_NAME = '{table.HeaderTableName}Id';";
                        var existColumnName = connection.ExecuteScalar<int>(existColumn);
                        if (existColumnName <= 0)
                        {
                            columnLines.Add($"    {table.HeaderTableName?.Trim()}Id {table.ParentPrimaryKeyType} NOT NULL");
                            constraintLines.Add($"    CONSTRAINT FK_{table.Name}_{table.HeaderTableName?.Trim()}Id FOREIGN KEY ({table.HeaderTableName?.Trim()}Id) REFERENCES {table.HeaderTableName?.Trim()}(ID) ON UPDATE CASCADE ON DELETE CASCADE");
                        }
                    }
                }
                foreach (var field in fieldList)
                {
                    string? fieldType = field.TypeName;
                    string fieldSize = string.Empty;
                    // Handle varchar and nvarchar types specifically
                    //if (fieldType == "varchar" || fieldType == "nvarchar")
                    //{
                    //    fieldSize = field.Max ? "(MAX)" : $"({field.Length})";
                    //}
                    //else if (fieldType == "decimal" || fieldType == "numeric")
                    //{
                    //    fieldSize = $"({field.Precision}, {field.Scale})";
                    //}
                    //else if (fieldType == "Image")
                    //{
                    //    fieldType = "varbinary(MAX)";
                    //}
                    //else if (fieldType == "dropdown")
                    //{
                    //    fieldType = "int";
                    //}

                    //else if (fieldType == "switches")
                    //{
                    //    fieldType = "bit";

                    //}

                    //else if (fieldType == "hyperlink")
                    //{
                    //    fieldType = "varchar(MAX)";
                    //}

                    //else if (fieldType == "radiogroup")
                    //{
                    //    fieldType = "int";
                    //}
                    //else if (fieldType == "slider")
                    //{
                    //    fieldType = "float";

                    //}
                    //else if (fieldType == "captcha")
                    //{
                    //    fieldType = "nvarchar(MAX)";

                    //}
                    //else if (fieldType == "rangeslider")
                    //{
                    //    fieldType = "varchar(MAX)";
                    //}
                    //else if (fieldType == "rating")
                    //{
                    //    fieldType = "int";
                    //}
                    //else if (fieldType == "timeduration")
                    //{
                    //    fieldType = "time";
                    //}
                    //else if (fieldType == "signature")
                    //{
                    //    fieldType = "varbinary";
                    //    fieldSize = "(MAX)";
                    //}
                    //else if (fieldType == "checkboxgroup")
                    //{

                    //    continue;  // Skips the current iteration and moves on to the next field
                    //}
                    ////else if (fieldType.Equals("richtexteditor", StringComparison.OrdinalIgnoreCase))
                    //else if (fieldType?.Equals("richtexteditor", StringComparison.OrdinalIgnoreCase) == true)
                    //{
                    //    fieldType = "nvarchar";
                    //    fieldSize = "(MAX)";
                    //}
                    //else if (fieldType == "ImageUpload" || fieldType == "varbinary")
                    //{
                    //    fieldType = "varbinary(MAX)";
                    //}
                    ////else if (fieldType.Equals("colorpicker", StringComparison.OrdinalIgnoreCase))
                    //else if (fieldType?.Equals("colorpicker", StringComparison.OrdinalIgnoreCase) == true)
                    //{
                    //    fieldType = "nvarchar";
                    //    fieldSize = "(50)";
                    //}
                    FieldTypeEnums typeEnum;
                    if (!Enum.TryParse(fieldType, true, out typeEnum))
                    {
                        typeEnum = FieldTypeEnums.Unknown;
                    }
    
                    //bool IsAllowPositive = field.IsAllowPositive;
                    // string signedSuffix = ""; 
                    string checkConstraint = "";

                    // Add suffix if needed for unsigned
                    if (field.IsAllowPositive)
                    {
                        switch (typeEnum)
                        {
                            case FieldTypeEnums.Tinyint:
                            case FieldTypeEnums.Smallint:
                            case FieldTypeEnums.Int:
                            case FieldTypeEnums.Bigint:
                            case FieldTypeEnums.Decimal:
                            case FieldTypeEnums.Float:
                            case FieldTypeEnums.Money:
                                //signedSuffix = " UNSIGNED";
                                checkConstraint = $" CHECK ({field.Name} >= 0)";
                                break;
                        }
                    }

                    switch (typeEnum)
                    {
                        case FieldTypeEnums.Varchar:
                        case FieldTypeEnums.Nvarchar:
                            fieldSize = field.Max ? "(MAX)" : $"({field.Length})";
                            break;

                        case FieldTypeEnums.Int:
                            fieldType = "int";
                            break;
                        case FieldTypeEnums.Float:
                            fieldType = "float";
                            break;

                        case FieldTypeEnums.Bigint:
                            fieldType = "bigint";
                            break;

                        case FieldTypeEnums.Smallint:
                            fieldType = "smallint";
                            break;

                        case FieldTypeEnums.Tinyint:
                            fieldType = "tinyint";
                            break;
                        case FieldTypeEnums.Money:
                            fieldType = "Money";
                            break;
                        case FieldTypeEnums.Decimal:
                            fieldType = "decimal";
                            fieldSize = $"({field.Precision}, {field.Scale})";
                            break;

                        case FieldTypeEnums.Image:
                            fieldType = "varbinary(MAX)";
                            break;

                        case FieldTypeEnums.DropDown:
                        case FieldTypeEnums.Radiogroup:

                            fieldType = $"{field.SourceTableType}";
                            break;
                        case FieldTypeEnums.Rating:
                            fieldType = "int";
                            break;
                        case FieldTypeEnums.Bit:
                            fieldType = "bit";
                            break;
                        case FieldTypeEnums.Switches:
                            fieldType = "bit";
                            break;
                        case FieldTypeEnums.Hyperlink:
                            fieldType = "varchar(MAX)";
                            break;

                        case FieldTypeEnums.Slider:
                               fieldType = "float";
                                    break;

                        case FieldTypeEnums.Rangeslider:
                            fieldType = "varchar(MAX)";
                            break;

                        case FieldTypeEnums.Captcha:
                            fieldType = "nvarchar(MAX)";
                            break;

                        case FieldTypeEnums.Date:
                            fieldType = "date";
                            break;
                        case FieldTypeEnums.Datetime:
                            fieldType = "datetime";
                            break;
                        case FieldTypeEnums.Timeduration:
                            fieldType = "time(7)";
                            break;

                        case FieldTypeEnums.Signature:
                            fieldType = "varbinary";
                            fieldSize = "(MAX)";
                            break;

                        case FieldTypeEnums.Checkboxgroup:
                            continue; // skip this field

                        case FieldTypeEnums.Multiselect:
                            continue;

                        case FieldTypeEnums.Richtexteditor:
                            fieldType = "nvarchar";
                            fieldSize = "(MAX)";
                            break;

                        case FieldTypeEnums.ImageUpload:
                        case FieldTypeEnums.Varbinary:
                            fieldType = "varbinary(MAX)";
                            break;

                        case FieldTypeEnums.Colorpicker:
                            fieldType = "nvarchar";
                            fieldSize = "(50)";
                            break;

                        case FieldTypeEnums.Barcode:
                            fieldType = "nvarchar";
                            fieldSize = "(100)";
                            break;

                        default:
                            // leave fieldType as is if no mapping is needed
                            break;
                    }

                    string nullability = field.Mandatory ? "NOT NULL" : "NULL";
                    string columnDefinition = $"{field.Name} {fieldType}{fieldSize} {checkConstraint} {nullability}";
                    columnLines.Add(columnDefinition);
                    //sb.AppendLine($"ALTER TABLE {table.Name} ADD {columnDefinition};");
                }

                var allLines = columnLines.Concat(constraintLines).ToList();
                if (allLines.Count != 0)
                {
                    sb.AppendLine($"ALTER TABLE {table.Name} ADD");
                    for (int i = 0; i < allLines.Count; i++)
                    {
                        sb.Append("    " + allLines[i]);
                        sb.AppendLine(i < allLines.Count - 1 ? "," : ";");
                    }
                }
            }
            else
            {
                sb.AppendLine($"CREATE TABLE {table.Name} (");

                // Add primary ID field
                // columnLines.Add("    ID INT IDENTITY(1,1) PRIMARY KEY");
                if (table.PrimaryKeyType != null)
                {
                    columnLines.Add(
                        table.PrimaryKeyType != "UNIQUEIDENTIFIER"
                            ? $"    ID {table.PrimaryKeyType.ToLower()} IDENTITY(1,1) PRIMARY KEY"
                            : $"    ID {table.PrimaryKeyType.ToLower()} DEFAULT NEWID() PRIMARY KEY"
                    );

                    // Inject ParentID if hierarchical
                    if (table.IsHierarchical)
                    {
                        columnLines.Add($"    ParentID {table.PrimaryKeyType.ToLower()} NULL");
                    }
                    if (table.HeaderTableId > 0 && !string.IsNullOrWhiteSpace(table.HeaderTableName))
                    {
                        columnLines.Add(
                          table.ParentPrimaryKeyType is not null && !string.IsNullOrWhiteSpace(table.ParentPrimaryKeyType)
                            ? $"    {table.HeaderTableName.Trim()}Id {table.ParentPrimaryKeyType.ToLower()} NOT NULL"
                            : $"    {table.HeaderTableName.Trim()}Id int NOT NULL"
                        );
                    }

                }
                else
                {
                    columnLines.Add("    ID INT IDENTITY(1,1) PRIMARY KEY");
                    // Inject ParentID if hierarchical
                    if (table.IsHierarchical)
                    {
                        columnLines.Add("    ParentID INT NULL");
                    }
                    // If the table has a HeaderTableId, add the foreign key field
                    if (table.HeaderTableId > 0 && !string.IsNullOrWhiteSpace(table.HeaderTableName))
                    {
                        columnLines.Add($"    {table.HeaderTableName.Trim()}Id {table.ParentPrimaryKeyType} NOT NULL");
                    }
                }

                // Add default fields
                columnLines.Add("    CreatedBy NVARCHAR(255) NULL");
                columnLines.Add("    ModifiedBy NVARCHAR(255) NULL");
                columnLines.Add("    CreatedDate DATETIME DEFAULT GETDATE()");
                columnLines.Add("    ModifiedDate DATETIME NULL");



                // Add user-defined fields
                if (fields != null && fields.Any())
                {
                    foreach (var field in fieldList)
                    {
                        string? fieldType = field.TypeName;
                        string fieldSize = string.Empty;

                        //if (fieldType == "varchar" || fieldType == "nvarchar")
                        //{
                        //    fieldSize = field.Max ? "(MAX)" : $"({field.Length})";
                        //}
                        //else if (fieldType == "decimal" || fieldType == "numeric")
                        //{
                        //    fieldSize = $"({field.Precision}, {field.Scale})";
                        //}

                        //else if (fieldType == "hyperlink")
                        //{
                        //    fieldType = "varchar(MAX)";
                        //}
                        //else if (fieldType == "image")
                        //{
                        //    fieldType = "varbinary(MAX)";
                        //}
                        //else if (fieldType == "dropdown")
                        //{
                        //    fieldType = "int";
                        //}
                        //else if (fieldType == "slider")
                        //{
                        //    fieldType = "float";

                        //}
                        //else if (fieldType == "captcha")
                        //{
                        //    fieldType = "nvarchar(MAX)";

                        //}
                        //else if (fieldType == "switches")
                        //{
                        //    fieldType = "bit";
                        //}

                        //else if (fieldType == "radiogroup")
                        //{
                        //    fieldType = "int";
                        //}
                        //else if (fieldType == "rangeslider")
                        //{
                        //    fieldType = "varchar(MAX)";
                        //}
                        //else if (fieldType == "rating")
                        //{
                        //    fieldType = "int";
                        //}
                        //else if (fieldType == "timeduration")
                        //{
                        //    fieldType = "time";
                        //}
                        //else if (fieldType == "signature")
                        //{
                        //    fieldType = "varbinary";
                        //    fieldSize = "(MAX)";
                        //}
                        //else if (fieldType == "checkboxgroup")
                        //{

                        //    continue;  // Skips the current iteration and moves on to the next field
                        //}
                        ////else if (fieldType == "varbinary")
                        ////{
                        ////    fieldType = "varbinary";
                        ////}


                        //else if (fieldType == "ImageUpload" || fieldType == "varbinary")
                        //{
                        //    fieldType = "varbinary(MAX)";
                        //}
                        ////else if (fieldType.Equals("colorpicker", StringComparison.OrdinalIgnoreCase))
                        //else if (fieldType?.Equals("colorpicker", StringComparison.OrdinalIgnoreCase) == true)                        
                        //{
                        //    fieldType = "nvarchar";
                        //    fieldSize = "(50)";
                        //}
                        //else if (fieldType?.Equals("richtexteditor", StringComparison.OrdinalIgnoreCase) == true)
                        //{
                        //    fieldType = "nvarchar";
                        //    fieldSize = "(MAX)";
                        //}
                        FieldTypeEnums typeEnum;
                        if (!Enum.TryParse(fieldType, true, out typeEnum))
                        {
                            typeEnum = FieldTypeEnums.Unknown;
                        }

                        bool IsAllowPositive = field.IsAllowPositive;
                        //string signedSuffix = "";
                        string checkConstraint = "";

                        // Add suffix if needed for unsigned
                        if (IsAllowPositive)
                        {
                            switch (typeEnum)
                            {
                                case FieldTypeEnums.Tinyint:
                                case FieldTypeEnums.Smallint:
                                case FieldTypeEnums.Int:
                                case FieldTypeEnums.Bigint:
                                case FieldTypeEnums.Decimal:
                                case FieldTypeEnums.Float:
                                case FieldTypeEnums.Money:
                                    //signedSuffix = " UNSIGNED";
                                    checkConstraint = $" CHECK ({field.Name} >= 0)";
                                    break;
                            }
                        }

                        switch (typeEnum)
                        {
                            case FieldTypeEnums.Varchar:
                            case FieldTypeEnums.Nvarchar:
                                fieldSize = field.Max ? "(MAX)" : $"({field.Length})";
                                break;

                            case FieldTypeEnums.Decimal:
                                fieldSize = $"({field.Precision}, {field.Scale})";
                                break;

                            case FieldTypeEnums.Image:
                                fieldType = "varbinary(MAX)";
                                break;

                            case FieldTypeEnums.DropDown:
                            case FieldTypeEnums.Radiogroup:
                                fieldType = $"{field.SourceTableType}";
                                break;

                            case FieldTypeEnums.Rating:
                                fieldType = "int";
                                break;
                            case FieldTypeEnums.Bit:
                                fieldType = "bit";
                                break;
                            case FieldTypeEnums.Switches:
                                fieldType = "bit";
                                break;
                            case FieldTypeEnums.Hyperlink:
                                fieldType = "varchar(MAX)";
                                break;

                            case FieldTypeEnums.Slider:
                                fieldType = "float";
                                break;

                            case FieldTypeEnums.Rangeslider:
                                fieldType = "varchar(MAX)";
                                break;


                            case FieldTypeEnums.Captcha:
                                fieldType = "nvarchar(MAX)";
                                break;



                            case FieldTypeEnums.Date:
                                fieldType = "date";
                                break;
                            case FieldTypeEnums.Datetime:
                                fieldType = "datetime";
                                break;
                            case FieldTypeEnums.Timeduration:
                                fieldType = "time(7)";
                                break;

                            case FieldTypeEnums.Signature:
                                fieldType = "varbinary";
                                fieldSize = "(MAX)";
                                break;

                            case FieldTypeEnums.Checkboxgroup:
                                continue; // skip this field

                            case FieldTypeEnums.Multiselect:
                                continue;

                            case FieldTypeEnums.Richtexteditor:
                                fieldType = "nvarchar";
                                fieldSize = "(MAX)";
                                break;

                            case FieldTypeEnums.ImageUpload:
                            case FieldTypeEnums.Varbinary:
                                fieldType = "varbinary(MAX)";
                                break;

                            case FieldTypeEnums.Colorpicker:
                                fieldType = "nvarchar";
                                fieldSize = "(50)";
                                break;

                            case FieldTypeEnums.Barcode:
                                fieldType = "nvarchar";
                                fieldSize = "(100)";
                                break;

                            default:
                                // leave fieldType as is if no mapping is needed
                                break;
                        }


                        string nullability = field.Mandatory ? "NOT NULL" : "NULL";
                        columnLines.Add($"    {field.Name} {fieldType}{fieldSize} {checkConstraint} {nullability}");
                    }
                }

                // List to hold constraints separately
                //var constraintLines = new List<string>();

                // Add self-referencing FK if hierarchical
                if (table.IsHierarchical)
                {
                    constraintLines.Add($"    CONSTRAINT FK_{table.Name}_Parent FOREIGN KEY (ParentID) REFERENCES {table.Name}(ID)");
                }

                // Add FK to header table if applicable
                if (table.HeaderTableId > 0 && !string.IsNullOrWhiteSpace(table.HeaderTableName))
                {
                    constraintLines.Add($"    CONSTRAINT FK_{table.Name}_{table.HeaderTableName.Trim()}Id FOREIGN KEY ({table.HeaderTableName.Trim()}Id) REFERENCES {table.HeaderTableName.Trim()}(ID) ON UPDATE CASCADE ON DELETE CASCADE");
                }

                // Combine columns and constraints
                var allLines = columnLines.Concat(constraintLines).ToList();
                for (int i = 0; i < allLines.Count; i++)
                {
                    sb.Append(allLines[i]);
                    sb.AppendLine(i < allLines.Count - 1 ? "," : "");
                }
                sb.AppendLine(");");
            }
            foreach (var extraTable in checkboxTables)
            {
                sb.AppendLine();
                sb.AppendLine(extraTable);
            }
            Console.WriteLine(sb);  // For debugging purposes
            return sb.ToString();
        }

        //For Document Table
        public string GenerateDocumentAndMappingTables(List<ClientForm> forms)
        {
            var sb = new StringBuilder();

            foreach (var form in forms)
            {
                // Create the FormDocument mapping table
                var mappingTableName = $"{form.Name}Document";
                sb.AppendLine($"IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='{mappingTableName}' AND xtype='U')");
                sb.AppendLine("BEGIN");
                sb.AppendLine($"CREATE TABLE {mappingTableName} (");
                sb.AppendLine("    ID INT IDENTITY(1,1) PRIMARY KEY,");
                sb.AppendLine($"    {form.Name}ID {form.KeyTypeName} NOT NULL,");
                sb.AppendLine("    DocumentID INT NOT NULL,");
                sb.AppendLine($"    CONSTRAINT FK_{mappingTableName}_{form.TableName} FOREIGN KEY ({form.Name}ID) REFERENCES {form.TableName}(ID),");
                sb.AppendLine($"    CONSTRAINT FK_{mappingTableName}_Documents FOREIGN KEY (DocumentID) REFERENCES Documents(ID)");
                sb.AppendLine(");");
                sb.AppendLine("END");
                sb.AppendLine();
            }
            return sb.ToString();
        }
        //AddToList
        public string GenerateAddToListTable(List<ClientForm> forms)
        {
            var sb = new StringBuilder();

            foreach (var form in forms)
            {
                if (form.IsAddToList == true)
                {
                    var mappingTableName = $"{form.TableName}List";

                    sb.AppendLine($"  IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = '{mappingTableName}' AND type = 'U')");
                    sb.AppendLine("   BEGIN");
                    sb.AppendLine($"        CREATE TABLE {mappingTableName} (");
                    sb.AppendLine("         ID int IDENTITY(1,1) NOT NULL,");
                    sb.AppendLine($"        {form.TableName}ID int NOT NULL,");
                    sb.AppendLine("         CreatedDate datetime NULL");
                    sb.AppendLine("         );");
                    sb.AppendLine("END");

                }
            }
            return sb.ToString();
        }


        // for checkboxgroup
        public List<string> BuildCheckboxMappingTables(ClientTable table, IEnumerable<ClientFieldDefinition> fields)
        {
            // Create mapping tables for checkboxgroup

            var checkboxTables = new List<string>();

            foreach (var field in fields)
            {
                if (string.Equals(field.TypeName, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) ||
                string.Equals(field.TypeName, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    string mapTableName = $"{table.Name}_{field.Name}";
                    var checkboxTableSb = new StringBuilder();

                    // Add IF NOT EXISTS check
                    checkboxTableSb.AppendLine($"IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[{mapTableName}]') AND type in (N'U'))");
                    checkboxTableSb.AppendLine("BEGIN");

                    checkboxTableSb.AppendLine($"    CREATE TABLE [dbo].[{mapTableName}] (");
                    checkboxTableSb.AppendLine($"        ID INT IDENTITY(1,1) PRIMARY KEY,"); // Primary Key
                                                                                              // checkboxTableSb.AppendLine($"        [{table.Name}ID] INT NOT NULL,"); // FK to main table
                                                                                              // checkboxTableSb.AppendLine($"        [{field.SourceTableName}ID] INT NOT NULL,"); // FK to source table
                    checkboxTableSb.AppendLine($"    [{table.Name}ID]  {table.PrimaryKeyType} NOT NULL,"); // FK to main table
                    checkboxTableSb.AppendLine($"    [{field.SourceTableName}ID] {field.SourceTableType} NOT NULL,"); // FK to source table

                    checkboxTableSb.AppendLine($"        CONSTRAINT FK_{mapTableName}_Main FOREIGN KEY ([{table.Name}ID]) REFERENCES [{table.Name}]([ID]) ON DELETE CASCADE,");
                    checkboxTableSb.AppendLine($"        CONSTRAINT FK_{mapTableName}_Ref FOREIGN KEY ([{field.SourceTableName}ID]) REFERENCES [{field.SourceTableName}]([ID]) ON DELETE NO ACTION");
                    checkboxTableSb.AppendLine("    );");

                    checkboxTableSb.AppendLine("END");

                    checkboxTables.Add(checkboxTableSb.ToString());

                }
            }

            return checkboxTables;
        }

        // Get checkbox mapping table names only
        public List<string> GetCheckboxMappingTableNames(ClientTable table, IEnumerable<ClientFieldDefinition> fields)
        {
            var mappingTableNames = new List<string>();
            foreach (var field in fields)
            {
                if (string.Equals(field.TypeName, FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase) ||
                string.Equals(field.TypeName, FieldTypeEnums.Multiselect.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    string mapTableName = $"{table.Name}_{field.Name}"; mappingTableNames.Add(mapTableName);
                }
            }
            return mappingTableNames;
        }

        // Get document mapping table names only
        public List<string> GetDocumentMappingTableNames(List<ClientForm> forms)
        {
            var mappingTableNames = new List<string>();
            foreach (var form in forms)
            {
                var mappingTableName = $"{form.Name}Document";
                mappingTableNames.Add(mappingTableName);
            }
            return mappingTableNames;
        }


        public async Task CreateDatabase(string databaseName, string newConnectionString)
        {
            AlterFolderAndDatabaseClass alterFolderAndDatabaseClass = new(_context, configuration);
            AlterFolderAndDatabaseClass alterFolderAndDatabaseClass1 = alterFolderAndDatabaseClass;
            //AlterFolderAndDatabaseClass alterFolderAndDatabaseClass = alterFolderAndDatabaseClass1;
            string backupFilePath = configuration["BaseDatabasePath"] + "\\DynamicDemo.bak";
            using var connection = _context.CreateConnection();
            var createDbQuery = $"CREATE DATABASE {databaseName}";
            await connection.ExecuteAsync(createDbQuery);
            var restoreDbQuery = $@"
                            RESTORE DATABASE {databaseName} 
                            FROM DISK = @BackupFilePath 
                            WITH MOVE 'DynamicDemo' TO 'C:\\SQLRestore\\{databaseName}.mdf',
                            MOVE 'DynamicDemo_log' TO 'C:\\SQLRestore\\{databaseName}_log.ldf', 
                            REPLACE, RECOVERY;";
            await connection.ExecuteAsync(restoreDbQuery, new { BackupFilePath = backupFilePath });
            var setMultiUserModeQuery = $"ALTER DATABASE {databaseName} SET MULTI_USER";
            await connection.ExecuteAsync(setMultiUserModeQuery);
            await AlterFolderAndDatabaseClass.InsertRestoredTablesMetadata(databaseName, newConnectionString);
        }


    }
}
