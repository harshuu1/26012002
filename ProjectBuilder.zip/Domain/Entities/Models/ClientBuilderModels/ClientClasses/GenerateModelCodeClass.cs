﻿using DapperDB;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using System.Text;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateModelCodeClass(DapperDbContext.DbContext context)
    {
        private readonly DapperDbContext.DbContext _context = context;

        private static void GenerateCheckboxModel(ClientTable table, ClientFieldDefinition field, string directoryPath)
        {
            string mapClassName = $"{table.Name}_{field.Name}";
            string tableFolderPath = Path.Combine(directoryPath, table.Name);
            Directory.CreateDirectory(tableFolderPath);
            string mapPath = Path.Combine(tableFolderPath, $"{mapClassName}Model.cs");
            string ckType = GetCSharpType(table.PrimaryKeyType?.Trim().ToLowerInvariant() ?? "int");
            var sb = new StringBuilder();

            sb.AppendLine("using System.ComponentModel.DataAnnotations;");
            sb.AppendLine("using System.ComponentModel.DataAnnotations.Schema;");
            sb.AppendLine();
            sb.AppendLine($"namespace Entities.Models.{table.Name}");
            sb.AppendLine("{");
            sb.AppendLine($"    public class {mapClassName}Model");
            sb.AppendLine("    {");
            sb.AppendLine("        [Key]");
            sb.AppendLine("        public int ID { get; set; }");
            sb.AppendLine();
            sb.AppendLine("        [Required]");
            sb.AppendLine($"        public {ckType}? {table.Name}ID {{ get; set; }}");
            sb.AppendLine();
            string idType = GetCSharpType((field.SourceTableType ?? "").Trim().ToLower());
            sb.AppendLine("        [Required]");
            sb.AppendLine($"        public {idType}?  {field.SourceTableName}ID {{ get; set; }}");
            sb.AppendLine();

            sb.AppendLine("    }");
            sb.AppendLine("}");

            File.WriteAllText(mapPath, sb.ToString());
        }

        private static string GetCSharpType(string dbType)
        {
            dbType = (dbType ?? "").Trim().ToLower();
            return Enum.TryParse<PKTypeEnum>(dbType, true, out var type)
                ? type.GetDescription()
                : PKTypeEnum.Int.GetDescription();
        }

        public void GenerateModelCode(ClientTable table, IEnumerable<ClientFieldDefinition> Fields, string ProjectName, string ClientName, IEnumerable<ClientForm> FormList)
        {
            // string projectfoldername = $"{ProjectName}_{ClientName}";
            string projectfoldername = $@"{ClientName}\{ProjectName}";

            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Domain\Entities\Models";

            if (!Directory.Exists(directoryPath))
                Directory.CreateDirectory(directoryPath);
            var sb = new StringBuilder();

            sb.AppendLine("using System;");
            sb.AppendLine("using System.Collections.Generic;");
            sb.AppendLine();
            sb.AppendLine($"namespace Entities.Models.{table.Name}");
            sb.AppendLine("{");
            string pkType;
            string idType;


            sb.AppendLine($"    public class {table.Name}Model:CommonFields");
            sb.AppendLine("    {");

            pkType = table.PrimaryKeyType?.Trim().ToLowerInvariant() ?? "int";

            idType = GetCSharpType(pkType);
            sb.AppendLine($"        /// <summary>The primary key for the entity.</summary>");
            sb.AppendLine($"        public {idType} ID {{ get; set; }}");

            if (table.IsHierarchical)
            {
                // Add ParentID column to model
                sb.AppendLine($"public {idType}? ParentID {{ get; set; }}");
                sb.AppendLine($"public List<{table.Name}Model> items {{ get; set; }} = new();");
            }

            // sb.AppendLine($"    public class {table.Name}:CommonFields");
            // sb.AppendLine("    {");

            // Add ParentId if the table is hierarchical
            //if (table.IsHierarchical)
            //{
            //    sb.AppendLine($"        public int? ParentId {{ get; set; }}");
            //}
            //int dropdownCounter = 1;//for increment condition of dropdown_source table name
            foreach (var field in Fields)
            {
                var fieldNameLower = string.IsNullOrWhiteSpace(field.Name)
    ? ""
    : char.ToUpper(field.Name.Trim()[0]) + field.Name.Trim().Substring(1).ToLower();
                FieldTypeEnums fieldType;
                if (!Enum.TryParse(field.TypeName, true, out fieldType))
                {
                    fieldType = FieldTypeEnums.Unknown;
                }
                if (fieldType == FieldTypeEnums.Checkboxgroup || fieldType == FieldTypeEnums.Multiselect)
                {
                    string safeName = field.Name?.Trim() ?? string.Empty;
                    string safeTableName = field.SourceTableName?.Trim() ?? string.Empty;

                    // string fieldName = char.ToLower(safeName[0]) + safeName[1..];
                    var fieldName = string.IsNullOrWhiteSpace(field.Name)
      ? ""
      : char.ToUpper(field.Name.Trim()[0]) + field.Name.Trim().Substring(1).ToLower();

                    string tableName = char.ToLower(safeTableName[0]) + safeTableName[1..];


                    //sb.AppendLine($"        public string? {field.SourceTableName}_{field.Name}_Name {{ get; set; }}");
                    sb.AppendLine($"        public string? {fieldName}_{tableName} {{ get; set; }}");
                    sb.AppendLine($"        public string? {fieldName}_{tableName}Ids {{ get; set; }}");
                    GenerateCheckboxModel(table, field, directoryPath); // ✅ Delegate to helper method
                    continue;
                }
                else if (fieldType == FieldTypeEnums.Signature)
                {
                    var fieldName = field.Name;

                    sb.AppendLine($"        public byte[]? {fieldName} {{ get; set; }}");
                    sb.AppendLine();
                    sb.AppendLine($"        public string? {fieldName}Base64 => {fieldName} != null ");
                    sb.AppendLine($"            ? $\"data:image/png;base64,{{Convert.ToBase64String({fieldName})}}\" ");
                    sb.AppendLine("            : null;");

                    continue;
                }
                // Convert DataTable field type to C# field type
                var csharpType = ConvertDataTableTypeToCSharpType(field.TypeName ?? "");
                if (field.Mandatory != true)
                {


                    switch (fieldType)
                    {
                        case FieldTypeEnums.Bigint:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Int:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Smallint:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Tinyint:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Decimal:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Money:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Float:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.DropDown:
                            // ID field
                            idType = GetCSharpType((field.SourceTableType ?? "").Trim().ToLower());
                            sb.AppendLine($"        public {idType}? {fieldNameLower} {{ get; set; }}");

                            // Display value field: FieldName_SourceTableName
                            string displayName = $"{fieldNameLower}_{field.SourceTableName}";
                            sb.AppendLine($"        public string? {displayName} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Slider:
                            sb.AppendLine($"        public float {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Rangeslider:
                            sb.AppendLine($"        public string {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Varchar:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Nvarchar:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Radiogroup:
                            idType = GetCSharpType((field.SourceTableType ?? "").Trim().ToLower());
                            sb.AppendLine($"        public {idType}? {fieldNameLower} {{ get; set; }}");
                            //sb.AppendLine($"        public string? {field.SourceTableName}Name {{ get; set; }}");
                            sb.AppendLine($"        public string? {fieldNameLower}_{field.SourceTableName} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Richtexteditor:
                        case FieldTypeEnums.Colorpicker:
                            sb.AppendLine($"        public string? {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Rating:
                            sb.AppendLine($"        public int? {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Varbinary:
                        case FieldTypeEnums.ImageUpload:
                            sb.AppendLine($"        public byte[]? {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Image:
                            sb.AppendLine($"        public string? {fieldNameLower}ImageBase64 {{ get; set; }}");
                            sb.AppendLine($"        public byte[]? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Date:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Datetime:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Timeduration:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Bit:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Switches:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Barcode:
                            sb.AppendLine($"        public string? {fieldNameLower} {{ get; set; }}");
                            break;

                        default:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                    }

                }
                else
                {
                    //if (field.TypeName == "dropdown")
                    //{
                    //    // ID field
                    //    sb.AppendLine($"        public int? {field.Name} {{ get; set; }}");

                    //    // Display value field: FieldName_SourceTableNameCounter
                    //    string displayName = $"{field.Name}_{field.SourceTableName}";
                    //    sb.AppendLine($"        public string? {displayName} {{ get; set; }}");

                    //    //dropdownCounter++;
                    //}
                    //else if (field.TypeName == "radiogroup")
                    //{
                    //    sb.AppendLine($"        public int {field.Name} {{ get; set; }}");
                    //    sb.AppendLine($"        public string? {field.SourceTableName}Name {{ get; set; }}");
                    //}
                    //else if (field.TypeName == "colorpicker")
                    //{
                    //    sb.AppendLine($"        public string? {field.Name} {{ get; set; }}");
                    //}

                    ////else if (field.TypeName == "varbinary")
                    ////{
                    ////    sb.AppendLine($"        public varbinary {field.Name} {{ get; set; }}");
                    ////    sb.AppendLine($"        public string? {field.SourceTableName}Name {{ get; set; }}");
                    ////}
                    ////else if (field.TypeName == "ImageUpload")
                    ////{
                    ////    sb.AppendLine($"        public byte[]? {field.Name} {{ get; set; }}");
                    ////    //sb.AppendLine($"        public string? {field.SourceTableName}Name {{ get; set; }}");
                    ////}
                    //else if (field.TypeName == "varbinary" || field.TypeName == "ImageUpload")
                    //{
                    //    sb.AppendLine($"        public byte[]? {field.Name} {{ get; set; }}");
                    //    //sb.AppendLine($"        public string? {field.SourceTableName}Name {{ get; set; }}");
                    //}



                    //else if (field.TypeName == "richtexteditor")
                    //{
                    //    sb.AppendLine($"        public string? {field.Name} {{ get; set; }}");
                    //}
                    //else if (string.Equals(field.TypeName, "image", StringComparison.CurrentCultureIgnoreCase))
                    //{
                    //    sb.AppendLine($"        public string? ImageBase64 {{ get; set; }}");
                    //    sb.AppendLine($"        public byte[]? {field.Name} {{ get; set; }}");
                    //}
                    //else
                    //{

                    //    sb.AppendLine($"        public {csharpType}? {field.Name} {{ get; set; }}");

                    //    //{
                    //    //    sb.AppendLine($"        public {csharpType}? {field.Name} {{ get; set; }}");
                    //    //}
                    //}

                    switch (fieldType)
                    {
                        case FieldTypeEnums.Bigint:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Int:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Smallint:

                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Tinyint:

                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Decimal:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Money:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Float:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.DropDown:
                            // ID field
                            idType = GetCSharpType((field.SourceTableType ?? "").Trim().ToLower());
                            sb.AppendLine($"        public {idType} {fieldNameLower} {{ get; set; }}");

                            // Display value field: FieldName_SourceTableName
                            string displayName = $"{fieldNameLower}_{field.SourceTableName}";
                            sb.AppendLine($"        public string? {displayName} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Radiogroup:
                            idType = GetCSharpType((field.SourceTableType ?? "").Trim().ToLower());
                            sb.AppendLine($"        public {idType} {fieldNameLower} {{ get; set; }}");
                            //sb.AppendLine($"        public string? {field.SourceTableName}Name {{ get; set; }}");
                            sb.AppendLine($"        public string? {fieldNameLower}_{field.SourceTableName} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Richtexteditor:
                        case FieldTypeEnums.Colorpicker:
                            sb.AppendLine($"        public string {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Rating:
                            sb.AppendLine($"        public int {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Slider:
                            sb.AppendLine($"        public float {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Rangeslider:
                            sb.AppendLine($"        public string {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Varchar:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Nvarchar:
                            sb.AppendLine($"        public {csharpType}? {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Varbinary:
                        case FieldTypeEnums.ImageUpload:
                            sb.AppendLine($"        public byte[] {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Image:
                            sb.AppendLine($"        public string? {fieldNameLower}ImageBase64 {{ get; set; }}");
                            sb.AppendLine($"        public byte[]? {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Date:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Datetime:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Timeduration:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Bit:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                        case FieldTypeEnums.Switches:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;

                        case FieldTypeEnums.Barcode:
                            sb.AppendLine($"        public string? {fieldNameLower} {{ get; set; }}");
                            break;
                        default:
                            sb.AppendLine($"        public {csharpType} {fieldNameLower} {{ get; set; }}");
                            break;
                    }


                }

                //sb.ToString();
            }

            if (table.HeaderTableId > 0)
            {
                idType = GetCSharpType((table.ParentPrimaryKeyType ?? "").Trim().ToLower());
                sb.AppendLine($"        public {idType} {table.HeaderTableName}Id {{ get; set; }}");
            }

            //if (table.IsHierarchical)
            //{
            //    // Add ParentID column to model
            //    sb.AppendLine("public int? ParentID { get; set; }");
            //    sb.AppendLine($"public List<{table.Name}> items {{ get; set; }} = new();");
            //}

            sb.AppendLine($"        public int FormId {{ get; set; }}");
            sb.AppendLine("    }");
            if (FormList.Any(x => x.IsAddToList == true))
            {
                sb.AppendLine(" ");
                sb.AppendLine($"     public class AddToList{table.Name}Model");
                sb.AppendLine("      {");
                sb.AppendLine($"         public List<int> {table.Name}Ids {{ get; set; }}");
                sb.AppendLine("      }");
            }
            sb.AppendLine("}");
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
            string filePath;
            string subFolderPath = Path.Combine(directoryPath, table.Name);
            if (!Directory.Exists(subFolderPath))
            {
                Directory.CreateDirectory(subFolderPath);
            }

            if (table.HeaderTableId > 0)
            {
                filePath = Path.Combine(subFolderPath, $"{table.Name}Model.cs");
            }
            else
            {
                filePath = Path.Combine(subFolderPath, $"{table.Name}Model.cs");
            }
            // Create the file path (using the table name as the file name)
            //string filePath = Path.Combine(directoryPath, $"{table.Name}.cs");

            // Write the model code to the file
            File.WriteAllText(filePath, sb.ToString());
            foreach (var field in Fields)
            {
                // Your existing code to handle CheckBox, Signature, etc.

                // Call the method here
                AppendReferenceResponseModel(table, directoryPath, field);
            }


        }
        public string ConvertDataTableTypeToCSharpType(string dataTableType)
        {
            var typeMapping = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
       {
        { "varchar", "string" },
        { "int", "int" },
        { "bit", "bool" },
        { "date", "DateOnly" },
        { "datetime", "DateTime" },
        { "bigint", "long" },
        { "decimal", "decimal" },
        { "float", "double" },
        { "nvarchar", "string" },
        { "smallint", "short" },
        { "money", "decimal" },
        {"tinyint", "byte" },
        { "varbinary", "byte" },
        { "rangeslider", "string" },
        { "switches", "bool" },
        { "captcha", "string" },
        {"timeduration", "TimeSpan" },
        { "hyperlink", "string" },
        { "ImageUpload", "byte" },
        {"slider", "float" },



 // Add more conversions as needed
       };

            // Return the mapped C# type or default to "object" if not found in the dictionary
            return typeMapping.TryGetValue(dataTableType, out var csharpType) ? csharpType : "object";
        }
        private static void AppendReferenceResponseModel(ClientTable table, string directoryPath, ClientFieldDefinition field)
        {
            string baseClassName = table.Name;
            string responseClassName = $"{table.Name}ReferenceResponse";
            string filePath = Path.Combine(directoryPath, baseClassName, $"{baseClassName}Model.cs");

            if (!File.Exists(filePath))
                throw new FileNotFoundException($"Base model file not found: {filePath}");

            string idType = GetCSharpType((table.PrimaryKeyType ?? "int").Trim().ToLower());

            var sb = new StringBuilder();
            sb.AppendLine();
            sb.AppendLine($"    public class {responseClassName}");
            sb.AppendLine("    {");
            sb.AppendLine($"        public {idType} {baseClassName}Id {{ get; set; }}");

            if (!string.IsNullOrWhiteSpace(field.SourceTableName))
            {
                // Example: TestField -> TestFieldName
                string propName = char.ToUpper(field.SourceTableName[0]) + field.SourceTableName[1..] + "Name";
                sb.AppendLine($"    public string {propName} {{ get; set; }}");
            }
            sb.AppendLine($"       public {idType} ParentId {{ get; set; }}");
            sb.AppendLine("       public List<string> DocumentName { get; set; } = new();");
            sb.AppendLine("       public bool IsParentTable { get; set; }");
            sb.AppendLine("       public bool HasChildReferences { get; set; }");
            sb.AppendLine("       public List<string> ChildTableNames { get; set; } = new();");
            sb.AppendLine($"      public string {field.SourceTableName}Names {{ get; set; }}");
            sb.AppendLine($"      public string {baseClassName}Names {{ get; set; }}");
            sb.AppendLine("       public Dictionary<string, List<string>> NamesByTable { get; set; } = new();");
            sb.AppendLine("       public Dictionary<string, int> MoreCountByTable { get; set; } = new();");
            sb.AppendLine("    }");
            sb.AppendLine("}");

            // Append just before the final closing brace of namespace
            string fileContent = File.ReadAllText(filePath);

            // Ensure we don’t duplicate
            if (!fileContent.Contains($"class {responseClassName}"))
            {
                int lastBraceIndex = fileContent.LastIndexOf('}');
                fileContent = fileContent.Substring(0, lastBraceIndex) + sb.ToString();
                File.WriteAllText(filePath, fileContent);
            }
        }

        //private static void GenerateReferenceResponseModel(ClientTable table, string directoryPath, ClientFieldDefinition field)
        //{
        //    // Class name based on table name
        //    string className = $"{table.Name}ReferenceResponse";
        //    string filePath = Path.Combine(directoryPath, $"{className}.cs");

        //    var sb = new StringBuilder();
        //    sb.AppendLine("using System;");
        //    sb.AppendLine("using System.Collections.Generic;");
        //    sb.AppendLine();
        //    sb.AppendLine("namespace Models");
        //    sb.AppendLine("{");
        //    sb.AppendLine($"    public class {className}");
        //    sb.AppendLine("    {");

        //    // Always include ID based on table's PK type
        //    string idType = GetCSharpType((table.PrimaryKeyType ?? "int").Trim().ToLower());
        //    sb.AppendLine($"        public {idType} {table.Name}Id {{ get; set; }}");

        //    // Dynamically add reference property based on SourceTableName
        //    if (!string.IsNullOrWhiteSpace(field.SourceTableName))
        //    {
        //        string propertyName = char.ToUpper(field.SourceTableName[0]) + field.SourceTableName[1..];
        //        sb.AppendLine($"        public string? {propertyName} {{ get; set; }}");
        //    }

        //    sb.AppendLine("        public string? DocumentName { get; set; }");

        //    // Tracking properties
        //    sb.AppendLine("        public bool IsParentTable { get; set; }");
        //    sb.AppendLine("        public bool HasChildReferences { get; set; }");
        //    sb.AppendLine("        public List<string> ChildTableNames { get; set; } = new();");

        //    sb.AppendLine("    }");
        //    sb.AppendLine("}");

        //    File.WriteAllText(filePath, sb.ToString());
        //}


    }
}
