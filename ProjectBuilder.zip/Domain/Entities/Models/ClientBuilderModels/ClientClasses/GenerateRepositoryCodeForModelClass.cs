﻿using Dapper;
using DapperDB;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic.FileIO;
using System.Linq;
using System.Text;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateRepositoryCodeForModelClass(DapperDbContext.DbContext context, IConfiguration configuration)
    {
        private readonly DapperDbContext.DbContext _context = context;
        private readonly IConfiguration _configuration = configuration;
       
        private Dictionary<string, string> FetchColumnsForTable(string tableName)
        {
            var columns = new Dictionary<string, string>();
            try
            {
                using var connection = _context.CreateConnection();
                connection.Open();

                //Query to fetch column names and data types
                var query = @"
                    SELECT COLUMN_NAME, DATA_TYPE
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_NAME = @TableName
                    AND TABLE_SCHEMA = 'dbo'"; // Default schema 'dbo'

                var result = connection.Query(query, new { TableName = tableName }).ToList();

                if (result.Count == 0)
                {
                    throw new InvalidOperationException($"No columns found for table {tableName}.");
                }

                foreach (var row in result)
                {
                    if (!string.IsNullOrEmpty(row.COLUMN_NAME))
                    {
                        columns.Add(row.COLUMN_NAME.Trim(), row.DATA_TYPE.Trim());
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine($"Error occurred: {ex.Message}");
                throw;
            }
            return columns;
        }

        public async Task<bool> HasMultiColumnFieldsAsync(int tableId, string configConnectionString)
        {
            var sql = @"
             SELECT CASE 
                 WHEN EXISTS (
                     SELECT 1 
                     FROM FieldDefination
                     WHERE SourceTableId = @TableId
                       AND IsMultiColumn = 1
                 ) THEN CAST(1 AS BIT)
                 ELSE CAST(0 AS BIT)
             END";

            //string? originalConnectionString = _configuration.GetConnectionString("DefaultConnection");

            using var connection = new SqlConnection(configConnectionString); // Use directly here

            await connection.OpenAsync();
            return await connection.ExecuteScalarAsync<bool>(sql, new { TableId = tableId });
        }
        public static void GenerateCheckboxRepositoryCode(ClientTable table, ClientFieldDefinition checkboxField, string ProjectName, string ClientName)
        {
            var code = new StringBuilder();
            string mapTableName = $"{table.Name}_{checkboxField.Name}";
            string className = $"{mapTableName}Repository";

            code.AppendLine("using Dapper;");
            code.AppendLine($"using Entities.Models.{table.Name};");
            code.AppendLine("using System.Data;");
            code.AppendLine("using Microsoft.Data.SqlClient;");
            code.AppendLine("using System.Collections.Generic;");
            code.AppendLine("using System.Linq;");
            code.AppendLine("using System.Threading.Tasks;");

            code.AppendLine("using static DapperDB.DapperDbContext;");
            code.AppendLine("using Interfaces;");
            code.AppendLine();
            var ckType = table.PrimaryKeyType?.ToString()?.Trim().ToLowerInvariant() ?? "int";
            var ckreturnType = GetCSharpType((table.PrimaryKeyType ?? "").Trim().ToLower());
            code.AppendLine("namespace Repositories");
            code.AppendLine("{");
            code.AppendLine($"    public class {className} : I{mapTableName}");
            code.AppendLine("    {");
            code.AppendLine("        private readonly DbContext _context;");
            code.AppendLine($"        public {className}(DbContext context)");
            code.AppendLine("        {");
            code.AppendLine("            _context = context;");
            code.AppendLine("        }");
            code.AppendLine();

            // Create
            code.AppendLine($"        public async Task<{ckreturnType}> CreateAsync({mapTableName}Model entity)");
            code.AppendLine("        {");
            code.AppendLine($"            var query = \"INSERT INTO {mapTableName} ([{table.Name}ID], [{checkboxField.SourceTableName}ID]) VALUES (@{table.Name}ID, @{checkboxField.SourceTableName}ID); SELECT CAST(SCOPE_IDENTITY() AS INT);\";");
            code.AppendLine("            using (var connection = _context.CreateConnection())");
            code.AppendLine("            {");
            code.AppendLine($"                return await connection.QuerySingleAsync<{ckreturnType}>(query, entity);");
            code.AppendLine("            }");
            code.AppendLine("        }");
            code.AppendLine();

            // Get all
            code.AppendLine($"        public async Task<List<{mapTableName}Model>> GetAllAsync()");
            code.AppendLine("        {");
            code.AppendLine($"            var query = \"SELECT * FROM {mapTableName}\";");
            code.AppendLine("            using (var connection = _context.CreateConnection())");
            code.AppendLine("            {");
            code.AppendLine($"                var result = await connection.QueryAsync<{mapTableName}Model>(query);");
            code.AppendLine("                return result.ToList();");
            code.AppendLine("            }");
            code.AppendLine("        }");
            code.AppendLine();

            // Get by ID
            code.AppendLine($"        public async Task<{mapTableName}Model> GetByIdAsync(int id)");
            code.AppendLine("        {");
            code.AppendLine($"            var query = \"SELECT * FROM {mapTableName} WHERE Id = @id\";");
            code.AppendLine("            using (var connection = _context.CreateConnection())");
            code.AppendLine("            {");
            code.AppendLine($"                return await connection.QueryFirstOrDefaultAsync<{mapTableName}Model>(query, new {{ id }});");
            code.AppendLine("            }");
            code.AppendLine("        }");
            code.AppendLine();

            // Update
            code.AppendLine($"        public async Task<int> UpdateAsync(int id, {mapTableName}Model entity)");
            code.AppendLine("        {");
            code.AppendLine($"            var query = \"UPDATE {mapTableName} SET [{checkboxField.SourceTableName}ID] = @{checkboxField.SourceTableName}ID WHERE Id = @Id\";");
            code.AppendLine("            using (var connection = _context.CreateConnection())");
            code.AppendLine("            {");
            code.AppendLine("                return await connection.ExecuteAsync(query, new { Id = id, entity." + checkboxField.SourceTableName + "ID });");
            code.AppendLine("            }");
            code.AppendLine("        }");
            code.AppendLine();
            /////




            code.AppendLine($"public async Task UpdateMappingsAsync({ckreturnType} id, List<{mapTableName}Model> mappings)");
            code.AppendLine("{");
            code.AppendLine($"    var deleteQuery = \"DELETE FROM {mapTableName} WHERE {table.Name}ID = @{table.Name}ID\";");
            code.AppendLine($"    var insertQuery = \"INSERT INTO {mapTableName} ({table.Name}ID, {checkboxField.SourceTableName}ID) VALUES (@{table.Name}ID, @{checkboxField.SourceTableName}ID)\";");
            code.AppendLine();
            code.AppendLine("    using var connection = _context.CreateConnection();");
            code.AppendLine("    connection.Open();");
            code.AppendLine();
            code.AppendLine("    using var transaction = connection.BeginTransaction();");
            code.AppendLine();
            code.AppendLine("    try");
            code.AppendLine("    {");
            code.AppendLine($"        await connection.ExecuteAsync(deleteQuery, new {{ {table.Name}ID = id }}, transaction);");
            code.AppendLine();
            if (checkboxField.SourceTableType == "UNIQUEIDENTIFIER")
            {
                code.AppendLine($"        if (mappings == null || mappings.All(m => m.{checkboxField.SourceTableName}ID == Guid.Empty || m.{checkboxField.SourceTableName}ID == null))");
            }
            else
            {
                code.AppendLine($"        if (mappings == null || mappings.All(m => m.{checkboxField.SourceTableName}ID == 0 || m.{checkboxField.SourceTableName}ID == null))");
            }            
            code.AppendLine("        {");
            code.AppendLine("            transaction.Commit();");
            code.AppendLine("            return;");
            code.AppendLine("        }");
            code.AppendLine();
            code.AppendLine("        foreach (var map in mappings)");
            code.AppendLine("        {");
            code.AppendLine("            await connection.ExecuteAsync(insertQuery, new");
            code.AppendLine("            {");
            code.AppendLine($"                {table.Name}ID = id,");
            code.AppendLine($"                {checkboxField.SourceTableName}ID = map.{checkboxField.SourceTableName}ID");
            code.AppendLine("            }, transaction);");
            code.AppendLine("        }");
            code.AppendLine();
            code.AppendLine("        transaction.Commit();");
            code.AppendLine("    }");
            code.AppendLine("    catch");
            code.AppendLine("    {");
            code.AppendLine("        transaction.Rollback();");
            code.AppendLine("        throw;");
            code.AppendLine("    }");
            code.AppendLine("}");


            // Delete by parent ID
            code.AppendLine($"        public async Task<bool> DeleteByParentIdAsync(int parentId)");
            code.AppendLine("        {");
            code.AppendLine($"            var query = \"DELETE FROM {mapTableName} WHERE [{table.Name}ID] = @parentId\";");
            code.AppendLine("            using (var connection = _context.CreateConnection())");
            code.AppendLine("            {");
            code.AppendLine("                await connection.ExecuteAsync(query, new { parentId });");
            code.AppendLine("                return true;");
            code.AppendLine("            }");
            code.AppendLine("        }");

            code.AppendLine("    }");
            code.AppendLine("}");

            // Write to file
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Infrastructure\Repositories";

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            string filePath = Path.Combine(directoryPath, $"{className}.cs");
            File.WriteAllText(filePath, code.ToString());
        }

        private static string GetCSharpType(string dbType)
        {
            dbType = (dbType ?? "").Trim().ToLower();
            return Enum.TryParse<PKTypeEnum>(dbType, true, out var type)
                ? type.GetDescription()
                : PKTypeEnum.Int.GetDescription();
        }
        private static string GetClassType(string dbType)
        {
            dbType = dbType?.Trim().ToLower() ?? string.Empty;

            return Enum.TryParse<PKTypeEnum>(dbType, true, out var type)
                ? type.GetResponseDescription(asCreationResponse: true)
                : PKTypeEnum.Int.GetResponseDescription(asCreationResponse: true);
        }

        public string GetInsertQuery(string tableName, string columnNames, string parameterNames, PKTypeEnum idType)
        {
            // Input validation
            if (string.IsNullOrWhiteSpace(tableName))
                throw new ArgumentException("Table name cannot be empty", nameof(tableName));
            if (string.IsNullOrWhiteSpace(columnNames))
                throw new ArgumentException("Column names cannot be empty", nameof(columnNames));
            if (string.IsNullOrWhiteSpace(parameterNames))
                throw new ArgumentException("Parameter names cannot be empty", nameof(parameterNames));

            switch (idType)
            {
                case PKTypeEnum.BigInt:
                    return $"INSERT INTO {tableName} ({columnNames}) VALUES ({parameterNames}); SELECT CAST(SCOPE_IDENTITY() AS BIGINT) AS Id;";
                case PKTypeEnum.SmallInt:
                    return $"INSERT INTO {tableName} ({columnNames}) VALUES ({parameterNames}); SELECT CAST(SCOPE_IDENTITY() AS SMALLINT) AS Id;";
                case PKTypeEnum.TinyInt:
                    return $"INSERT INTO {tableName} ({columnNames}) VALUES ({parameterNames}); SELECT CAST(SCOPE_IDENTITY() AS TINYINT) AS Id;";
                case PKTypeEnum.UniqueIdentifier:
                    return $" INSERT INTO {tableName} ({columnNames}) OUTPUT INSERTED.Id VALUES ({parameterNames});";
                case PKTypeEnum.Int:
                    return $"INSERT INTO {tableName} ({columnNames}) VALUES ({parameterNames}); SELECT CAST(SCOPE_IDENTITY() AS INT) AS Id;";
                default:
                    throw new ArgumentException($"Unsupported PKTypeEnum value: {idType}", nameof(idType));
            }
        }

        public async void GenerateRepositoryCodeForModel(ClientTable table, string ProjectName, string ClientName, List<ClientCardViewFields> AddEditFields, int tableId, IEnumerable<ClientFieldDefinition> AddEditDetailsFields, List<ClientDisplayField> displayfields, IEnumerable<ClientForm> FormList, IEnumerable<ClientForm> Forms, string configConnectionString, List<ClientSearchField> childSearchListByParentIds, List<ClientSearchField> ClientSearch)
        {
         
            // Get mapping table names for checkbox fields


            var code = new StringBuilder();
            try
            {
                //Add namespaces to the code
                code.AppendLine("using Dapper;");
                code.AppendLine("using Entities.Models.CreationResponse;");
                code.AppendLine($"using Entities.Models.{table.Name};");
                code.AppendLine("using System.Data;");
                code.AppendLine("using Microsoft.Data.SqlClient;");
                code.AppendLine("using System.Collections.Generic;");
                code.AppendLine("using System.Linq;");
                code.AppendLine("using System.Threading.Tasks;");
                code.AppendLine("using Entities.Models.AppUser;");
                code.AppendLine("using Entities.Models.Request;");
                code.AppendLine("using Entities.Models.Response;");
                code.AppendLine("using static DapperDB.DapperDbContext;");
                code.AppendLine("using Interfaces;");
                code.AppendLine("using System.Text;");

                foreach (var field in AddEditDetailsFields)
                {
                    if (!string.IsNullOrEmpty(field.ParentFieldName) && field.IsLazyLoaded == true)
                    {
                        code.AppendLine("   using Entities.Models.PagedResult;");
                        code.AppendLine($"   using Entities.Models.{field.SourceTableName};");
                    }
                }

                code.AppendLine();

                //Define model and repository class names
                string modelName = table.Name;
                string className = modelName + "Repository";

                //Write the class structure
                code.AppendLine($"namespace Repositories");
                code.AppendLine("{");
                code.AppendLine($"    public class {className}:I{modelName}");
                code.AppendLine("    {");
                ////Changes for IDType
                var pkType = table.PrimaryKeyType?.ToString()?.Trim().ToLowerInvariant() ?? "int";
                var responseClassName = GetClassType(pkType);
                var returnType = GetCSharpType((table.PrimaryKeyType ?? "").Trim().ToLower());

                //Add constructor for DbContext injection
                code.AppendLine("        private readonly DbContext _context;");
                code.AppendLine("        private readonly IUserInfo _userInfo;");
                code.AppendLine();
                code.AppendLine($"        public {className}(DbContext context, IUserInfo userInfo)");
                code.AppendLine("        {");
                code.AppendLine("            _context = context;");
                code.AppendLine("           _userInfo = userInfo;");
                code.AppendLine("        }");
                code.AppendLine();

                //Fetch columns for the model
                var columns = FetchColumnsForTable(table.Name);
                if (columns == null || columns.Count == 0)
                    throw new InvalidOperationException($"No columns found for table {table.Name}.");

                // Exclude columns from INSERT and UPDATE queries
                var excludedFromInsert = new[] { "ID", "ModifiedBy", "ModifiedDate" };
                var excludedFromUpdate = new[] { "CreatedBy", "CreatedDate" };

                var insertColumns = columns.Keys.Where(c => !excludedFromInsert.Contains(c)).ToList();
                var columnNames = string.Join(", ", insertColumns);
                var parameterNames = string.Join(", ", insertColumns.Select(c => "@" + c));

                var updateColumns = columns.Keys.Where(c => !excludedFromUpdate.Contains(c) || c == "ID").ToList();
                var setClauses = string.Join(", ", updateColumns
                    .Where(c => c != "ID")
                    .Select(c =>
                    {
                        if (c == "ModifiedDate")
                            return $"{c} = @{c}";
                        if (c == "ModifiedBy")
                            return $"{c} = @ModifiedBy";
                        return $"{c} = @{c}";
                    }));
                string? fields = string.Join(", ", displayfields.Select(f => f.FieldName));
                string addeditfields = string.Join(", ", AddEditFields.Select(f => f.FieldName));
                string? firstField = fields.Split(',').FirstOrDefault()?.Trim();
                // Generate the queries
                //var selectgetbyidquery = $"SELECT * FROM {tableName} WHERE ID = @ID"; // Use "ID" with capital "D"
                var selectgetbyidquery = $"SELECT * FROM {table.Name} WHERE ID = @ID"; // Use "ID" with capital "D"
                // var insertQuery = $"INSERT INTO {table.Name} ({columnNames}) VALUES ({parameterNames}) SELECT CAST(SCOPE_IDENTITY() AS INT)";

                if (!Enum.TryParse<PKTypeEnum>(table.PrimaryKeyType?.Trim(), true, out var sqlIdType))
                {
                    throw new ArgumentException($"Unsupported Id type: {table.PrimaryKeyType}");
                }

                string insertQuery = GetInsertQuery(table.Name, columnNames, parameterNames, sqlIdType);
                Console.WriteLine(insertQuery);

                var deletequery = $"DELETE FROM {table.Name} WHERE ID = @ID"; // Use "ID" with capital "D"
                var updateQuery = $"UPDATE {table.Name} SET {setClauses} WHERE ID = @ID"; // Use "ID" with capital "D"


                // TODO: Need to append fieldname based on selected TEXTFIELDNAME here

                var selectQuery = $"SELECT * FROM {table.Name}";


                //bool isMultiColumn = await HasMultiColumnFieldsAsync(tableId, configConnectionString);                                                              // var selectQuery = $"SELECT * FROM {tableName}";
                //string selectQuery;
                //if (isMultiColumn)
                //{

                //    // Assign the query
                //    selectQuery = $"SELECT * FROM {table.Name} ";
                //}
                //else
                //{
                //    selectQuery = $"SELECT ID,{fields} FROM {table.Name}";
                //}

                //string selectQuery = $"SELECT ID,{fields} FROM {table.Name}";

                HashSet<int> formIdCollection = [];
                //if (table.HeaderTableId > 0)
                //{
                //    foreach (var field in AddEditDetailsFields)
                //    {
                //        if (field.TypeName == "dropdown")
                //        {
                //            var selectgetbyparentfield = "";
                //            selectgetbyparentfield = $"SELECT * FROM {table.Name} WHERE {table.HeaderTableName}Id = @Id ORDER BY {firstField} ASC";
                //            code.AppendLine($"        public async Task<IEnumerable<{table.Name}Model>>  Get{table.Name}By{table.HeaderTableName}Id({returnType} Id)");
                //            code.AppendLine("        {");
                //            code.AppendLine($"            string query = \"{selectgetbyparentfield}\";");
                //            code.AppendLine();
                //            code.AppendLine("            using (var connection = _context.CreateConnection())");
                //            code.AppendLine("            {");
                //            code.AppendLine($"                return await connection.QueryAsync<{table.Name}Model>(query, new {{ Id = Id }});");
                //            code.AppendLine("            }");
                //            code.AppendLine("        }");
                //        }
                //    }
                //}
                //                if (table.HeaderTableId > 0)
                //                {
                //                    //foreach (var field in AddEditDetailsFields)
                //                    //{
                //                    //    if (!string.IsNullOrEmpty(field.ParentFieldName))
                //                    //    {
                //                    var selectgetbyparentfield = $"SELECT * FROM {table.Name} WHERE {table.HeaderTableName}Id = @Id ORDER BY {firstField} ASC";
                //                    code.AppendLine($"        public async Task<IEnumerable<{table.Name}>>  Get{table.Name}By{table.HeaderTableName}Id(int Id)");
                //                    code.AppendLine("        {");
                //                    code.AppendLine($"            string query = \"{selectgetbyparentfield}\";");
                //                    code.AppendLine();
                //                    code.AppendLine("            using (var connection = _context.CreateConnection())");
                //                    code.AppendLine("            {");
                //                    code.AppendLine($"                return await connection.QueryAsync<{table.Name}>(query, new {{ Id = Id }});");
                //                    code.AppendLine("            }");
                //                    code.AppendLine("        }");

                //                    //    }

                //                    //}
                //                }
                foreach (var field in AddEditDetailsFields)
                {
                    //formIdCollection.Add(field.FormId);
                    if (field.TypeName == "checkboxgroup" || field.TypeName == "Multiselect")
                    {
                        GenerateCheckboxRepositoryCode(table, field, ProjectName, ClientName);
                    }
                    if (!string.IsNullOrEmpty(field.ParentFieldName) && field.ParentSourceTblName == field.SourceTableName && field.IsLazyLoaded == false)
                    {
                        var selectgetbyparentfield = $"SELECT * FROM {field.SourceTableName} WHERE {field.ParentFieldName} = @{field.ParentFieldName}";
                        code.AppendLine($"        public async Task<IEnumerable<{field.SourceTableName}>>  Get{field.SourceTableName}By{field.ParentFieldName}(int {field.ParentFieldName})");
                        code.AppendLine("        {");
                        code.AppendLine($"            string query = \"{selectgetbyparentfield}\";");
                        code.AppendLine();
                        code.AppendLine("            using (var connection = _context.CreateConnection())");
                        code.AppendLine("            {");
                        code.AppendLine($"                return await connection.QueryAsync<{field.SourceTableName}>(query, new {{ {field.ParentFieldName} = {field.ParentFieldName} }});");
                        code.AppendLine("            }");
                        code.AppendLine("        }");



                    }
                    else if (!string.IsNullOrEmpty(field.ParentFieldName) && field.IsLazyLoaded == true)
                    {
                        var selectgetbyparentfield = $"SELECT * FROM {field.SourceTableName} WHERE {field.SourceHeaderTableName}Id = @Id";
                        var countQuery = $"SELECT COUNT(*) FROM {field.SourceTableName} WHERE {field.SourceHeaderTableName}Id = @Id";

                        code.AppendLine($"        public async Task<PagedResultModel<{field.SourceTableName}Model>> Get{field.SourceTableName}By{field.ParentFieldName}Id({returnType} id, int skip, int take)");
                        code.AppendLine("        {");
                        code.AppendLine($"            string dataQuery = \"{selectgetbyparentfield}\";");
                        code.AppendLine($"            string countQuery = \"{countQuery}\";");
                        code.AppendLine();
                        code.AppendLine("            if (skip >= 0 && take > 0)");
                        code.AppendLine("            {");
                        code.AppendLine("                dataQuery += \" ORDER BY Id OFFSET @Skip ROWS FETCH NEXT @Take ROWS ONLY\";");
                        code.AppendLine("            }");
                        code.AppendLine();
                        code.AppendLine("            using (var connection = _context.CreateConnection())");
                        code.AppendLine("            {");
                        code.AppendLine($"                var totalCount = await connection.ExecuteScalarAsync<int>(countQuery, new {{ Id = id }});");
                        code.AppendLine($"                var data = await connection.QueryAsync<{field.SourceTableName}Model>(dataQuery, new {{ Id = id, Skip = skip, Take = take }});");
                        code.AppendLine();
                        code.AppendLine($"                return new PagedResultModel<{field.SourceTableName}Model>");
                        code.AppendLine("                {");
                        code.AppendLine("                    Data = data,");
                        code.AppendLine("                    TotalCount = totalCount");
                        code.AppendLine("                };");
                        code.AppendLine("            }");
                        code.AppendLine("        }");


                    }

                }


                //var FirstFormId = formIdCollection.FirstOrDefault();
                //HashSet<int> secondformId = new HashSet<int>();
                //foreach (var field in AddEditDetailsFields)
                //{
                //    secondformId.Add(field.FormId);
                //}
                //var SecondFormId = secondformId.FirstOrDefault();

                //if (FirstFormId > 0 || SecondFormId > 0)
                //{


                //var formActionQuery = await _addEditField.GetFormUpdateQueries((FirstFormId != 0 ? FirstFormId : (SecondFormId != 0 ? SecondFormId : 0)), originalConnectionString);


                //foreach (var form in Forms)
                //{

                bool hasDateFields = AddEditFields.Any(f => f.TypeId?.ToLower() == "date" || f.TypeId?.ToLower() == "datetime")
                     || AddEditDetailsFields.Any(f => f.TypeId.ToString()?.ToLower() == "date" || f.TypeId.ToString()?.ToLower() == "datetime");

                code.AppendLine($"public async Task<{responseClassName}> Create{modelName}({modelName}Model {modelName.ToLower()})");

                code.AppendLine("{");

                //''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                if (hasDateFields)
                {
                    code.AppendLine("    // Convert all DateTime and DateTime? fields to UTC with local assumption for unspecified kinds");
                    code.AppendLine($"    foreach (var prop in typeof({modelName}Model).GetProperties())");
                    code.AppendLine("    {");
                    code.AppendLine("        var propName = prop.Name.ToLower();");
                    code.AppendLine();
                    code.AppendLine("        if (prop.PropertyType == typeof(DateTime))");
                    code.AppendLine("        {");
                    code.AppendLine($"            var value = (DateTime)prop.GetValue({modelName.ToLower()});");
                    code.AppendLine("            if (value.Kind == DateTimeKind.Unspecified)");
                    code.AppendLine("                value = DateTime.SpecifyKind(value, DateTimeKind.Local);");
                    code.AppendLine("            if (!propName.Contains(\"dateonly\") && !propName.Equals(\"date\"))");
                    code.AppendLine("                value = TimeZoneInfo.ConvertTimeToUtc(value);");
                    code.AppendLine($"            prop.SetValue({modelName.ToLower()}, value);");
                    code.AppendLine("        }");
                    code.AppendLine("        else if (prop.PropertyType == typeof(DateTime?))");
                    code.AppendLine("        {");
                    code.AppendLine($"            var value = (DateTime?)prop.GetValue({modelName.ToLower()});");
                    code.AppendLine("            if (value.HasValue)");
                    code.AppendLine("            {");
                    code.AppendLine("                var dt = value.Value;");
                    code.AppendLine("                if (dt.Kind == DateTimeKind.Unspecified)");
                    code.AppendLine("                    dt = DateTime.SpecifyKind(dt, DateTimeKind.Local);");
                    code.AppendLine("                if (!propName.Contains(\"dateonly\") && !propName.Equals(\"date\"))");
                    code.AppendLine("                    dt = TimeZoneInfo.ConvertTimeToUtc(dt);");
                    code.AppendLine($"                prop.SetValue({modelName.ToLower()}, dt);");
                    code.AppendLine("            }");
                    code.AppendLine("        }");
                    code.AppendLine("    }");
                }



                //code.AppendLine("    // Step 1: Validate the user data against rules based on TableId and FormId");
                //code.AppendLine($"    string validationResult = await ValidateRules({modelName.ToLower()});");


                //code.AppendLine("    if (validationResult != \"Validation passed\") // If validation fails, return the error message");
                //code.AppendLine("    {");
                //code.AppendLine("        return new CreationResponse { Id = 0, Message = validationResult };");
                //code.AppendLine("    }");
                //code.AppendLine();
                code.AppendLine($"     {modelName.ToLower()}.CREATEDBY = _userInfo.UserId;");
                code.AppendLine($"     {modelName.ToLower()}.CREATEDDATE = DateTime.UtcNow;");
                code.AppendLine("    // Step 2: Insert the user into the database");
                code.AppendLine($"    string query = \"{insertQuery}\";");
                code.AppendLine();
                code.AppendLine("    using (var connection = _context.CreateConnection())");
                code.AppendLine("    {");
                code.AppendLine("        // Insert the new user and get the newly created user ID");
                code.AppendLine($"        var newUserId = await connection.QuerySingleAsync<{returnType}>(query, {modelName.ToLower()});");
                code.AppendLine();
                code.AppendLine(
                   pkType.ToUpper() != PKTypeEnum.UniqueIdentifier.ToString().ToUpper()
                       ? "        if (newUserId > 0)"
                       : "        if (newUserId != Guid.Empty)"
               );
                code.AppendLine("        {");
                //if (formActionList.Count > 0)
                //{


                //    code.AppendLine("            // Step 3: After successful insertion, apply actions to the user (if formId is provided)");
                //    //code.AppendLine($"            if ({(FirstFormId != 0 ? FirstFormId : (SecondFormId != 0 ? SecondFormId : 0))} > 0)");
                //    //code.AppendLine("            {");
                //    code.AppendLine($"                string actionResult = await ApplyFormActions(newUserId,{modelName.ToLower() + ".FormId"});");
                //    code.AppendLine("                if (actionResult != \"Actions applied successfully.\")");
                //    code.AppendLine("                {");
                //    code.AppendLine("                    return new CreationResponse { Id = 0, Message = actionResult }; // Return error if action application fails");
                //    code.AppendLine("                }");
                //    //code.AppendLine("            }");
                //    code.AppendLine();
                //}

                code.AppendLine($"            return new {responseClassName} {{ Id = ({returnType}) newUserId, Message = \"created and actions applied successfully\" }};");
                code.AppendLine("        }");
                code.AppendLine("        else");
                code.AppendLine("        {");
                //if (returnType == "Guid")
                //{

                //    code.AppendLine($"            return new {responseClassName} {{ Id = Guid.Empty, Message = \"Failed to create {modelName}\" }};");
                //}
                //else
                //{

                //    code.AppendLine($"            return new {responseClassName} {{ Id = ({returnType}) 0, Message = \"Failed to create {modelName}\" }};");
                //}
                string message = $"Failed to create {modelName}";
                string returnStatement = returnType == "Guid"
                    ? $"            return new {responseClassName} {{ Id = Guid.Empty, Message = \"{message}\" }};"
                    : $"            return new {responseClassName} {{ Id = ({returnType}) 0, Message = \"{message}\" }};";

                code.AppendLine(returnStatement);
                code.AppendLine("        }");
                code.AppendLine("    }");
                code.AppendLine("}");
                //}

                //FormBased Save Method
                foreach (var formItem in FormList)
                {

                    code.AppendLine($"      public async Task<{responseClassName}> Save{formItem.Name}({modelName}Model {modelName.ToLower()})");
                    code.AppendLine("{");
                    code.AppendLine("    // Check if the asset ID is 0 (i.e., the asset is new)");
                    string condition = pkType.ToUpper() != PKTypeEnum.UniqueIdentifier.ToString().ToUpper()
                         ? $"{modelName.ToLower()}.ID == 0"
                         : $"{modelName.ToLower()}.ID == Guid.Empty";

                    code.AppendLine($"    if ({condition})");
                    code.AppendLine("    {");
                    code.AppendLine($"        return await Create{modelName}({modelName.ToLower()});  // Assuming CreateAssets returns a Task<{responseClassName}>");
                    code.AppendLine("    }");
                    code.AppendLine("    else");
                    code.AppendLine("    {");
                    code.AppendLine($"        return await Update{modelName}({modelName.ToLower()});  // Assuming UpdateAssets returns a Task<CreationResponse>");
                    code.AppendLine("    }");
                    code.AppendLine("}");
                    //}
                }

                if (FormList.Any(x => x.IsAddToList == true))
                {
                    // AddSitesToList
                    //code.AppendLine($"public async Task<string> Add{modelName}sToList(List<int> {modelName.ToLower()}Ids)");
                    //code.AppendLine("{");
                    //code.AppendLine($"    if ({modelName.ToLower()}Ids == null || {modelName.ToLower()}Ids.Count == 0)");
                    //code.AppendLine($"        return \"No {modelName.ToLower()}s provided to add to list\";");
                    //code.AppendLine("");
                    //code.AppendLine("    try");
                    //code.AppendLine("    {");
                    //code.AppendLine("        using var connection = _context.CreateConnection();");
                    //code.AppendLine("");
                    //code.AppendLine($"        const string query = @\"INSERT INTO {modelName}List ({modelName}ID, SelectedDate) ");
                    //code.AppendLine($"                        VALUES (@{modelName}ID, GETDATE())\";");
                    //code.AppendLine("");
                    //code.AppendLine($"        var rows = await connection.ExecuteAsync(query, {modelName.ToLower()}Ids.Select(id => new {{ {modelName}ID = id }}));");
                    //code.AppendLine("");
                    //code.AppendLine("        return rows > 0");
                    //code.AppendLine($"            ? $\"{{rows}} {modelName.ToLower()}s added to list successfully\"");
                    //code.AppendLine($"            : \"Failed to add {modelName.ToLower()}s to list\";");
                    //code.AppendLine("    }");
                    //code.AppendLine("    catch (Exception ex)");
                    //code.AppendLine("    {");
                    //code.AppendLine("        return $\"Error: {ex.Message}\";");
                    //code.AppendLine("    }");
                    //code.AppendLine("}");
                    code.AppendLine($"public async Task<string> Add{modelName}sToList(List<int> {modelName.ToLower()}Ids)");
                    code.AppendLine("{");
                    code.AppendLine($"    if ({modelName.ToLower()}Ids == null || {modelName.ToLower()}Ids.Count == 0)");
                    code.AppendLine($"        return \"No Items provided to add to list\";");
                    code.AppendLine();
                    code.AppendLine("    try");
                    code.AppendLine("    {");
                    code.AppendLine("        using var connection = _context.CreateConnection();");
                    code.AppendLine();
                    code.AppendLine($"        var existingIds = (await connection.QueryAsync<int>(");
                    code.AppendLine($"            \"SELECT {modelName}ID FROM {modelName}List WHERE {modelName}ID IN @Ids\",");
                    code.AppendLine($"            new {{ Ids = {modelName.ToLower()}Ids }}");
                    code.AppendLine("        )).ToHashSet();");
                    code.AppendLine();
                    code.AppendLine($"        var newIds = {modelName.ToLower()}Ids.Where(id => !existingIds.Contains(id)).ToList();");
                    code.AppendLine();
                    code.AppendLine("        if (newIds.Count == 0)");
                    code.AppendLine("            return \"Items already exist in the list\";");
                    code.AppendLine();
                    code.AppendLine($"        const string query = @\"INSERT INTO {modelName}List ({modelName}ID, CreatedDate) ");
                    code.AppendLine($"                           VALUES (@{modelName}ID, GETDATE())\";");
                    code.AppendLine();
                    code.AppendLine($"        var rows = await connection.ExecuteAsync(query, newIds.Select(id => new {{ {modelName}ID = id }}));");
                    code.AppendLine();
                    code.AppendLine("        return $\"{rows} Items added successfully\";");
                    code.AppendLine("    }");
                    code.AppendLine("    catch (Exception ex)");
                    code.AppendLine("    {");
                    code.AppendLine("        return $\"Error: {ex.Message}\";");
                    code.AppendLine("    }");
                    code.AppendLine("}");


                    // GetSelectedSites
                    code.AppendLine("");
                    code.AppendLine($"public async Task<List<{modelName}Model>> GetSelected{modelName}s()");
                    code.AppendLine("{");
                    code.AppendLine("    try");
                    code.AppendLine("    {");
                    code.AppendLine("        string query = @\"");
                    code.AppendLine($"          SELECT m.*");
                    code.AppendLine($"          FROM {modelName} m");
                    code.AppendLine($"          INNER JOIN {modelName}List ml ON m.ID = ml.{modelName}ID");
                    code.AppendLine("           ORDER BY ml.CreatedDate DESC\";");

                    code.AppendLine("");
                    code.AppendLine("        using (var connection = _context.CreateConnection())");
                    code.AppendLine("        {");
                    code.AppendLine($"            var result = await connection.QueryAsync<{modelName}Model>(query);");
                    code.AppendLine("");
                    code.AppendLine("            // Apply timezone conversion if needed");
                    code.AppendLine($"            foreach (var {modelName.ToLower()} in result)");
                    code.AppendLine("            {");
                    code.AppendLine("                var timeZone = TimeZoneInfo.Local;");
                    code.AppendLine($"                foreach (var prop in typeof({modelName}Model).GetProperties())");
                    code.AppendLine("                {");
                    code.AppendLine("                    if (prop.PropertyType == typeof(DateTime))");
                    code.AppendLine("                    {");
                    code.AppendLine($"                        var value = (DateTime)prop.GetValue({modelName.ToLower()});");
                    code.AppendLine("                        if (value.Kind == DateTimeKind.Utc || value.Kind == DateTimeKind.Unspecified)");
                    code.AppendLine("                        {");
                    code.AppendLine("                            var local = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(value, DateTimeKind.Utc), timeZone);");
                    code.AppendLine($"                            prop.SetValue({modelName.ToLower()}, local);");
                    code.AppendLine("                        }");
                    code.AppendLine("                    }");
                    code.AppendLine("                    else if (prop.PropertyType == typeof(DateTime?))");
                    code.AppendLine("                    {");
                    code.AppendLine($"                        var value = (DateTime?)prop.GetValue({modelName.ToLower()});");
                    code.AppendLine("                        if (value.HasValue)");
                    code.AppendLine("                        {");
                    code.AppendLine("                            var dt = DateTime.SpecifyKind(value.Value, DateTimeKind.Utc);");
                    code.AppendLine("                            var local = TimeZoneInfo.ConvertTimeFromUtc(dt, timeZone);");
                    code.AppendLine($"                            prop.SetValue({modelName.ToLower()}, local);");
                    code.AppendLine("                        }");
                    code.AppendLine("                    }");
                    code.AppendLine("                }");
                    code.AppendLine("            }");
                    code.AppendLine("");
                    code.AppendLine("            return result.ToList();");
                    code.AppendLine("        }");
                    code.AppendLine("    }");
                    code.AppendLine("    catch (Exception)");
                    code.AppendLine("    {");
                    code.AppendLine($"        return new List<{modelName}Model>();");
                    code.AppendLine("    }");
                    code.AppendLine("}");

                    // ClearList
                    code.AppendLine("");
                    code.AppendLine("public async Task<string> ClearList()");
                    code.AppendLine("{");
                    code.AppendLine("    try");
                    code.AppendLine("    {");
                    code.AppendLine($"        string query = \"  delete from {modelName}List\";");
                    code.AppendLine("");
                    code.AppendLine("        using (var connection = _context.CreateConnection())");
                    code.AppendLine("        {");
                    code.AppendLine("            var result = await connection.ExecuteAsync(query);");
                    code.AppendLine("");
                    code.AppendLine("            return $\"List cleared successfully. {result} items removed.\";");
                    code.AppendLine("        }");
                    code.AppendLine("    }");
                    code.AppendLine("    catch (Exception ex)");
                    code.AppendLine("    {");
                    code.AppendLine("        return $\"Error clearing list: {ex.Message}\";");
                    code.AppendLine("    }");
                    code.AppendLine("}");

                }

                //// --- ValidateRules Method ---

                //code.AppendLine($"public async Task<string> ValidateRules" + $"({modelName} {modelName.ToLower()})");
                //code.AppendLine("{");
                //code.AppendLine("    var rules = new List<RuleCriteria>();");

                //var allRule = new StringBuilder();

                //foreach (var rule in RuleList)
                //{
                //    allRule.AppendLine($"   if ({modelName.ToLower()}.FormId == {rule.FormId})");
                //    allRule.AppendLine("    {");
                //    allRule.AppendLine("    rules.Add(new RuleCriteria");
                //    allRule.AppendLine("    {");

                //    allRule.AppendLine($"            RuleId = {rule.
                //    allRule.AppendLine($"            FieldName = \"{rule.FieldName}\",");
                //    allRule.AppendLine($"            FieldValue = \"{rule.FieldValue}\",");
                //    allRule.AppendLine($"            Operator = \"{rule.Operator}\",");
                //    allRule.AppendLine($"            FailMessage = \"{rule.FailMessage}\"");
                //    allRule.AppendLine("        });");
                //    allRule.AppendLine("        }");

                //    //code.AppendLine($"            RuleId = {rule.RuleId},");
                //    //code.AppendLine($"            ConditionalId = {(rule.ConditionalId.HasValue ? rule.ConditionalId.Value.ToString() : "0")},");
                //    //code.AppendLine($"            FieldName = \"{rule.FieldName}\",");
                //    //code.AppendLine($"            FieldValue = \"{rule.FieldValue}\",");
                //    //code.AppendLine($"            Operator = \"{rule.Operator}\",");
                //    //code.AppendLine($"            FailMessage = \"{rule.FailMessage}\"");
                //    //code.AppendLine("        },");
                //}

                //code.AppendLine(allRule.ToString());
                ////code.AppendLine("    };");
                //code.AppendLine();
                //code.AppendLine($"    return CheckRuleCriteria(rules, {modelName.ToLower()});");
                //code.AppendLine("}");
                //code.AppendLine();


                //code.AppendLine($"private string CheckRuleCriteria(List<RuleCriteria> rules, {modelName} {modelName.ToLower()})");
                //code.AppendLine("{");
                //code.AppendLine("    var errors = new List<string>();");
                //code.AppendLine("    var passedRuleIds = new HashSet<int>();");
                //code.AppendLine();
                //code.AppendLine("    foreach (var rule in rules)");
                //code.AppendLine("    {");
                //code.AppendLine("        // Only run if no dependency or parent passed");
                //code.AppendLine("        if (rule.ConditionalId > 0 && !passedRuleIds.Contains(rule.ConditionalId))");
                //code.AppendLine("            continue;");
                //code.AppendLine();
                //code.AppendLine($"        var property = typeof({modelName}).GetProperty(rule.FieldName?.Trim());");
                //code.AppendLine("        if (property == null) continue;");
                //code.AppendLine();
                //code.AppendLine($"        var userValue = property.GetValue({modelName.ToLower()})?.ToString() ?? string.Empty;");
                //code.AppendLine("        var ruleValue = rule.FieldValue ?? string.Empty;");
                //code.AppendLine();
                //code.AppendLine("        bool isValid = rule.Operator?.Trim().ToUpperInvariant() switch");
                //code.AppendLine("        {");
                //code.AppendLine("            \"=\" => userValue == ruleValue,");
                //code.AppendLine("            \"!=\" => userValue != ruleValue,");
                //code.AppendLine("            \">\" => CompareInts(userValue, ruleValue, (a, b) => a > b),");
                //code.AppendLine("            \"<\" => CompareInts(userValue, ruleValue, (a, b) => a < b),");
                //code.AppendLine("            \">=\" => CompareInts(userValue, ruleValue, (a, b) => a >= b),");
                //code.AppendLine("            \"<=\" => CompareInts(userValue, ruleValue, (a, b) => a <= b),");
                //code.AppendLine("            \"CONTAINS\" => userValue.Contains(ruleValue, StringComparison.OrdinalIgnoreCase),");
                //code.AppendLine("            _ => true");
                //code.AppendLine("        };");
                //code.AppendLine();
                //code.AppendLine("        if (isValid)");
                //code.AppendLine("        {");
                //code.AppendLine("            passedRuleIds.Add(rule.RuleId); // Mark rule as passed");
                //code.AppendLine("        }");
                //code.AppendLine("        else");
                //code.AppendLine("        {");
                //code.AppendLine("            errors.Add(rule.FailMessage);   // Track error");
                //code.AppendLine("        }");
                //code.AppendLine("    }");
                //code.AppendLine();
                //code.AppendLine("    return errors.Any() ? string.Join(\", \", errors) : \"Validation passed\";");
                //code.AppendLine("}");
                //code.AppendLine();


                ////CompareInts
                //code.AppendLine("private static bool CompareInts(string a, string b, Func<int, int, bool> comparison) =>");
                //code.AppendLine("    int.TryParse(a, out var aVal) && int.TryParse(b, out var bVal) && comparison(aVal, bVal);");


                //////ApplyFormActions
                //code.AppendLine("public async Task<string> ApplyFormActions(int id, int? FormId)");
                //code.AppendLine("{");

                //code.AppendLine("    var sb = new StringBuilder();  // StringBuilder to build the response");

                //code.AppendLine("    using (var connection = _context.CreateConnection())");
                //code.AppendLine("    {");
                //code.AppendLine("        object parameters = new { Id = id };");




                ////foreach(var formItem in formActionList)
                ////{
                ////    code.AppendLine("        if (FormId == " + formItem.FormId + ")");
                ////    code.AppendLine("        {");
                ////    code.AppendLine("");
                ////    code.AppendLine("        // Execute the action-specific update query");
                ////    code.AppendLine($"        var updateResult = await connection.ExecuteAsync( \"{formItem.FormActionQuery}\", parameters);");

                ////    code.AppendLine("");
                ////    code.AppendLine("        if (updateResult == 0)");
                ////    code.AppendLine("        {");
                ////    code.AppendLine("            sb.AppendLine(\"Failed to apply action to the new user.\");");
                ////    code.AppendLine("            return sb.ToString();  // Return the formatted message");
                ////    code.AppendLine("        }");
                ////    code.AppendLine("        }");
                ////}

                //code.AppendLine("    }");

                //code.AppendLine("");
                //code.AppendLine("    sb.AppendLine(\"Actions applied successfully.\");");
                //code.AppendLine("    return sb.ToString();  // Return the formatted success message");

                //code.AppendLine("}");

                //await _addEditField.GetFormUpdateQueries(addEditField.FormId, item.Name, originalConnectionString);

                //code.AppendLine();
                //code.AppendLine("        // Step 3: Apply each action to the newly created AppUser");
                //code.AppendLine("        foreach (var action in actions)");
                //code.AppendLine("        {");
                //code.AppendLine("            string updateQuery = \"\";");
                //code.AppendLine("            object parameters = null;");
                //code.AppendLine();
                //code.AppendLine("            // Determine which action to apply based on the ActionID");
                //code.AppendLine("            switch (action.ActionID)");
                //code.AppendLine("            {");

                //code.AppendLine("                case 2: // Set Value");
                //code.AppendLine($"                    updateQuery = \"UPDATE {modelName} SET \" + action.Name + \" = @Value WHERE Id = @UserId\";");
                //code.AppendLine("                    parameters = new { Value = action.Value, UserId = newUserId };");
                //code.AppendLine("                    break;");

                //code.AppendLine();

                //code.AppendLine("                case 3: // Clear Field");
                //code.AppendLine($"                    updateQuery = \"UPDATE {modelName} SET \" + action.Name + \" = NULL WHERE Id = @UserId\";");
                //code.AppendLine("                    parameters = new { UserId = newUserId };");
                //code.AppendLine("                    break;");
                //code.AppendLine();

                //code.AppendLine("                case 4: // Autofill (custom autofill logic)");
                //code.AppendLine("                    string autofilledValue = \"Autofilled value\"; // Example autofill logic");
                //code.AppendLine($"                    updateQuery = \"UPDATE {modelName} SET \" + action.Name + \" = @Value WHERE Id = @UserId\";");
                //code.AppendLine("                    parameters = new { Value = autofilledValue, UserId = newUserId };");
                //code.AppendLine("                    break;");
                //code.AppendLine();
                //code.AppendLine("                case 5: // Set Default Selection");
                //code.AppendLine($"                    updateQuery = \"UPDATE {modelName} SET \" + action.Name + \" = @Value WHERE Id = @UserId\";");
                //code.AppendLine("                    parameters = new { Value = action.Value, UserId = newUserId };");
                //code.AppendLine("                    break;");
                //code.AppendLine();
                //code.AppendLine("                case 6: // Reset Form (Reset fields, setting all values to NULL for this user)");
                //code.AppendLine($"                    updateQuery = \"UPDATE {modelName} SET \" + action.Name + \" = NULL WHERE Id = @UserId\";");
                //code.AppendLine("                    parameters = new { UserId = newUserId };");
                //code.AppendLine("                    break;");
                //code.AppendLine();

                //code.AppendLine("                default:");
                //code.AppendLine("                    return \"Unsupported action type encountered: \" + action.Name;");
                //code.AppendLine("            }");
                //code.AppendLine();
                //code.AppendLine("            // Execute the action-specific update query");
                //code.AppendLine("            var updateResult = await connection.ExecuteAsync(updateQuery, parameters);");
                //code.AppendLine();
                //code.AppendLine("            if (updateResult == 0)");
                //code.AppendLine("            {");
                //code.AppendLine("                return \"Failed to apply action to the new user.\";");
                //code.AppendLine("            }");
                //code.AppendLine("        }");
                //code.AppendLine();
                //code.AppendLine("        return \"Actions applied successfully.\";");
                //code.AppendLine("    }");




                // Delete Method
                code.AppendLine($"        public async Task<string> Delete{modelName}({returnType} {modelName.ToLower()})");
                code.AppendLine("        {");
                code.AppendLine($"           string query = \"{deletequery}\";");
                code.AppendLine();
                code.AppendLine("            using (var connection = _context.CreateConnection())");
                code.AppendLine("            {");
                code.AppendLine($"               var result = await connection.ExecuteAsync(query, new {{ Id = {modelName.ToLower()} }});");
                code.AppendLine("                if (result > 0)");
                code.AppendLine("                {");
                code.AppendLine($"                    return \"{modelName} deleted successfully.\";");
                code.AppendLine("                }");
                code.AppendLine("                else");
                code.AppendLine("                {");
                code.AppendLine($"                    return \"{modelName} not found or could not be deleted.\";");
                code.AppendLine("                }");
                code.AppendLine("            }");
                code.AppendLine("        }");

                //Get Checkboxgroup Reference 
       
                var checkBoxGroupFields = AddEditDetailsFields
                .Where(f => f.IsUsedAsSource == true
                         && !string.IsNullOrEmpty(f.MappedFieldTypeName)
                         && f.MappedFieldTypeName.Equals(FieldTypeEnums.Checkboxgroup.ToString(), StringComparison.OrdinalIgnoreCase))
                .ToList();

                if (checkBoxGroupFields.Any())
                {
                    var primaryField = checkBoxGroupFields.First();

                    code.AppendLine($"private async Task<IEnumerable<{primaryField.TableName}ReferenceResponse>> Get{primaryField.TableName}CheckBoxReferencesAsync({returnType} {primaryField.TableName.ToLower()}Id)");
                    code.AppendLine("{");
                    code.AppendLine("    using var connection = _context.CreateConnection();");
                    code.AppendLine();
                    code.AppendLine($"    var response = new {primaryField.TableName}ReferenceResponse()");
                    code.AppendLine("    {");
                    code.AppendLine($"        {primaryField.TableName}Id = {primaryField.TableName.ToLower()}Id,");
                    code.AppendLine("        ChildTableNames = new List<string>(),");
                    code.AppendLine("        NamesByTable = new Dictionary<string, List<string>>(),");
                    code.AppendLine("        MoreCountByTable = new Dictionary<string, int>()");
                    code.AppendLine("    };");
                    code.AppendLine();
                    code.AppendLine("    // ✅ All checkbox relationships in one list (including ChildField)");
                    code.AppendLine("    var checkBoxGroupMappings = new List<(string JunctionTable, string ParentTable, string ChildTable, string ParentField, string ChildField, string FormName)>");
                    code.AppendLine("    {");

                    //  Dynamically build mappings
                    foreach (var field in checkBoxGroupFields)
                    {
                        string mapTable = field.MappedTableName ?? field.SourceTableName;
                        string mapField = field.MappedFieldName ?? field.Name;
                  
                        var childForm = FormList.FirstOrDefault(f =>
                            (!string.IsNullOrEmpty(f.DetailFormName) &&
                             f.DetailFormName.Trim().ToLower().Contains(mapTable.Trim().ToLower())) ||
                            (!string.IsNullOrEmpty(f.Name) &&
                             f.Name.Trim().ToLower().Contains(mapTable.Trim().ToLower())));

                        var childFormName = childForm?.DetailFormName ?? $"{mapTable}MasterForm";

                        //  Add mapping line with ChildField
                        code.AppendLine($"        (\"{mapTable}_{mapField}\", \"{modelName}\", \"{mapTable}\", \"{field.Name}\", \"{mapTable}ID\", \"{childFormName}\"),");
                    }

                    code.AppendLine("    };");
                    code.AppendLine();
                    code.AppendLine("    foreach (var map in checkBoxGroupMappings)");
                    code.AppendLine("    {");
                    code.AppendLine("        var sql = $@\"");
                    code.AppendLine("        SELECT ");
                    code.AppendLine("            PT.{map.ParentField} AS FieldDisplayName,");
                    code.AppendLine("            '{map.FormName}' AS FormName");
                    code.AppendLine("        FROM {map.JunctionTable} CMT");
                    code.AppendLine("        INNER JOIN {map.ChildTable} CT ON CT.ID = CMT.{map.ChildField}");
                    code.AppendLine("        INNER JOIN {map.ParentTable} PT ON PT.ID = CMT.{map.ParentTable}ID");
                    code.AppendLine($"        WHERE CMT.{{map.ParentTable}}ID = @{primaryField.TableName.ToLower()}Id\";");
                    code.AppendLine();
                    code.AppendLine($"        var controlRefs = (await connection.QueryAsync<(string FieldDisplayName, string FormName)>(");
                    code.AppendLine($"            sql, new {{ {primaryField.TableName.ToLower()}Id }})).ToList();");
                    code.AppendLine();
                    code.AppendLine("        if (controlRefs.Any())");
                    code.AppendLine("        {");
                    code.AppendLine("            response.HasChildReferences = true;");
                    code.AppendLine();
                    code.AppendLine("            if (!response.ChildTableNames.Contains(map.FormName))");
                    code.AppendLine("                response.ChildTableNames.Add(map.FormName);");
                    code.AppendLine();
                    code.AppendLine("            if (!response.NamesByTable.ContainsKey(map.FormName))");
                    code.AppendLine("                response.NamesByTable[map.FormName] = new List<string>();");
                    code.AppendLine();
                    code.AppendLine("            response.NamesByTable[map.FormName].AddRange(controlRefs.Select(c => c.FieldDisplayName));");
                    code.AppendLine();
                    code.AppendLine("            var allFields = response.NamesByTable[map.FormName].Distinct().ToList();");
                    code.AppendLine("            if (allFields.Count > 3)");
                    code.AppendLine("            {");
                    code.AppendLine("                int remaining = allFields.Count - 3;");
                    code.AppendLine("                response.MoreCountByTable[map.FormName] = remaining;");
                    code.AppendLine("                allFields = allFields.Take(3).Append($\"+{remaining} more...\").ToList();");
                    code.AppendLine("            }");
                    code.AppendLine("            response.NamesByTable[map.FormName] = allFields;");
                    code.AppendLine("        }");
                    code.AppendLine("    }");
                    code.AppendLine();
                    code.AppendLine($"    return new List<{primaryField.TableName}ReferenceResponse> {{ response }};");
                    code.AppendLine("}");
                }

                //Get Document Reference                
                var clientForm = FormList
                .FirstOrDefault(f => f.Name?.IndexOf(modelName, StringComparison.OrdinalIgnoreCase) >= 0);

                if (clientForm != null && clientForm.IsDocumentEnabled)
                {                    
                    code.AppendLine($"private async Task<IEnumerable<{modelName}ReferenceResponse>> Get{modelName}DocumentReferencesAsync({returnType} {modelName.ToLower()}Id)");
                    code.AppendLine("{");
                    code.AppendLine("    using var connection = _context.CreateConnection();");
                    code.AppendLine("");                    
                    code.AppendLine($"    var response = new {modelName}ReferenceResponse()");
                    code.AppendLine("    {");
                    code.AppendLine($"       {modelName}Id = {modelName.ToLower()}Id,");
                    code.AppendLine("        ChildTableNames = new List<string>(),");
                    code.AppendLine("        NamesByTable = new Dictionary<string, List<string>>(),");
                    code.AppendLine("        DocumentName = new List<string>()");
                    code.AppendLine("    };");
                    code.AppendLine("");                    
              
                    var mapTable = clientForm.Name + "Document";
                    var mapfield = clientForm.Name;
                        
                    code.AppendLine($"    var documentRefs = (await connection.QueryAsync<string>(@\"SELECT D.Name");
                    code.AppendLine($"FROM {mapTable} CMFD");
                    code.AppendLine("INNER JOIN Documents D ON D.Id = CMFD.DocumentID");
                    code.AppendLine($"WHERE CMFD.{mapfield}Id = @{modelName.ToLower()}Id\", new {{ {modelName.ToLower()}Id }})).ToList();");
                    code.AppendLine("");

                    // Add to response if any documents found
                    code.AppendLine("    if (documentRefs.Any())");
                    code.AppendLine("    {");
                    code.AppendLine("        response.HasChildReferences = true;");
                    code.AppendLine($"        response.ChildTableNames.Add(\"{mapTable}\");");
                    code.AppendLine("             var visibleDocs = documentRefs.Take(3).ToList();");
                    code.AppendLine("             int remainingDocs = documentRefs.Count - visibleDocs.Count;");
                    code.AppendLine("             if (remainingDocs > 0)");
                    code.AppendLine("             {");
                    code.AppendLine("                visibleDocs.Add($\"+{remainingDocs} more...\");");
                    code.AppendLine($"                response.MoreCountByTable[\"{mapTable}\"] = remainingDocs;");
                    code.AppendLine("             }");
                    code.AppendLine("        response.DocumentName = visibleDocs;");
                    code.AppendLine("    }");                         
                    code.AppendLine("");
                    // Return response as list
                    code.AppendLine($"    return new List<{modelName}ReferenceResponse> {{ response }};");
                    code.AppendLine("}");
                }
                else
                {
                    code.AppendLine($"// Document references not generated for {modelName} because form not found or IsDocumentEnabled=false");
                }

                //parentchild reference
                bool isParent = !string.IsNullOrEmpty(table.ChildTableNames);

                // Assign parent reference only if it is a parent
                var parentchildReference = isParent ? table : null;

                if (isParent)
                {
                    var childForm = FormList.FirstOrDefault(f => (!string.IsNullOrEmpty(f.DetailFormName) && f.DetailFormName.Trim().ToLower().Contains(modelName.Trim().ToLower())) || (!string.IsNullOrEmpty(f.Name) && f.Name.Trim().ToLower().Contains(modelName.Trim().ToLower())));

                    var childFormName = childForm?.DetailFormName;

                    code.AppendLine($"private async Task<IEnumerable<{table.Name}ReferenceResponse>> Get{table.Name}ParentChildReferencesAsync({returnType} {table.Name.ToLower()}Id,bool showAll = false) ");
                    code.AppendLine("{");
                    code.AppendLine("    using var connection = _context.CreateConnection();");
                    code.AppendLine("");
                    code.AppendLine($"    var response = new {modelName}ReferenceResponse()");
                    code.AppendLine("     {");
                    code.AppendLine($"       ParentId = {table.Name.ToLower()}Id,");
                    code.AppendLine("        ChildTableNames = new List<string>(),");
                    code.AppendLine("        NamesByTable = new Dictionary<string, List<string>>(),");
                    code.AppendLine("        MoreCountByTable = new Dictionary<string, int>(),");
                    code.AppendLine("     };");                    
                    // Split child tables
                    var childTables = table.ChildTableNames?
                        .Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(c => c.Trim().ToLower())
                        .Distinct()
                        .ToList() ?? new List<string>();

                    // Find all matching forms where TableName matches any child table
                    var matchingChildForms = Forms
                        .Where(f => !string.IsNullOrEmpty(f.TableName) &&
                                    childTables.Contains(f.TableName.Trim().ToLower()))
                        .ToList();

                    code.AppendLine("       var childTableMappings = new List<(string TableName, string ForeignKey, string FormName)>");
                    code.AppendLine("       {");

                    foreach (var child in childTables)
                    {
                        //  Find matching form for this specific child
                        var form = matchingChildForms.FirstOrDefault(f =>
                            f.TableName.Equals(child, StringComparison.OrdinalIgnoreCase));

                        //  Use that form’s DetailFormName, or fallback to pattern
                        var formName = form?.DisplayName;

                        code.AppendLine($"    (\"{child}\", \"{table.Name.ToLower()}Id\", \"{formName}\"),");
                    }

                    code.AppendLine("        };");
                    code.AppendLine("        foreach (var child in childTableMappings)");
                    code.AppendLine("        {");
                    code.AppendLine("           string sampleSql = $\"SELECT TOP 1 * FROM [{child.TableName}]\";");
                    code.AppendLine("           var sampleRow = await connection.QueryFirstOrDefaultAsync(sampleSql);");
                    code.AppendLine("           if (sampleRow == null)");
                    code.AppendLine("               continue; ");
                    code.AppendLine("            var dict = (IDictionary<string, object>)sampleRow;");
                    code.AppendLine("            var allColumns = dict.Keys.ToList();");
                    code.AppendLine("            var displayColumn = allColumns.FirstOrDefault(c => !c.Equals(\"ID\", StringComparison.OrdinalIgnoreCase) && !c.Equals(child.ForeignKey, StringComparison.OrdinalIgnoreCase) && !c.Contains(\"Created\", StringComparison.OrdinalIgnoreCase) && !c.Contains(\"Modified\", StringComparison.OrdinalIgnoreCase)) ?? allColumns.First();");
                    code.AppendLine("            string sql = $@\" SELECT {(showAll ? \"\" : \"TOP 10\")} TRY_CAST([{displayColumn}] AS NVARCHAR(MAX)) AS DisplayValue FROM [{child.TableName}] WHERE [{child.ForeignKey}] = @ParentId AND [{displayColumn}] IS NOT NULL\";");

                    code.AppendLine($"           var records = (await connection.QueryAsync<string>(sql, new {{ ParentId = {table.Name.ToLower()}Id }})).ToList();");
                    code.AppendLine("            if (records.Any())");
                    code.AppendLine("            {");
                    code.AppendLine("               response.HasChildReferences = true;");
                    code.AppendLine("               response.ChildTableNames.Add(child.FormName);");
                    code.AppendLine("                var visible = records.Take(3).ToList();");
                    code.AppendLine("               int remaining = records.Count - visible.Count;");
                    code.AppendLine("               if (remaining > 0)");
                    code.AppendLine("               {");
                    code.AppendLine("                  visible.Add($\"+{remaining} more...\");");
                    code.AppendLine("                   response.MoreCountByTable[child.FormName] = remaining;");
                    code.AppendLine("               }");
                    code.AppendLine("               response.NamesByTable[child.FormName] = visible;");
                    code.AppendLine("           }");
                    code.AppendLine("        }");
                    code.AppendLine($"         return new List<{table.Name}ReferenceResponse> {{ response }};");
                    code.AppendLine("      }");
                }
                // Check if this table is a parent           
                code.AppendLine($"public async Task<IEnumerable<{table.Name}ReferenceResponse>> Get{table.Name}ReferencesAsync({returnType} {table.Name.ToLower()}Id)");
                code.AppendLine("{");
                code.AppendLine($"    var allResponses = new List<{table.Name}ReferenceResponse>();");
                code.AppendLine("");
               
                if (checkBoxGroupFields.Any())
                {
                    var firstCheckBoxField = checkBoxGroupFields.First();
                    code.AppendLine($"    var checkboxResponses = await Get{firstCheckBoxField.TableName}CheckBoxReferencesAsync({table.Name.ToLower()}Id);");
                    code.AppendLine("     if (checkboxResponses != null && checkboxResponses.Any())");
                    code.AppendLine("     allResponses.AddRange(checkboxResponses);");
                    code.AppendLine("");
                }

                var clientFormUse = FormList.FirstOrDefault(f => f.Name?.IndexOf(modelName, StringComparison.OrdinalIgnoreCase) >= 0);
                if (clientFormUse != null && clientForm.IsDocumentEnabled)
                {
                    code.AppendLine($"    var documentResponses = await Get{table.Name}DocumentReferencesAsync({table.Name.ToLower()}Id);");
                    code.AppendLine("     if (documentResponses != null && documentResponses.Any())");
                    code.AppendLine("     allResponses.AddRange(documentResponses);");
                    code.AppendLine("");
                }
                if (isParent)
                {
                    code.AppendLine($"    var ParentchildReference = await  Get{table.Name}ParentChildReferencesAsync({table.Name.ToLower()}Id);");
                    code.AppendLine("     if (ParentchildReference != null && ParentchildReference.Any())");
                    code.AppendLine("     allResponses.AddRange(ParentchildReference);");
                    code.AppendLine("");
                }
                code.AppendLine("    return allResponses;");
                code.AppendLine("}");

                if (table.IsHierarchical)
                {
                    code.AppendLine($"        public async Task<List<{modelName}Model>> GetHierarchyAsync()");
                    code.AppendLine("        {");
                    code.AppendLine($"            string query = \"SELECT * FROM [{table.Name}]\";");
                    code.AppendLine();
                    code.AppendLine("            using (var connection = _context.CreateConnection())");
                    code.AppendLine("            {");
                    code.AppendLine($"                var allItems = (await connection.QueryAsync<{modelName}Model>(query)).ToList();");
                    code.AppendLine($"                var lookup = allItems.ToDictionary(x => x.ID);");
                    code.AppendLine($"                var roots = new List<{modelName}Model>();");
                    code.AppendLine();
                    code.AppendLine("                foreach (var item in allItems)");
                    code.AppendLine("                {");
                    code.AppendLine("                    if (item.ParentID != null && lookup.ContainsKey(item.ParentID.Value))");
                    code.AppendLine("                    {");
                    code.AppendLine("                        var parent = lookup[item.ParentID.Value];");
                    code.AppendLine($"                        parent.items ??= new List<{modelName}Model>();");
                    code.AppendLine("                        parent.items.Add(item);");
                    code.AppendLine("                    }");
                    code.AppendLine("                    else");
                    code.AppendLine("                    {");
                    code.AppendLine("                        roots.Add(item);");
                    code.AppendLine("                    }");
                    code.AppendLine("                }");
                    code.AppendLine();
                    code.AppendLine("                return roots;");
                    code.AppendLine("            }");
                    code.AppendLine("        }");

                    code.AppendLine($" public async Task<string> RemoveChild{modelName}({returnType} {modelName}Id)");
                    code.AppendLine(" {");
                    code.AppendLine("     using (var connection = _context.CreateConnection())");
                    code.AppendLine("     {");
                    code.AppendLine($"         string checkChildrenQuery = \"SELECT COUNT(*) FROM {modelName} WHERE parentID = @Id\";");
                    code.AppendLine($"         var childCount = await connection.ExecuteScalarAsync<int>(checkChildrenQuery, new {{ Id = {modelName}Id }});");
                    code.AppendLine("");
                    code.AppendLine("         if (childCount > 0)");
                    code.AppendLine("         {");
                    code.AppendLine("             return \"Cannot remove a node that has children.\";");
                    code.AppendLine("         }");
                    code.AppendLine("");
                    code.AppendLine($"         string query = \"UPDATE {modelName} SET parentID = NULL WHERE ID = @Id\";");
                    code.AppendLine($"         var result = await connection.ExecuteAsync(query, new {{ Id = {modelName}Id }});");
                    code.AppendLine("         if (result > 0)");
                    code.AppendLine("         {");
                    code.AppendLine("             return \"Child removed successfully..\";");
                    code.AppendLine("         }");
                    code.AppendLine("         else");
                    code.AppendLine("         {");
                    code.AppendLine($"             return \"{modelName} not found or could not be updated.\";");
                    code.AppendLine("         }");
                    code.AppendLine("     }");
                    code.AppendLine(" }");
                }

                //EmailTemplate method 

                //code.AppendLine("public async Task<string> GetEmailBodyByTemplateName(string templateName)");
                //code.AppendLine("{");
                //code.AppendLine("    string sql = \"SELECT Body FROM EmailTemplate WHERE [Name] = '{templateName}'\";");
                //code.AppendLine("    using (var connection = _context.CreateConnection())");
                //code.AppendLine("    {");
                //code.AppendLine("        var result = await connection.QueryFirstOrDefaultAsync<string>(sql, new { Name = templateName });");
                //code.AppendLine("        return result;");
                //code.AppendLine("    }");
                //code.AppendLine("}");


                //EmailAction  RELETED METHOD 

                code.AppendLine("public async Task<string> GetEmailBodyByTemplateId(int templateId)");
                code.AppendLine("{");
                code.AppendLine("    string sql = \"SELECT Body FROM EmailTemplate WHERE [Id] = @Id\";");
                code.AppendLine("    using (var connection = _context.CreateConnection())");
                code.AppendLine("    {");
                code.AppendLine("        var result = await connection.QueryFirstOrDefaultAsync<string>(sql, new { Id = templateId });");
                code.AppendLine("        return result;");
                code.AppendLine("    }");
                code.AppendLine("}");

                code.AppendLine("public async Task<string> GetAllEmailsByRole(string roleIds)");
                code.AppendLine("{");
                code.AppendLine("    string sql = @\"");
                code.AppendLine("        SELECT STRING_AGG(Email, ',') AS Emails");
                code.AppendLine("        FROM AppUser");
                code.AppendLine("        WHERE RoleId IN (");
                code.AppendLine("            SELECT TRY_CAST(value AS INT)");
                code.AppendLine("            FROM STRING_SPLIT(@EmailRoleId, ',')");
                code.AppendLine("        );\";");
                code.AppendLine("");
                code.AppendLine("    using (var connection = _context.CreateConnection())");
                code.AppendLine("    {");
                code.AppendLine("        var result = await connection.QueryFirstOrDefaultAsync<string>(");
                code.AppendLine("            sql, ");
                code.AppendLine("            new { EmailRoleId = roleIds }");
                code.AppendLine("        );");
                code.AppendLine("        return result ?? string.Empty;");
                code.AppendLine("    }");
                code.AppendLine("}");



                // Update Method
                code.AppendLine($"        public async Task<{responseClassName}> Update{modelName}({modelName}Model {modelName.ToLower()})");
                code.AppendLine("{");


                if (hasDateFields)
                {
                    code.AppendLine("    // Convert all DateTime and DateTime? fields to UTC with local assumption for unspecified kinds");
                    code.AppendLine($"    foreach (var prop in typeof({modelName}Model).GetProperties())");
                    code.AppendLine("    {");
                    code.AppendLine("        var propName = prop.Name.ToLower();");
                    code.AppendLine();
                    code.AppendLine("        if (prop.PropertyType == typeof(DateTime))");
                    code.AppendLine("        {");
                    code.AppendLine($"            var value = (DateTime)prop.GetValue({modelName.ToLower()});");
                    code.AppendLine("            if (value.Kind == DateTimeKind.Unspecified)");
                    code.AppendLine("                value = DateTime.SpecifyKind(value, DateTimeKind.Local);");
                    code.AppendLine("            if (!propName.Contains(\"dateonly\") && !propName.Equals(\"date\"))");
                    code.AppendLine("                value = TimeZoneInfo.ConvertTimeToUtc(value);");
                    code.AppendLine($"            prop.SetValue({modelName.ToLower()}, value);");
                    code.AppendLine("        }");
                    code.AppendLine("        else if (prop.PropertyType == typeof(DateTime?))");
                    code.AppendLine("        {");
                    code.AppendLine($"            var value = (DateTime?)prop.GetValue({modelName.ToLower()});");
                    code.AppendLine("            if (value.HasValue)");
                    code.AppendLine("            {");
                    code.AppendLine("                var dt = value.Value;");
                    code.AppendLine("                if (dt.Kind == DateTimeKind.Unspecified)");
                    code.AppendLine("                    dt = DateTime.SpecifyKind(dt, DateTimeKind.Local);");
                    code.AppendLine("                if (!propName.Contains(\"dateonly\") && !propName.Equals(\"date\"))");
                    code.AppendLine("                    dt = TimeZoneInfo.ConvertTimeToUtc(dt);");
                    code.AppendLine($"                prop.SetValue({modelName.ToLower()}, dt);");
                    code.AppendLine("            }");
                    code.AppendLine("        }");
                    code.AppendLine("    }");
                }

                //code.AppendLine("    // Step 1: Validate the user data against rules based on TableId and FormId");
                //code.AppendLine($"    string validationResult = await ValidateRules({modelName.ToLower()});");
                //code.AppendLine("    if (validationResult != \"Validation passed\") // If validation fails, return the error message");
                //code.AppendLine("    {");
                //code.AppendLine("        return new CreationResponse { Id = 0, Message = validationResult };");
                //code.AppendLine("    }");
                code.AppendLine();
                code.AppendLine("    // Step 2: SQL Query to update the student record");
                code.AppendLine($"     {modelName.ToLower()}.MODIFIEDBY = _userInfo.UserId;");
                code.AppendLine($"     {modelName.ToLower()}.MODIFIEDDATE = DateTime.UtcNow;");

                code.AppendLine($"           string query = \"{updateQuery}\";");

                code.AppendLine();
                code.AppendLine("    using (var connection = _context.CreateConnection())");
                code.AppendLine("    {");
                code.AppendLine("        // Execute the update query and check how many rows were affected");
                code.AppendLine($"               var result = await connection.ExecuteAsync(query, {modelName.ToLower()});");
                code.AppendLine();
                code.AppendLine("        // Step 3: Check if the update was successful");
                //code.AppendLine("        if (result > 0)");
                //code.AppendLine("        {");
                //code.AppendLine("            // Step 4: After successful update, apply actions to the student (if formIdCollection is provided)");
                //code.AppendLine($"            if ({(FirstFormId != 0 ? FirstFormId : (SecondFormId != 0 ? SecondFormId : 0))} > 0) // Check if formIdCollection is valid (adjust this logic based on your use case)");
                //code.AppendLine("            {");
                //code.AppendLine($"                string actionResult = await ApplyFormActions(result,{modelName.ToLower() + ".FormId"});");
                //code.AppendLine("                if (actionResult != \"Actions applied successfully.\")");
                //code.AppendLine("                {");
                //code.AppendLine("                    return new CreationResponse { Id = 0, Message = actionResult }; // Return error if action application fails");
                //code.AppendLine("                }");
                //code.AppendLine("            }");
                code.AppendLine();
                code.AppendLine("if (result > 0)")
                     .AppendLine("{")
                     .AppendLine($"    return new {responseClassName}")
                     .AppendLine("    {")
                     .AppendLine($"        Id = {modelName.ToLower()}.ID,")
                     .AppendLine(string.Format("        Message = \"{0}\"", "Updated and actions applied successfully"))
                     .AppendLine("    };")
                     .AppendLine("}")
                     .AppendLine("else")
                     .AppendLine("{");

                // Then the conditional portion:
                string elseReturn = returnType == "Guid"
                    ? $"    return new {responseClassName} {{ Id = Guid.Empty, Message = \"Failed to update the student. Please check if the ID is valid\" }};"
                    : $"    return new {responseClassName} {{ Id = ({returnType})0, Message = \"Failed to update the student. Please check if the ID is valid\" }};";

                code.AppendLine(elseReturn)
                    .AppendLine("");

                // code.AppendLine("    };");
                code.AppendLine("}");

                //code.AppendLine($"            return new {responseClassName} {{ Id = ({returnType}) result, Message = \"updated and actions applied successfully\" }};");
                //code.AppendLine("        }");
                //code.AppendLine("        else");
                //code.AppendLine("        {");
                //code.AppendLine($"            return new CreationResponse {{ Id = 0, Message = \"Failed to update the student. Please check if the ID is valid\" }};");
                //code.AppendLine("        }");
                code.AppendLine("    }");
                code.AppendLine("}");


                // GetById Method
                code.AppendLine($"        public async Task<{modelName}Model> Get{modelName}ById({returnType}  {modelName.ToLower()})");
                code.AppendLine("        {");

                var multiSelectFields = AddEditFields
    .Where(f => string.Equals(f.TypeId, "Multiselect", StringComparison.OrdinalIgnoreCase))
    .ToList();

                var checkboxFields = AddEditFields
                    .Where(f => string.Equals(f.TypeId, "checkboxgroup", StringComparison.OrdinalIgnoreCase))
                    .ToList();

                var nonMappingFields = AddEditFields
                    .Where(f => !string.Equals(f.TypeId, "checkboxgroup", StringComparison.OrdinalIgnoreCase)
                             && !string.Equals(f.TypeId, "Multiselect", StringComparison.OrdinalIgnoreCase))
                    .ToList();

                if (checkboxFields.Count > 0 || multiSelectFields.Count > 0)
                {
                    var selectParts = new List<string> { $"{table.Name}.*" };
                    var joins = new List<string>();

                    // Handle checkboxgroup fields
                    foreach (var field in checkboxFields)
                    {
                        var fieldName = field.FieldName ?? "";
                        var mapTable = $"{table.Name}_{fieldName}";
                        var relatedTable = field.SourceTableName;
                        var mapAlias = $"dtm_{fieldName}";
                        var relatedAlias = $"t_{fieldName}";

                        var aliasField = $"{fieldName}_{relatedTable}Ids";

                        selectParts.Add($"STRING_AGG(CAST({relatedAlias}.ID AS VARCHAR(MAX)), ',') AS {aliasField}");

                        joins.Add($"LEFT JOIN {mapTable} {mapAlias} ON {mapAlias}.{table.Name}ID = {table.Name}.ID");
                        joins.Add($"LEFT JOIN {relatedTable} {relatedAlias} ON {relatedAlias}.ID = {mapAlias}.{relatedTable}ID");
                    }

                    // Handle multiselect fields
                    foreach (var field in multiSelectFields)
                    {
                        var fieldName = field.FieldName ?? "";
                        var mapTable = $"{table.Name}_{fieldName}";
                        var relatedTable = field.SourceTableName;
                        var mapAlias = $"msm_{fieldName}";
                        var relatedAlias = $"ms_{fieldName}";
                        var aliasField = $"{fieldName}_{relatedTable}Ids";

                        selectParts.Add($"STRING_AGG(CAST({relatedAlias}.ID AS VARCHAR), ',') AS {aliasField}");
                        joins.Add($"LEFT JOIN {mapTable} {mapAlias} ON {mapAlias}.{table.Name}ID = {table.Name}.ID");
                        joins.Add($"LEFT JOIN {relatedTable} {relatedAlias} ON {relatedAlias}.ID = {mapAlias}.{relatedTable}ID");
                    }

                    // Group By
                    var groupByParts = new List<string>
                    {
                        $"{table.Name}.ID",
                        $"{table.Name}.CreatedBy",
                        $"{table.Name}.ModifiedBy",
                        $"{table.Name}.CreatedDate",
                        $"{table.Name}.ModifiedDate"
                    };

                    if (nonMappingFields.Count != 0)
                    {
                        groupByParts.AddRange(nonMappingFields.Select(f => $"{table.Name}.{f.FieldName}"));
                    }

                    if (table.HeaderTableId > 0)
                    {
                        groupByParts.AddRange(nonMappingFields.Select(f => $"{table.Name}.{table.HeaderTableName}Id"));
                    }
                    var fullQuery = $@"
                                    SELECT {string.Join(", ", selectParts)}
                                    FROM {table.Name}
                                    {string.Join("\n", joins)}
                                    WHERE {table.Name}.ID = @ID
                                    GROUP BY {string.Join(", ", groupByParts)}
                                ";

                    code.AppendLine($"    string query = @\"{fullQuery.Trim()}\";");
                }
                else
                {
                    code.AppendLine($"    string query = \"{selectgetbyidquery}\";");
                }



                code.AppendLine();
                code.AppendLine("    using (var connection = _context.CreateConnection())");
                code.AppendLine("    {");
                code.AppendLine($"                var result = await connection.QuerySingleOrDefaultAsync<{modelName}Model>(query, new {{ Id = {modelName.ToLower()} }});");

                code.AppendLine();
                code.AppendLine("                if (result != null)");
                code.AppendLine("                {");
                code.AppendLine("                    var timeZone = TimeZoneInfo.Local;");
                code.AppendLine($"                    foreach (var prop in typeof({modelName}Model).GetProperties())");
                code.AppendLine("                    {");
                code.AppendLine("                        if (prop.PropertyType == typeof(DateTime))");
                code.AppendLine("                        {");
                code.AppendLine("                            var value = (DateTime)prop.GetValue(result);");
                code.AppendLine("                            if (value.Kind == DateTimeKind.Utc || value.Kind == DateTimeKind.Unspecified)");
                code.AppendLine("                            {");
                code.AppendLine("                                var local = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(value, DateTimeKind.Utc), timeZone);");
                code.AppendLine("                                prop.SetValue(result, local);");
                code.AppendLine("                            }");
                code.AppendLine("                        }");
                code.AppendLine("                        else if (prop.PropertyType == typeof(DateTime?))");
                code.AppendLine("                        {");
                code.AppendLine("                            var value = (DateTime?)prop.GetValue(result);");
                code.AppendLine("                            if (value.HasValue)");
                code.AppendLine("                            {");
                code.AppendLine("                                var dt = DateTime.SpecifyKind(value.Value, DateTimeKind.Utc);");
                code.AppendLine("                                var local = TimeZoneInfo.ConvertTimeFromUtc(dt, timeZone);");
                code.AppendLine("                                prop.SetValue(result, local);");
                code.AppendLine("                            }");
                code.AppendLine("                        }");
                code.AppendLine("                    }");

                foreach (var field in AddEditDetailsFields)
                {
                    var fieldName = string.IsNullOrWhiteSpace(field.Name)
      ? ""
      : char.ToUpper(field.Name.Trim()[0]) + field.Name.Trim().Substring(1).ToLower();
                    if (string.Equals(field?.TypeName, "image", StringComparison.CurrentCultureIgnoreCase))
                    {
                        code.AppendLine($"if (result.{fieldName} != null && result.{fieldName}.Length > 0)");
                        code.AppendLine("{");
                        code.AppendLine($"    result.{fieldName}ImageBase64 = \"data:image/jpeg;base64,\" + Convert.ToBase64String(result.{fieldName});");
                        code.AppendLine("}");
                    }
                }
                code.AppendLine("                }");

                code.AppendLine();
                code.AppendLine("                return result;");
                code.AppendLine("            }");
                code.AppendLine("        }");


                // GetById Method
                code.AppendLine($"        public async Task<List<{modelName}Model>> GetAll{modelName}()");
                code.AppendLine("        {");

                code.AppendLine($"            string query = \"{selectQuery}\";");
                code.AppendLine();
                code.AppendLine("            using (var connection = _context.CreateConnection())");
                code.AppendLine("            {");
                code.AppendLine($"               var result= await connection.QueryAsync<{modelName}Model>(query);");
                code.AppendLine($"               return result.ToList();");
                code.AppendLine("            }");
                code.AppendLine("        }");

                //GetAll Method
                // Filter and get the first non-null SourceTableId
                // Get valid source tables
                var sourceTableInfo = AddEditDetailsFields
    .Where(f => f.SourceTableId.HasValue
                && !string.IsNullOrEmpty(f.SourceTableName)
                && f.TypeName != "checkboxgroup" && f.TypeName != "Multiselect") // Exclude checkboxgroup/multiselect
    .Select(f => new { f.SourceTableName, f.TextFieldName, f.Name })
    .Distinct()
    .ToList();

                code.AppendLine($"public async Task<Response> Get{modelName}(Request request)");
                code.AppendLine("{");

                code.AppendLine("var parameters = new DynamicParameters();");
                code.AppendLine("    var whereClause = \"\";");
                code.AppendLine("    if (request.Filter != null)");
                code.AppendLine("    {");
                code.AppendLine("        Filter.ApplyFieldMapping(request.Filter, FieldMap);");
                code.AppendLine($"        whereClause = new Filter().BuildWhereClause(request.Filter, \"{modelName}\");");
                code.AppendLine("        if (!string.IsNullOrEmpty(whereClause)){ whereClause = \"WHERE \" + whereClause;}");
                code.AppendLine("    }");

                code.AppendLine("var Childjoins = @\"");
                // Keep track of which tables we already joined
                var joinedTables = new HashSet<string>();

                foreach (var parent in FormList.Where(f => f.ParentId == null))
                {
                    // Add all child search fields as properties
                    var childFields = childSearchListByParentIds
                        //.Where(c => c.FormId == parent.TableId || c.ParentId == parent.TableId)
                        .OrderBy(c => c.InOrder)
                        .ToList();

                    foreach (var sf in childFields)
                    {
                        if (string.IsNullOrEmpty(sf.TableName))
                            continue;
                        // Only add LEFT JOIN once per child table
                        if (!joinedTables.Contains(sf.TableName))
                        {
                            var alias = sf.TableName;
                            code.AppendLine($"    LEFT JOIN {sf.TableName} {alias} ON {alias}.{modelName}Id = {modelName}.ID");
                            joinedTables.Add(sf.TableName);
                        }
                    }
                }
                code.AppendLine("\";");
                var aliasIndex = 1;
                var selectFields = new StringBuilder($"{table.Name}.*");
                var joinClauses = new StringBuilder();
                var fieldMap = new Dictionary<string, string>();

                // Handle dropdown/radiogroup (1-to-1)
                foreach (var field in AddEditFields.Where(f => f.TypeId?.ToLower() == "dropdown" || f.TypeId?.ToLower() == "radiogroup"))
                {
                    var sourceTable = field.SourceTableName?.Trim();
                    var textField = field.TextFieldName?.Trim();
                    var fieldName = field.FieldName?.Trim();
                    if (string.IsNullOrEmpty(sourceTable) || string.IsNullOrEmpty(textField)) continue;

                    var tableAlias = $"{sourceTable}_alias{aliasIndex++}";
                    var joinType = field.Mandatory == true ? "INNER JOIN" : "LEFT JOIN";
                    joinClauses.AppendLine($"    {joinType} {sourceTable} {tableAlias} ON {table.Name}.{fieldName} = {tableAlias}.ID");

                    var aliasName = $"{fieldName}_{sourceTable}";
                    selectFields.AppendLine($", {tableAlias}.{textField} AS {aliasName}");
                    fieldMap[aliasName] = $"{tableAlias}.{textField}";
                }

                // Handle checkboxgroup/multiselect (1-to-many with aggregation)
                foreach (var field in AddEditFields.Where(f => f.TypeId?.ToLower() == "checkboxgroup" || f.TypeId?.ToLower() == "multiselect"))
                {
                    var mapTable = $"{table.Name}_{field.FieldName}";
                    var relatedTable = field.SourceTableName;
                    var textField = field.TextFieldName;
                    var fieldAlias = (field.TypeId?.ToLower() == "checkboxgroup" ? "t_" : "ms_") + field.FieldName;

                    joinClauses.AppendLine($@"
                                            LEFT JOIN (
                                                SELECT map.{table.Name}ID, STRING_AGG(rel.{textField}, ',') AS {fieldAlias}
                                                FROM {mapTable} map
                                                INNER JOIN {relatedTable} rel ON rel.ID = map.{relatedTable}ID
                                                GROUP BY map.{table.Name}ID
                                            ) {fieldAlias}_values ON {fieldAlias}_values.{table.Name}ID = {table.Name}.ID");

                    selectFields.AppendLine($", {fieldAlias}_values.{fieldAlias} AS {field.FieldName}_{relatedTable}");
                    fieldMap[$"{field.FieldName}_{relatedTable}"] = $"{fieldAlias}_values.{fieldAlias}";
                }

                // Build final query
                code.AppendLine("var joins = $@\"" + joinClauses.ToString() + "\";");

                code.AppendLine($"     var totalCountQuery = $\"SELECT COUNT(DISTINCT {table.Name}.ID) FROM {table.Name} {{joins}} {{Childjoins}} {{whereClause}};\";");

                code.AppendLine("var baseQuery = $@\"");
                code.AppendLine($"          SELECT DISTINCT {selectFields} FROM {table.Name} {{joins}} {{Childjoins}} {{whereClause}}");
                code.AppendLine("           ORDER BY {(request.Sort != null && request.Sort.Any() ? string.Join(\",\", request.Sort.Select(s => $\"{s.Field} {s.Dir}\")) : \"" + table.Name + ".Id\")}");
                code.AppendLine("           OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY;");
                code.AppendLine("           \";");
                code.AppendLine("parameters.Add(\"Skip\", request.Skip);");
                code.AppendLine("parameters.Add(\"Take\", request.Take);");

                code.AppendLine("using (var connection = _context.CreateConnection())");
                code.AppendLine("{");
                //code.AppendLine("        var total = await connection.ExecuteScalarAsync<int>(totalCountQuery);");
                //code.AppendLine($"        var result = await connection.QueryAsync<{modelName}Model>(baseQuery, request);");
                code.AppendLine("        var total = await connection.ExecuteScalarAsync<int>(totalCountQuery,parameters);");
                code.AppendLine($"        var result = await connection.QueryAsync<{modelName}Model>(baseQuery, parameters);");
                code.AppendLine("    var aggregates = new Dictionary<string, Dictionary<string, string>>();");
                code.AppendLine("    bool isGrouped = false;");
                code.AppendLine("    var response = new Response(result.ToList(), aggregates, total, isGrouped);");
                code.AppendLine("    return response;");
                code.AppendLine("}");
                code.AppendLine("}");

                foreach (var parent in FormList.Where(f => f.ParentId == null))
                {
                    var parentTable = parent.TableName ?? string.Empty;
                    //var parentFields = ClientSearch
                    //    .Where(c => c.FormId == parent.ID && c.ParentId == null)
                    //    .OrderBy(c => c.InOrder)
                    //    .ToList();

                    foreach (var pf in ClientSearch)
                    {
                        // Skip fields where ParentId > 1
                        if (pf?.ParentId > 0)
                            continue;

                        var fieldName = pf?.FieldName?.Trim();
                        if (!string.IsNullOrEmpty(fieldName))
                        {
                            fieldMap[fieldName] = $"{parentTable}.{fieldName}";
                        }
                    }


                    // Child fields
                    var childFields = childSearchListByParentIds
                        //.Where(c => c.ParentId == parent.TableId)
                        .OrderBy(c => c.InOrder)
                        .ToList();

                    foreach (var sf in childFields)
                    {
                        var alias = sf.TableName;
                        var fieldName = sf?.FieldName?.Trim();

                        if (!string.IsNullOrEmpty(fieldName))
                        {
                            fieldMap[fieldName] = $"{alias}.{fieldName}";
                        }
                    }
                }

                // Generate FieldMap dictionary
                code.AppendLine("       public static readonly Dictionary<string, string> FieldMap = new()");
                code.AppendLine("       {");
                foreach (var kvp in fieldMap)
                {
                    code.AppendLine($"    [\"{kvp.Key}\"] = \"{kvp.Value}\",");
                }
                code.AppendLine("       };");
                code.AppendLine("   }");
                code.AppendLine("}");


                string projectfoldername = $@"{ClientName}\{ProjectName}";

                string directoryPath = $@"C:\ClientProject\{projectfoldername}\Infrastructure\Repositories";

                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                // Create the file path (using the table name as the file name)
                string filePath = Path.Combine(directoryPath, $"{table.Name}Repository.cs");

                // Write the model code to the file
                File.WriteAllText(filePath, code.ToString());
            }
            //}


            //}

            catch (Exception ex)
            {
                Console.WriteLine("Error generating repository code: " + ex.Message);
                throw;
            }
        }
    }
}
