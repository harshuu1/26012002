﻿using Dapper;
using DapperDB;
using Entities.Enums;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class CreateFormTableClass(DapperDbContext.DbContext context)
    {
        private readonly DapperDbContext.DbContext _context = context;

        public async Task CreateConfigSchema(string databaseName)
        {
            string createSchemaQuery = @$"IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = '{DbSchemaEnums.config.ToString()}')
                                          EXEC('CREATE SCHEMA [{DbSchemaEnums.config.ToString()}]');";

            using var connection = _context.CreateConnection();
            await connection.ExecuteAsync(createSchemaQuery);

        }
        public async Task CreateFormTable(string databaseName)
        {
            string createTableQuery = @$"
            CREATE TABLE [{DbSchemaEnums.config.ToString()}].[Form](
	            [ID] [int] IDENTITY(1,1) NOT NULL,
	            [Name] [varchar](60) NOT NULL,
	            [TableId] [int] NULL,
	            [CreatedBy] [int] NULL,
	            [CreatedDate] [datetime] NULL,
	            [ModifiedBy] [int] NULL,
	            [ModifiedDate] [datetime] NULL,
	            [DetailTableId] [int] NULL,
	            [ParentId] [int] NULL,
	            [SearchProfileId] [int] NULL,
	            [CardViewProfileId] [int] NULL,
	            [IsDocumentEnabled] [bit] NULL,
	            [SaveReuse] [bit] NULL,
	            [SaveContinue] [bit] NULL,
	            [ListProfileId] [int] NULL,
	            [IsAddToList] [bit] NULL,
	            [IsBarcodePrinting] [bit] NULL,
	            [DisplayName] [varchar](128) NULL,
	            [ListLabel] [nvarchar](255) NULL,
	            [CardviewLabel] [nvarchar](255) NULL,
	            [Delimiter] [char](1) NULL,
             CONSTRAINT [PK__Form__3214EC079E6149CD] PRIMARY KEY CLUSTERED 
            (
	            [ID] ASC
            )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
            ) ON [PRIMARY]";

            createTableQuery += " INSERT INTO dbo.DefaultTable (TableName, IsDefault) VALUES ('Form', 1)";

            using var connection = _context.CreateConnection();
            await connection.ExecuteAsync(createTableQuery);
        }

        public async Task InsertDataIntoClientForm(string databaseName, int clientId, int projectId, string adminDatabaseName)
        {
            // Insert only new data into ClientForm based on ID
            string insertDataQuery = $@"
                INSERT INTO [{databaseName}].[dbo].[ClientForm] (
                     ID, Name, TableId,
                    CreatedBy, CreatedDate, ModifiedBy, ModifiedDate, 
                    DetailTableId, ParentId ,SearchProfileId ,CardViewProfileId, IsDocumentEnabled, SaveReuse, SaveContinue, ListProfileId,
                    IsAddToList, IsBarcodePrinting, DisplayName, ListLabel, CardviewLabel, Delimiter
                )
                SELECT 
                    f.ID,
                    f.Name,
                    f.TableId,
                    f.CreatedBy,
                    f.CreatedDate,
                    f.ModifiedBy,
                    f.ModifiedDate,
                    f.DetailTableId,
                    f.ParentId,
                    f.SearchProfileId,                 
                    f.CardViewProfileId,
                    f.IsDocumentEnabled,
                    f.SaveReuse,    
                    f.SaveContinue,
                    f.ListProfileId,
                    f.IsAddToList,
                    f.IsBarcodePrinting,
                    f.DisplayName,
                    f.ListLabel,
                    f.CardviewLabel,
                    f.Delimiter
                FROM [{adminDatabaseName}].[{DbSchemaEnums.config.ToString()}].[Form] f
                WHERE
                NOT EXISTS (
                    SELECT 1 FROM [{databaseName}].[dbo].[ClientForm] cf WHERE cf.ID = f.ID
                )";

            using var connection = _context.CreateConnection();
            //var parameters = new { ClientId = clientId, ProjectId = projectId };
            await connection.ExecuteAsync(insertDataQuery, null);
        }
    }
}