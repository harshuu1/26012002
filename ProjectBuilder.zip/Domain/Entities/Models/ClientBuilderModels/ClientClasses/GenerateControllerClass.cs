﻿using System.Text;
using Entities.Enums;
using Entities.Models.ClientBuilderModels.ClientModels;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateControllerClass
    {
        public static void GenerateCheckboxController(ClientTable table, ClientFieldDefinition checkboxField, string ProjectName, string ClientName)
        {
            StringBuilder controllerCode = new();
            string mapTableName = $"{table.Name}_{checkboxField.Name}";
            string className = $"{mapTableName}Controller";
            string routePrefix = mapTableName.ToLower(); // Use lowercase for route consistency

            controllerCode.AppendLine("using Microsoft.AspNetCore.Mvc;");
            controllerCode.AppendLine("using Microsoft.AspNetCore.Authorization;");
            controllerCode.AppendLine("using System;");
            controllerCode.AppendLine("using System.Collections.Generic;");
            controllerCode.AppendLine("using System.Linq;");
            controllerCode.AppendLine("using System.Threading.Tasks;");
            controllerCode.AppendLine("using Interfaces;");
            controllerCode.AppendLine($"using Entities.Models.{table.Name};");
            controllerCode.AppendLine($"using Application.Modules.{mapTableName}.Queries;");
            controllerCode.AppendLine($"using Application.Modules.{mapTableName}.Commands;");
            controllerCode.AppendLine("using MediatR;");
            controllerCode.AppendLine();

            controllerCode.AppendLine($"namespace ClientProjectBuilder.Api.Controllers");
            controllerCode.AppendLine("{");
            controllerCode.AppendLine($"    [Route(\"{routePrefix}\")]");
            controllerCode.AppendLine($"    [ApiController]");
            controllerCode.AppendLine($"    public class {className} : ControllerBase");
            controllerCode.AppendLine("    {");
            controllerCode.AppendLine($"        private readonly I{mapTableName} _repository;");
            controllerCode.AppendLine("        private readonly IMediator _mediator;");
            controllerCode.AppendLine();
            controllerCode.AppendLine($"        public {className}(I{mapTableName} repository, IMediator mediator)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            _repository = repository;");
            controllerCode.AppendLine("            _mediator = mediator;");
            controllerCode.AppendLine("        }");

            // CREATE/SAVE method
            controllerCode.AppendLine();
            controllerCode.AppendLine("        /// <summary>");
            controllerCode.AppendLine($"        /// Creates or updates {mapTableName} mappings.");
            controllerCode.AppendLine("        /// </summary>");
            //controllerCode.AppendLine("        [Authorize]");
            controllerCode.AppendLine($"        [HttpPost]");
            controllerCode.AppendLine($"        public async Task<IActionResult> Save{mapTableName}([FromBody] List<{mapTableName}Model> entities)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            if (entities == null || !entities.Any())");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return BadRequest(\"Mapping data is null or empty.\");");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine();
            var ckType = table.PrimaryKeyType?.ToString()?.Trim().ToLowerInvariant() ?? "int";
            var ckreturnType = GetCSharpType((table.PrimaryKeyType ?? "").Trim().ToLower());
            controllerCode.AppendLine($"            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                {ckreturnType} {table.Name?.ToLower() ?? ""}Id = ({ckreturnType}) entities.First().{table.Name}ID;");
            controllerCode.AppendLine();
            var idField = $"{table.Name?.ToLower() ?? ""}Id";
            var condition = ckreturnType == "Guid" ? $"{idField} != Guid.Empty" : $"{idField} > 0";
            //controllerCode.AppendLine($"                if ({condition})");
            //controllerCode.AppendLine("                {");
            //controllerCode.AppendLine($"                    await _repository.UpdateMappingsAsync({table.Name?.ToLower() ?? ""}Id, entities);");
            //controllerCode.AppendLine("                }");
            //controllerCode.AppendLine("                else");
            //controllerCode.AppendLine("                {");
            //controllerCode.AppendLine($"                    {table.Name?.ToLower() ?? ""}Id = ({ckreturnType}) await _repository.CreateAsync(entities.First());");
            //controllerCode.AppendLine("                }");
            controllerCode.AppendLine($"                 var result = await _mediator.Send(new Save{mapTableName}Command({table.Name?.ToLower() ?? ""}Id, entities));");
            controllerCode.AppendLine();
            controllerCode.AppendLine($"                return Ok(new {{ id = {table.Name?.ToLower() ?? ""}Id, message = \"Saved successfully\" }});");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, $\"Internal server error: {ex.Message}\");");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");

            // GET ALL method
            controllerCode.AppendLine();
            controllerCode.AppendLine("        /// <summary>");
            controllerCode.AppendLine($"        /// Gets all {mapTableName} records.");
            controllerCode.AppendLine("        /// </summary>");
            //controllerCode.AppendLine("        [Authorize]");
            controllerCode.AppendLine($"        [HttpGet]");
            controllerCode.AppendLine($"        public async Task<IActionResult> GetAll{mapTableName}()");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                var result = await _mediator.Send(new GetAll{mapTableName}Query());");
            //controllerCode.AppendLine($"                var result = await _repository.GetAllAsync();");
            controllerCode.AppendLine("                return Ok(result);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");

            // GET BY ID method
            controllerCode.AppendLine();
            controllerCode.AppendLine("        /// <summary>");
            controllerCode.AppendLine($"        /// Gets {mapTableName} by ID.");
            controllerCode.AppendLine("        /// </summary>");
            controllerCode.AppendLine("        /// <param name=\"id\">The ID to retrieve.</param>");
            //controllerCode.AppendLine("        [Authorize]");
            controllerCode.AppendLine($"        [HttpGet(\"{{id}}\")]");
            controllerCode.AppendLine($"        public async Task<IActionResult> Get{mapTableName}ById(int id)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                var result = await _mediator.Send(new Get{mapTableName}ByIdQuery(id));");
            //controllerCode.AppendLine($"                var result = await _repository.GetByIdAsync(id);");
            controllerCode.AppendLine("                if (result == null)");
            controllerCode.AppendLine("                {");
            controllerCode.AppendLine("                    return NotFound($\"{nameof(result)} not found.\");");
            controllerCode.AppendLine("                }");
            controllerCode.AppendLine("                return Ok(result);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");

            // UPDATE method
            controllerCode.AppendLine();
            controllerCode.AppendLine("        /// <summary>");
            controllerCode.AppendLine($"        /// Updates {mapTableName} by ID.");
            controllerCode.AppendLine("        /// </summary>");
            controllerCode.AppendLine("        /// <param name=\"id\">The ID to update.</param>");
            //controllerCode.AppendLine("        [Authorize]");
            controllerCode.AppendLine($"        [HttpPut(\"{{id}}\")]");
            controllerCode.AppendLine($"        public async Task<IActionResult> Update{mapTableName}(int id, [FromBody] {mapTableName}Model entity)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            if (entity == null)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return BadRequest(\"Entity data is null.\");");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            if (id != entity.ID)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return BadRequest(\"ID mismatch.\");");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                var result = await _mediator.Send(new Update{mapTableName}Command(id, entity));");
            //controllerCode.AppendLine($"                var result = await _repository.UpdateAsync(id, entity);");
            controllerCode.AppendLine("                return Ok(result);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");

            // DELETE method by Parent ID
            controllerCode.AppendLine();
            controllerCode.AppendLine("        /// <summary>");
            controllerCode.AppendLine($"        /// Deletes {mapTableName} records by parent ID.");
            controllerCode.AppendLine("        /// </summary>");
            controllerCode.AppendLine("        /// <param name=\"parentId\">The parent ID.</param>");
            //controllerCode.AppendLine("        [Authorize]");
            controllerCode.AppendLine($"        [HttpDelete(\"parent/{{parentId}}\")]");
            controllerCode.AppendLine($"        public async Task<IActionResult> DeleteByParentId(int parentId)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                var result = await _mediator.Send(new Delete{mapTableName}ByParentIdCommand(parentId));");
            //controllerCode.AppendLine($"                var result = await _repository.DeleteByParentIdAsync(parentId);");
            controllerCode.AppendLine("                return Ok(result);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");
            controllerCode.AppendLine("        }");
            controllerCode.AppendLine("        }");



            // Write to file
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.Api\Controllers";

            if (!Directory.Exists(directoryPath))
                Directory.CreateDirectory(directoryPath);

            string filePath = Path.Combine(directoryPath, $"{className}.cs");
            File.WriteAllText(filePath, controllerCode.ToString());
        }

        public static void GenerateCaptchaController(string ProjectName, string ClientName)
        {

            var controllerCode = new StringBuilder();

            controllerCode.AppendLine("using System.Drawing;");
            controllerCode.AppendLine("using Microsoft.AspNetCore.Mvc;");
            controllerCode.AppendLine("using System.Drawing.Imaging;");
            controllerCode.AppendLine("using Microsoft.Extensions.Caching.Memory;");
            controllerCode.AppendLine("using System.Drawing.Drawing2D;");
            //controllerCode.AppendLine("using NAudio.Wave;");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("namespace ClientProjectBuilder.Api.Controllers");
            controllerCode.AppendLine("{");
            controllerCode.AppendLine("    public class CaptchaController : Controller");
            controllerCode.AppendLine("    {");
            controllerCode.AppendLine("        private readonly IMemoryCache _memoryCache;");
            controllerCode.AppendLine("        private readonly ILogger<CaptchaController> _logger;");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("        public CaptchaController(IMemoryCache memoryCache, ILogger<CaptchaController> logger)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            _memoryCache = memoryCache;");
            controllerCode.AppendLine("            _logger = logger;");
            controllerCode.AppendLine("        }");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("        [HttpGet(\"/Captcha/Handler\")]");
            controllerCode.AppendLine("        public IActionResult Handler()");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            var captchaText = GenerateRandomText();");
            controllerCode.AppendLine("            var captchaId = Guid.NewGuid().ToString();");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("            _memoryCache.Set(\"captcha_\" + captchaId, captchaText, TimeSpan.FromMinutes(5));");
            controllerCode.AppendLine("            _logger.LogInformation($\"[SET] captcha_{captchaId} = {captchaText}\");");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("            var imageBytes = GenerateImage(captchaText);");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("            return Json(new");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                captchaId = captchaId,");
            controllerCode.AppendLine("                captcha = $\"data:image/png;base64,{Convert.ToBase64String(imageBytes)}\",");
            controllerCode.AppendLine("                mimeType = \"image/png\"");
            controllerCode.AppendLine("            });");
            controllerCode.AppendLine("        }");
            controllerCode.AppendLine("");
            //controllerCode.AppendLine("        [HttpGet(\"/Captcha/Audio\")]");
            //controllerCode.AppendLine("        public IActionResult Audio([FromQuery] string captchaId)");
            //controllerCode.AppendLine("        {");
            //controllerCode.AppendLine("            if (string.IsNullOrEmpty(captchaId))");
            //controllerCode.AppendLine("            {");
            //controllerCode.AppendLine("                return BadRequest(\"Missing captchaId.\");");
            //controllerCode.AppendLine("            }");
            //controllerCode.AppendLine("");
            //controllerCode.AppendLine("            if (!_memoryCache.TryGetValue(\"captcha_\" + captchaId, out string captchaText))");
            //controllerCode.AppendLine("            {");
            //controllerCode.AppendLine("                return BadRequest(\"Invalid CAPTCHA ID\");");
            //controllerCode.AppendLine("            }");
            //controllerCode.AppendLine("");
            //controllerCode.AppendLine("            byte[] audioBytes = GenerateCaptchaAudio(captchaText);");
            //controllerCode.AppendLine("            if (audioBytes == null || audioBytes.Length == 0)");
            //controllerCode.AppendLine("            {");
            //controllerCode.AppendLine("                return BadRequest(\"Audio generation failed\");");
            //controllerCode.AppendLine("            }");
            //controllerCode.AppendLine("");
            //controllerCode.AppendLine("            return File(audioBytes, \"audio/wav\");");
            //controllerCode.AppendLine("        }");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("        [HttpGet(\"/Captcha/Validate\")]");
            controllerCode.AppendLine("        public IActionResult Validate(string captchaId, string captcha)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            if (!_memoryCache.TryGetValue(\"captcha_\" + captchaId, out string expected))");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return Json(false);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("            bool isValid = string.Equals(expected, captcha, StringComparison.Ordinal);");
            controllerCode.AppendLine("            return Json(isValid);");
            controllerCode.AppendLine("        }");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("        private string GenerateRandomText()");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            var chars = \"ABCDEFGHJKLMNPQRSTUVWXYZ23456789\";");
            controllerCode.AppendLine("            var random = new Random();");
            controllerCode.AppendLine("            return new string(Enumerable.Repeat(chars, 5).Select(s => s[random.Next(s.Length)]).ToArray());");
            controllerCode.AppendLine("        }");
            controllerCode.AppendLine("");
            //controllerCode.AppendLine("        private byte[] GenerateCaptchaAudio(string captchaText)");
            //controllerCode.AppendLine("        {");
            //controllerCode.AppendLine("            using var stream = new MemoryStream();");
            //controllerCode.AppendLine("            using var synth = new System.Speech.Synthesis.SpeechSynthesizer();");
            //controllerCode.AppendLine("            synth.SetOutputToWaveStream(stream);");
            //controllerCode.AppendLine("            synth.Speak(captchaText);");
            //controllerCode.AppendLine("            return stream.ToArray();");
            //controllerCode.AppendLine("        }");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("private byte[] GenerateImage(string text)");
            controllerCode.AppendLine("{");
            controllerCode.AppendLine("    int width = 150;");
            controllerCode.AppendLine("    int height = 50;");
            controllerCode.AppendLine("    var random = new Random();");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("    using var bmp = new Bitmap(width, height);");
            controllerCode.AppendLine("    using var gfx = Graphics.FromImage(bmp);");
            controllerCode.AppendLine("    gfx.SmoothingMode = SmoothingMode.AntiAlias;");
            controllerCode.AppendLine("    gfx.Clear(Color.White);");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("    using var font = new Font(\"Arial\", 24, FontStyle.Bold);");
            controllerCode.AppendLine("    using var brush = new SolidBrush(Color.Gray);");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("    // 1. Add background noise (dots)");
            controllerCode.AppendLine("    for (int i = 0; i < 100; i++)");
            controllerCode.AppendLine("    {");
            controllerCode.AppendLine("        int x = random.Next(width);");
            controllerCode.AppendLine("        int y = random.Next(height);");
            controllerCode.AppendLine("        bmp.SetPixel(x, y, Color.Gray);");
            controllerCode.AppendLine("    }");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("    // 2. Draw a wavy line across the image");
            controllerCode.AppendLine("    using var pen = new Pen(Color.Gray, 1);");
            controllerCode.AppendLine("    Point[] wavePoints = Enumerable.Range(0, width).Select(x => new Point(x, (int)(10 * Math.Sin(x * 0.1)) + height / 2)).ToArray();");
            controllerCode.AppendLine("    gfx.DrawLines(pen, wavePoints);");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("    int charSpacing = 25;");
            controllerCode.AppendLine("    for (int i = 0; i < text.Length; i++)");
            controllerCode.AppendLine("    {");
            controllerCode.AppendLine("        // Optional: Rotate each character slightly");
            controllerCode.AppendLine("        float angle = random.Next(-20, 20);");
            controllerCode.AppendLine("        gfx.TranslateTransform(10 + i * charSpacing, 10);");
            controllerCode.AppendLine("        gfx.RotateTransform(angle);");
            controllerCode.AppendLine("        gfx.DrawString(text[i].ToString(), font, brush, 0, 0);");
            controllerCode.AppendLine("        gfx.ResetTransform();");
            controllerCode.AppendLine("    }");
            controllerCode.AppendLine("");
            controllerCode.AppendLine("    // 4. Export to byte[]");
            controllerCode.AppendLine("    using var ms = new MemoryStream();");
            controllerCode.AppendLine("    bmp.Save(ms, ImageFormat.Png);");
            controllerCode.AppendLine("    return ms.ToArray();");
            controllerCode.AppendLine("}");
            controllerCode.AppendLine("    }");
            controllerCode.AppendLine("}");

            // Write to file
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.Api\Controllers";

            if (!Directory.Exists(directoryPath))
                Directory.CreateDirectory(directoryPath);

            string filePath = Path.Combine(directoryPath, "CaptchaController.cs");
            File.WriteAllText(filePath, controllerCode.ToString());
        }

        //Changes for PKTYPE
        private static string GetCSharpType(string dbType)
        {
            dbType = (dbType ?? "").Trim().ToLower();
            return Enum.TryParse<PKTypeEnum>(dbType, true, out var type)
                ? type.GetDescription()
                : PKTypeEnum.Int.GetDescription();
        }

        private static string GetClassType(string dbType)
        {
            dbType = dbType?.Trim().ToLower() ?? string.Empty;

            return Enum.TryParse<PKTypeEnum>(dbType, true, out var type)
                ? type.GetResponseDescription(asCreationResponse: true)
                : PKTypeEnum.Int.GetResponseDescription(asCreationResponse: true);
        }

        //controller
        public void GenerateController(ClientTable table, string modelName, string ProjectName, string ClientName, IEnumerable<ClientForm> FormList, IEnumerable<ClientFieldDefinition> AddEditFields, List<ClientActionDetail> formAction)
        {
            var controllerCode = new StringBuilder();

            //Changes for PKType
            var pkType = table.PrimaryKeyType?.ToString()?.Trim().ToLowerInvariant() ?? "int";
            var responseClassName = GetClassType(pkType);
            var returnType = GetCSharpType((table.PrimaryKeyType ?? "").Trim().ToLower());



            // Controller Header
            controllerCode.AppendLine("using Microsoft.AspNetCore.Mvc;");
            controllerCode.AppendLine("using Microsoft.AspNetCore.Authorization;");
            controllerCode.AppendLine("using System;");
            controllerCode.AppendLine("using System.Collections.Generic;");

            controllerCode.AppendLine("using System.Threading.Tasks;");
            controllerCode.AppendLine("using Entities.Models.Request;");
            controllerCode.AppendLine("using Entities.Models.Response;");
            controllerCode.AppendLine("using Entities.Models.CreationResponse;");
            controllerCode.AppendLine("using Entities.Models.Services;");
            controllerCode.AppendLine($"using Entities.Models.{table.Name};");
            controllerCode.AppendLine($"using BusinessRule.{table.Name};");
            controllerCode.AppendLine("using Interfaces;");
            controllerCode.AppendLine("using Dapper;");
            controllerCode.AppendLine("using Services;");
            //controllerCode.AppendLine("using Services;");
            controllerCode.AppendLine("using Windows.ApplicationModel.Email;");
            //controllerCode.AppendLine("using Models.Services;");
            //controllerCode.AppendLine("using Infrastructure;");
            //controllerCode.AppendLine("using Infrastructure.Services;");
            controllerCode.AppendLine("using System.Net;");
            controllerCode.AppendLine("using System.IdentityModel.Tokens.Jwt;");
            controllerCode.AppendLine("using Serilog;");
            controllerCode.AppendLine("using System.Reflection;");
            controllerCode.AppendLine("using ClientProjectBuilder.Api.Services;");
            controllerCode.AppendLine("using MediatR;");
            controllerCode.AppendLine($"using Application.Modules.{modelName}.Queries;");
            controllerCode.AppendLine($"using Application.Modules.{modelName}.Commands;");
            controllerCode.AppendLine($"using Telerik.Reporting.Processing;");
            controllerCode.AppendLine($"using ClientProjectBuilder.Api.Services;");
            controllerCode.AppendLine();



            // Clean route name (pluralized and lowercase)
            //string routeName = $"{modelName.ToLower()}s";
            // OLD: string routeName = $"{modelName.ToLower()}s";
            string routeName = $"{modelName.ToLower()}"; // Removed the 's'

            controllerCode.AppendLine($"namespace ClientProjectBuilder.Api.Controllers");
            controllerCode.AppendLine("{");
            controllerCode.AppendLine($"    /// <summary>");
            controllerCode.AppendLine($"    /// Controller for managing {modelName} operations");
            controllerCode.AppendLine($"    /// </summary>");
            controllerCode.AppendLine($"    [Route(\"{routeName}\")]");

            controllerCode.AppendLine("    [ApiController]");
            controllerCode.AppendLine($"    public class {modelName}Controller : ControllerBase");
            controllerCode.AppendLine("    {");
            controllerCode.AppendLine($"        private readonly I{modelName} _context;");
            controllerCode.AppendLine($"        private readonly {modelName}Rule _rule;");
            controllerCode.AppendLine($"        private readonly MailService mailService;");
            controllerCode.AppendLine($"        private readonly IWebHostEnvironment _env;");
            controllerCode.AppendLine($" private readonly string _reportsPath;");
            controllerCode.AppendLine($"        private readonly IMediator _mediator;");
            controllerCode.AppendLine($"   private readonly TelerikReportsController _telerikReportsController;");
            controllerCode.AppendLine();
            controllerCode.AppendLine($"        public {modelName}Controller(I{modelName} context ,{modelName}Rule rule, MailService mailService, IWebHostEnvironment env, IMediator mediator,TelerikReportsController telerikReportsController)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            _context = context;");
            controllerCode.AppendLine("            _rule = rule;");
            controllerCode.AppendLine("            _env = env;");
            controllerCode.AppendLine("   _reportsPath = CustomReportSourceResolver.GetReportsPath(env);");
            controllerCode.AppendLine("            this.mailService = mailService;");
            controllerCode.AppendLine("             _mediator = mediator;");
            controllerCode.AppendLine("       _telerikReportsController = telerikReportsController;");
            controllerCode.AppendLine("        }");
            // GET ALL API method
            controllerCode.AppendLine();
            controllerCode.AppendLine($"        /// <summary>");
            controllerCode.AppendLine($"        /// Retrieves all {modelName} records");
            controllerCode.AppendLine($"        /// </summary>");
            //controllerCode.AppendLine($"        [Authorize]");
            controllerCode.AppendLine($"        [HttpGet]");
            controllerCode.AppendLine("        public async Task<IActionResult> GetAll()");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                var result = await _mediator.Send(new GetAll{modelName}sQuery());");
            //controllerCode.AppendLine($"                var result = await _context.GetAll{modelName}();");
            controllerCode.AppendLine("                return Ok(result);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");

            // GET BY ID API method
            controllerCode.AppendLine();
            controllerCode.AppendLine($"        /// <summary>");
            controllerCode.AppendLine($"        /// Gets {modelName} by ID");
            controllerCode.AppendLine($"        /// </summary>");
            controllerCode.AppendLine($"        /// <param name=\"id\">The ID of the {modelName} to retrieve</param>");
            //controllerCode.AppendLine($"        [Authorize]");
            controllerCode.AppendLine($"        [HttpGet(\"{{id}}\")]");
            controllerCode.AppendLine($"        public async Task<IActionResult> Get{modelName}ById({returnType} id)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                var response = await _mediator.Send(new Get{modelName}ByIdQuery(id));");
            //controllerCode.AppendLine($"                var response = await _context.Get{modelName}ById(id);");
            controllerCode.AppendLine("                if (response == null)");
            controllerCode.AppendLine("                {");
            controllerCode.AppendLine("                    return NotFound();");
            controllerCode.AppendLine("                }");
            controllerCode.AppendLine("                return Ok(response);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");

            // GET WITH FILTER method
            controllerCode.AppendLine();
            controllerCode.AppendLine($"        /// <summary>");
            controllerCode.AppendLine($"        /// Retrieves filtered {modelName} data");
            controllerCode.AppendLine($"        /// </summary>");
            //controllerCode.AppendLine($"        [Authorize]");
            controllerCode.AppendLine($"        [HttpPost(\"/{modelName.ToLower()}s\")]");
            controllerCode.AppendLine($"        public async Task<IActionResult> Get{modelName}(Request request)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                var result = await _mediator.Send(new Get{modelName}Query(request));");
            //controllerCode.AppendLine($"                var result = await _context.Get{modelName}(request);");
            controllerCode.AppendLine("                return Ok(result.ToResult());");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");

            // CREATE API method
            controllerCode.AppendLine();
            controllerCode.AppendLine($"        /// <summary>");
            controllerCode.AppendLine($"        /// Creates a new {modelName}");
            controllerCode.AppendLine($"        /// </summary>");
            //controllerCode.AppendLine($"        [Authorize]");
            controllerCode.AppendLine("        [HttpPost]");
            controllerCode.AppendLine("        public async Task<IActionResult> Create(" + modelName + "Model" + " " + modelName.ToLower() + ")");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine($"            if ({modelName.ToLower()} == null)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                return BadRequest($\"{modelName} data is null.\");");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine();            
            controllerCode.AppendLine($"            var result = await _mediator.Send(new Create{modelName}Command({modelName.ToLower()}));");
            //controllerCode.AppendLine($"            var result = await _context.Create{modelName}(" + modelName.ToLower() + ");");
            controllerCode.AppendLine("            return Ok(result);");
            controllerCode.AppendLine("        }");

            // UPDATE API method
            controllerCode.AppendLine();
            controllerCode.AppendLine($"        /// <summary>");
            controllerCode.AppendLine($"        /// Updates a {modelName}");
            controllerCode.AppendLine($"        /// </summary>");
            //controllerCode.AppendLine($"        [Authorize]");
            controllerCode.AppendLine($"        [HttpPut(\"{{id}}\")]");
            controllerCode.AppendLine($"        public async Task<IActionResult> Update{modelName}({modelName}Model {modelName.ToLower()})");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                var result = await _mediator.Send(new Update{modelName}Command({modelName.ToLower()}));");
            //controllerCode.AppendLine($"                var response = await _context.Update{modelName}({modelName.ToLower()});");
            controllerCode.AppendLine("                return Ok(result);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");

            controllerCode.AppendLine("        [HttpGet(\"references/{id}\")]");
            controllerCode.AppendLine($"       public async Task<IActionResult> Get{table.Name}References({returnType} id)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine($"          var references = (await _context.Get{table.Name}ReferencesAsync(id)).ToList();");
            controllerCode.AppendLine();
            controllerCode.AppendLine("           if (references.Any(r => r.HasChildReferences))");
            controllerCode.AppendLine("           {");
            controllerCode.AppendLine("              return Ok(new { message = \"Cannot Delete Item :\", references });");
            controllerCode.AppendLine("           }");
            controllerCode.AppendLine();
            controllerCode.AppendLine("           return Ok(references);");
            controllerCode.AppendLine("           }");
            // DELETE API method
            controllerCode.AppendLine();
            controllerCode.AppendLine($"        /// <summary>");
            controllerCode.AppendLine($"        /// Deletes a {modelName} by ID");
            controllerCode.AppendLine($"        /// </summary>");
            controllerCode.AppendLine($"        /// <param name=\"id\">{modelName} ID to delete</param>");
            //controllerCode.AppendLine($"        [Authorize]");
            controllerCode.AppendLine("        [HttpDelete(\"{id}\")]");
            controllerCode.AppendLine($"        public async Task<IActionResult> Delete({returnType} id)");
            controllerCode.AppendLine("        {");
            controllerCode.AppendLine("            try");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine($"                var result = await _mediator.Send(new Delete{modelName}Command(id));");
            //controllerCode.AppendLine("                var result = await " + $"_context.Delete{modelName}(id);");
            string defaultCheck = returnType == "Guid"
              ? "if (id == Guid.Empty)"
              : "if (id == 0)";

            controllerCode.AppendLine($"    {defaultCheck}");
            //controllerCode.AppendLine("                if (id == 0)");
            controllerCode.AppendLine("                {");
            controllerCode.AppendLine("                    return NotFound();");
            controllerCode.AppendLine("                }");
            controllerCode.AppendLine("                return Ok(result);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("            catch (Exception ex)");
            controllerCode.AppendLine("            {");
            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            controllerCode.AppendLine("            }");
            controllerCode.AppendLine("        }");


            //TODO: Need To Discuss About Usage
            // Header table relationship methods
            //if (table.HeaderTableId > 0)
            //{
            //    foreach (var field in AddEditFields)
            //    {
            //        if (field.TypeName == "dropdown")
            //        {
            //            controllerCode.AppendLine($"        [HttpGet(\"getby{table.HeaderTableName}Id/{{id}}\")]");
            //            controllerCode.AppendLine($"        public async Task<IActionResult> Get{table.Name}By{table.HeaderTableName}Id({returnType} id)");
            //            controllerCode.AppendLine("        {");
            //            controllerCode.AppendLine("            try");
            //            controllerCode.AppendLine("            {");
            //            controllerCode.AppendLine($"               var response = await _mediator.Send(new Get{table.Name}By{table.HeaderTableName}IdQuery(id));");
            //            //controllerCode.AppendLine($"                var response = await _context.Get{table.Name}By{table.HeaderTableName}Id(id);");
            //            controllerCode.AppendLine("                if (response == null)");
            //            controllerCode.AppendLine("                {");
            //            controllerCode.AppendLine("                    return NotFound($\"{nameof(response)} not found.\");");
            //            controllerCode.AppendLine("                }");
            //            controllerCode.AppendLine("                return Ok(response);");
            //            controllerCode.AppendLine("            }");
            //            controllerCode.AppendLine("            catch (Exception ex)");
            //            controllerCode.AppendLine("            {");
            //            controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
            //            controllerCode.AppendLine("            }");
            //            controllerCode.AppendLine("        }");

            //        }
            //    }

                //controllerCode.AppendLine();
                //controllerCode.AppendLine($"        /// <summary>");
                //controllerCode.AppendLine($"        /// Gets {table.Name} by {table.HeaderTableName} ID");
                //controllerCode.AppendLine($"        /// </summary>");
                //controllerCode.AppendLine($"        /// <param name=\"id\">The {table.HeaderTableName} ID</param>");
                ////controllerCode.AppendLine($"        [Authorize]");
                //controllerCode.AppendLine($"        [HttpGet(\"by-{table.HeaderTableName.ToLower()}/{{id}}\")]");
                //controllerCode.AppendLine($"        public async Task<IActionResult> Get{table.Name}By{table.HeaderTableName}Id(int id,int skip,int take)");
                //controllerCode.AppendLine("        {");
                //controllerCode.AppendLine("            try");
                //controllerCode.AppendLine("            {");
                //controllerCode.AppendLine($"                var response = await _context.Get{table.Name}By{table.HeaderTableName}Id(id,skip,take);");
                //controllerCode.AppendLine("                if (response == null)");
                //controllerCode.AppendLine("                {");
                //controllerCode.AppendLine("                    return NotFound();");
                //controllerCode.AppendLine("                }");
                //controllerCode.AppendLine("                return Ok(response);");
                //controllerCode.AppendLine("            }");
                //controllerCode.AppendLine("            catch (Exception ex)");
                //controllerCode.AppendLine("            {");
                //controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
                //controllerCode.AppendLine("            }");
                //controllerCode.AppendLine("        }");
            //}

            if (FormList.Any(x => x.IsAddToList == true))
            {
                controllerCode.AppendLine("         /// <summary>");
                controllerCode.AppendLine($"        /// Add selected row of {modelName}s to list");
                controllerCode.AppendLine("         /// </summary>");
                controllerCode.AppendLine("         [HttpPost(\"addtolist\")]");
                controllerCode.AppendLine($"        public async Task<IActionResult> AddTo{modelName}List([FromBody] AddToList{modelName}Model " + modelName.ToLower() + ")");
                controllerCode.AppendLine("         {");
                controllerCode.AppendLine($"             if ({modelName.ToLower()}.{modelName}Ids == null || {modelName.ToLower()}.{modelName}Ids.Count == 0)");
                controllerCode.AppendLine($"                return BadRequest(\"No {modelName.ToLower()}s selected\");");
                controllerCode.AppendLine("              try");
                controllerCode.AppendLine("                 {");
                //controllerCode.AppendLine($"                     if ({modelName.ToLower()}.{modelName}Ids == null || {modelName.ToLower()}.{modelName}Ids.Count == 0)");
                //controllerCode.AppendLine($"                      return NotFound(\"No {modelName.ToLower()}s selected\");");
                //controllerCode.AppendLine("");
                controllerCode.AppendLine($"                      var message = await _mediator.Send(new AddTo{modelName}ListCommand({modelName.ToLower()}.{modelName}Ids));");
                //controllerCode.AppendLine($"                      var message = await _context.Add{modelName}sToList({modelName.ToLower()}.{modelName}Ids);");
                controllerCode.AppendLine("                      return Ok(message);");
                controllerCode.AppendLine("                  }");
                controllerCode.AppendLine("             catch (Exception ex)");
                controllerCode.AppendLine("                  {");
                controllerCode.AppendLine("                     Log.Error(ex, \" Exception in {Method} | RequestId: {RequestId}\",");
                controllerCode.AppendLine("                     MethodBase.GetCurrentMethod()?.Name ?? \"UnknownMethod\",");
                controllerCode.AppendLine("                     HttpContext?.TraceIdentifier ?? \"N/A\");");
                controllerCode.AppendLine("                     return StatusCode(500, ex.Message);");
                //controllerCode.AppendLine("                     return StatusCode(500, $\"Unexpected error: {ex.Message}\");");
                controllerCode.AppendLine("                  }");
                controllerCode.AppendLine("         }");
                controllerCode.AppendLine("");

                // GetSelectedSites action
                controllerCode.AppendLine("             /// <summary>");
                controllerCode.AppendLine($"             /// Gets selected {modelName}s from list");
                controllerCode.AppendLine("             /// </summary>");
                controllerCode.AppendLine($"             [HttpGet(\"selected{modelName.ToLower()}s\")]");
                controllerCode.AppendLine($"             public async Task<IActionResult> GetSelected{modelName}s()");
                controllerCode.AppendLine("             {");
                controllerCode.AppendLine("                 try");
                controllerCode.AppendLine("                    {");
                controllerCode.AppendLine($"                        var result = await _mediator.Send(new GetSelected{modelName}sQuery());");
                //controllerCode.AppendLine($"                        var result = await _context.GetSelected{modelName}s();");
                controllerCode.AppendLine("                         return Ok(result);");
                controllerCode.AppendLine("                     }");
                controllerCode.AppendLine("                 catch (Exception ex)");
                controllerCode.AppendLine("                    {");
                controllerCode.AppendLine("                     Log.Error(ex, \" Exception in {Method} | RequestId: {RequestId}\",");
                controllerCode.AppendLine("                     MethodBase.GetCurrentMethod()?.Name ?? \"UnknownMethod\",");
                controllerCode.AppendLine("                     HttpContext?.TraceIdentifier ?? \"N/A\");");
                controllerCode.AppendLine("                        return StatusCode(500, ex.Message);");
                controllerCode.AppendLine("                     }");
                controllerCode.AppendLine("             }");
                controllerCode.AppendLine("");

                // ClearList action
                controllerCode.AppendLine("");
                controllerCode.AppendLine("             /// <summary>");
                controllerCode.AppendLine($"            /// clearList  from {modelName}  ");
                controllerCode.AppendLine("             /// </summary>");
                controllerCode.AppendLine("             [HttpDelete(\"clearlist\")]");
                controllerCode.AppendLine("             public async Task<IActionResult> ClearList()");
                controllerCode.AppendLine("             {");
                controllerCode.AppendLine("                 try");
                controllerCode.AppendLine("                     {");
                controllerCode.AppendLine($"                        var result = await _mediator.Send(new Clear{modelName}ListCommand());");
                //controllerCode.AppendLine("                        var result = await _context.ClearList();");
                controllerCode.AppendLine("                        return Ok(result);");
                controllerCode.AppendLine("                      }");
                controllerCode.AppendLine("                 catch (Exception ex)");
                controllerCode.AppendLine("                     {");
                controllerCode.AppendLine("                        Log.Error(ex, \" Exception in {Method} | RequestId: {RequestId}\",");
                controllerCode.AppendLine("                        MethodBase.GetCurrentMethod()?.Name ?? \"UnknownMethod\",");
                controllerCode.AppendLine("                        HttpContext?.TraceIdentifier ?? \"N/A\");");
                controllerCode.AppendLine("                        return StatusCode(500, ex.Message);");
                controllerCode.AppendLine("                     }");
                controllerCode.AppendLine("             }");

            }

            //            foreach (var field in AddEditFields)
            //            {
            //                //if (!string.IsNullOrEmpty(field.ParentFieldName) && field.ParentSourceTblName != table.HeaderTableName)
            //                //{

            //            }
            // Parent field relationship methods
            foreach (var field in AddEditFields)
            {
                if (!string.IsNullOrEmpty(field.ParentFieldName) && field.ParentSourceTblName != field.SourceHeaderTableName && field.IsLazyLoaded == true)
                {
                    controllerCode.AppendLine();
                    controllerCode.AppendLine($"        /// <summary>");
                    controllerCode.AppendLine($"        /// Gets {field.SourceTableName} by {field.ParentFieldName}");
                    controllerCode.AppendLine($"        /// </summary>");
                    controllerCode.AppendLine($"        /// <param name=\"id\">The {field.ParentFieldName} ID</param>");
                    //controllerCode.AppendLine($"        [Authorize]");
                    controllerCode.AppendLine($"        [HttpGet(\"/{field.TableName?.ToLower() ?? ""}/by-{field.ParentFieldName?.ToLower() ?? ""}/{{id}}\")]");
                    controllerCode.AppendLine($"        public async Task<IActionResult> Get{field.SourceTableName}By{field.ParentFieldName}({returnType} id,int skip,int take)");
                    controllerCode.AppendLine("        {");
                    controllerCode.AppendLine("            try");
                    controllerCode.AppendLine("            {");
                    controllerCode.AppendLine($"                var response = await _context.Get{field.SourceTableName}By{field.ParentFieldName}Id(id,skip,take);");
                    controllerCode.AppendLine("                if (response == null)");
                    controllerCode.AppendLine("                {");
                    controllerCode.AppendLine("                    return NotFound();");
                    controllerCode.AppendLine("                }");
                    controllerCode.AppendLine("                return Ok(response);");
                    controllerCode.AppendLine("            }");
                    controllerCode.AppendLine("            catch (Exception ex)");
                    controllerCode.AppendLine("            {");
                    controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
                    controllerCode.AppendLine("            }");
                    controllerCode.AppendLine("        }");
                }
                else if (!string.IsNullOrEmpty(field.ParentFieldName) && field.ParentSourceTblName == field.SourceTableName)
                {
                    controllerCode.AppendLine($"        [HttpGet(\"getby{field.SourceTableName}/{{id}}\")]");
                    controllerCode.AppendLine($"        public async Task<IActionResult> Get{field.SourceTableName}By{field.ParentFieldName}({returnType} id)");
                    controllerCode.AppendLine("        {");
                    controllerCode.AppendLine("            try");
                    controllerCode.AppendLine("            {");
                    controllerCode.AppendLine($"                var response = await _context.Get{field.SourceTableName}By{field.ParentFieldName}(id);");
                    controllerCode.AppendLine("                if (response == null)");
                    controllerCode.AppendLine("                {");
                    controllerCode.AppendLine("                    return NotFound($\"{nameof(response)} not found.\");");
                    controllerCode.AppendLine("                }");
                    controllerCode.AppendLine("                return Ok(response);");
                    controllerCode.AppendLine("            }");
                    controllerCode.AppendLine("            catch (Exception ex)");
                    controllerCode.AppendLine("            {");
                    controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
                    controllerCode.AppendLine("            }");
                    controllerCode.AppendLine("        }");

                }

            }

            // Hierarchical structure method
            if (table.IsHierarchical)
            {
                controllerCode.AppendLine();
                controllerCode.AppendLine($"        /// <summary>");
                controllerCode.AppendLine($"        /// Gets hierarchical structure of {modelName}");
                controllerCode.AppendLine($"        /// </summary>");
                //controllerCode.AppendLine($"        [Authorize]");
                controllerCode.AppendLine("        [HttpGet(\"hierarchy\")]");
                controllerCode.AppendLine($"        public async Task<IActionResult> GetHierarchyAsync()");
                controllerCode.AppendLine("        {");
                controllerCode.AppendLine("            try");
                controllerCode.AppendLine("            {");
                controllerCode.AppendLine("                var result = await _mediator.Send(new GetHierarchyQuery());");
                //controllerCode.AppendLine($"                var result = await _context.GetHierarchyAsync();");
                controllerCode.AppendLine("                return Ok(result);");
                controllerCode.AppendLine("            }");
                controllerCode.AppendLine("            catch (Exception ex)");
                controllerCode.AppendLine("            {");
                controllerCode.AppendLine("                return StatusCode(500, ex.Message);");
                controllerCode.AppendLine("            }");
                controllerCode.AppendLine("        }");

                controllerCode.AppendLine($" [HttpPut(\"{{id}}/removechild\")]");
                controllerCode.AppendLine($" public async Task<IActionResult> RemoveChild{table.Name}({returnType} id)");
                controllerCode.AppendLine(" {");                
                string defaultId = returnType == "Guid" ? "Guid.Empty" : $"({returnType})0";
                controllerCode.AppendLine($"         if (id == {defaultId})");
                controllerCode.AppendLine("         {");
                controllerCode.AppendLine("             return NotFound(new { message = \"Invalid ID provided.\" });");
                controllerCode.AppendLine("         }");
                controllerCode.AppendLine("");
                controllerCode.AppendLine($"         var result = await _context.RemoveChild{table.Name}(id);");               
                controllerCode.AppendLine("             return Ok(result);");           
                controllerCode.AppendLine(" }");
            }

            //// Form-specific API methods
            foreach (var formItem in FormList)
            {
                controllerCode.AppendLine();
                controllerCode.AppendLine($"        /// <summary>");
                controllerCode.AppendLine($"        /// Saves {modelName} for {formItem.Name} form with validation");
                controllerCode.AppendLine($"        /// </summary>");
                //controllerCode.AppendLine($"        [Authorize]");
                controllerCode.AppendLine($"        [HttpPost(\"/forms/{formItem.Name?.ToLower()}\")]");
                controllerCode.AppendLine($"        public async Task<{responseClassName}> Save{formItem.Name}({modelName}Model {modelName.ToLower()})");
                controllerCode.AppendLine("        {");
                controllerCode.AppendLine($"            if ({modelName.ToLower()} == null)");
                controllerCode.AppendLine("            {");
                controllerCode.AppendLine(
                     returnType == "Guid"
                         ? $"                return new {responseClassName} {{ Id = Guid.Empty, Message = \"{modelName} data is null.\" }};"
                         : $"                return new {responseClassName} {{ Id = ({returnType}) 0, Message = \"{modelName} data is null.\" }};"
                 );
                controllerCode.AppendLine("            }");

                var hasSignatureField = AddEditFields.Where(f => f.TypeName?.ToLower() == "signature");

                if (hasSignatureField.Any())
                {
                    foreach (var field in hasSignatureField)
                    {
                        var fieldName = field.Name;

                        controllerCode.AppendLine($"            // Convert base64 to byte[] if present for: {fieldName}");
                        controllerCode.AppendLine($"            if (!string.IsNullOrEmpty({modelName.ToLower()}.{fieldName}Base64))");
                        controllerCode.AppendLine("            {");
                        controllerCode.AppendLine($"                if ({modelName.ToLower()}.{fieldName}Base64.StartsWith(\"data:image\"))");
                        controllerCode.AppendLine("                {");
                        controllerCode.AppendLine($"                    var base64 = {modelName.ToLower()}.{fieldName}Base64.Split(',')[1];");
                        controllerCode.AppendLine($"                    {modelName.ToLower()}.{fieldName} = Convert.FromBase64String(base64);");
                        controllerCode.AppendLine("                }");
                        controllerCode.AppendLine("            }");
                    }
                }


                controllerCode.AppendLine();
                controllerCode.AppendLine($"            string validationResult = await _rule.ValidateAllRule({modelName.ToLower()} ,\"{formItem.Name}\");");
                controllerCode.AppendLine("            if (validationResult != \"Validation passed\")");
                controllerCode.AppendLine("            {");
                controllerCode.AppendLine(
                   returnType == "Guid"
                       ? $"           return new {responseClassName} {{ Id = Guid.Empty, Message = validationResult }};"
                       : $"           return new {responseClassName} {{ Id = ({returnType}) 0, Message = validationResult }};"
               );
                controllerCode.AppendLine("            }");
                controllerCode.AppendLine();
                foreach (var field in AddEditFields)
                {
                    if (field.TypeName != null && field.TypeName.ToLower() == "image")
                    {


                        var fieldName = string.IsNullOrWhiteSpace(field.Name)
    ? ""
    : char.ToUpper(field.Name.Trim()[0]) + field.Name.Trim().Substring(1).ToLower();
                        //controllerCode.AppendLine();
                        //controllerCode.AppendLine("        // ✅ Save image to wwwroot/EditedImage and store path");
                        //controllerCode.AppendLine("        if (!string.IsNullOrEmpty(" + modelName.ToLower() + ".ImageBase64))");
                        //controllerCode.AppendLine("        {");
                        //controllerCode.AppendLine("            try");
                        //controllerCode.AppendLine("            {");
                        //controllerCode.AppendLine("                string mimeType = \"\";");
                        //controllerCode.AppendLine("                if (" + modelName.ToLower() + ".ImageBase64.StartsWith(\"data:image/jpeg\"))");
                        //controllerCode.AppendLine("                    mimeType = \"jpeg\";");
                        //controllerCode.AppendLine("                else if (" + modelName.ToLower() + ".ImageBase64.StartsWith(\"data:image/jpg\"))");
                        //controllerCode.AppendLine("                    mimeType = \"jpg\";");
                        //controllerCode.AppendLine("                else if (" + modelName.ToLower() + ".ImageBase64.StartsWith(\"data:image/png\"))");
                        //controllerCode.AppendLine("                    mimeType = \"png\";");
                        //controllerCode.AppendLine("                else");
                        //controllerCode.AppendLine("                    return new CreationResponse { Id = 0, Message = \"Only JPEG, JPG, and PNG image formats are allowed.\" };");
                        //controllerCode.AppendLine();
                        //controllerCode.AppendLine("                string folderPath = Path.Combine(_env.WebRootPath, \"EditedImage\");");
                        //controllerCode.AppendLine("                if (!Directory.Exists(folderPath))");
                        //controllerCode.AppendLine("                    Directory.CreateDirectory(folderPath);");
                        //controllerCode.AppendLine();
                        //controllerCode.AppendLine("                string fileExtension = mimeType == \"jpeg\" || mimeType == \"jpg\" ? \".jpg\" : \".png\";");
                        //controllerCode.AppendLine("                string fileName = \"Edited_\" + Guid.NewGuid().ToString(\"N\") + fileExtension;");
                        //controllerCode.AppendLine("                string physicalPath = Path.Combine(folderPath, fileName);");
                        //controllerCode.AppendLine("                string relativePath = $\"/EditedImage/{fileName}\";");
                        //controllerCode.AppendLine();
                        //controllerCode.AppendLine("                var base64Data = " + modelName.ToLower() + ".ImageBase64.Contains(\",\")");
                        //controllerCode.AppendLine("                    ? " + modelName.ToLower() + ".ImageBase64.Split(',')[1]");
                        //controllerCode.AppendLine("                    : " + modelName.ToLower() + ".ImageBase64;");
                        //controllerCode.AppendLine();
                        //controllerCode.AppendLine("                byte[] imageBytes = Convert.FromBase64String(base64Data);");
                        //controllerCode.AppendLine("                await System.IO.File.WriteAllBytesAsync(physicalPath, imageBytes);");
                        //controllerCode.AppendLine();
                        //controllerCode.AppendLine("                " + modelName.ToLower() + ".Image = relativePath;");
                        //controllerCode.AppendLine("            }");
                        //controllerCode.AppendLine("            catch (Exception ex)");
                        //controllerCode.AppendLine("            {");
                        //controllerCode.AppendLine("                return new CreationResponse { Id = 0, Message = \"Image processing failed: \" + ex.Message };");
                        //controllerCode.AppendLine("            }");
                        //controllerCode.AppendLine("        }");
                        controllerCode.AppendLine($"if (!string.IsNullOrEmpty({modelName.ToLower()}.{fieldName}ImageBase64))");
                        controllerCode.AppendLine("{");
                        controllerCode.AppendLine("    try");
                        controllerCode.AppendLine("    {");
                        controllerCode.AppendLine($"        var base64Data = {modelName.ToLower()}.{fieldName}ImageBase64.Contains(\",\")");
                        controllerCode.AppendLine($"            ? {modelName.ToLower()}.{fieldName}ImageBase64.Split(',')[1]");
                        controllerCode.AppendLine($"            : {modelName.ToLower()}.{fieldName}ImageBase64;");
                        controllerCode.AppendLine("");
                        controllerCode.AppendLine($"        {modelName.ToLower()}.{fieldName} = Convert.FromBase64String(base64Data);");
                        controllerCode.AppendLine("    }");
                        controllerCode.AppendLine("    catch (Exception ex)");
                        controllerCode.AppendLine("    {");
                        controllerCode.AppendLine($"        return new {responseClassName} {{ Id = 0, Message = \"Image processing failed: \" + ex.Message }};");
                        controllerCode.AppendLine("    }");
                        controllerCode.AppendLine("}");

                    }
                }
                controllerCode.AppendLine($"                var result = await _mediator.Send(new Save{formItem.Name}Command({modelName.ToLower()}));");
                //controllerCode.AppendLine($"            var result = await _context.Save{formItem.Name}({modelName.ToLower()});");




                // Add this line before the foreach loop to declare reportNames
                controllerCode.AppendLine("    List<string> reportNames = new(); // List to store generated report names");

                // Declare redirectUrl if any action is a valid ViewReport
                bool hasViewReport = formAction.Any(a => a.ViewReport == true && a.ActionID == 2 && a.Report > 0);
                if (hasViewReport)
                {
                    controllerCode.AppendLine("    string? redirectUrl = null;");
                }

                int actionIndex = 0;
                foreach (var action in formAction)
                {
                    bool isGenerateReportAction = action.ActionID == 2; // Generate Report Action
                    bool isSendEmailAction = action.ActionID == 3; // Send Email Action
                    bool isValidReport = action.Report > 0;
                    bool isViewReport = action.ViewReport == true && isGenerateReportAction && isValidReport;
                    bool isEmailAttachment = action.EmailAttachment == true && isGenerateReportAction && isValidReport;
                    bool isEmail = !string.IsNullOrEmpty(action.EmailTemplate);

                    bool shouldRenderBlock = (isGenerateReportAction && isValidReport) || (isSendEmailAction && isEmail);

                    if (shouldRenderBlock)
                    {
                        controllerCode.AppendLine($"    // === Begin Action Block {actionIndex + 1} - {action.ActionName} ===");
                        controllerCode.AppendLine("    {");

                       
                        // === GENERATE REPORT ACTION (ActionID = 2) ===
           
                        if (isGenerateReportAction && isValidReport)
                        {
                            // Generate the report PDF
                            controllerCode.AppendLine($"        string reportName = \"{action.Report}.trdx\";");
                            controllerCode.AppendLine($"        string pdfFileName = \"{action.Report}.pdf\";");
                            controllerCode.AppendLine("        string pdfSavePath = Path.Combine(_reportsPath, pdfFileName);");
                            controllerCode.AppendLine("");
                            controllerCode.AppendLine("        var reportSource = _telerikReportsController.LoadReport(reportName, result.Id);");
                            controllerCode.AppendLine("        var reportProcessor = new ReportProcessor();");
                            controllerCode.AppendLine("        var renderingResult = reportProcessor.RenderReport(\"PDF\", reportSource, null);");
                            controllerCode.AppendLine("");
                            controllerCode.AppendLine("        if (renderingResult.HasErrors)");
                            controllerCode.AppendLine("        {");
                            controllerCode.AppendLine("            var errors = string.Join(\"; \", renderingResult.Errors.Select(e => e.ToString()));");
                            controllerCode.AppendLine("            Console.WriteLine($\"Error rendering report: {errors}\");");
                            controllerCode.AppendLine("        }");
                            controllerCode.AppendLine("        else");
                            controllerCode.AppendLine("        {");
                            controllerCode.AppendLine("            var pdfBytes = renderingResult.DocumentBytes;");
                            controllerCode.AppendLine("            await System.IO.File.WriteAllBytesAsync(pdfSavePath, pdfBytes);");
                            controllerCode.AppendLine("        }");

                            // Handle ViewReport option
                            if (isViewReport)
                            {
                                controllerCode.AppendLine("        // === Generate Redirect URL for Report Viewer ===");
                                controllerCode.AppendLine("        redirectUrl = $\"{Request.Scheme}://{Request.Host}/reportviewer?report={reportName}\";");
                            }

                            controllerCode.AppendLine("        reportNames.Add(reportName);");

                            // Handle EmailAttachment option (send email with report)
                            if (isEmailAttachment && isEmail)
                            {
                                controllerCode.AppendLine("");
                                controllerCode.AppendLine("        // === Send Email with Report Attachment ===");
                                controllerCode.AppendLine($"        string emailBody = await _context.GetEmailBodyByTemplateId({action.EmailTemplate});");
                                controllerCode.AppendLine("        string finalBody = WebUtility.HtmlDecode(emailBody ?? \"Default body if not found\");");

                                // Determine recipients
                                if (action.EmailOptionId == 4) // Role-based
                                {
                                    controllerCode.AppendLine($"        string allEmailByRoles = await _context.GetAllEmailsByRole(\"{action.RoleId}\");");
                                    controllerCode.AppendLine("        List<EmailRecipient> recipients = allEmailByRoles");
                                    controllerCode.AppendLine("            .Split(',', StringSplitOptions.RemoveEmptyEntries)");
                                    controllerCode.AppendLine("            .Select(email => new EmailRecipient(email.Trim()))");
                                    controllerCode.AppendLine("            .ToList();");
                                }
                                else if (action.EmailOptionId == 5) // JWT-based
                                {
                                    controllerCode.AppendLine("        var authHeader = Request.Headers[\"Authorization\"].FirstOrDefault();");
                                    controllerCode.AppendLine("        var token = authHeader?.Substring(\"Bearer \".Length).Trim();");
                                    controllerCode.AppendLine("        var jwtHandler = new JwtSecurityTokenHandler();");
                                    controllerCode.AppendLine("        var jwtToken = jwtHandler.ReadJwtToken(token);");
                                    controllerCode.AppendLine("        var email = jwtToken.Claims.FirstOrDefault(c => c.Type == \"email\")?.Value;");
                                    controllerCode.AppendLine("        List<EmailRecipient> recipients = new() { new(email) };");
                                }
                                else // Direct emails
                                {
                                    controllerCode.AppendLine("        List<EmailRecipient> recipients = new();");
                                    controllerCode.AppendLine($"        var emailList = \"{action.EmailTo}\";");
                                    controllerCode.AppendLine("        if (!string.IsNullOrWhiteSpace(emailList))");
                                    controllerCode.AppendLine("        {");
                                    controllerCode.AppendLine("            recipients = emailList");
                                    controllerCode.AppendLine("                .Split(',', StringSplitOptions.RemoveEmptyEntries)");
                                    controllerCode.AppendLine("                .Select(email => new EmailRecipient(email.Trim()))");
                                    controllerCode.AppendLine("                .ToList();");
                                    controllerCode.AppendLine("        }");
                                }

                                // Send email with report attachment
                                if (action.IndividualEmail == true)
                                {
                                    controllerCode.AppendLine("        foreach (var recipient in recipients)");
                                    controllerCode.AppendLine("        {");
                                    controllerCode.AppendLine("            var mailModel = new MailModel");
                                    controllerCode.AppendLine("            {");
                                    controllerCode.AppendLine("                emailRecipient1 = recipient,");
                                    controllerCode.AppendLine($"                Subject = \"{action.EmailSubject}\",");
                                    controllerCode.AppendLine("                Body = finalBody,");
                                    controllerCode.AppendLine("                Attachments = new List<string> { pdfSavePath }");
                                    controllerCode.AppendLine("            };");
                                    controllerCode.AppendLine("            await mailService.SendSMTPEmailAsync(mailModel);");
                                    controllerCode.AppendLine("        }");
                                }
                                else
                                {
                                    controllerCode.AppendLine("        if (recipients.Any())");
                                    controllerCode.AppendLine("        {");
                                    controllerCode.AppendLine("            var mailModel = new MailModel");
                                    controllerCode.AppendLine("            {");
                                    controllerCode.AppendLine("                emailRecipient = recipients,");
                                    controllerCode.AppendLine($"                Subject = \"{action.EmailSubject}\",");
                                    controllerCode.AppendLine("                Body = finalBody,");
                                    controllerCode.AppendLine("                Attachments = new List<string> { pdfSavePath }");
                                    controllerCode.AppendLine("            };");
                                    controllerCode.AppendLine("            await mailService.SendSMTPEmailAsync(mailModel);");
                                    controllerCode.AppendLine("        }");
                                }
                            }
                        }
                        
                        // === SEND EMAIL ACTION ONLY (ActionID = 3) ===
                    
                        else if (isSendEmailAction && isEmail)
                        {
                            controllerCode.AppendLine("        // === Fetch EmailTemplate Body Dynamically ===");
                            controllerCode.AppendLine($"        string emailBody = await _context.GetEmailBodyByTemplateId({action.EmailTemplate});");
                            controllerCode.AppendLine("        string finalBody = WebUtility.HtmlDecode(emailBody ?? \"Default body if not found\");");

                            // Determine recipients
                            if (action.EmailOptionId == 4) // Role-based
                            {
                                controllerCode.AppendLine($"        string allEmailByRoles = await _context.GetAllEmailsByRole(\"{action.RoleId}\");");
                                controllerCode.AppendLine("        List<EmailRecipient> recipients = allEmailByRoles");
                                controllerCode.AppendLine("            .Split(',', StringSplitOptions.RemoveEmptyEntries)");
                                controllerCode.AppendLine("            .Select(email => new EmailRecipient(email.Trim()))");
                                controllerCode.AppendLine("            .ToList();");
                            }
                            else if (action.EmailOptionId == 5) // JWT-based
                            {
                                controllerCode.AppendLine("        var authHeader = Request.Headers[\"Authorization\"].FirstOrDefault();");
                                controllerCode.AppendLine("        var token = authHeader?.Substring(\"Bearer \".Length).Trim();");
                                controllerCode.AppendLine("        var jwtHandler = new JwtSecurityTokenHandler();");
                                controllerCode.AppendLine("        var jwtToken = jwtHandler.ReadJwtToken(token);");
                                controllerCode.AppendLine("        var email = jwtToken.Claims.FirstOrDefault(c => c.Type == \"email\")?.Value;");
                                controllerCode.AppendLine("        List<EmailRecipient> recipients = new() { new(email) };");
                            }
                            else // Direct emails
                            {
                                controllerCode.AppendLine("        List<EmailRecipient> recipients = new();");
                                controllerCode.AppendLine($"        var emailList = \"{action.EmailTo}\";");
                                controllerCode.AppendLine("        if (!string.IsNullOrWhiteSpace(emailList))");
                                controllerCode.AppendLine("        {");
                                controllerCode.AppendLine("            recipients = emailList");
                                controllerCode.AppendLine("                .Split(',', StringSplitOptions.RemoveEmptyEntries)");
                                controllerCode.AppendLine("                .Select(email => new EmailRecipient(email.Trim()))");
                                controllerCode.AppendLine("                .ToList();");
                                controllerCode.AppendLine("        }");
                            }

                            // Send individual or bulk emails (NO REPORT ATTACHMENT)
                            if (action.IndividualEmail == true)
                            {
                                controllerCode.AppendLine("        foreach (var recipient in recipients)");
                                controllerCode.AppendLine("        {");
                                controllerCode.AppendLine("            var mailModel = new MailModel");
                                controllerCode.AppendLine("            {");
                                controllerCode.AppendLine("                emailRecipient1 = recipient,");
                                controllerCode.AppendLine($"                Subject = \"{action.EmailSubject}\",");
                                controllerCode.AppendLine("                Body = finalBody,");
                                controllerCode.AppendLine("                Attachments = new List<string>()"); // NO attachments
                                controllerCode.AppendLine("            };");
                                controllerCode.AppendLine("            await mailService.SendSMTPEmailAsync(mailModel);");
                                controllerCode.AppendLine("        }");
                            }
                            else
                            {
                                controllerCode.AppendLine("        if (recipients.Any())");
                                controllerCode.AppendLine("        {");
                                controllerCode.AppendLine("            var mailModel = new MailModel");
                                controllerCode.AppendLine("            {");
                                controllerCode.AppendLine("                emailRecipient = recipients,");
                                controllerCode.AppendLine($"                Subject = \"{action.EmailSubject}\",");
                                controllerCode.AppendLine("                Body = finalBody,");
                                controllerCode.AppendLine("                Attachments = new List<string>()"); // NO attachments
                                controllerCode.AppendLine("            };");
                                controllerCode.AppendLine("            await mailService.SendSMTPEmailAsync(mailModel);");
                                controllerCode.AppendLine("        }");
                            }
                        }

                        controllerCode.AppendLine("    }"); // End Action Block
                        actionIndex++;
                    }
                }





                // Add the proper return statement with ExtraData
                controllerCode.AppendLine("    if (result != null)");
                controllerCode.AppendLine("    {");
                controllerCode.AppendLine($"        return new {responseClassName}");
                controllerCode.AppendLine("        {");
                controllerCode.AppendLine($"            Id =  ({returnType}) result.Id,");
                controllerCode.AppendLine("            Message = \"Applied successfully\",");
                controllerCode.AppendLine("            ExtraData = reportNames");
                controllerCode.AppendLine("        };");
                controllerCode.AppendLine("    }");
                //controllerCode.AppendLine("    return new CreationResponse { Id = 0, Message = \"Failed to create bus.\" };");

                controllerCode.AppendLine("            if (result != null)");
                controllerCode.AppendLine("            {");
                controllerCode.AppendLine($"                return new {responseClassName} {{ Id = ({returnType}) result.Id, Message = \"Applied successfully\" }};");
                controllerCode.AppendLine("            }");
                controllerCode.AppendLine("            else");
                controllerCode.AppendLine("            {");

                string defaultId = returnType == "Guid" ? "Guid.Empty" : $"({returnType}) 0";
                controllerCode.AppendLine(
                    $"           return new {responseClassName} {{ Id = {defaultId}, Message = \"Failed to create {modelName.ToLower()}.\" }};"
                );
                controllerCode.AppendLine("            }");
                controllerCode.AppendLine("        }");
            }



            // Validation methods and rule methods would continue here...
            // [Rest of your existing validation logic]

            //// --- Validate{FormName} Rules Method ---
            //var ruleGroups = RuleList
            //  .Where(r => r.FormId == formItem.ID)
            //  .GroupBy(r => r.RuleId);

            //controllerCode.AppendLine($"        private async Task<string> Validate{formItem.Name}({modelName} {modelName.ToLower()})");
            //controllerCode.AppendLine("        {");
            //controllerCode.AppendLine("            var errors = new List<string>();");

            //foreach (var group in ruleGroups)
            //{
            //    // Fetch rule name directly from RuleList
            //    var ruleId = RuleList.FirstOrDefault(r => r.RuleId == group.Key);
            //    var ruleName = ruleId != null ? ruleId.RuleName : $"UnknownRule_{group.Key}";
            //    var newname = ruleName.Trim().Replace(" ", "");
            //    newname = char.ToLower(newname[0]) + newname.Substring(1);
            //    var methodName = ruleName.Trim().Replace(" ", "_");
            //    methodName = char.ToUpper(methodName[0]) + methodName.Substring(1);


            //    if (ruleId.ValidateCriteria.HasValue && (CriteriaEnum)ruleId.ValidateCriteria == CriteriaEnum.All)
            //    //if ((CriteriaEnum)ruleId.ValidateCriteria == CriteriaEnum.All)
            //    {
            //        controllerCode.AppendLine($"  var {newname} = {methodName}({modelName.ToLower()});");
            //        controllerCode.AppendLine($"if (!{newname}.All(v => v.Success))");
            //        controllerCode.AppendLine("{");
            //        controllerCode.AppendLine($"    errors.AddRange({newname}.Where(e => !e.Success).Select(e => e.FailMessage));");
            //        controllerCode.AppendLine("}");
            //    }
            //    else
            //    {
            //        controllerCode.AppendLine($"  var {newname} = {methodName}({modelName.ToLower()});");
            //        controllerCode.AppendLine($"if (!{newname}.Any(v => v.Success))");
            //        controllerCode.AppendLine("{");
            //        controllerCode.AppendLine($"    errors.AddRange({newname}.Where(e => !e.Success).Select(e => e.FailMessage));");
            //        controllerCode.AppendLine("}");
            //    }
            //}

            //HashSet<int> ConditionalRuleIds = new HashSet<int>();

            //// --- Rule Methods for each RuleId in this form ---
            //foreach (var group in ruleGroups)
            //{
            //    // Fetch rule name directly from RuleList
            //    var ruleId = RuleList.FirstOrDefault(r => r.RuleId == group.Key);
            //    var ruleName = ruleId != null ? ruleId.RuleName : $"UnknownRule_{group.Key}";
            //    var methodName = ruleName.Trim().Replace(" ", "_");
            //    methodName = char.ToUpper(methodName[0]) + methodName.Substring(1);


            //    controllerCode.AppendLine($"        List<Validation> {methodName}({modelName} {modelName.ToLower()})");
            //    controllerCode.AppendLine("        {");
            //    controllerCode.AppendLine("            var validations = new List<Validation>();");
            //    string indent = "            ";

            //    foreach (var rule in group)
            //    {
            //        EvaluateRule(controllerCode, modelName, rule, group.ToList(), indent, ConditionalRuleIds);
            //    }

            //    controllerCode.AppendLine("            return validations;");
            //    controllerCode.AppendLine("        }");
            //    controllerCode.AppendLine();
            //}

            //controllerCode.AppendLine("            return errors.Any() ? string.Join(\", \", errors) : \"Validation passed\";");
            //controllerCode.AppendLine("        }");
            //controllerCode.AppendLine();

            //// EvaluateRule Method (keeping your existing logic)
            //void EvaluateRule(StringBuilder controllerCode, string modelName, ClientCardViewFields rule, List<ClientCardViewFields> allRules, string indent, HashSet<int> ConditionalRuleIds)
            //{
            //    string condition = "";

            //    foreach (var rule1 in allRules)
            //    {
            //        switch (rule.FieldTypeName)
            //        {
            //            case "int":
            //            case "number":
            //                condition = $"({modelName.ToLower()}.{rule.FieldName} {rule.Operator} {rule.FieldValue})";
            //                break;

            //            case "varchar":
            //            case "string":
            //                condition = $"{modelName.ToLower()}.{rule.FieldName}.{rule.Operator}(\"{rule.FieldValue}\")";
            //                break;

            //            case "bit":
            //            case "bigint":
            //                condition = $"({modelName.ToLower()}.{rule.FieldName} {rule.Operator} {rule.FieldValue})";
            //                break;

            //            case "date":
            //            case "datetime":
            //                condition = $"{modelName.ToLower()}.{rule.FieldName}.{rule.Operator} DateTime.Parse(\"{rule.FieldValue}\")";
            //                break;
            //        }
            //    }

            //    // Your existing conditional rule logic...
            //    if (rule.ConditionalRuleId != 0 && !ConditionalRuleIds.Contains(rule.ConditionalRuleId))
            //    {
            //        ConditionalRuleIds.Add(rule.ConditionalRuleId);
            //        var methodName = rule.ConditionalRuleName.Trim().Replace(" ", "_");

            //        if ((CriteriaEnum)Enum.Parse(typeof(CriteriaEnum), rule.ConditionalRuleValidateCriteria) == CriteriaEnum.All)
            //        {
            //            controllerCode.AppendLine($"{indent}if ({methodName}({modelName.ToLower()}).All(r => r.Success))");
            //        }
            //        else
            //        {
            //            controllerCode.AppendLine($"{indent}if ({methodName}({modelName.ToLower()}).Any(r => r.Success))");
            //        }

            //        controllerCode.AppendLine($"{indent}{{");
            //        controllerCode.AppendLine($"{indent}    if ({condition})");
            //        controllerCode.AppendLine($"{indent}    {{");
            //        controllerCode.AppendLine($"{indent}        validations.Add(new Validation {{ Success = true }});");
            //        controllerCode.AppendLine($"{indent}    }}");
            //        controllerCode.AppendLine($"{indent}    else");
            //        controllerCode.AppendLine($"{indent}    {{");

            //        if (!string.IsNullOrWhiteSpace(rule.FailMessage))
            //        {
            //            controllerCode.AppendLine($"{indent}        validations.Add(new Validation {{ FailMessage = \"{rule.FailMessage}\", Success = false }});");
            //        }
            //        controllerCode.AppendLine($"{indent}    }}");
            //        controllerCode.AppendLine($"{indent}}}");
            //    }

            //    if (rule.ConditionalRuleId == 0 || !ConditionalRuleIds.Contains(rule.ConditionalRuleId))
            //    {
            //        controllerCode.AppendLine($"{indent}if ({condition})");
            //        controllerCode.AppendLine($"{indent}{{");
            //        controllerCode.AppendLine($"{indent}    validations.Add(new Validation {{ Success = true }});");
            //        controllerCode.AppendLine($"{indent}}}");
            //        controllerCode.AppendLine($"{indent}else");
            //        controllerCode.AppendLine($"{indent}{{");

            //        if (!string.IsNullOrWhiteSpace(rule.FailMessage))
            //        {
            //            controllerCode.AppendLine($"{indent}    validations.Add(new Validation {{ FailMessage = \"{rule.FailMessage}\", Success = false }});");
            //        }
            //        controllerCode.AppendLine($"{indent}}}");
            //    }
            //}
            //}

            // Close controller class and namespace
            controllerCode.AppendLine("    }");
            controllerCode.AppendLine("}");

            // Write to file
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.Api\Controllers";

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            string filePath = Path.Combine(directoryPath, $"{modelName}Controller.cs");
            File.WriteAllText(filePath, controllerCode.ToString());

            // Generate checkbox controllers
            foreach (var field in AddEditFields)
            {
                if (field.TypeName == "checkboxgroup" || field.TypeName == "Multiselect")
                {
                    GenerateCheckboxController(table, field, ProjectName, ClientName);
                }

                else if (field.TypeName == "captcha")
                {
                    GenerateCaptchaController(ProjectName, ClientName);
                }
            }
        }
    }
}
