﻿using Entities.Models.ClientBuilderModels.ClientModels;
using System.Collections.Generic;
using System.Text;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateProgramCodeClass
    {
        public  void GenerateProgramCode(List<string> tableNames, string ProjectName, string ClientName, List<ClientCardViewFields> fields, List<ClientForm> formDocEnabled)
        {
            var sb = new StringBuilder();

            sb.AppendLine("using Interfaces;");
            sb.AppendLine("using Microsoft.AspNetCore.Identity;");
            //sb.AppendLine("using Repository;");
            sb.AppendLine("using Microsoft.IdentityModel.Tokens;");
            sb.AppendLine("using System.Text;");
            sb.AppendLine("using Repositories;");
            sb.AppendLine("using System.Reflection;");
            //sb.AppendLine("using static DapperDB.DapperDbContext;");
            sb.AppendLine("using ClientProjectBuilder.Api.Services;");
            sb.AppendLine("using Entities.Models.Services;");
            //sb.AppendLine("using Entities.Models.AppUser;");
            //foreach (var table in tableNames)
            //{
            //    sb.AppendLine($"using BusinessRule.{table};");
            //}
            sb.AppendLine("using Services;");
            sb.AppendLine("using ApplicationDI;");
            sb.AppendLine("using InfrastructureDI;");
            //sb.AppendLine("using Models;");
            //sb.AppendLine("using Infrastructure;");
            //sb.AppendLine("using Infrastructure.Services;");
            //sb.AppendLine("using Models.Services;");
            sb.AppendLine("using Microsoft.AspNetCore.Authentication.JwtBearer;");
            sb.AppendLine("using Microsoft.AspNetCore.Authorization;");           
            sb.AppendLine("using Microsoft.Extensions.DependencyInjection.Extensions;");
            //sb.AppendLine("using DynamicFormBuilder.Services;");
            sb.AppendLine("using Telerik.Reporting.Services;");
            sb.AppendLine("using ClientProjectBuilder.Api.Controllers; ");
            sb.AppendLine("using Dapper;");
            sb.AppendLine();


            sb.AppendLine("");
            sb.AppendLine("var builder = WebApplication.CreateBuilder(args);");
            sb.AppendLine("SqlMapper.AddTypeHandler(new SqlDateOnlyTypeHandler());");
            sb.AppendLine("// Add services to the container.");
            sb.AppendLine("builder.Services.AddControllers().AddNewtonsoftJson();");
            sb.AppendLine("builder.Services.AddMemoryCache();");
            sb.AppendLine("builder.Services.AddHttpClient();");
            sb.AppendLine(" builder.Services.AddScoped<TelerikReportsController>();");
            sb.AppendLine();
            sb.AppendLine();

            sb.AppendLine("// Application DI (MediatR, Behaviors, etc.)");
            sb.AppendLine("builder.Services.AddApplication();");
            sb.AppendLine();
            sb.AppendLine("// Infrastructure DI (DbContext, Repositories, etc.)");
            sb.AppendLine("builder.Services.AddInfrastructure(builder.Configuration);");
            sb.AppendLine("builder.Services.AddHttpContextAccessor();");

            sb.AppendLine("// Configure ReportServiceConfiguration");
            sb.AppendLine("builder.Services.TryAddSingleton<IReportServiceConfiguration>(static sp =>");
            sb.AppendLine("{");
            sb.AppendLine("    var env = sp.GetRequiredService<IWebHostEnvironment>();");
            sb.AppendLine("    var config = sp.GetRequiredService<IConfiguration>();");
            sb.AppendLine("");
            sb.AppendLine("    return new Telerik.Reporting.Services.ReportServiceConfiguration");
            sb.AppendLine("    {");
            sb.AppendLine("        HostAppId = \"MyCustomReportApp\",");
            sb.AppendLine("        Storage = new Telerik.Reporting.Cache.File.FileStorage(),");
            sb.AppendLine("        ReportSourceResolver = new CustomReportSourceResolver(env)");
            sb.AppendLine("    };");
            sb.AppendLine("});");


            sb.AppendLine("// Swagger");
            sb.AppendLine("// Add Swagger/OpenAPI support.");
            sb.AppendLine("builder.Services.AddEndpointsApiExplorer();");
            sb.AppendLine("builder.Services.AddEndpointsApiExplorer();");
            sb.AppendLine("builder.Services.Configure<SmtpSettings>(builder.Configuration.GetSection(\"MailSettings\"));");

            sb.AppendLine("builder.Services.AddSwaggerGen(c =>");
            sb.AppendLine("{");
            sb.AppendLine("     var xmlFile = $\"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml\";");
            sb.AppendLine("     var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);");
            sb.AppendLine("     c.IncludeXmlComments(xmlPath, includeControllerXmlComments: true);");
            sb.AppendLine();
            sb.AppendLine("    // Add Bearer token authentication to Swagger UI");
            sb.AppendLine("    c.AddSecurityDefinition(\"Bearer\", new Microsoft.OpenApi.Models.OpenApiSecurityScheme");
            sb.AppendLine("    {");
            sb.AppendLine("        Name = \"Authorization\",");
            sb.AppendLine("        Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey,");
            sb.AppendLine("        In = Microsoft.OpenApi.Models.ParameterLocation.Header,");
            sb.AppendLine("        Description = \"Enter 'Bearer' followed by a space and your JWT token\",");
            sb.AppendLine("    });");
            sb.AppendLine("    c.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement");
            sb.AppendLine("    {");
            sb.AppendLine("        {");
            sb.AppendLine("            new Microsoft.OpenApi.Models.OpenApiSecurityScheme");
            sb.AppendLine("            {");
            sb.AppendLine("                Reference = new Microsoft.OpenApi.Models.OpenApiReference");
            sb.AppendLine("                {");
            sb.AppendLine("                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,");
            sb.AppendLine("                    Id = \"Bearer\"");
            sb.AppendLine("                }");
            sb.AppendLine("            },");
            sb.AppendLine("            new string[] { }");
            sb.AppendLine("        }");
            sb.AppendLine("    });");
            sb.AppendLine("});");
            sb.AppendLine("");
            //sb.AppendLine("// Register DbContext with scoped lifetime (appropriate for database connections).");
            //sb.AppendLine("builder.Services.AddScoped<DbContext>();");
            //sb.AppendLine("builder.Services.AddHttpContextAccessor();");
            //sb.AppendLine("builder.Services.AddScoped<IUserInfo, UserInfo>();");
            //sb.AppendLine("builder.Services.AddScoped<UserInfo>();");

            //sb.AppendLine("builder.Services.AddScoped<IAppUser, AppUserRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IPasswordHasher<AppUserModel>, PasswordHasher<AppUserModel>>();");
            //sb.AppendLine("builder.Services.AddScoped<IToken, TokenRepository>();");
            //sb.AppendLine("builder.Services.AddTransient<IDynamicMenu, DynamicMenuRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<INotification, NotificationRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IPasswordPolicy, PasswordPolicyRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IEmailTemplate, EmailTemplateRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<ILink, LinkRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IFileIntegration, FileIntegrationRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IFieldDefination, FieldDefinationRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<ITable, TableRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IGenerateReportAction, GenerateReportActionRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IDocument, DocumentRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IDynamicQuery, DynamicQueryRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IRole, RoleRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IReport, ReportRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IReportCategory, ReportCategoryRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IMenuPermission, MenuPermissionRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IAppSetting, AppSettingRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IFormPermission, FormPermissionRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IValueMapper, ValueMapperRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<MailService>();");
            //sb.AppendLine("builder.Services.AddScoped<IKpi, KpiRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IImportProfile, ImportProfileRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IChartConfig, ChartConfigRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IQueryType, QueryTypeRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IPredefinedQueryParameter, PredefinedQueryParameterRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IFieldType, FieldTypeRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IPredefinedQuery, PredefinedQueryRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IResourceString, ResourceStringRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<ISequenceFormat, SequenceFormatRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IPdfReportConfiguration, PdfReportConfigurationRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IDashboardProfile, DashboardProfileRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<ITileLayout, TileLayoutRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IRestPullIntegration, RestPullIntegrationRepository>();");
            //sb.AppendLine("builder.Services.AddScoped<IRestPushIntegration, RestPushIntegrationRepository>();");



            //foreach (var form in formDocEnabled)
            //{
            //    if (form.IsMenuValid)
            //    {
            //        sb.AppendLine($"builder.Services.AddScoped<I{form.Name}Document, {form.Name}DocumentRepository>();");
            //    }
            //}

            //foreach (var table in tableNames)
            //{
            //    sb.AppendLine($"builder.Services.AddScoped<I{table}, {table}Repository>();");
            //    foreach (var field in fields)
            //    {
            //        if (field.TypeId == "checkbox")
            //        {
            //            string mapTableName = $"{table}_{field.FieldName}";
            //            string className = $"{mapTableName}Repository";
            //            sb.AppendLine($"builder.Services.AddScoped<I{className}, {className}>();");
            //        }
            //    }
            //}

            //foreach (var table in tableNames)
            //{
            //    var tableFields = fields.Where(f => f.TableName == table).ToList();

            //    sb.AppendLine($"builder.Services.AddScoped<I{table}, {table}Repository>();");
            //    sb.AppendLine($"builder.Services.AddScoped<{table}Rule>();");

            //    foreach (var field in tableFields.Where(f => f.TypeId == "checkboxgroup" || f.TypeId == "Multiselect"))
            //    {
            //        string mapTableName = $"{table}_{field.FieldName}";
            //        string className = $"{mapTableName}";
            //        sb.AppendLine($"builder.Services.AddScoped<I{className}, {className}Repository>();");
            //    }
            //}

            sb.AppendLine("builder.Services.AddAuthorization(options =>");
            sb.AppendLine("{");

            // Default policy: requires PasswordExpired = false
            sb.AppendLine("    options.DefaultPolicy = new AuthorizationPolicyBuilder()");
            sb.AppendLine("        .RequireAuthenticatedUser()");
            sb.AppendLine("        .RequireClaim(\"PasswordExpired\", \"false\")");
            sb.AppendLine("        .Build();");

            // Expired password policy
            sb.AppendLine();
            sb.AppendLine("    options.AddPolicy(\"AllowWhenPasswordExpired\", policy =>");
            sb.AppendLine("        policy.RequireClaim(\"PasswordExpired\", \"true\"));");

            // New policy: Allow both expired and valid tokens
            sb.AppendLine();
            sb.AppendLine("    options.AddPolicy(\"AllowAllAuthenticated\", policy =>");
            sb.AppendLine("        policy.RequireAuthenticatedUser());");

            sb.AppendLine("});");
            sb.AppendLine("// CORS Policy");
            sb.AppendLine("builder.Services.AddCors(options =>");
            sb.AppendLine("{");
            sb.AppendLine("    options.AddPolicy(\"AllowAll\",");
            sb.AppendLine("        policy => policy");
            sb.AppendLine("            .AllowAnyOrigin()");
            sb.AppendLine("            .AllowAnyMethod()");
            sb.AppendLine("            .AllowAnyHeader());");
            sb.AppendLine("});");
            sb.AppendLine("builder.Services.AddDistributedMemoryCache();");
            sb.AppendLine("builder.Services.AddSession();");
            sb.AppendLine("");
            sb.AppendLine("// JWT Authentication with Token Validation in Database");
            sb.AppendLine("builder.Services.AddSession();");
            sb.AppendLine("builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)");
            sb.AppendLine("    .AddJwtBearer(options =>");
            sb.AppendLine("    {");
            sb.AppendLine("        options.Events = new JwtBearerEvents");
            sb.AppendLine("        {");
            sb.AppendLine("            OnMessageReceived = async context =>");
            sb.AppendLine("            {");
            sb.AppendLine("                var token = context.Request.Headers[\"Authorization\"].FirstOrDefault()?.Split(\" \").Last();");
            sb.AppendLine("                if (!string.IsNullOrEmpty(token))");
            sb.AppendLine("                {");
            sb.AppendLine("                    using var scope = context.HttpContext.RequestServices.CreateScope();");
            sb.AppendLine("                    var tokenRepo = scope.ServiceProvider.GetRequiredService<IToken>();");
            sb.AppendLine("                    bool isValid = await tokenRepo.IsValidTokenAsync(token);");
            sb.AppendLine("                    if (!isValid)");
            sb.AppendLine("                    {");
            sb.AppendLine("                        context.Fail(\"Invalid or expired token.\");");
            sb.AppendLine("                    }");
            sb.AppendLine("                }");
            sb.AppendLine("            }");
            sb.AppendLine("        };");
            sb.AppendLine("        options.TokenValidationParameters = new TokenValidationParameters");
            sb.AppendLine("        {");
            sb.AppendLine("            ValidateIssuer = true,");
            sb.AppendLine("            ValidateAudience = true,");
            sb.AppendLine("            ValidateLifetime = true,");
            sb.AppendLine("            ValidateIssuerSigningKey = true,");
            sb.AppendLine("            ValidIssuer = \"yourdomain.com\",");
            sb.AppendLine("            ValidAudience = \"yourdomain.com\",");
            sb.AppendLine("            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(\"Your_New_Secret_Key_At_Least_16_Chars_Long\"))");
            sb.AppendLine("        };");
            sb.AppendLine("    });");
            sb.AppendLine("");
            sb.AppendLine("var app = builder.Build();");
            sb.AppendLine("");
            sb.AppendLine("// Middleware Configuration");
            sb.AppendLine("// Configure the HTTP request pipeline.");
            sb.AppendLine("app.UseCors(\"AllowAll\");");
            sb.AppendLine("app.UseHttpsRedirection();");
            sb.AppendLine("app.UseStaticFiles();");
            sb.AppendLine("// Register TokenValidationMiddleware before UseRouting");
            sb.AppendLine("app.UseMiddleware<TokenValidationMiddleware>(); // Ensure this is added before UseRouting()");
            sb.AppendLine("app.UseRouting();");
            sb.AppendLine("app.UseAuthentication();");
            sb.AppendLine("app.UseAuthorization();");
            sb.AppendLine("// Swagger UI for development");
            sb.AppendLine("");
            sb.AppendLine("// Configure the HTTP request pipeline.");
            sb.AppendLine("if (app.Environment.IsDevelopment())");
            sb.AppendLine("{");
            sb.AppendLine("    app.UseSwagger();");
            sb.AppendLine("    app.UseSwaggerUI();");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("app.UseHttpsRedirection();");
            sb.AppendLine("");
            sb.AppendLine("app.UseCors(\"AllowSpecificOrigin\");");
            sb.AppendLine("app.UseAuthorization();");
            sb.AppendLine("app.MapControllers();");
            sb.AppendLine("");
            sb.AppendLine("app.Run();");
           
            string projectfoldername = $@"{ClientName}\{ProjectName}";

            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Presentation\ClientProjectBuilder.Api";

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            // Create the file path (using the table name as the file name)
            string filePath = Path.Combine(directoryPath, "Program.cs");

            // Write the model code to the file
            File.WriteAllText(filePath, sb.ToString());

            GenerateInfrastructureDI(tableNames, ProjectName, ClientName, fields, formDocEnabled);

        }

        public void GenerateInfrastructureDI(List<string> tableNames, string ProjectName, string ClientName, List<ClientCardViewFields> fields, List<ClientForm> formDocEnabled)
        {
            var sb = new StringBuilder();

            sb.AppendLine("using Entities.Models.AppUser;");
            sb.AppendLine("using Interfaces;");
            sb.AppendLine("using Microsoft.AspNetCore.Identity;");
            sb.AppendLine("using Microsoft.Extensions.Configuration;");
            sb.AppendLine("using Microsoft.Extensions.DependencyInjection;");
            sb.AppendLine("using Repositories;");
            sb.AppendLine("using Services;");

            foreach (var table in tableNames)
            {
                sb.AppendLine($"using BusinessRule.{table};");
            }
            
            sb.AppendLine();

            sb.AppendLine("namespace InfrastructureDI");
            sb.AppendLine("{");
            sb.AppendLine("    public static class DependencyInjection");
            sb.AppendLine("    {");
            sb.AppendLine("        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)");
            sb.AppendLine("        {");
            sb.AppendLine("            services.AddScoped<DapperDB.DapperDbContext.DbContext>();");
            sb.AppendLine("            services.AddHttpContextAccessor();");
            sb.AppendLine("            services.AddScoped<IUserInfo, UserInfo>();");
            sb.AppendLine("            services.AddScoped<UserInfo>();");
            sb.AppendLine("            services.AddScoped<IAppUser, AppUserRepository>();");
            sb.AppendLine("            //builder.Services.AddScoped<IFieldDefination, FieldDefinationRepository>();");
            sb.AppendLine("            services.AddScoped<IPasswordHasher<AppUserModel>, PasswordHasher<AppUserModel>>();");
            sb.AppendLine("            services.AddScoped<IToken, TokenRepository>();");
            sb.AppendLine("            services.AddTransient<IDynamicMenu, DynamicMenuRepository>();");
            sb.AppendLine("            services.AddScoped<IPasswordPolicy, PasswordPolicyRepository>();");
            sb.AppendLine("            services.AddScoped<IFileIntegration, FileIntegrationRepository>();");
            sb.AppendLine("            services.AddScoped<IEmailTemplate, EmailTemplateRepository>();");
            sb.AppendLine("            services.AddScoped<ITable, TableRepository>();");
            sb.AppendLine("            services.AddScoped<IFieldDefination, FieldDefinationRepository>();");
            sb.AppendLine("            services.AddScoped<IGenerateReportAction, GenerateReportActionRepository>();");
            sb.AppendLine("            services.AddScoped<IDocument, DocumentRepository>();");
            sb.AppendLine("            services.AddScoped<IRole, RoleRepository>();");
            sb.AppendLine("            services.AddScoped<IReport, ReportRepository>();");
            sb.AppendLine("            services.AddScoped<IReportCategory, ReportCategoryRepository>();");
            sb.AppendLine("            services.AddScoped<IMenuPermission, MenuPermissionRepository>();");
            sb.AppendLine("            services.AddScoped<IFormPermission, FormPermissionRepository>();");
            sb.AppendLine("            services.AddScoped<IValueMapper, ValueMapperRepository>();");
            sb.AppendLine("            services.AddScoped<MailService>();");
            sb.AppendLine("            services.AddScoped<IImportProfile, ImportProfileRepository>();");
            sb.AppendLine("            services.AddScoped<IPredefinedQuery, PredefinedQueryRepository>();");
            sb.AppendLine("            services.AddScoped<IQueryType, QueryTypeRepository>();");
            sb.AppendLine("            services.AddScoped<IPredefinedQueryParameter, PredefinedQueryParameterRepository>();");
            sb.AppendLine("            services.AddScoped<IFieldType, FieldTypeRepository>();");
            sb.AppendLine("            services.AddScoped<ITileLayout, TileLayoutRepository>();");
            sb.AppendLine("            services.AddScoped<ISequenceFormat, SequenceFormatRepository>();");
            sb.AppendLine("            services.AddScoped<IPdfReportConfiguration, PdfReportConfigurationRepository>();");
            sb.AppendLine("            services.AddScoped<IRestPullIntegration, RestPullIntegrationRepository>();");
            sb.AppendLine("            services.AddScoped<IRestPushIntegration, RestPushIntegrationRepository>();");
            sb.AppendLine("            //builder.Services.AddScoped<IRequestParameter, RequestParameterRepository>();");
            sb.AppendLine("            services.AddScoped<IResourceString, ResourceStringRepository>();");
            sb.AppendLine("            services.AddScoped<IRestPushIntegration, RestPushIntegrationRepository>();");

            foreach (var form in formDocEnabled)
            {
                if (form.IsMenuValid)
                {
                    sb.AppendLine($"        services.AddScoped<I{form.Name}Document, {form.Name}DocumentRepository>();");
                }
            }

            foreach (var table in tableNames)
            {
                var tableFields = fields.Where(f => f.TableName == table).ToList();

                sb.AppendLine($"            services.AddScoped<I{table}, {table}Repository>();");
                sb.AppendLine($"            services.AddScoped<{table}Rule>();");

                foreach (var field in tableFields.Where(f => f.TypeId == "checkboxgroup" || f.TypeId == "Multiselect"))
                {
                    string mapTableName = $"{table}_{field.FieldName}";
                    string className = $"{mapTableName}";
                    sb.AppendLine($"        services.AddScoped<I{className}, {className}Repository>();");
                }
            }

            sb.AppendLine();
            sb.AppendLine("            return services;");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");


            string projectfoldername = $@"{ClientName}\{ProjectName}";

            string directoryPath = $@"C:\ClientProject\{projectfoldername}\Infrastructure\InfrastructureDI";

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            // Create the file path (using the table name as the file name)
            string filePath = Path.Combine(directoryPath, "DependencyInjection.cs");

            // Write the model code to the file
            File.WriteAllText(filePath, sb.ToString());

        }

    }
}
