﻿using Entities.Models.ClientBuilderModels.ClientModels;
using System.Text;

namespace Entities.Models.ClientBuilderModels.ClientClasses
{
    public class GenerateXUnitTest
    {
        public async Task GenerateXUnitTests(ClientTable table, string modelName, string ProjectName, string ClientName, IEnumerable<ClientForm> FormList, IEnumerable<ClientFieldDefinition> AddEditFields, List<ClientCardViewFields> RuleList)
        {

            await GenerateGetTests(table, modelName, ProjectName, ClientName, FormList, AddEditFields, RuleList);
            await GeneratePostTests(table, modelName, ProjectName, ClientName, FormList, AddEditFields);
            await GeneratePutTests(table, modelName, ProjectName, ClientName, FormList, AddEditFields);
            await GenerateDeleteTests(table, modelName, ProjectName, ClientName, FormList, AddEditFields);
        }

        private static async Task GenerateGetTests(ClientTable table, string modelName, string ProjectName, string ClientName, IEnumerable<ClientForm> FormList, IEnumerable<ClientFieldDefinition> AddEditFields, List<ClientCardViewFields> RuleList)
        {
            //ArgumentNullException.ThrowIfNull(RuleList);

            var testCode = new StringBuilder();

            // Add using statements
            testCode.AppendLine("using System;");
            testCode.AppendLine("using System.Collections.Generic;");
            testCode.AppendLine("using System.Linq;");
            testCode.AppendLine("using System.Threading.Tasks;");
            testCode.AppendLine("using Xunit;");
            testCode.AppendLine("using Moq;");
            testCode.AppendLine("using DynamicFormBuilder.Controllers;");
            testCode.AppendLine("using Interface;");
            testCode.AppendLine("using Models;");
            testCode.AppendLine("using Infrastructure;");
            testCode.AppendLine("using Models.Request;");
            testCode.AppendLine("using Models.Response;");
            testCode.AppendLine("using Microsoft.AspNetCore.Mvc;");
            testCode.AppendLine();

            testCode.AppendLine($"namespace XunitWeb");
            testCode.AppendLine("{");
            testCode.AppendLine($"    public class {modelName}ControllerTests");
            testCode.AppendLine("    {");
            testCode.AppendLine($"        private readonly Mock<I{modelName}> _mockRepo;");
            testCode.AppendLine($"        private readonly Mock<{modelName}Rule> _mockRule;");
            testCode.AppendLine($"        private readonly {modelName}Controller _controller;");
            testCode.AppendLine();
            testCode.AppendLine($"        public {modelName}ControllerTests()");
            testCode.AppendLine("        {");
            testCode.AppendLine($"            _mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine($"            _mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            _controller = new {modelName}Controller(_mockRepo.Object, _mockRule.Object);");
            testCode.AppendLine("        }");
            testCode.AppendLine();


            // 1. GetAll Test
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task GetAll_{modelName}_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var expectedData = new List<{modelName}> {{ new {modelName}() }};");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.GetAll{modelName}()).ReturnsAsync(expectedData);");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine("            var result = await _controller.GetAll();");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            Assert.Equal(expectedData, okResult.Value);");
            testCode.AppendLine("            _mockRepo.Verify(repo => repo.GetAll" + $"{modelName}(), Times.Once);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // 2. GetAll Exception Test
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task GetAll_{modelName}_ThrowsException_ReturnsInternalServerError()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine("            var exceptionMessage = \"Database connection failed\";");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.GetAll{modelName}()).ThrowsAsync(new Exception(exceptionMessage));");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine("            var result = await _controller.GetAll();");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var statusResult = Assert.IsType<ObjectResult>(result);");
            testCode.AppendLine("            Assert.Equal(500, statusResult.StatusCode);");
            testCode.AppendLine("            Assert.Equal(exceptionMessage, statusResult.Value);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            //// 3. Get (with Request) Test
            //testCode.AppendLine("        [Fact]");
            //testCode.AppendLine($"        public async Task Get_{modelName}_WithRequest_ReturnsOkResult()");
            //testCode.AppendLine("        {");
            //testCode.AppendLine("            // Arrange");
            //testCode.AppendLine("            var request = new Request();");
            //testCode.AppendLine($"            var expectedResponse = new Response<{modelName}>((IList)new List<{modelName}>(), new Dictionary<string, Dictionary<string, string>>(), 0, true);");
            //testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{modelName}(request)).ReturnsAsync(expectedResponse);");
            //testCode.AppendLine();
            //testCode.AppendLine("            // Act");
            //testCode.AppendLine($"            var result = await _controller.Get{modelName}(request);");
            //testCode.AppendLine();
            //testCode.AppendLine("            // Assert");
            //testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            //testCode.AppendLine("            Assert.NotNull(okResult.Value);");
            //testCode.AppendLine("            _mockRepo.Verify(repo => repo.Get" + $"{modelName}(request), Times.Once);");
            //testCode.AppendLine("        }");
            //testCode.AppendLine();

            // 4. GetById Test
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Get{modelName}ById_ValidId_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine("            int testId = 1;");
            testCode.AppendLine($"            var expected{modelName} = new {modelName} {{ ID = testId }};");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{modelName}ById(testId)).ReturnsAsync(expected{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await _controller.Get{modelName}ById(testId);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine($"            Assert.Equal(expected{modelName}, okResult.Value);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // 5. GetById NotFound Test
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Get{modelName}ById_InvalidId_ReturnsNotFound()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine("            int testId = 999;");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{modelName}ById(testId)).ReturnsAsync(({modelName})null);");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await _controller.Get{modelName}ById(testId);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            Assert.IsType<NotFoundObjectResult>(result);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // 6. Header Table Tests (if exists)
            if (table.HeaderTableId > 0)
            {
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Get{table.Name}By{table.HeaderTableName}Id_ValidId_ReturnsOkResult()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine("            int testId = 1;");
                testCode.AppendLine("            int skip = 0;");
                testCode.AppendLine("            int take = 10;");
                testCode.AppendLine($"            var expectedData = new List<{table.Name}> {{ new {table.Name}() }};");
                testCode.AppendLine($"            var pagedResult = new PagedResult<{table.Name}> {{ Data = expectedData, TotalCount = expectedData.Count }};");
                testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{table.Name}By{table.HeaderTableName}Id(testId, skip, take)).ReturnsAsync(pagedResult);");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await _controller.Get{table.Name}By{table.HeaderTableName}Id(testId, skip, take);");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
                testCode.AppendLine($"            var returnValue = Assert.IsType<PagedResult<{table.Name}>>(okResult.Value);");
                testCode.AppendLine($"            Assert.Equal(expectedData, returnValue.Data);");
                testCode.AppendLine("            Assert.True(returnValue.TotalCount > 0);");
                testCode.AppendLine("        }");
                testCode.AppendLine();
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Get{table.Name}By{table.HeaderTableName}Id_InvalidId_ReturnsNotFound()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine("            int testId = 999;");
                testCode.AppendLine("            int skip = 0;");
                testCode.AppendLine("            int take = 10;");
                testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{table.Name}By{table.HeaderTableName}Id(testId, skip, take)).ReturnsAsync((PagedResult<{table.Name}>)null);");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await _controller.Get{table.Name}By{table.HeaderTableName}Id(testId, skip, take);");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.IsType<NotFoundObjectResult>(result);");
                testCode.AppendLine("        }");
                testCode.AppendLine();

            }

            // 7. Dynamic Parent Field Tests
            var processedMethods = new HashSet<string>();
            foreach (var field in AddEditFields)
            {
                if (!string.IsNullOrEmpty(field.ParentFieldName) && field.ParentSourceTblName != field.SourceHeaderTableName)
                {
                    string methodName = $"Get{field.SourceTableName}By{field.ParentFieldName}";
                    if (processedMethods.Contains(methodName))
                    {
                        continue;
                    }
                    processedMethods.Add(methodName);

                    testCode.AppendLine("        [Fact]");
                    testCode.AppendLine($"        public async Task {methodName}_ValidId_ReturnsOkResult()");
                    testCode.AppendLine("        {");
                    testCode.AppendLine("            // Arrange");
                    testCode.AppendLine("            int testId = 1;");
                    testCode.AppendLine($"            var expectedData = new List<{field.SourceTableName}> {{ new {field.SourceTableName}() }};");
                    testCode.AppendLine($"            _mockRepo.Setup(repo => repo.{methodName}(testId)).ReturnsAsync(expectedData);");
                    testCode.AppendLine();
                    testCode.AppendLine("            // Act");
                    testCode.AppendLine($"            var result = await _controller.{methodName}(testId);");
                    testCode.AppendLine();
                    testCode.AppendLine("            // Assert");
                    testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
                    testCode.AppendLine("            Assert.Equal(expectedData, okResult.Value);");
                    testCode.AppendLine("        }");
                    testCode.AppendLine();
                }
            }

            // 8. Hierarchical Test (if applicable)
            if (table.IsHierarchical)
            {
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine("        public async Task GetHierarchyAsync_ReturnsOkResult()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            var expectedHierarchy = new List<{modelName}>();");
                testCode.AppendLine("            _mockRepo.Setup(repo => repo.GetHierarchyAsync()).ReturnsAsync(expectedHierarchy);");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine("            var result = await _controller.GetHierarchyAsync();");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
                testCode.AppendLine("            Assert.Equal(expectedHierarchy, okResult.Value);");
                testCode.AppendLine("        }");
                testCode.AppendLine();
            }

            // 9. Create Tests
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Create_{modelName}_ValidData_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var new{modelName} = new {modelName}();");
            testCode.AppendLine("            var expectedResponse = new CreationResponse { Id = 1, Message = \"Created successfully\" };");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Create{modelName}(new{modelName})).ReturnsAsync(expectedResponse);");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await _controller.Create(new{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            Assert.Equal(expectedResponse, okResult.Value);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Create_{modelName}_NullData_ReturnsBadRequest()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            {modelName} null{modelName} = null;");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await _controller.Create(null{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);");
            testCode.AppendLine($"            Assert.Contains(\"{modelName} data is null\", badRequestResult.Value.ToString());");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // 12. Form-specific Save Tests
            foreach (var formItem in FormList)
            {
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Save{formItem.Name}_ValidData_ReturnsSuccessResponse()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            var {modelName.ToLower()} = new {modelName}();");
                testCode.AppendLine("            var expectedResponse = new CreationResponse { Id = 1, Message = \"applied successfully\" };");
                testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Save{formItem.Name}({modelName.ToLower()})).ReturnsAsync(expectedResponse);");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await _controller.Save{formItem.Name}({modelName.ToLower()});");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.NotNull(result);");
                testCode.AppendLine("            Assert.True(result.Id > 0);");
                testCode.AppendLine("            Assert.Equal(\"applied successfully\", result.Message);");
                testCode.AppendLine("        }");
                testCode.AppendLine();

                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Save{formItem.Name}_NullData_ReturnsErrorResponse()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            {modelName} null{modelName} = null;");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await _controller.Save{formItem.Name}(null{modelName});");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.NotNull(result);");
                testCode.AppendLine("            Assert.Equal(0, result.Id);");
                testCode.AppendLine("            Assert.Equal(\"Assets data is null.\", result.Message);");
                testCode.AppendLine("        }");
                testCode.AppendLine();

                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Save{formItem.Name}_SaveFails_ReturnsErrorResponse()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            var {modelName.ToLower()} = new {modelName}();");
                testCode.AppendLine("            var failedResponse = new CreationResponse { Id = 0, Message = \"Save failed\" };");
                testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Save{formItem.Name}({modelName.ToLower()})).ReturnsAsync(failedResponse);");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await _controller.Save{formItem.Name}({modelName.ToLower()});");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.NotNull(result);");
                testCode.AppendLine("            Assert.Equal(0, result.Id);");
                testCode.AppendLine("            Assert.Equal(\"Failed to create asset.\", result.Message);");
                testCode.AppendLine("        }");
                testCode.AppendLine();
            }

            testCode.AppendLine("    }");
            testCode.AppendLine("}");

            // Save the test file
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\XunitWeb";

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            // Create a folder for the specific model's tests
            string modelTestsFolder = Path.Combine(directoryPath, $"{modelName}Tests");
            if (!Directory.Exists(modelTestsFolder))
            {
                Directory.CreateDirectory(modelTestsFolder);
            }

            string filePath = Path.Combine(modelTestsFolder, $"{modelName}GetTests.cs");
            await File.WriteAllTextAsync(filePath, testCode.ToString());
        }

        private static async Task GeneratePostTests(ClientTable table, string modelName, string ProjectName, string ClientName, IEnumerable<ClientForm> FormList, IEnumerable<ClientFieldDefinition> AddEditFields)
        {
            var testCode = new StringBuilder();

            // Add using statements
            testCode.AppendLine("using System;");
            testCode.AppendLine("using System.Collections.Generic;");
            testCode.AppendLine("using System.Linq;");
            testCode.AppendLine("using System.Threading.Tasks;");
            testCode.AppendLine("using Xunit;");
            testCode.AppendLine("using Moq;");
            testCode.AppendLine("using Microsoft.AspNetCore.Mvc;");
            testCode.AppendLine($"using DynamicFormBuilder.Controllers;");
            testCode.AppendLine($"using Interface;");
            testCode.AppendLine($"using Models;");
            testCode.AppendLine("using Models.Request;");
            testCode.AppendLine("using Models.Response;");
            testCode.AppendLine("using Infrastructure;");
            testCode.AppendLine();

            testCode.AppendLine($"namespace XunitWeb");
            testCode.AppendLine("{");
            testCode.AppendLine($"    public class {modelName}PostTests");
            testCode.AppendLine("    {");
            testCode.AppendLine($"        private readonly Mock<I{modelName}> _mockRepo;");
            testCode.AppendLine($"        private readonly Mock<{modelName}Rule> _mockRule;");
            testCode.AppendLine($"        private readonly {modelName}Controller _controller;");
            testCode.AppendLine();

            // Constructor
            testCode.AppendLine($"        public {modelName}PostTests()");
            testCode.AppendLine("        {");
            testCode.AppendLine($"            _mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine($"            _mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            _controller = new {modelName}Controller(_mockRepo.Object, _mockRule.Object);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // ========== GET ALL TESTS ==========
            testCode.AppendLine("        #region GetAll Tests");
            testCode.AppendLine();
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task GetAll_{modelName}_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var testData = new List<{modelName}> {{ new {modelName}() }};");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.GetAll{modelName}()).ReturnsAsync(testData);");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine("            var result = await _controller.GetAll();");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine($"            Assert.IsType<List<{modelName}>>(okResult.Value);");
            testCode.AppendLine("        }");
            testCode.AppendLine();
            testCode.AppendLine("        #endregion");
            testCode.AppendLine();

            // ========== GET BY ID TESTS ==========
            testCode.AppendLine("        #region GetById Tests");
            testCode.AppendLine();
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Get{modelName}ById_WithValidId_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine("            int testId = 1;");
            testCode.AppendLine($"            var test{modelName} = new {modelName}();");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{modelName}ById(testId)).ReturnsAsync(test{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await _controller.Get{modelName}ById(testId);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine($"            Assert.IsType<{modelName}>(okResult.Value);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Get{modelName}ById_WithInvalidId_ReturnsNotFound()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine("            int testId = 999;");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{modelName}ById(testId)).ReturnsAsync(({modelName})null);");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await _controller.Get{modelName}ById(testId);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            Assert.IsType<NotFoundObjectResult>(result);");
            testCode.AppendLine("        }");
            testCode.AppendLine();
            testCode.AppendLine("        #endregion");
            testCode.AppendLine();

            // ========== HEADER TABLE TESTS (if applicable) ==========
            if (table.HeaderTableId > 0)
            {
                testCode.AppendLine($"        #region Get{table.Name}By{table.HeaderTableName}Id Tests");
                testCode.AppendLine();
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Get{table.Name}By{table.HeaderTableName}Id_WithValidId_ReturnsOkResult()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine("            int testId = 1;");
                testCode.AppendLine("            int skip = 0;");
                testCode.AppendLine("            int take = 10;");
                testCode.AppendLine($"            var testData = new List<{modelName}> {{ new {modelName}() }};");
                testCode.AppendLine($"            var pagedResult = new PagedResult<{modelName}> {{ Data = testData, TotalCount = testData.Count }};");
                testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{table.Name}By{table.HeaderTableName}Id(testId, skip, take)).ReturnsAsync(pagedResult);");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await _controller.Get{table.Name}By{table.HeaderTableName}Id(testId, skip, take);");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
                testCode.AppendLine($"            Assert.IsType<PagedResult<{modelName}>>(okResult.Value);");
                testCode.AppendLine($"            var returnValue = okResult.Value as PagedResult<{modelName}>;");
                testCode.AppendLine("            Assert.NotNull(returnValue);");
                testCode.AppendLine("            Assert.True(returnValue.TotalCount > 0);");
                testCode.AppendLine("        }");
                testCode.AppendLine();
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Get{table.Name}By{table.HeaderTableName}Id_WithInvalidId_ReturnsNotFound()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine("            int testId = 999;");
                testCode.AppendLine("            int skip = 0;");
                testCode.AppendLine("            int take = 10;");
                testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{table.Name}By{table.HeaderTableName}Id(testId, skip, take)).ReturnsAsync((PagedResult<{modelName}>)null);");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await _controller.Get{table.Name}By{table.HeaderTableName}Id(testId, skip, take);");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.IsType<NotFoundObjectResult>(result);");
                testCode.AppendLine("        }");
                testCode.AppendLine();
                testCode.AppendLine("        #endregion");
                testCode.AppendLine();
            }

            // ========== DYNAMIC GET BY PARENT FIELD TESTS ==========
            var parentFields = AddEditFields.Where(f => !string.IsNullOrEmpty(f.ParentFieldName) &&
                                                        f.ParentSourceTblName != f.SourceHeaderTableName).ToList();

            if (parentFields.Count != 0)
            {
                testCode.AppendLine("        #region Dynamic Parent Field Tests");
                testCode.AppendLine();

                foreach (var field in parentFields)
                {
                    testCode.AppendLine("        [Fact]");
                    testCode.AppendLine($"        public async Task Get{field.SourceTableName}By{field.ParentFieldName}_WithValidId_ReturnsOkResult()");
                    testCode.AppendLine("        {");
                    testCode.AppendLine("            // Arrange");
                    testCode.AppendLine("            int testId = 1;");
                    testCode.AppendLine($"            var testData = new List<{modelName}> {{ new {modelName}() }};");
                    testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Get{field.SourceTableName}By{field.ParentFieldName}(testId)).ReturnsAsync(testData);");
                    testCode.AppendLine();
                    testCode.AppendLine("            // Act");
                    testCode.AppendLine($"            var result = await _controller.Get{field.SourceTableName}By{field.ParentFieldName}(testId);");
                    testCode.AppendLine();
                    testCode.AppendLine("            // Assert");
                    testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
                    testCode.AppendLine($"            Assert.IsType<List<{modelName}>>(okResult.Value);");
                    testCode.AppendLine("        }");
                    testCode.AppendLine();
                }

                testCode.AppendLine("        #endregion");
                testCode.AppendLine();
            }

            // ========== HIERARCHICAL TESTS (if applicable) ==========
            if (table.IsHierarchical)
            {
                testCode.AppendLine("        #region Hierarchy Tests");
                testCode.AppendLine();
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine("        public async Task GetHierarchyAsync_ReturnsOkResult()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            var testData = new List<{modelName}> {{ new {modelName}() }};");
                testCode.AppendLine("            _mockRepo.Setup(repo => repo.GetHierarchyAsync()).ReturnsAsync(testData);");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine("            var result = await _controller.GetHierarchyAsync();");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
                testCode.AppendLine($"            Assert.IsType<List<{modelName}>>(okResult.Value);");
                testCode.AppendLine("        }");
                testCode.AppendLine();
                testCode.AppendLine("        #endregion");
                testCode.AppendLine();
            }

            // ========== CREATE TESTS ==========
            testCode.AppendLine("        #region Create Tests");
            testCode.AppendLine();
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Create_{modelName}_WithValidData_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var test{modelName} = new {modelName}();");
            testCode.AppendLine($"            var expectedResponse = new CreationResponse {{ Id = 1, Message = \"Success\" }};");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Create{modelName}(It.IsAny<{modelName}>())).ReturnsAsync(expectedResponse);");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await _controller.Create(test{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            var returnValue = Assert.IsType<CreationResponse>(okResult.Value);");
            testCode.AppendLine("            Assert.True(returnValue.Id > 0);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Create_{modelName}_WithNullData_ReturnsBadRequest()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Act");
            testCode.AppendLine("            var result = await _controller.Create(null);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            Assert.IsType<BadRequestObjectResult>(result);");
            testCode.AppendLine("        }");
            testCode.AppendLine();
            testCode.AppendLine("        #endregion");
            testCode.AppendLine();

            // ========== UPDATE TESTS ==========
            testCode.AppendLine("        #region Update Tests");
            testCode.AppendLine();
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Update{modelName}_WithValidData_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var test{modelName} = new {modelName}();");
            testCode.AppendLine($"            var expectedResponse = new CreationResponse {{ Id = 1, Message = \"Updated successfully\" }};");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Update{modelName}(It.IsAny<{modelName}>())).ReturnsAsync(expectedResponse);");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await _controller.Update{modelName}(test{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            var returnValue = Assert.IsType<CreationResponse>(okResult.Value);");
            testCode.AppendLine("            Assert.True(returnValue.Id > 0);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Update{modelName}_ThrowsException_ReturnsInternalServerError()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var test{modelName} = new {modelName}();");
            testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Update{modelName}(It.IsAny<{modelName}>())).ThrowsAsync(new Exception(\"Update failed\"));");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await _controller.Update{modelName}(test{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var statusResult = Assert.IsType<ObjectResult>(result);");
            testCode.AppendLine("            Assert.Equal(500, statusResult.StatusCode);");
            testCode.AppendLine("        }");
            testCode.AppendLine();
            testCode.AppendLine("        #endregion");
            testCode.AppendLine();

            // ========== FORM-WISE SAVE TESTS ==========
            if (FormList != null && FormList.Any())
            {
                testCode.AppendLine("        #region Form-Wise Save Tests");
                testCode.AppendLine();

                foreach (var formItem in FormList)
                {
                    testCode.AppendLine("        [Fact]");
                    testCode.AppendLine($"        public async Task Save{formItem.Name}_WithValidData_ReturnsSuccessResponse()");
                    testCode.AppendLine("        {");
                    testCode.AppendLine("            // Arrange");
                    testCode.AppendLine($"            var test{modelName} = new {modelName}();");
                    testCode.AppendLine($"            var expectedResponse = new CreationResponse {{ Id = 1, Message = \"applied successfully\" }};");
                    testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Save{formItem.Name}(It.IsAny<{modelName}>())).ReturnsAsync(expectedResponse);");
                    testCode.AppendLine();
                    testCode.AppendLine("            // Act");
                    testCode.AppendLine($"            var result = await _controller.Save{formItem.Name}(test{modelName});");
                    testCode.AppendLine();
                    testCode.AppendLine("            // Assert");
                    testCode.AppendLine("            Assert.NotNull(result);");
                    testCode.AppendLine("            Assert.True(result.Id > 0);");
                    testCode.AppendLine("            Assert.Equal(\"applied successfully\", result.Message);");
                    testCode.AppendLine("        }");
                    testCode.AppendLine();

                    testCode.AppendLine("        [Fact]");
                    testCode.AppendLine($"        public async Task Save{formItem.Name}_WithNullData_ReturnsErrorResponse()");
                    testCode.AppendLine("        {");
                    testCode.AppendLine("            // Act");
                    testCode.AppendLine($"            var result = await _controller.Save{formItem.Name}(null);");
                    testCode.AppendLine();
                    testCode.AppendLine("            // Assert");
                    testCode.AppendLine("            Assert.NotNull(result);");
                    testCode.AppendLine("            Assert.Equal(0, result.Id);");
                    testCode.AppendLine("            Assert.Contains(\"null\", result.Message);");
                    testCode.AppendLine("        }");
                    testCode.AppendLine();

                    testCode.AppendLine("        [Fact]");
                    testCode.AppendLine($"        public async Task Save{formItem.Name}_WithFailedSave_ReturnsErrorResponse()");
                    testCode.AppendLine("        {");
                    testCode.AppendLine("            // Arrange");
                    testCode.AppendLine($"            var test{modelName} = new {modelName}();");
                    testCode.AppendLine($"            var failedResponse = new CreationResponse {{ Id = 0, Message = \"Failed\" }};");
                    testCode.AppendLine($"            _mockRepo.Setup(repo => repo.Save{formItem.Name}(It.IsAny<{modelName}>())).ReturnsAsync(failedResponse);");
                    testCode.AppendLine();
                    testCode.AppendLine("            // Act");
                    testCode.AppendLine($"            var result = await _controller.Save{formItem.Name}(test{modelName});");
                    testCode.AppendLine();
                    testCode.AppendLine("            // Assert");
                    testCode.AppendLine("            Assert.NotNull(result);");
                    testCode.AppendLine("            Assert.Equal(0, result.Id);");
                    testCode.AppendLine("            Assert.Contains(\"Failed\", result.Message);");
                    testCode.AppendLine("        }");
                    testCode.AppendLine();
                }

                testCode.AppendLine("        #endregion");
                testCode.AppendLine();
            }

            // ========== CHECKBOX CONTROLLER TESTS (if applicable) ==========
            var checkboxFields = AddEditFields.Where(f => f.TypeName == "checkbox").ToList();
            if (checkboxFields.Count != 0)
            {
                testCode.AppendLine("        #region Checkbox Field Tests");
                testCode.AppendLine();
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine("        public void CheckboxControllers_ShouldBeGenerated()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // This test verifies that checkbox controllers are generated");
                testCode.AppendLine("            // Additional specific tests should be added for each checkbox controller");
                testCode.AppendLine($"            Assert.True({checkboxFields.Count} > 0); // Number of checkbox fields");
                testCode.AppendLine("        }");
                testCode.AppendLine();
                testCode.AppendLine("        #endregion");
                testCode.AppendLine();
            }

            // Close the class and namespace
            testCode.AppendLine("    }");
            testCode.AppendLine("}");

            // Save the test file
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\XunitWeb";
            string modelTestsFolder = Path.Combine(directoryPath, $"{modelName}Tests");

            if (!Directory.Exists(modelTestsFolder))
            {
                Directory.CreateDirectory(modelTestsFolder);
            }

            string filePath = Path.Combine(modelTestsFolder, $"{modelName}PostTests.cs");
            await File.WriteAllTextAsync(filePath, testCode.ToString());
        }

        private static async Task GeneratePutTests(ClientTable table, string modelName, string ProjectName, string ClientName, IEnumerable<ClientForm> FormList, IEnumerable<ClientFieldDefinition> AddEditFields)
        {
            //ArgumentNullException.ThrowIfNull(table);
            //ArgumentNullException.ThrowIfNull(AddEditFields);

            var testCode = new StringBuilder();

            // Add using statements
            testCode.AppendLine("using System;");
            testCode.AppendLine("using System.Collections.Generic;");
            testCode.AppendLine("using System.Threading.Tasks;");
            testCode.AppendLine("using Xunit;");
            testCode.AppendLine("using Moq;");
            testCode.AppendLine("using Microsoft.AspNetCore.Mvc;");
            testCode.AppendLine($"using DynamicFormBuilder.Controllers;");
            testCode.AppendLine($"using Interface;");
            testCode.AppendLine($"using Models;");
            testCode.AppendLine($"using Models.Request;");
            testCode.AppendLine($"using Models.Response;");
            testCode.AppendLine("using Infrastructure;");
            testCode.AppendLine();

            testCode.AppendLine($"namespace XunitWeb");
            testCode.AppendLine("{");
            testCode.AppendLine($"    public class {modelName}PutTests");
            testCode.AppendLine("    {");

            // Test 1: Update with valid data
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Update_{modelName}_WithValidData_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
            testCode.AppendLine($"            var test{modelName} = new {modelName}");
            testCode.AppendLine("            {");
            testCode.AppendLine("                ID = 1,");
            testCode.AppendLine("                // Add other required properties");
            testCode.AppendLine("            };");
            testCode.AppendLine();
            testCode.AppendLine($"            mockRepo.Setup(repo => repo.Update{modelName}(It.IsAny<{modelName}>()))");
            testCode.AppendLine("                    .ReturnsAsync(new CreationResponse { Id = 1, Message = \"Updated successfully\" });");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await controller.Update{modelName}(test{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            var response = Assert.IsType<CreationResponse>(okResult.Value);");
            testCode.AppendLine("            Assert.Equal(1, response.Id);");
            testCode.AppendLine("            Assert.Equal(\"Updated successfully\", response.Message);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // Test 2: Update with invalid data
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Update_{modelName}_WithInvalidData_ReturnsError()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
            testCode.AppendLine($"            var test{modelName} = new {modelName}();");
            testCode.AppendLine();
            testCode.AppendLine($"            mockRepo.Setup(repo => repo.Update{modelName}(It.IsAny<{modelName}>()))");
            testCode.AppendLine("                    .ThrowsAsync(new Exception(\"Update failed\"));");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await controller.Update{modelName}(test{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var statusCodeResult = Assert.IsType<ObjectResult>(result);");
            testCode.AppendLine("            Assert.Equal(500, statusCodeResult.StatusCode);");
            testCode.AppendLine("            Assert.Equal(\"Update failed\", statusCodeResult.Value);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // Test 3: Update with null object
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Update_{modelName}_WithNullObject_ReturnsInternalServerError()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
            testCode.AppendLine();
            testCode.AppendLine($"            mockRepo.Setup(repo => repo.Update{modelName}(It.IsAny<{modelName}>()))");
            testCode.AppendLine("                    .ThrowsAsync(new ArgumentNullException(\"Value cannot be null\"));");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await controller.Update{modelName}(null);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var statusCodeResult = Assert.IsType<ObjectResult>(result);");
            testCode.AppendLine("            Assert.Equal(500, statusCodeResult.StatusCode);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // Generate FormWise Save tests
            foreach (var formItem in FormList)
            {
                // Test 4a: Save FormWise with valid data
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Save{formItem.Name}_WithValidData_ReturnsSuccessResponse()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
                testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
                testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
                testCode.AppendLine($"            var test{modelName} = new {modelName}");
                testCode.AppendLine("            {");
                testCode.AppendLine("                ID = 1,");
                testCode.AppendLine("                // Add other required properties for validation");
                testCode.AppendLine("            };");
                testCode.AppendLine();
                testCode.AppendLine($"            mockRepo.Setup(repo => repo.Save{formItem.Name}(It.IsAny<{modelName}>()))");
                testCode.AppendLine("                    .ReturnsAsync(new CreationResponse { Id = 1, Message = \"applied successfully\" });");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await controller.Save{formItem.Name}(test{modelName});");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.NotNull(result);");
                testCode.AppendLine("            Assert.Equal(1, result.Id);");
                testCode.AppendLine("            Assert.Equal(\"applied successfully\", result.Message);");
                testCode.AppendLine("        }");
                testCode.AppendLine();

                // Test 4b: Save FormWise with null data
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Save{formItem.Name}_WithNullData_ReturnsFailureResponse()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
                testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
                testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await controller.Save{formItem.Name}(null);");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.NotNull(result);");
                testCode.AppendLine("            Assert.Equal(0, result.Id);");
                testCode.AppendLine("            Assert.Equal(\"Assets data is null.\", result.Message);");
                testCode.AppendLine("        }");
                testCode.AppendLine();

                // Test 4c: Save FormWise with validation failure
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Save{formItem.Name}_WithValidationFailure_ReturnsValidationError()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
                testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
                testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
                testCode.AppendLine($"            var test{modelName} = new {modelName}");
                testCode.AppendLine("            {");
                testCode.AppendLine("                ID = 1,");
                testCode.AppendLine("                // Add properties that will fail validation");
                testCode.AppendLine("            };");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await controller.Save{formItem.Name}(test{modelName});");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.NotNull(result);");
                testCode.AppendLine("            Assert.Equal(0, result.Id);");
                testCode.AppendLine("            Assert.NotEqual(\"Validation passed\", result.Message);");
                testCode.AppendLine("        }");
                testCode.AppendLine();

                // Test 4d: Save FormWise with repository failure
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Save{formItem.Name}_WithRepositoryFailure_ReturnsFailureResponse()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
                testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
                testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
                testCode.AppendLine($"            var test{modelName} = new {modelName}");
                testCode.AppendLine("            {");
                testCode.AppendLine("                ID = 1,");
                testCode.AppendLine("                // Add other required properties for validation");
                testCode.AppendLine("            };");
                testCode.AppendLine();
                testCode.AppendLine($"            mockRepo.Setup(repo => repo.Save{formItem.Name}(It.IsAny<{modelName}>()))");
                testCode.AppendLine("                    .ReturnsAsync(new CreationResponse { Id = 0, Message = \"Failed\" });");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await controller.Save{formItem.Name}(test{modelName});");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.NotNull(result);");
                testCode.AppendLine("            Assert.Equal(0, result.Id);");
                testCode.AppendLine("            Assert.Equal(\"Failed to create asset.\", result.Message);");
                testCode.AppendLine("        }");
                testCode.AppendLine();
            }

            // Test 5: Update method with repository returning null
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Update_{modelName}_WithRepositoryReturningNull_ReturnsOkWithNull()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
            testCode.AppendLine($"            var test{modelName} = new {modelName} {{ ID = 999 }};");
            testCode.AppendLine();
            testCode.AppendLine($"            mockRepo.Setup(repo => repo.Update{modelName}(It.IsAny<{modelName}>()))");
            testCode.AppendLine("                    .ReturnsAsync((CreationResponse)null);");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await controller.Update{modelName}(test{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            Assert.Null(okResult.Value);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // Test 6: Update method with concurrent modification scenario
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Update_{modelName}_WithConcurrentModification_ReturnsError()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
            testCode.AppendLine($"            var test{modelName} = new {modelName} {{ ID = 1 }};");
            testCode.AppendLine();
            testCode.AppendLine($"            mockRepo.Setup(repo => repo.Update{modelName}(It.IsAny<{modelName}>()))");
            testCode.AppendLine("                    .ThrowsAsync(new InvalidOperationException(\"Concurrent modification detected\"));");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await controller.Update{modelName}(test{modelName});");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var statusCodeResult = Assert.IsType<ObjectResult>(result);");
            testCode.AppendLine("            Assert.Equal(500, statusCodeResult.StatusCode);");
            testCode.AppendLine("            Assert.Contains(\"Concurrent modification detected\", statusCodeResult.Value.ToString());");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // Test 7: Update method performance test
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Update_{modelName}_PerformanceTest_CompletesWithinTimeLimit()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
            testCode.AppendLine($"            var test{modelName} = new {modelName} {{ ID = 1 }};");
            testCode.AppendLine("            var stopwatch = System.Diagnostics.Stopwatch.StartNew();");
            testCode.AppendLine();
            testCode.AppendLine($"            mockRepo.Setup(repo => repo.Update{modelName}(It.IsAny<{modelName}>()))");
            testCode.AppendLine("                    .ReturnsAsync(new CreationResponse { Id = 1, Message = \"Updated successfully\" });");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var result = await controller.Update{modelName}(test{modelName});");
            testCode.AppendLine("            stopwatch.Stop();");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            Assert.True(stopwatch.ElapsedMilliseconds < 1000, \"Update operation took too long\");");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // Generate validation tests for each form
            foreach (var formItem in FormList)
            {
                testCode.AppendLine("        [Fact]");
                testCode.AppendLine($"        public async Task Save{formItem.Name}_WithAllValidationRules_ReturnsExpectedResults()");
                testCode.AppendLine("        {");
                testCode.AppendLine("            // Arrange");
                testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
                testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
                testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
                testCode.AppendLine($"            var test{modelName} = new {modelName}");
                testCode.AppendLine("            {");
                testCode.AppendLine("                ID = 1,");
                testCode.AppendLine("                // Configure properties to test all validation rules");
                testCode.AppendLine("            };");
                testCode.AppendLine();
                testCode.AppendLine($"            mockRepo.Setup(repo => repo.Save{formItem.Name}(It.IsAny<{modelName}>()))");
                testCode.AppendLine("                    .ReturnsAsync(new CreationResponse { Id = 1, Message = \"applied successfully\" });");
                testCode.AppendLine();
                testCode.AppendLine("            // Act");
                testCode.AppendLine($"            var result = await controller.Save{formItem.Name}(test{modelName});");
                testCode.AppendLine();
                testCode.AppendLine("            // Assert");
                testCode.AppendLine("            Assert.NotNull(result);");
                testCode.AppendLine("            // Add specific assertions based on your validation rules");
                testCode.AppendLine("        }");
                testCode.AppendLine();
            }

            // Helper method tests
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public void {modelName}Controller_Constructor_InitializesCorrectly()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine($"            var mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine($"            var mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            var controller = new {modelName}Controller(mockRepo.Object, mockRule.Object);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            Assert.NotNull(controller);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public void {modelName}Controller_Constructor_WithNullRepository_ThrowsException()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Act & Assert");
            testCode.AppendLine($"            Assert.Throws<ArgumentNullException>(() => new {modelName}Controller(null, null));");
            testCode.AppendLine("        }");

            testCode.AppendLine("    }");
            testCode.AppendLine("}");

            // File saving logic
            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\XunitWeb";
            string modelTestsFolder = Path.Combine(directoryPath, $"{modelName}Tests");

            if (!Directory.Exists(modelTestsFolder))
            {
                Directory.CreateDirectory(modelTestsFolder);
            }

            string filePath = Path.Combine(modelTestsFolder, $"{modelName}PutTests.cs");
            await File.WriteAllTextAsync(filePath, testCode.ToString());
        }

        private static async Task GenerateDeleteTests(ClientTable table, string modelName, string ProjectName, string ClientName, IEnumerable<ClientForm> FormList, IEnumerable<ClientFieldDefinition> AddEditFields)
        {

            //ArgumentNullException.ThrowIfNull(table);
            //ArgumentNullException.ThrowIfNull(FormList);
            //ArgumentNullException.ThrowIfNull(AddEditFields);
            var testCode = new StringBuilder();

            // Add using statements
            testCode.AppendLine("using System;");
            testCode.AppendLine("using System.Collections.Generic;");
            testCode.AppendLine("using System.Threading.Tasks;");
            testCode.AppendLine("using Xunit;");
            testCode.AppendLine("using Moq;");
            testCode.AppendLine("using Microsoft.AspNetCore.Mvc;");
            testCode.AppendLine($"using DynamicFormBuilder.Controllers;");
            testCode.AppendLine($"using Interface;");
            testCode.AppendLine($"using Models;");
            testCode.AppendLine($"using Models.Request;");
            testCode.AppendLine($"using Models.Response;");
            testCode.AppendLine("using Infrastructure;");
            testCode.AppendLine();

            testCode.AppendLine($"namespace XunitWeb");
            testCode.AppendLine("{");
            testCode.AppendLine($"    public class {modelName}DeleteTests");
            testCode.AppendLine("    {");
            testCode.AppendLine($"        private readonly Mock<I{modelName}> _mockRepo;");
            testCode.AppendLine($"        private readonly Mock<{modelName}Rule> _mockRule;");
            testCode.AppendLine($"        private readonly {modelName}Controller _controller;");
            testCode.AppendLine();
            testCode.AppendLine("        public " + modelName + "DeleteTests()");
            testCode.AppendLine("        {");
            testCode.AppendLine($"            _mockRepo = new Mock<I{modelName}>();");
            testCode.AppendLine($"            _mockRule = new Mock<{modelName}Rule>();");
            testCode.AppendLine($"            _controller = new {modelName}Controller(_mockRepo.Object, _mockRule.Object);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // 1. Test successful delete
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Delete_{modelName}_WithValidId_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine("            int testId = 1;");
            testCode.AppendLine("            _mockRepo.Setup(repo => " +
                $"repo.Delete{modelName}(testId))" +
                ".Returns(Task.FromResult(\"Deleted successfully\"));");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine("            var result = await _controller.Delete(testId);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            var response = Assert.IsType<string>(okResult.Value);");
            testCode.AppendLine("            Assert.Equal(\"Deleted successfully\", response);");
            testCode.AppendLine("            _mockRepo.Verify(repo => repo.Delete" + modelName + "(testId), Times.Once);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // 2. Test delete with invalid ID
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Delete_{modelName}_WithInvalidId_ReturnsNotFound()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine("            int invalidId = -1;");
            testCode.AppendLine("            _mockRepo.Setup(repo => " +
                $"repo.Delete{modelName}(invalidId))" +
                ".Returns(Task.FromResult(\"Record not found\"));");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine("            var result = await _controller.Delete(invalidId);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            var response = Assert.IsType<string>(okResult.Value);");
            testCode.AppendLine("            Assert.Equal(\"Record not found\", response);");
            testCode.AppendLine("            _mockRepo.Verify(repo => repo.Delete" + modelName + "(invalidId), Times.Once);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // 3. Test delete with zero ID
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Delete_{modelName}_WithZeroId_ReturnsOkResult()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine("            int zeroId = 0;");
            testCode.AppendLine("            _mockRepo.Setup(repo => " +
                $"repo.Delete{modelName}(zeroId))" +
                ".Returns(Task.FromResult(\"Invalid ID provided\"));");
            testCode.AppendLine();
            testCode.AppendLine("            // Act");
            testCode.AppendLine("            var result = await _controller.Delete(zeroId);");
            testCode.AppendLine();
            testCode.AppendLine("            // Assert");
            testCode.AppendLine("            var okResult = Assert.IsType<OkObjectResult>(result);");
            testCode.AppendLine("            var response = Assert.IsType<string>(okResult.Value);");
            testCode.AppendLine("            Assert.Equal(\"Invalid ID provided\", response);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            // 4. Test delete when exception occurs
            testCode.AppendLine("        [Fact]");
            testCode.AppendLine($"        public async Task Delete_{modelName}_WhenExceptionThrown_ReturnsInternalServerError()");
            testCode.AppendLine("        {");
            testCode.AppendLine("            // Arrange");
            testCode.AppendLine("            int testId = 1;");
            testCode.AppendLine("            _mockRepo.Setup(repo => " +
                $"repo.Delete{modelName}(testId))" +
                ".ThrowsAsync(new Exception(\"Database connection failed\"));");
            testCode.AppendLine();
            testCode.AppendLine("            // Act & Assert");
            testCode.AppendLine("            var exception = await Assert.ThrowsAsync<Exception>(() => _controller.Delete(testId));");
            testCode.AppendLine("            Assert.Equal(\"Database connection failed\", exception.Message);");
            testCode.AppendLine("        }");
            testCode.AppendLine();

            testCode.AppendLine("    }");
            testCode.AppendLine("}");

            string projectfoldername = $@"{ClientName}\{ProjectName}";
            string directoryPath = $@"C:\ClientProject\{projectfoldername}\XunitWeb";

            string modelTestsFolder = Path.Combine(directoryPath, $"{modelName}Tests");
            if (!Directory.Exists(modelTestsFolder))
            {
                Directory.CreateDirectory(modelTestsFolder);
            }

            string filePath = Path.Combine(modelTestsFolder, $"{modelName}DeleteTests.cs");
            await File.WriteAllTextAsync(filePath, testCode.ToString());
        }
    }
}
