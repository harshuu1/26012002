﻿namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ClientDisplayField: CommonField
    {
        public int InOrder { get; set; }
        /// <summary> The unique identifier of the field (foreign key to the FieldDefinition table).</summary>
        public int FieldId { get; set; }
        /// <summary>The ID of the Form this field is a part of (foreign key to the Form table).</summary>
        public int FormId { get; set; }
        /// <summary>The ID of the ListProfile this field is a part of (foreign key to the ListProfile table).</summary>
        public int? ListProfileId { get; set; }
        /// <summary>The name of the field as defined in the field metadata.</summary>
        public string? FieldName { get; set; }
        /// <summary> Defines how the field will be validated and displayed (e.g., text, number, date).</summary>
        public string? FieldType { get; set; }
        /// <summary> The name of the form this field belongs to.</summary>
        public string? FormName { get; set; }
        /// <summary>Represents the ID of the source table.</summary>
        public int? SourceTableId { get; set; }
        /// <summary> Represents the name of the source table where the field's data is coming from. </summary>
        public string? SourceTableName { get; set; }
        /// <summary> Name Of The Table.</summary>
        public string? TableName { get; set; }
        public bool? IsDragDrop { get; set; }
        public string? DisplayName { get; set; }
        public int? TableId { get; set; }
        public int? ParentId { get; set; }
        public string? TypeId { get; set; }
        public string? ToolTip { get; set; }
        public string? ListLabel { get; set; }
    }
}
