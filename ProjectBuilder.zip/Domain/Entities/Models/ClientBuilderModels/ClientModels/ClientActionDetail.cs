﻿namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ClientActionDetail: CommonField
    {
        /// <summary>The name of the action to be performed (e.g., "Submit", "Reset", "Validate").</summary>
        public string? ActionName { get; set; }
        /// <summary>A brief description of what the action does or represents.</summary>
        public string? Description { get; set; }
        /// <summary> The display name or label associated with the action.</summary>
        public string? Name { get; set; }
        /// <summary>A unique identifier for the action..</summary>
        public int ActionID { get; set; }
        /// <summary>The unique identifier of the field this action is associated with.</summary>
        public int FieldId { get; set; }
        /// <summary>The value or parameter associated with the action (e.g., default value, condition).</summary>
        public string? Value { get; set; }
        public string? FieldName { get; set; }
        public string? EmailSubject { get; set; }
        public string? EmailMessage { get; set; }
        public string? EmailTemplate { get; set; }
        public string? EmailTo { get; set; }
        public int EmailOptionId { get; set; }
        public string? RoleId { get; set; }
        public bool IndividualEmail { get; set; }
        public int GenerateReportId { get; set; }
        public int Report { get; set; }
        public bool ViewReport { get; set; }
        public bool EmailAttachment { get; set; }
      
        /// <summary>The identifier of the form to which this action belongs.</summary>
        public int FormId { get; set; }
        /// <summary>The name of the database table related to this action.</summary>
        public string? TableName { get; set; }
        public int FormActionId { get; set; }
        public int TableId { get; set; }
        public int ActionConfigurationId { get; set; }
   
   

   


    }
}
