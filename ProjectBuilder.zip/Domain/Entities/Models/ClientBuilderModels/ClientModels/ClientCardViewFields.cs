﻿using Entities.Enums;
using Newtonsoft.Json;

namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ClientCardViewFields: CommonField
    {
        public bool IsUsedAsSource { get; set; }
        /// <summary>
        /// The display order of the field in the form layout.
        /// </summary>
        public int InOrder { get; set; }

        /// <summary>
        /// The identifier of the form to which the field belongs.
        /// </summary>
        public int FormId { get; set; }
        /// <summary>
        /// The identifier of the CardViewProfileId to which the field belongs.
        /// </summary>
        public int CardViewProfileId { get; set; }
        /// <summary>
        /// The unique identifier of the field.
        /// </summary>
        public string? CardViewLabel { get; set; }

        /// <summary>
        /// The unique identifier of the field.
        /// </summary>
        public List<string>? CardViewControlFields { get; set; }
        /// <summary>
        /// The unique identifier of the field.
        /// </summary>
        public string? Delimiter { get; set; }
        /// <summary>
        /// The unique identifier of the field.
        /// </summary>
        public int FieldId { get; set; }

        public int PredefineQueryId { get; set; }

        public string? PredefineQueryName { get; set; }

        /// <summary>
        /// The name of the field.
        /// </summary>
        public string? FieldName { get; set; }

        /// <summary>
        /// The type identifier of the field (e.g., text, number, date).
        /// </summary>
        public string? TypeId { get; set; }

        /// <summary>
        /// The name of the form the field belongs to.
        /// </summary>
        public string? FormName { get; set; }

        /// <summary>
        /// The name of the table this field belongs to.
        /// </summary>
        public string? TableName { get; set; }

        /// <summary>
        /// Length of the textbox field (eg. varchar,nvarchar).
        /// </summary>
        public int Length { get; set; }

        /// <summary>
        /// Flag for determining whether multiselect dropdown selectors will show or not.
        /// </summary>
        public bool IsCheckBox { get; set; }

        /// <summary>
        /// The name of the source table for lookup/dropdown fields.
        /// </summary>
        public string? SourceTableName { get; set; }
        public string? ParentSourceTblName { get; set; }
        public string? SourceHeaderTableName { get; set; }
        /// <summary>
        /// The identifier of the source table.
        /// </summary>
        public int? SourceTableId { get; set; }

        /// <summary>
        /// The name of the field used for filtering data in this field (e.g., cascaded dropdown).
        /// </summary>
        public string? FilterFieldName { get; set; }

        /// <summary>
        /// The identifier of the filter field.
        /// </summary>
        public int? FilterId { get; set; }

        /// <summary>
        /// The identifier of the text field used for display.
        /// </summary>
        public int? TextFieldId { get; set; }

        /// <summary>
        /// The name of the text field used for display.
        /// </summary>
        public string? TextFieldName { get; set; }

        /// <summary>
        /// The identifier of the parent field in case of parent-child field relations.
        /// </summary>
        public int? ParentFieldId { get; set; }
        public int? SymbolPosition { get; set; }

        /// <summary>
        /// Flag That Determine Size Of Field.
        /// </summary>
        public bool Max { get; set; }

        /// <summary>
        /// The name of the parent field.
        /// </summary>
        public string? ParentFieldName { get; set; }

        /// <summary>
        /// A value to compare or validate the field against (used in rules/conditions).
        /// </summary>
        public string? FieldValue { get; set; }

        /// <summary>
        ///  The comparison operator used in the rule (e.g., ==, &gt;, &lt;).
        /// </summary>
        public string? Operator { get; set; }

        /// <summary>
        /// Message displayed when the field fails validation.
        /// </summary>
        public string? FailMessage { get; set; }

        /// <summary>
        /// Indicates whether the field is mandatory.
        /// </summary>
        public bool Mandatory { get; set; }

        /// <summary>
        /// The display label shown for the field.
        /// </summary>
        public string? DisplayName { get; set; }

        /// <summary>
        /// The identifier for any conditional rule applied to this field.
        /// </summary>
        public int ConditionalRuleId { get; set; }
        public string? ConditionalRuleName { get; set; }

        /// <summary>
        /// The rule ID, ignored during JSON serialization.
        /// </summary>
        [JsonIgnore]
        public int? RuleId { get; set; }
        public int? TableId { get; set; }

        public string? RuleName { get; set; }
        public string? FieldTypeName { get; set; }

        /// <summary>
        /// The criteria type used for the rule (e.g., value-based, state-based).
        /// </summary>
        public int? RuleCriteria { get; set; }

        /// <summary>
        /// Indicates whether the field is read-only in the UI.
        /// </summary>
        public bool IsReadOnly { get; set; }

        /// <summary>
        /// The default value to prefill in the field.
        /// </summary>
        public string? DefaultValue { get; set; }
        /// <summary>
        /// The default value to prefill in the field.
        /// </summary>
        public bool isDragDrop { get; set; }
        public string? SectionName { get; set; }
        public int? SectionOrder { get; set; }
        public bool? IsMultiColumn { get; set; }
        public List<ClientMultiColumnDropdownField>? MultiColumnFieldNames { get; set; }
        public string? FilterOption { get; set; }
        public string? ConditionalRuleValidateCriteria { get; set; }

        public int? ValidateCriteria { get; set; }
        public bool IsLazyLoaded { get; set; }
      //  public bool? IsSwitch { get; set; }
       //  public bool Rangeslider { get; set; } = false;
        public bool IsAllowPositive { get; set; } = false;

        //for Rangeslider

        public float? MinValue { get; set; }
        public float? MaxValue { get; set; }
        public float? SmallStep { get; set; }
        public float? LargeStep { get; set; }

        public string? Symbol { get; set; }
        //For Switch
        public string? SwitchLabel1 { get; set; }
        public string? SwitchLabel2 { get; set; }

        public string? ToolTip { get; set; }
        public string? Link { get; set; }
        public decimal? Orientation { get; set; }
        public bool ShowButton { get; set; }
        public int Scale { get; set; }
        public string? BarcodeType { get; set; }
        public bool IsResetField { get; set; }
        public List<string>? ResetFieldNames { get; set; }
        


    }
}
