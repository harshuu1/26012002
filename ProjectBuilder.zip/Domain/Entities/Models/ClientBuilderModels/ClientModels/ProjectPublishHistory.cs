﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ProjectPublishHistory
    {
        public int Id { get; set; }
        public int? ProjectId { get; set; }
        public bool IsBuildConfig { get; set; }
        public bool IsBuildClient { get; set; }
        public bool IsConfigDatabase { get; set; }
        public bool IsConfigProject { get; set; }
        public bool IsClientDatabase { get; set; }
        public bool IsClientProject { get; set; }
        public bool IsClientAdmin { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedDate { get; set; }
        public string? CreatedBy { get; set; }       
        public string? Remark { get; set; }
    }
}
