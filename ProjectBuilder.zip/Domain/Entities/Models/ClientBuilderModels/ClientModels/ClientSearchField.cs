﻿namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ClientSearchField:CommonField
    {
        /// <summary> The display order of the search field.</summary>
        public int InOrder { get; set; }

        /// <summary> The unique ID of the field.</summary>
        public int FieldId { get; set; }

        /// <summary> The ID of the form this field belongs to.</summary>
        public int? FormId { get; set; }

        /// <summary> The ID of the ListProfile this field belongs to.</summary>
        public int ListProfileId { get; set; }

        /// <summary> The internal field name.</summary>
        public string? FieldName { get; set; }

        /// <summary> The data type of the field (e.g., text, dropdown).</summary>
        public string? FieldType { get; set; }

        /// <summary> The name of the form this field is used in.</summary>
        public string? FormName { get; set; }

        /// <summary> The name of the table associated with this field.</summary>
        public string? TableName { get; set; }

        /// <summary> The ID of the field type (if using type lookups).</summary>
        public int? FieldTypeId { get; set; }

        /// <summary> The display name for the field in the UI.</summary>
        public string? DisplayName { get; set; }

        /// <summary> The default value used in the search field.</summary>
        public string? DefaultValue { get; set; }
        public bool? IsDragDrop { get; set; }
        //   public bool? IsSwitch { get; set; }
        /// <summary>
        /// Flag That Determine Size Of Field.
        /// </summary>
        public bool Max { get; set; }
        public string? san { get; set; }
        /// <summary> The ID of the parent form (for hierarchical forms).</summary>
        public int ParentId { get; set; }

        /// <summary> The ID of the source table associated with this field.</summary>
        public int? SourceTableId { get; set; }

        /// <summary> The name of the source table.</summary>
        public string? SourceTableName { get; set; }
        public int? TableId { get; set; }
        public string? TextFieldName { get; set; }
        public string? ParentFieldName { get; set; }
        public bool IsMultiColumn { get; set; }
        //public bool IsDetailSearch { get; set; }
        public List<ClientMultiColumnDropdownField>? MultiColumnFieldNames { get; set; }
        public string? SearchProfileName { get; set; }
        public string? FilterOption { get; set; }
        public float? MinValue { get; set; }
        public float? MaxValue { get; set; }
        public String? ToolTip { get; set; }
    }
}
