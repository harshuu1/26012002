﻿using Entities.Models.MultiColumnDropdownField;

namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ClientFieldDefinition: CommonField
    {
        public string? MappedTableName { get; set; }
        public string? MappedFieldName { get; set; }
        public string? MappedFieldTypeName { get; set; }
        public bool IsUsedAsSource { get; set; }
        /// <summary> name of the field.</summary>
        public string? Name { get; set; }
        /// <summary> The ID representing the data type of the field.</summary>
        public string? FieldName { get; set; }
        public int? TypeId { get; set; }
        /// <summary> The name of the field's data type.</summary>
        public string? TypeName { get; set; }
        /// <summary> size of the field.</summary>
        public int? Length { get; set; }
        /// <summary> Indicates whether the maximum allowed length should be used (e.g., varchar(MAX)).</summary>
        public bool Max { get; set; }
        /// <summary> The total number of digits (used in decimal fields).</summary>
        public int? Precision { get; set; }
        /// <summary> The number of digits after the decimal point (used in decimal fields).</summary>
        public int? Scale { get; set; }
        /// <summary> The ID of the table to which this field belongs.</summary>
        public int? TableId { get; set; }
        /// <summary> If the field is a foreign key, this is the ID of the referenced/source table.</summary>
        public int? SourceTableId { get; set; }
        /// <summary> Name of the source table (for foreign key).</summary>
        public string? SourceTableName { get; set; }
        public string? TextFieldName { get; set; }
        /// <summary> ID of the text field from the source table.</summary>
        public int? TextFieldId { get; set; }
        /// <summary> ID of the value field from the source table.</summary>
        public int? ValueId { get; set; }
        /// <summary> ID of the section or group in the form layout this field belongs to.</summary>
        public int? SectionId { get; set; }

        //comment this Fields Due to Delete this Column in Database PBuilder
        ///// <summary> Width.</summary>
        //public short? Width { get; set; }
        ///// <summary> Height.</summary>
        //public short? Height { get; set; }
        ///// <summary> Regular Expression.</summary>
        //public string? RegularExpression { get; set; } =    null;
        ///// <summary> Calculation.</summary>
        //public string? Calculation { get; set; }
        ///// <summary> Value List.</summary>
        //public int? ValueList { get; set; }
        ///// <summary> Locked.</summary>
        //public bool Locked { get; set; }


        /// <summary> Indicates whether this field is required.</summary>
        public bool Mandatory { get; set; }

        ///// <summary> Disable.</summary>
        //public bool Disable { get; set; }
        ///// <summary> Is Hidden.</summary>
        //public bool IsHidden { get; set; }
        ///// <summary> Is Mask.</summary>
        //public bool IsMask { get; set; }


        /// <summary> ID of the parent field.</summary>
        public int? ParentFieldId { get; set; }
        /// <summary> display name shown in the UI for this field.</summary>
        public string? DisplayName { get; set; }
        public string? ParentFieldName { get; set; }
        public string? ParentSourceTblName { get; set; }
        public string? SourceHeaderTableName { get; set; }

        ///// <summary> Tab Index.</summary>
        //public int? TabIndex { get; set; }

        /// <summary> A description  for the field, used for documentation or help text.</summary>
        public string? Description { get; set; }

        ///// <summary> Display Mask.</summary>
        //public string? DisplayMask { get; set; }
        ///// <summary> Mask Start.</summary>
        //public int? MaskStart { get; set; }
        ///// <summary> Mask End.</summary>
        //public int? MaskEnd { get; set; }

        /// <summary> Field Type Name.</summary>
        public string? FieldTypeName { get; set; }

        /// <summary> ID of the value field from the FilterBy.</summary>
        public string? FilterBy { get; set; }

        // <summary> IsLazyLoaded </summary>
        public bool IsLazyLoaded { get; set; }

        public bool IsAllowPositive { get; set; } = false;

        // <summary> IsMultiColumn </summary>
        //public bool IsMultiColumn { get; set; }
        public bool? IsMultiColumn { get; set; }
        // <summary> MultiColumnFieldNames </summary>
        public List<MultiColumnDropdownFieldModel>? MultiColumnFieldNames { get; set; }

        // <summary> SourceFieldNames </summary>
        public string? SourceFieldNames { get; set; }

        // <summary> SourceFieldIds </summary>
        public string? SourceFieldIds { get; set; }
        public string? TableName { get; set; }
        public string? FilterOption { get; set; }
        public bool? RangeSlider { get; set; }
        // <summary> SourceTableType </summary>
        public string? SourceTableType { get; set; }

        


    }
}
