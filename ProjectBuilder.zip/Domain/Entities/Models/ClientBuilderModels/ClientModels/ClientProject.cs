﻿using Microsoft.AspNetCore.Http;

namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ClientProject: CommonField
    {

        public object? ClientID;

        //public object ClientID;
        /// <summary>
        /// The Client ID associated with the project.
        /// </summary>
        public int ClientId { get; set; }

        /// <summary>
        /// The unique ID of the project.
        /// </summary>
        public int? ProjectId { get; set; }

        /// <summary>
        /// The name of the project (e.g., "Web Development", "Database Setup").
        /// </summary>
        public string? Name { get; set; }

        /// <summary>
        /// A description of the project, explaining its scope, goals, and details.
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// The name of the company associated with the project. This field is optional.
        /// </summary>
        public string? CompanyName { get; set; }

        /// <summary>
        /// The logo file for the project. It can be uploaded through a form.
        /// </summary>
        public IFormFile? ProjectLogoFile { get; set; }  // For uploading logo via form

        /// <summary>
        /// The URL or path to the project logo. This can be used to display the logo in the application.
        /// </summary>
        public string? ProjectLogo { get; set; }

        public List<ProjectPublishHistory> ProjectHistories { get; set; } = new List<ProjectPublishHistory>();
    }
}
