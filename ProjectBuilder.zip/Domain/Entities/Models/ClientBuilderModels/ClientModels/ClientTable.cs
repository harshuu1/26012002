﻿using Entities.Models.Table;

namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ClientTable: CommonField
    {
        /// <summary>
        /// Name of the table.
        /// </summary>
        public required string Name { get; set; }
        public int ParentId { get; set; }

        public string? ParentName { get; set; }
        /// <summary>
        /// Identifier for the client who owns this table.
        /// </summary>
        public required int ClientId { get; set; }
        /// <summary>
        /// Identifier for the associated project.
        /// </summary>
        public int? ProjectId { get; set; }
        /// <summary>
        /// Name of the associated project.
        /// </summary>
        public string? Projectname { get; set; }
        /// <summary>
        /// Name of the client.
        /// </summary>
        public string? Clientname { get; set; }
        public string? HeaderTableName { get; set; }
        /// <summary>
        /// Indicates whether the table is hierarchical (e.g., master-detail relationship).
        /// </summary>
        public bool IsHierarchical { get; set; }
        /// <summary>
        /// Name of the detail table in a hierarchical relationship.
        /// </summary>
        public string? DetailTableName { get; set; }
        public string? PrimaryKeyType { get; set; }
        public string? ParentPrimaryKeyType { get; set; }

        /// <summary>
        ///  This the SaveReuse button. 
        /// </summary>
        public bool? SaveReuse { get; set; }

        /// <summary>
        ///  This the SaveContinue button. 
        /// </summary>
        public bool? SaveContinue { get; set; }

        /// <summary>
        /// ID of the header table.
        /// </summary>
        public int? HeaderTableId { get; set; }

        public bool IsDocumentEnabled { get; set; }
        public bool IsSourceTable { get; set; }
        public bool IsMenuCreated { get; set; }

        /// <summary>
        /// ID of the detail table.
        /// </summary>
        public int? DetailTableId { get; set; }
        /// <summary>
        /// List of associated detail tables.
        /// </summary>
        public List<DetailTable>? DetailTableList { get; set; }

        /// <summary>
        /// List of fields (columns) for this table.
        /// Needed for building mapping tables (checkbox groups, etc).
        /// </summary>
         public IEnumerable<ClientFieldDefinition>? Fields { get; set; }
        public string? ChildTableNames { get; set; }

        public string? ChildTableColumns { get; set; }

    }
}
