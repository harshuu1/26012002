﻿namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ClientForm: CommonField
    {
        /// <summary>
        ///  name of the form.
        /// </summary>
        public string? Name { get; set; }
        /// <summary>
        ///  DisplayName of the form.
        /// </summary>
        public string? DisplayName { get; set; }
        /// <summary>
        ///  ID of the primary table associated with this form.
        /// </summary>
        public string? ListLabel { get; set; }
        /// <summary>
        ///  ID of the primary table associated with this form.
        /// </summary>
        public int TableId { get; set; }

        /// <summary>
        ///  the ID of the client to whom this form belongs.
        /// </summary>
        public int ClientId { get; set; }

        /// <summary>
        ///  the ID of the project under which this form is created.
        /// </summary>
        public int ProjectId { get; set; }

        /// <summary>
        ///  the ID of the detail (child) table, if any, associated with the form.
        /// </summary>
        public int? DetailTableId { get; set; }

        /// <summary>
        ///  name of the main table associated with this form. 
        /// </summary>
        public string? TableName { get; set; }

        /// <summary>
        ///  name of the company associated with the client or project. 
        /// </summary>
        public string? CompanyName { get; set; }

        /// <summary>
        ///  This the SaveReuse button. 
        /// </summary>
        public bool? SaveReuse { get; set; }

        /// <summary>
        ///  This the SaveContinue button. 
        /// </summary>
        public bool? SaveContinue { get; set; }

        public bool IsDocumentEnabled { get; set; }
        /// <summary>
        ///  This for AddtoList button. 
        /// </summary>
        public bool? IsAddToList { get; set; }
        /// <summary>
        ///  This for BarcodePrinting button. 
        /// </summary>
        public bool? IsBarcodePrinting { get; set; }

        /// <summary>
        ///  the name of the project. 
        /// </summary>
        public string? ProjectName { get; set; }
        public string? HeaderFormName { get; set; }
        public string? DetailFormName { get; set; }

        public int? HeaderFormId { get; set; }
        public int? RuleFormId { get; set; }
        public int? RuleTableId { get; set; }
        public int? DetailFormId { get; set; }
        public int? ListProfileId { get; set; }

        public List<string> ParentFormNames { get; set; } = [];
        public List<int> ParentFormIds { get; set; } = [];
        public string? ParentFormName { get; set; } // Optional: if you still want a single name
        public int? ParentId { get; set; } // Temp field for Dapper mapping
        public int? ParentFormId { get; set; }  // nullable int to hold each row's child form ID from SQL      

        public int? CardViewProfileId { get; set; }

        public string? ListViewProfileName { get; set; }

        public string? CardViewProfileName { get; set; }
        public object? FieldList { get; set; }
        //public string? ParentFormName { get; set; }
        public string? ParentTableName { get; set; }
        public string? KeyTypeName { get; set; }
        public bool IsMenuValid { get; set; }
    }

    public class FormActionModel
    {
        /// <summary>
        ///  sets the ID of the form for which the action is defined.
        /// </summary>
        public int FormId { get; set; }
        /// <summary>
        /// sets the SQL or command query associated with the form's action.
        /// </summary>
        public string? FormActionQuery { get; set; }

    }
   
}
