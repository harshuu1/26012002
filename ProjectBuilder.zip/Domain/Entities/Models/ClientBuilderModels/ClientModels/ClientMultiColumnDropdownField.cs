﻿namespace Entities.Models.ClientBuilderModels.ClientModels
{
    public class ClientMultiColumnDropdownField: CommonField
    {
        public bool IsUsedAsSource { get; set; }
        public int FieldDefinitionId { get; set; }
        //public int SourceFieldId { get; set; }
        public List<int> SourceFieldIds { get; set; } = [];

        // public List<int>? SourceFieldIds { get; set; }

        // public required List<int> SourceFieldIds { get; set; } 

        public int? SourceFieldId { get; set; }

        public string? SourceFieldName { get; set; }

        public string? SourceDisplayFieldName { get; set; }
        //public List<int> MultiColumnIds { get; set; } // This will hold the selected IDs
    }
}
