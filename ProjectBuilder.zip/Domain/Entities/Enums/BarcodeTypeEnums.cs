﻿using System;

namespace Entities.Enums
{
    public enum BarcodeTypeEnums
    {
        Code11,
        Code39,
        Code93,
        Code128,
        Code39Extended,
        QrCode
        //not support type
        // Ean8,
        // Ean13,
        // Itf,
        // Msi,
        // Pdf417,

    }
}
