﻿using System;

namespace Entities.Enums
{
    public enum DatabaseSchema
    {
        Config
    }

    public static class SchemaTypeExtensions
    {
        public static string ToSchemaName(this DatabaseSchema schemaType)
        {
            return schemaType switch
            {
                DatabaseSchema.Config => "config",
                _ => throw new ArgumentOutOfRangeException(nameof(schemaType), schemaType, null)
            };
        }
    }
}