﻿namespace Entities.Enums
{
    /// <summary>
    /// Represents different types of fields that can be used in a form or data structure.
    /// </summary>
    public enum FieldTypeEnums
    {
        ///// <summary>
        ///// Represents a CAPTCHA field used for user verification to prevent automated submissions.
        ///// </summary>
        //captcha = 1,

        ///// <summary>
        ///// Represents a color picker field for selecting colors.
        ///// </summary>
        //colorpicker = 2,

        ///// <summary>
        ///// Represents a hyperlink field for storing or displaying URLs.
        ///// </summary>
        //hyperlink = 3,

        ///// <summary>
        ///// Represents an image field for storing or displaying image data.
        ///// </summary>
        //image = 4,

        ///// <summary>
        ///// Represents a rich text editor field for formatted text input.
        ///// </summary>
        //richtexteditor = 5,

        ///// <summary>
        ///// Represents a signature field for capturing digital signatures.
        ///// </summary>
        //signature = 6,

        ///// <summary>
        ///// Represents a varbinary field for storing binary data.
        ///// </summary>
        //varbinary = 7,
        Bigint = 1,
        Bit = 2,
        Datetime = 3,
        Decimal = 4,
        Float = 5,
        Numeric = 6,
        Varchar = 7,
        Nvarchar = 8,
        Int = 9,
        Varbinary = 10,
        Money = 11,
        Smallint = 12,
        DropDown = 13,
        Checkboxgroup = 14,
        Radiogroup = 15,
        Date = 16,
        Switches = 17,
        Rangeslider = 18,
        Rating = 19,
        Colorpicker = 20,
        Hyperlink = 21,
        Richtexteditor = 22,
        Timeduration = 23,
        Slider = 24,
        Image = 25,
        Tinyint = 26,
        Signature = 27,
        Captcha = 28,
        Multiselect = 29,
        ImageUpload = 30,
        Unknown = 30,
        Barcode=32

    }
}