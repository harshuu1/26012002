﻿namespace Entities.Enums
{
    public enum PKTypeEnum
    {
        BigInt,
        SmallInt,
        TinyInt,
        UniqueIdentifier,
        Int
    }

    public static class EnumExtensions
    {
        private static readonly Dictionary<PKTypeEnum, string> TypeMappings = new Dictionary<PKTypeEnum, string>
        {
            { PKTypeEnum.BigInt, "Int64" },
            { PKTypeEnum.SmallInt, "Int16" },
            { PKTypeEnum.TinyInt, "byte" },
            { PKTypeEnum.UniqueIdentifier, "Guid" },
            { PKTypeEnum.Int, "Int32" }
        };

        public static string GetDescription(this PKTypeEnum value)
        {
            return TypeMappings.TryGetValue(value, out var description) ? description : value.ToString();
        }
    }

    public static class ResponseClassEnumExtensions
    {
        public static string GetResponseDescription(this PKTypeEnum value, bool asCreationResponse = false)
        {
            var desc = value.GetDescription();
            return asCreationResponse ? $"CreationResponseModel<{desc}>" : "CreationResponseModel";
        }
    }
}