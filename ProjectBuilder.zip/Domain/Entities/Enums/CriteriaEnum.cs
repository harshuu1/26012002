﻿namespace Entities.Enums
{
    public enum CriteriaEnum
    {
        All = 1,
        Any
    }
}