﻿using Entities.Models.AppUser;
using Entities.Models.Request;

namespace Interfaces
{
    public interface IAppUser
    {
        Task<IEnumerable<AppUserModel>> GetAllAppUser();
        Task<string> CreateAppUser(AppUserModel appUser);
        Task<string> UpdateAppUser(AppUserModel appUser, bool statusOnly = false);
        Task<string> DeleteAppUser(int id);
        Task<IEnumerable<AppUserModel>> GetAppUser(Request request);
        Task<AppUserModel> GetAppUserById(int id);
        Task<AppUserModel?> GetUserByEmail(string email);
        Task<AuthUserModel> AuthenticateUser(string email, string password);
    }
}
