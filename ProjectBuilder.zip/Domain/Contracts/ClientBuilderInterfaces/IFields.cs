﻿using Entities.Models.ClientBuilderModels.ClientModels;

namespace Interfaces.ClientBuilderInterfaces
{
    public interface IFields
    {
        Task<List<ClientDisplayField>> GetDisplayFieldByParentId(int formId, string oldConnectionString);
        Task<List<ClientCardViewFields>> GetCardViewByCardViewProfileId(ClientCardViewFields addEditField, string oldConnectionString);
        Task<List<ClientDisplayField>> GetDisplayFieldBylistProfileId(ClientDisplayField displayField, string oldConnectionString);
        //Task<List<ClientSearchField>> GetSearchFields(ClientSearchField searchField, string oldConnectionString);
        //Task<List<ClientSearchField>> GetSearchFieldsByParentId(int parentId, string oldConnectionString);
        Task<List<ClientSearchField>> GetDetailSearchByParentId(int FormId, string oldConnectionString);
        Task<List<ClientSearchField>> GetSearchFieldsHierarchy(int formId, string oldConnectionString);
        //Task<List<ClientSearchField>> GetChildSearchFields(int parentFormId, string oldConnectionString);
    }
}
