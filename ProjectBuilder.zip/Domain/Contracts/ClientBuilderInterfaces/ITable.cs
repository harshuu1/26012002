﻿using Entities.Models.ClientBuilderModels.ClientModels;

namespace Interfaces.ClientBuilderInterfaces
{
    public interface ITable
    {
        Task<IEnumerable<ClientTable>> GetTableById(int clientId, int projectId);
        Task<string?> GetClientName(int clientId);
        Task<string> GetProjectName(int clientId, int projectId);
        Task<string> GetProjectLogo(int projectId, string originalConnectionString);
        Task<List<ClientActionDetail>> GetFormUpdateQueries(int TableId, string oldConnectionString);
        Task<IEnumerable<ClientFieldDefinition>> GetFieldNamesByTableId(int tableId, string originalConnectionString);
        Task<List<ClientCardViewFields>> GetRuleCriteriaList(int tableId, string oldConnectionString);
        Task<IEnumerable<ClientMenu>> GetMenuIcon(int MenuID, string oldConnectionString);
        Task<IEnumerable<ClientForm>> GetFormByTableId(int clientId, int projectId, string oldConnectionString);
        Task<IEnumerable<ClientForm>> GetFormListByTableId(int clientId, int projectId, int tableId, string oldConnectionString);
        Task<int?> GetAlignmentTypeById(int id);
        Task<IEnumerable<ClientForm>> GetDocumentEnabledForms(int projectId, string oldConnectionString);
        Task<IEnumerable<ClientForm>> GetAddToListEnabledForms(int projectId, string oldConnectionString);
    }
}
