﻿using Entities.Models.Client;
using Entities.Models.Request;
using Entities.Models.Response;

namespace Interfaces
{
    public interface IClient
    {
        public Task<IEnumerable<ClientModel>> GetAllClient();
        public Task<Response> GetAll(Request request);
        Task<ClientModel> GetById(int Id);
        Task<(string message, int clientId)> Create(ClientModel client);
        Task<string> Update(ClientModel client);
        Task<string?> GetClientName(int clientId);
        Task<IEnumerable<ClientModel>> GetClient();
        Task<string> Delete(int Id);
    }
}
