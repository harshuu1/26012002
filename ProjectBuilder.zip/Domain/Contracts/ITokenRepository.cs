﻿namespace Interfaces
{
    public interface ITokenRepository
    {
        Task<bool> IsValidTokenAsync(string token);
    }
}
