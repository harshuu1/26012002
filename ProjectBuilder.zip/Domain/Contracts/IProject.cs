﻿using Entities.Models.Menu;
using Entities.Models.Project;
using Entities.Models.Request;
using Entities.Models.Response;
using System.Data;

namespace Interfaces
{
    public interface IProject
    {
        object Project { get; }
        Task<string> CreateProject(ProjectModel project, IDbConnection connection, IDbTransaction transaction, string webRootPath);
        Task<string> UpdateProject(ProjectModel project, string webRootPath);
        Task<Response> GetAllProject(Request request);
        public Task<Response> GetAllProjectByClientId(int ClientId, Request request);
        Task<ProjectModel> GetProjectById(int id);
        Task<string> DeleteProject(int id);
        Task<int?> GetAlignmentTypeById(int id);
        Task<IEnumerable<ProjectModel>> GetAllProjectFromClient(int id);
        Task<IEnumerable<ProjectModel>> GetTableById(int Id);
        Task<string> GetProjectName(int clientId, int projectId);
        //Task<IEnumerable<Menu>> GetMenuIcon(int MenuID, string oldConnectionString);
        Task<string> GetProjectLogo(int projectId, string originalConnectionString);
        Task<IEnumerable<MenuModel>> GetMenuIcon(int MenuID, string oldConnectionString);
        public Task<List<Dictionary<string, object>>> CheckProjectUsageAsync(int projectId);
        Task<bool> DeleteProjectAsync(int projectId, bool deleteConfigDatabase = false,bool deleteConfigProject = false, bool deleteClientDatabase = false,
            bool deleteClientProject = false);
    }
}
